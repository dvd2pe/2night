{
    "stage_message_limit": 2,
    "site_id": 35243,
    "public_campaign_type_priority": [1, 6],
    "multi_campaign_enabled": true,
    "stage_campaign_type_priority": [],
    "public_message_limit": 2
}
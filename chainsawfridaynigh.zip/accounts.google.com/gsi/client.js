"use strict";
this.default_gsi = this.default_gsi || {};
(function(_) {
    var window = this;
    try {
        _._F_toggles_initialize = function(a) {
            (typeof globalThis !== "undefined" ? globalThis : typeof self !== "undefined" ? self : this)._F_toggles_default_gsi = a || []
        };
        (0, _._F_toggles_initialize)([0x0, 0x6408200, 0x5174, ]);
        var ca, da, t, fa, ma, na;
        _.aa = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        };
        ca = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        };
        da = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("a");
        };
        _.ea = da(this);
        t = function(a, b) {
            if (b) a: {
                var c = _.ea;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && ca(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        };
        if (typeof Object.setPrototypeOf == "function") fa = Object.setPrototypeOf;
        else {
            var ha;
            a: {
                var ja = {
                        a: !0
                    },
                    ka = {};
                try {
                    ka.__proto__ = ja;
                    ha = ka.a;
                    break a
                } catch (a) {}
                ha = !1
            }
            fa = ha ? function(a, b) {
                a.__proto__ = b;
                if (a.__proto__ !== b) throw new TypeError("b`" + a);
                return a
            } : null
        }
        _.la = fa;
        ma = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        };
        _.v = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: ma(a)
            };
            throw Error("c`" + String(a));
        };
        na = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        };
        _.oa = typeof Object.assign == "function" ? Object.assign : function(a, b) {
            if (a == null) throw new TypeError("d");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) na(d, e) && (a[e] = d[e])
            }
            return a
        };
        _.pa = function(a) {
            if (!(a instanceof Object)) throw new TypeError("e`" + a);
        };
        _.w = function() {
            this.G = !1;
            this.v = null;
            this.j = void 0;
            this.h = 1;
            this.A = this.C = 0;
            this.M = this.l = null
        };
        _.w.prototype.K = function(a) {
            this.j = a
        };
        _.w.prototype.getNextAddressJsc = function() {
            return this.h
        };
        _.w.prototype.getYieldResultJsc = function() {
            return this.j
        };
        _.w.prototype.return = function(a) {
            this.l = {
                return: a
            };
            this.h = this.A
        };
        _.w.prototype["return"] = _.w.prototype.return;
        _.w.prototype.T = function(a) {
            this.l = {
                Y: a
            };
            this.A < a ? (this.h = a, this.l = null) : this.h = this.A
        };
        _.w.prototype.jumpThroughFinallyBlocks = _.w.prototype.T;
        _.w.prototype.i = function(a, b) {
            this.h = b;
            return {
                value: a
            }
        };
        _.w.prototype.yield = _.w.prototype.i;
        _.w.prototype.X = function(a, b) {
            a = _.v(a);
            var c = a.next();
            _.pa(c);
            if (c.done) this.j = c.value, this.h = b;
            else return this.v = a, this.i(c.value, b)
        };
        _.w.prototype.yieldAll = _.w.prototype.X;
        _.w.prototype.Y = function(a) {
            this.h = a
        };
        _.w.prototype.jumpTo = _.w.prototype.Y;
        _.w.prototype.L = function() {
            this.h = 0
        };
        _.w.prototype.jumpToEnd = _.w.prototype.L;
        _.w.prototype.u = function(a, b) {
            this.C = a;
            b != void 0 && (this.A = b)
        };
        _.w.prototype.setCatchFinallyBlocks = _.w.prototype.u;
        _.w.prototype.P = function(a) {
            this.C = 0;
            this.A = a || 0
        };
        _.w.prototype.setFinallyBlock = _.w.prototype.P;
        _.w.prototype.H = function(a, b) {
            this.h = a;
            this.C = b || 0
        };
        _.w.prototype.leaveTryBlock = _.w.prototype.H;
        _.w.prototype.m = function(a) {
            this.C = a || 0;
            a = this.l.Ec;
            this.l = null;
            return a
        };
        _.w.prototype.enterCatchBlock = _.w.prototype.m;
        _.w.prototype.D = function(a, b, c) {
            c ? this.M[c] = this.l : this.M = [this.l];
            this.C = a || 0;
            this.A = b || 0;
            this.l = null
        };
        _.w.prototype.enterFinallyBlock = _.w.prototype.D;
        _.w.prototype.F = function(a, b) {
            b = this.M.splice(b || 0)[0];
            (b = this.l = this.l || b) ? b.Oc ? this.h = this.C || this.A : b.Y != void 0 && this.A < b.Y ? (this.h = b.Y, this.l = null) : this.h = this.A: this.h = a
        };
        _.w.prototype.leaveFinallyBlock = _.w.prototype.F;
        _.w.prototype.U = function(a) {
            return new qa(a)
        };
        _.w.prototype.forIn = _.w.prototype.U;
        var qa = function(a) {
            this.j = a;
            this.h = [];
            for (var b in a) this.h.push(b);
            this.h.reverse()
        };
        qa.prototype.i = function() {
            for (; this.h.length > 0;) {
                var a = this.h.pop();
                if (a in this.j) return a
            }
            return null
        };
        qa.prototype.getNext = qa.prototype.i;
        t("globalThis", function(a) {
            return a || _.ea
        });
        t("Reflect.setPrototypeOf", function(a) {
            return a ? a : _.la ? function(b, c) {
                try {
                    return (0, _.la)(b, c), !0
                } catch (d) {
                    return !1
                }
            } : null
        });
        t("Symbol", function(a) {
            if (a) return a;
            var b = function(f, g) {
                this.h = f;
                ca(this, "description", {
                    configurable: !0,
                    writable: !0,
                    value: g
                })
            };
            b.prototype.toString = function() {
                return this.h
            };
            var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
                d = 0,
                e = function(f) {
                    if (this instanceof e) throw new TypeError("h");
                    return new b(c + (f || "") + "_" + d++, f)
                };
            return e
        });
        t("Symbol.iterator", function(a) {
            if (a) return a;
            a = Symbol("i");
            ca(Array.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return ra(ma(this))
                }
            });
            return a
        });
        var ra = function(a) {
            var b = (typeof Iterator != "undefined" && Iterator.prototype && !Iterator.prototype.next ? Iterator.prototype : null) || Object.prototype,
                c = (0, _.aa)(b);
            c.next = a;
            b[Symbol.iterator] || (c[Symbol.iterator] = function() {
                return this
            });
            return c
        };
        t("Promise", function(a) {
            function b() {
                this.h = null
            }

            function c(g) {
                return g instanceof e ? g : new e(function(h) {
                    h(g)
                })
            }
            if (a) return a;
            b.prototype.i = function(g) {
                if (this.h == null) {
                    this.h = [];
                    var h = this;
                    this.j(function() {
                        h.m()
                    })
                }
                this.h.push(g)
            };
            var d = _.ea.setTimeout;
            b.prototype.j = function(g) {
                d(g, 0)
            };
            b.prototype.m = function() {
                for (; this.h && this.h.length;) {
                    var g = this.h;
                    this.h = [];
                    for (var h = 0; h < g.length; ++h) {
                        var k = g[h];
                        g[h] = null;
                        try {
                            k()
                        } catch (l) {
                            this.l(l)
                        }
                    }
                }
                this.h = null
            };
            b.prototype.l = function(g) {
                this.j(function() {
                    throw g;
                })
            };
            var e = function(g) {
                this.h = 0;
                this.j = void 0;
                this.i = [];
                this.v = !1;
                var h = this.l();
                try {
                    g(h.resolve, h.reject)
                } catch (k) {
                    h.reject(k)
                }
            };
            e.prototype.l = function() {
                function g(l) {
                    return function(n) {
                        k || (k = !0, l.call(h, n))
                    }
                }
                var h = this,
                    k = !1;
                return {
                    resolve: g(this.H),
                    reject: g(this.m)
                }
            };
            e.prototype.H = function(g) {
                if (g === this) this.m(new TypeError("j"));
                else if (g instanceof e) this.L(g);
                else {
                    a: switch (typeof g) {
                        case "object":
                            var h = g != null;
                            break a;
                        case "function":
                            h = !0;
                            break a;
                        default:
                            h = !1
                    }
                    h ? this.F(g) : this.u(g)
                }
            };
            e.prototype.F =
                function(g) {
                    var h = void 0;
                    try {
                        h = g.then
                    } catch (k) {
                        this.m(k);
                        return
                    }
                    typeof h == "function" ? this.P(h, g) : this.u(g)
                };
            e.prototype.m = function(g) {
                this.A(2, g)
            };
            e.prototype.u = function(g) {
                this.A(1, g)
            };
            e.prototype.A = function(g, h) {
                if (this.h != 0) throw Error("k`" + g + "`" + h + "`" + this.h);
                this.h = g;
                this.j = h;
                this.h === 2 && this.G();
                this.C()
            };
            e.prototype.G = function() {
                var g = this;
                d(function() {
                    if (g.D()) {
                        var h = _.ea.console;
                        typeof h !== "undefined" && h.error(g.j)
                    }
                }, 1)
            };
            e.prototype.D = function() {
                if (this.v) return !1;
                var g = _.ea.CustomEvent,
                    h = _.ea.Event,
                    k = _.ea.dispatchEvent;
                if (typeof k === "undefined") return !0;
                typeof g === "function" ? g = new g("unhandledrejection", {
                    cancelable: !0
                }) : typeof h === "function" ? g = new h("unhandledrejection", {
                    cancelable: !0
                }) : (g = _.ea.document.createEvent("CustomEvent"), g.initCustomEvent("unhandledrejection", !1, !0, g));
                g.promise = this;
                g.reason = this.j;
                return k(g)
            };
            e.prototype.C = function() {
                if (this.i != null) {
                    for (var g = 0; g < this.i.length; ++g) f.i(this.i[g]);
                    this.i = null
                }
            };
            var f = new b;
            e.prototype.L = function(g) {
                var h = this.l();
                g.sb(h.resolve,
                    h.reject)
            };
            e.prototype.P = function(g, h) {
                var k = this.l();
                try {
                    g.call(h, k.resolve, k.reject)
                } catch (l) {
                    k.reject(l)
                }
            };
            e.prototype.then = function(g, h) {
                function k(q, r) {
                    return typeof q == "function" ? function(y) {
                        try {
                            l(q(y))
                        } catch (u) {
                            n(u)
                        }
                    } : r
                }
                var l, n, p = new e(function(q, r) {
                    l = q;
                    n = r
                });
                this.sb(k(g, l), k(h, n));
                return p
            };
            e.prototype.catch = function(g) {
                return this.then(void 0, g)
            };
            e.prototype.sb = function(g, h) {
                function k() {
                    switch (l.h) {
                        case 1:
                            g(l.j);
                            break;
                        case 2:
                            h(l.j);
                            break;
                        default:
                            throw Error("l`" + l.h);
                    }
                }
                var l = this;
                this.i ==
                    null ? f.i(k) : this.i.push(k);
                this.v = !0
            };
            e.resolve = c;
            e.reject = function(g) {
                return new e(function(h, k) {
                    k(g)
                })
            };
            e.race = function(g) {
                return new e(function(h, k) {
                    for (var l = _.v(g), n = l.next(); !n.done; n = l.next()) c(n.value).sb(h, k)
                })
            };
            e.all = function(g) {
                var h = _.v(g),
                    k = h.next();
                return k.done ? c([]) : new e(function(l, n) {
                    function p(y) {
                        return function(u) {
                            q[y] = u;
                            r--;
                            r == 0 && l(q)
                        }
                    }
                    var q = [],
                        r = 0;
                    do q.push(void 0), r++, c(k.value).sb(p(q.length - 1), n), k = h.next(); while (!k.done)
                })
            };
            return e
        });
        var sa = function(a, b, c) {
            if (a == null) throw new TypeError("m`" + c);
            if (b instanceof RegExp) throw new TypeError("n`" + c);
            return a + ""
        };
        t("String.prototype.startsWith", function(a) {
            return a ? a : function(b, c) {
                var d = sa(this, b, "startsWith"),
                    e = d.length,
                    f = b.length;
                c = Math.max(0, Math.min(c | 0, d.length));
                for (var g = 0; g < f && c < e;)
                    if (d[c++] != b[g++]) return !1;
                return g >= f
            }
        });
        t("Object.setPrototypeOf", function(a) {
            return a || _.la
        });
        t("Object.assign", function(a) {
            return a || _.oa
        });
        t("Symbol.dispose", function(a) {
            return a ? a : Symbol("o")
        });
        t("Array.prototype.find", function(a) {
            return a ? a : function(b, c) {
                a: {
                    var d = this;d instanceof String && (d = String(d));
                    for (var e = d.length, f = 0; f < e; f++) {
                        var g = d[f];
                        if (b.call(c, g, f, d)) {
                            b = g;
                            break a
                        }
                    }
                    b = void 0
                }
                return b
            }
        });
        t("WeakMap", function(a) {
            function b() {}

            function c(k) {
                var l = typeof k;
                return l === "object" && k !== null || l === "function"
            }

            function d(k) {
                if (!na(k, f)) {
                    var l = new b;
                    ca(k, f, {
                        value: l
                    })
                }
            }

            function e(k) {
                var l = Object[k];
                l && (Object[k] = function(n) {
                    if (n instanceof b) return n;
                    Object.isExtensible(n) && d(n);
                    return l(n)
                })
            }
            if (function() {
                    if (!a || !Object.seal) return !1;
                    try {
                        var k = Object.seal({}),
                            l = Object.seal({}),
                            n = new a([
                                [k, 2],
                                [l, 3]
                            ]);
                        if (n.get(k) != 2 || n.get(l) != 3) return !1;
                        n.delete(k);
                        n.set(l, 4);
                        return !n.has(k) && n.get(l) == 4
                    } catch (p) {
                        return !1
                    }
                }()) return a;
            var f = "$jscomp_hidden_" + Math.random();
            e("freeze");
            e("preventExtensions");
            e("seal");
            var g = 0,
                h = function(k) {
                    this.h = (g += Math.random() + 1).toString();
                    if (k) {
                        k = _.v(k);
                        for (var l; !(l = k.next()).done;) l = l.value, this.set(l[0], l[1])
                    }
                };
            h.prototype.set = function(k, l) {
                if (!c(k)) throw Error("p");
                d(k);
                if (!na(k, f)) throw Error("q`" + k);
                k[f][this.h] = l;
                return this
            };
            h.prototype.get = function(k) {
                return c(k) && na(k, f) ? k[f][this.h] : void 0
            };
            h.prototype.has = function(k) {
                return c(k) && na(k, f) && na(k[f], this.h)
            };
            h.prototype.delete = function(k) {
                return c(k) &&
                    na(k, f) && na(k[f], this.h) ? delete k[f][this.h] : !1
            };
            return h
        });
        t("Map", function(a) {
            if (function() {
                    if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                    try {
                        var h = Object.seal({
                                x: 4
                            }),
                            k = new a(_.v([
                                [h, "s"]
                            ]));
                        if (k.get(h) != "s" || k.size != 1 || k.get({
                                x: 4
                            }) || k.set({
                                x: 4
                            }, "t") != k || k.size != 2) return !1;
                        var l = k.entries(),
                            n = l.next();
                        if (n.done || n.value[0] != h || n.value[1] != "s") return !1;
                        n = l.next();
                        return !(n.done || n.value[0].x != 4 || n.value[1] != "t" || !l.next().done)
                    } catch (p) {
                        return !1
                    }
                }()) return a;
            var b = new WeakMap,
                c = function(h) {
                    this[0] = {};
                    this[1] = f();
                    this.size = 0;
                    if (h) {
                        h = _.v(h);
                        for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                    }
                };
            c.prototype.set = function(h, k) {
                h = h === 0 ? 0 : h;
                var l = d(this, h);
                l.list || (l.list = this[0][l.id] = []);
                l.entry ? l.entry.value = k : (l.entry = {
                    next: this[1],
                    qa: this[1].qa,
                    head: this[1],
                    key: h,
                    value: k
                }, l.list.push(l.entry), this[1].qa.next = l.entry, this[1].qa = l.entry, this.size++);
                return this
            };
            c.prototype.delete = function(h) {
                h = d(this, h);
                return h.entry && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.entry.qa.next =
                    h.entry.next, h.entry.next.qa = h.entry.qa, h.entry.head = null, this.size--, !0) : !1
            };
            c.prototype.clear = function() {
                this[0] = {};
                this[1] = this[1].qa = f();
                this.size = 0
            };
            c.prototype.has = function(h) {
                return !!d(this, h).entry
            };
            c.prototype.get = function(h) {
                return (h = d(this, h).entry) && h.value
            };
            c.prototype.entries = function() {
                return e(this, function(h) {
                    return [h.key, h.value]
                })
            };
            c.prototype.keys = function() {
                return e(this, function(h) {
                    return h.key
                })
            };
            c.prototype.values = function() {
                return e(this, function(h) {
                    return h.value
                })
            };
            c.prototype.forEach =
                function(h, k) {
                    for (var l = this.entries(), n; !(n = l.next()).done;) n = n.value, h.call(k, n[1], n[0], this)
                };
            c.prototype[Symbol.iterator] = c.prototype.entries;
            var d = function(h, k) {
                    var l = k && typeof k;
                    l == "object" || l == "function" ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                    var n = h[0][l];
                    if (n && na(h[0], l))
                        for (h = 0; h < n.length; h++) {
                            var p = n[h];
                            if (k !== k && p.key !== p.key || k === p.key) return {
                                id: l,
                                list: n,
                                index: h,
                                entry: p
                            }
                        }
                    return {
                        id: l,
                        list: n,
                        index: -1,
                        entry: void 0
                    }
                },
                e = function(h, k) {
                    var l = h[1];
                    return ra(function() {
                        if (l) {
                            for (; l.head !=
                                h[1];) l = l.qa;
                            for (; l.next != l.head;) return l = l.next, {
                                done: !1,
                                value: k(l)
                            };
                            l = null
                        }
                        return {
                            done: !0,
                            value: void 0
                        }
                    })
                },
                f = function() {
                    var h = {};
                    return h.qa = h.next = h.head = h
                },
                g = 0;
            return c
        });
        t("Set", function(a) {
            if (function() {
                    if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                    try {
                        var c = Object.seal({
                                x: 4
                            }),
                            d = new a(_.v([c]));
                        if (!d.has(c) || d.size != 1 || d.add(c) != d || d.size != 1 || d.add({
                                x: 4
                            }) != d || d.size != 2) return !1;
                        var e = d.entries(),
                            f = e.next();
                        if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                        f = e.next();
                        return f.done || f.value[0] == c || f.value[0].x != 4 || f.value[1] != f.value[0] ? !1 : e.next().done
                    } catch (g) {
                        return !1
                    }
                }()) return a;
            var b = function(c) {
                this.h = new Map;
                if (c) {
                    c =
                        _.v(c);
                    for (var d; !(d = c.next()).done;) this.add(d.value)
                }
                this.size = this.h.size
            };
            b.prototype.add = function(c) {
                c = c === 0 ? 0 : c;
                this.h.set(c, c);
                this.size = this.h.size;
                return this
            };
            b.prototype.delete = function(c) {
                c = this.h.delete(c);
                this.size = this.h.size;
                return c
            };
            b.prototype.clear = function() {
                this.h.clear();
                this.size = 0
            };
            b.prototype.has = function(c) {
                return this.h.has(c)
            };
            b.prototype.entries = function() {
                return this.h.entries()
            };
            b.prototype.values = function() {
                return this.h.values()
            };
            b.prototype.keys = b.prototype.values;
            b.prototype[Symbol.iterator] = b.prototype.values;
            b.prototype.forEach = function(c, d) {
                var e = this;
                this.h.forEach(function(f) {
                    return c.call(d, f, f, e)
                })
            };
            return b
        });
        t("Object.values", function(a) {
            return a ? a : function(b) {
                var c = [],
                    d;
                for (d in b) na(b, d) && c.push(b[d]);
                return c
            }
        });
        t("Object.is", function(a) {
            return a ? a : function(b, c) {
                return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
            }
        });
        t("Array.prototype.includes", function(a) {
            return a ? a : function(b, c) {
                var d = this;
                d instanceof String && (d = String(d));
                var e = d.length;
                c = c || 0;
                for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                    var f = d[c];
                    if (f === b || Object.is(f, b)) return !0
                }
                return !1
            }
        });
        t("String.prototype.includes", function(a) {
            return a ? a : function(b, c) {
                return sa(this, b, "includes").indexOf(b, c || 0) !== -1
            }
        });
        t("Array.from", function(a) {
            return a ? a : function(b, c, d) {
                c = c != null ? c : function(h) {
                    return h
                };
                var e = [],
                    f = typeof Symbol != "undefined" && Symbol.iterator && b[Symbol.iterator];
                if (typeof f == "function") {
                    b = f.call(b);
                    for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
                } else
                    for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
                return e
            }
        });
        t("Object.entries", function(a) {
            return a ? a : function(b) {
                var c = [],
                    d;
                for (d in b) na(b, d) && c.push([d, b[d]]);
                return c
            }
        });
        t("Number.isFinite", function(a) {
            return a ? a : function(b) {
                return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
            }
        });
        t("Number.MAX_SAFE_INTEGER", function() {
            return 9007199254740991
        });
        t("Number.MIN_SAFE_INTEGER", function() {
            return -9007199254740991
        });
        t("Number.isInteger", function(a) {
            return a ? a : function(b) {
                return Number.isFinite(b) ? b === Math.floor(b) : !1
            }
        });
        t("Number.isSafeInteger", function(a) {
            return a ? a : function(b) {
                return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER
            }
        });
        t("String.prototype.endsWith", function(a) {
            return a ? a : function(b, c) {
                var d = sa(this, b, "endsWith");
                c === void 0 && (c = d.length);
                c = Math.max(0, Math.min(c | 0, d.length));
                for (var e = b.length; e > 0 && c > 0;)
                    if (d[--c] != b[--e]) return !1;
                return e <= 0
            }
        });
        var ta = function(a, b) {
            a instanceof String && (a += "");
            var c = 0,
                d = !1;
            return ra(function() {
                if (!d && c < a.length) {
                    var e = c++;
                    return {
                        value: b(e, a[e]),
                        done: !1
                    }
                }
                d = !0;
                return {
                    done: !0,
                    value: void 0
                }
            })
        };
        t("Array.prototype.entries", function(a) {
            return a ? a : function() {
                return ta(this, function(b, c) {
                    return [b, c]
                })
            }
        });
        t("Math.trunc", function(a) {
            return a ? a : function(b) {
                b = Number(b);
                if (isNaN(b) || b === Infinity || b === -Infinity || b === 0) return b;
                var c = Math.floor(Math.abs(b));
                return b < 0 ? -c : c
            }
        });
        t("Number.isNaN", function(a) {
            return a ? a : function(b) {
                return typeof b === "number" && isNaN(b)
            }
        });
        t("Array.prototype.keys", function(a) {
            return a ? a : function() {
                return ta(this, function(b) {
                    return b
                })
            }
        });
        t("Array.prototype.values", function(a) {
            return a ? a : function() {
                return ta(this, function(b, c) {
                    return c
                })
            }
        });
        t("String.prototype.codePointAt", function(a) {
            return a ? a : function(b) {
                var c = sa(this, null, "codePointAt"),
                    d = c.length;
                b = Number(b) || 0;
                if (b >= 0 && b < d) {
                    b |= 0;
                    var e = c.charCodeAt(b);
                    if (e < 55296 || e > 56319 || b + 1 === d) return e;
                    b = c.charCodeAt(b + 1);
                    return b < 56320 || b > 57343 ? e : (e - 55296) * 1024 + b + 9216
                }
            }
        });
        t("String.fromCodePoint", function(a) {
            return a ? a : function(b) {
                for (var c = "", d = 0; d < arguments.length; d++) {
                    var e = Number(arguments[d]);
                    if (e < 0 || e > 1114111 || e !== Math.floor(e)) throw new RangeError("r`" + e);
                    e <= 65535 ? c += String.fromCharCode(e) : (e -= 65536, c += String.fromCharCode(e >>> 10 & 1023 | 55296), c += String.fromCharCode(e & 1023 | 56320))
                }
                return c
            }
        });
        t("Promise.prototype.finally", function(a) {
            return a ? a : function(b) {
                return this.then(function(c) {
                    return Promise.resolve(b()).then(function() {
                        return c
                    })
                }, function(c) {
                    return Promise.resolve(b()).then(function() {
                        throw c;
                    })
                })
            }
        });
    } catch (e) {
        _._DumpException(e)
    }
    try {
        /*

         Copyright The Closure Library Authors.
         SPDX-License-Identifier: Apache-2.0
        */
        _.ua = _.ua || {};
        _.x = this || self;
        _.va = _.x._F_toggles_default_gsi || [];
    } catch (e) {
        _._DumpException(e)
    }
    try {
        /*

         Copyright Google LLC
         SPDX-License-Identifier: Apache-2.0
        */
        var Ia, La, Oa, Xa, Ta, $a, qb, wb, Gb, Lb, Ob, Qb, Vb, Wb, Zb, dc, lc, oc, sc, pc, Hc, Ic, Mc, Uc, Wc, Zc, id, kd, ld, Dd, Ed, Gd, Jd, Hd, Id, Kd, Ld, Od;
        _.za = function(a) {
            var b = !1;
            b = b === void 0 ? !1 : b;
            if (wa) {
                if (b && (xa ? !a.isWellFormed() : /(?:[^\uD800-\uDBFF]|^)[\uDC00-\uDFFF]|[\uD800-\uDBFF](?![\uDC00-\uDFFF])/.test(a))) throw Error("t");
                a = (ya || (ya = new TextEncoder)).encode(a)
            } else {
                for (var c = 0, d = new Uint8Array(3 * a.length), e = 0; e < a.length; e++) {
                    var f = a.charCodeAt(e);
                    if (f < 128) d[c++] = f;
                    else {
                        if (f < 2048) d[c++] = f >> 6 | 192;
                        else {
                            if (f >= 55296 && f <= 57343) {
                                if (f <= 56319 && e < a.length) {
                                    var g = a.charCodeAt(++e);
                                    if (g >= 56320 && g <= 57343) {
                                        f = (f - 55296) * 1024 + g - 56320 + 65536;
                                        d[c++] = f >> 18 | 240;
                                        d[c++] = f >> 12 & 63 | 128;
                                        d[c++] = f >> 6 & 63 | 128;
                                        d[c++] = f & 63 | 128;
                                        continue
                                    } else e--
                                }
                                if (b) throw Error("t");
                                f = 65533
                            }
                            d[c++] = f >> 12 | 224;
                            d[c++] = f >> 6 & 63 | 128
                        }
                        d[c++] = f & 63 | 128
                    }
                }
                a = c === d.length ? d : d.subarray(0, c)
            }
            return a
        };
        _.Aa = function(a) {
            _.x.setTimeout(function() {
                throw a;
            }, 0)
        };
        _.Ba = function() {
            var a = _.x.navigator;
            return a && (a = a.userAgent) ? a : ""
        };
        _.z = function(a) {
            return _.Ba().indexOf(a) != -1
        };
        _.Ca = function(a) {
            for (var b = RegExp("([A-Z][\\w ]+)/([^\\s]+)\\s*(?:\\((.*?)\\))?", "g"), c = [], d; d = b.exec(a);) c.push([d[1], d[2], d[3] || void 0]);
            return c
        };
        _.Da = function() {
            return _.z("Opera")
        };
        _.Ea = function() {
            return _.z("Trident") || _.z("MSIE")
        };
        _.Fa = function() {
            return _.z("Firefox") || _.z("FxiOS")
        };
        _.Ha = function() {
            return _.z("Safari") && !(_.Ga() || _.z("Coast") || _.Da() || _.z("Edge") || _.z("Edg/") || _.z("OPR") || _.Fa() || _.z("Silk") || _.z("Android"))
        };
        _.Ga = function() {
            return (_.z("Chrome") || _.z("CriOS")) && !_.z("Edge") || _.z("Silk")
        };
        Ia = function() {
            return _.z("Android") && !(_.Ga() || _.Fa() || _.Da() || _.z("Silk"))
        };
        _.Ja = function(a) {
            var b = {};
            a.forEach(function(c) {
                b[c[0]] = c[1]
            });
            return function(c) {
                return b[c.find(function(d) {
                    return d in b
                })] || ""
            }
        };
        _.Ka = function(a) {
            var b = /rv: *([\d\.]*)/.exec(a);
            if (b && b[1]) return b[1];
            b = "";
            var c = /MSIE +([\d\.]+)/.exec(a);
            if (c && c[1])
                if (a = /Trident\/(\d.\d)/.exec(a), c[1] == "7.0")
                    if (a && a[1]) switch (a[1]) {
                        case "4.0":
                            b = "8.0";
                            break;
                        case "5.0":
                            b = "9.0";
                            break;
                        case "6.0":
                            b = "10.0";
                            break;
                        case "7.0":
                            b = "11.0"
                    } else b = "7.0";
                    else b = c[1];
            return b
        };
        La = function(a) {
            var b = _.Ba();
            if (a === "Internet Explorer") return _.Ea() ? _.Ka(b) : "";
            b = _.Ca(b);
            var c = _.Ja(b);
            switch (a) {
                case "Opera":
                    if (_.Da()) return c(["Version", "Opera"]);
                    if (_.z("OPR")) return c(["OPR"]);
                    break;
                case "Microsoft Edge":
                    if (_.z("Edge")) return c(["Edge"]);
                    if (_.z("Edg/")) return c(["Edg"]);
                    break;
                case "Chromium":
                    if (_.Ga()) return c(["Chrome", "CriOS", "HeadlessChrome"])
            }
            return a === "Firefox" && _.Fa() || a === "Safari" && _.Ha() || a === "Android Browser" && Ia() || a === "Silk" && _.z("Silk") ? (a = b[2]) && a[1] || "" : ""
        };
        _.Ma = function(a) {
            a = La(a);
            if (a === "") return NaN;
            a = a.split(".");
            return a.length === 0 ? NaN : Number(a[0])
        };
        _.Na = function() {
            return _.z("Android")
        };
        Oa = function() {
            return _.z("iPhone") && !_.z("iPod") && !_.z("iPad")
        };
        _.Pa = function() {
            return Oa() || _.z("iPad") || _.z("iPod")
        };
        _.Ra = function(a, b) {
            b = (0, _.Qa)(a, b);
            var c;
            (c = b >= 0) && Array.prototype.splice.call(a, b, 1);
            return c
        };
        _.Sa = function(a) {
            var b = a.length;
            if (b > 0) {
                for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
                return c
            }
            return []
        };
        _.Va = function(a, b) {
            b === void 0 && (b = 0);
            Ta();
            b = Ua[b];
            for (var c = Array(Math.floor(a.length / 3)), d = b[64] || "", e = 0, f = 0; e < a.length - 2; e += 3) {
                var g = a[e],
                    h = a[e + 1],
                    k = a[e + 2],
                    l = b[g >> 2];
                g = b[(g & 3) << 4 | h >> 4];
                h = b[(h & 15) << 2 | k >> 6];
                k = b[k & 63];
                c[f++] = l + g + h + k
            }
            l = 0;
            k = d;
            switch (a.length - e) {
                case 2:
                    l = a[e + 1], k = b[(l & 15) << 2] || d;
                case 1:
                    a = a[e], c[f] = b[a >> 2] + b[(a & 3) << 4 | l >> 4] + k + d
            }
            return c.join("")
        };
        Xa = function(a) {
            var b = a.length,
                c = b * 3 / 4;
            c % 3 ? c = Math.floor(c) : "=.".indexOf(a[b - 1]) != -1 && (c = "=.".indexOf(a[b - 2]) != -1 ? c - 2 : c - 1);
            var d = new Uint8Array(c),
                e = 0;
            _.Wa(a, function(f) {
                d[e++] = f
            });
            return e !== c ? d.subarray(0, e) : d
        };
        _.Wa = function(a, b) {
            function c(k) {
                for (; d < a.length;) {
                    var l = a.charAt(d++),
                        n = Ya[l];
                    if (n != null) return n;
                    if (!/^[\s\xa0]*$/.test(l)) throw Error("v`" + l);
                }
                return k
            }
            Ta();
            for (var d = 0;;) {
                var e = c(-1),
                    f = c(0),
                    g = c(64),
                    h = c(64);
                if (h === 64 && e === -1) break;
                b(e << 2 | f >> 4);
                g != 64 && (b(f << 4 & 240 | g >> 2), h != 64 && b(g << 6 & 192 | h))
            }
        };
        Ta = function() {
            if (!Ya) {
                Ya = {};
                for (var a = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), b = ["+/=", "+/", "-_=", "-_.", "-_"], c = 0; c < 5; c++) {
                    var d = a.concat(b[c].split(""));
                    Ua[c] = d;
                    for (var e = 0; e < d.length; e++) {
                        var f = d[e];
                        Ya[f] === void 0 && (Ya[f] = e)
                    }
                }
            }
        };
        $a = function(a) {
            return Za[a] || ""
        };
        _.cb = function(a) {
            if (!ab) return Xa(a);
            a = bb.test(a) ? a.replace(bb, $a) : a;
            a = atob(a);
            for (var b = new Uint8Array(a.length), c = 0; c < a.length; c++) b[c] = a.charCodeAt(c);
            return b
        };
        _.db = function(a, b) {
            a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
            a.__closure__error__context__984382.severity = b
        };
        _.fb = function(a, b) {
            if (a != null) {
                var c;
                var d = (c = eb) != null ? c : eb = {};
                c = d[a] || 0;
                c >= b || (d[a] = c + 1, a = Error(), _.db(a, "incident"), _.Aa(a))
            }
        };
        _.gb = function(a, b, c) {
            return typeof Symbol === "function" && typeof Symbol() === "symbol" ? (c === void 0 ? 0 : c) && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol() : b
        };
        _.kb = function(a, b) {
            _.hb || _.A in a || ib(a, jb);
            a[_.A] |= b
        };
        _.lb = function(a, b) {
            _.hb || _.A in a || ib(a, jb);
            a[_.A] = b
        };
        _.ob = function(a, b) {
            return b === void 0 ? a.i !== mb && !!(2 & (a.B[_.A] | 0)) : !!(2 & b) && a.i !== mb
        };
        _.pb = function(a, b, c) {
            var d = b & 128 ? 0 : -1,
                e = a.length,
                f;
            if (f = !!e) f = a[e - 1], f = f != null && typeof f === "object" && f.constructor === Object;
            var g = e + (f ? -1 : 0);
            for (b = b & 128 ? 1 : 0; b < g; b++) c(b - d, a[b]);
            if (f) {
                a = a[e - 1];
                for (var h in a) !isNaN(h) && c(+h, a[h])
            }
        };
        qb = function(a) {
            a.Oe = !0;
            return a
        };
        _.vb = function(a) {
            var b = a;
            if (rb(b)) {
                if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error(String(b));
            } else if (sb(b) && !Number.isSafeInteger(b)) throw Error(String(b));
            return tb ? BigInt(a) : a = ub(a) ? a ? "1" : "0" : rb(a) ? a.trim() || "0" : String(a)
        };
        wb = function(a, b) {
            if (a.length > b.length) return !1;
            if (a.length < b.length || a === b) return !0;
            for (var c = 0; c < a.length; c++) {
                var d = a[c],
                    e = b[c];
                if (d > e) return !1;
                if (d < e) return !0
            }
        };
        _.xb = function(a) {
            return Array.prototype.slice.call(a)
        };
        _.yb = function(a) {
            if (a == null || typeof a === "boolean") return a;
            if (typeof a === "number") return !!a
        };
        _.Ab = function(a) {
            return a == null ? a : (0, _.zb)(a) ? a | 0 : void 0
        };
        _.Bb = function(a) {
            if (a == null) return a;
            if (typeof a === "string" && a) a = +a;
            else if (typeof a !== "number") return;
            return (0, _.zb)(a) ? a | 0 : void 0
        };
        _.Cb = function(a) {
            return a == null || typeof a === "string" ? a : void 0
        };
        _.Fb = function(a, b, c) {
            if (a != null && a[Db] === Eb) return a;
            if (Array.isArray(a)) {
                var d = a[_.A] | 0;
                c = d | c & 32 | c & 2;
                c !== d && _.lb(a, c);
                return new b(a)
            }
        };
        Gb = function(a) {
            return a
        };
        _.Jb = function(a) {
            var b = _.Hb(_.Ib);
            return b ? a[b] : void 0
        };
        Lb = function(a, b) {
            b < 100 || _.fb(Kb, 1)
        };
        Ob = function(a, b, c, d) {
            var e = d !== void 0;
            d = !!d;
            var f = _.Hb(_.Ib),
                g;
            !e && _.hb && f && (g = a[f]) && g.xb(Lb);
            f = [];
            var h = a.length;
            g = 4294967295;
            var k = !1,
                l = !!(b & 64),
                n = l ? b & 128 ? 0 : -1 : void 0;
            if (!(b & 1)) {
                var p = h && a[h - 1];
                p != null && typeof p === "object" && p.constructor === Object ? (h--, g = h) : p = void 0;
                if (l && !(b & 128) && !e) {
                    k = !0;
                    var q;
                    g = ((q = Mb) != null ? q : Gb)(g - n, n, a, p, void 0) + n
                }
            }
            b = void 0;
            for (q = 0; q < h; q++) {
                var r = a[q];
                if (r != null && (r = c(r, d)) != null)
                    if (l && q >= g) {
                        var y = q - n,
                            u = void 0;
                        ((u = b) != null ? u : b = {})[y] = r
                    } else f[q] = r
            }
            if (p)
                for (var C in p) h = p[C],
                    h != null && (h = c(h, d)) != null && (q = +C, r = void 0, l && !Number.isNaN(q) && (r = q + n) < g ? f[r] = h : (q = void 0, ((q = b) != null ? q : b = {})[C] = h));
            b && (k ? f.push(b) : f[g] = b);
            e && (c = _.Hb(_.Ib)) && (a = _.Jb(a)) && "function" == typeof _.Nb && a instanceof _.Nb && (f[c] = a.i());
            return f
        };
        Qb = function(a) {
            switch (typeof a) {
                case "number":
                    return Number.isFinite(a) ? a : "" + a;
                case "bigint":
                    return (0, _.Pb)(a) ? Number(a) : "" + a;
                case "boolean":
                    return a ? 1 : 0;
                case "object":
                    if (Array.isArray(a)) {
                        var b = a[_.A] | 0;
                        return a.length === 0 && b & 1 ? void 0 : Ob(a, b, Qb)
                    }
                    if (a != null && a[Db] === Eb) return _.Rb(a);
                    if ("function" == typeof _.Sb && a instanceof _.Sb) {
                        b = a.h;
                        if (b == null) a = "";
                        else if (typeof b === "string") a = b;
                        else {
                            if (ab) {
                                for (var c = "", d = 0, e = b.length - 10240; d < e;) c += String.fromCharCode.apply(null, b.subarray(d, d += 10240));
                                c += String.fromCharCode.apply(null,
                                    d ? b.subarray(d) : b);
                                b = btoa(c)
                            } else b = _.Va(b);
                            a = a.h = b
                        }
                        return a
                    }
                    return
            }
            return a
        };
        _.Rb = function(a) {
            a = a.B;
            return Ob(a, a[_.A] | 0, Qb)
        };
        Vb = function(a) {
            switch (typeof a) {
                case "boolean":
                    return Tb || (Tb = [0, void 0, !0]);
                case "number":
                    return a > 0 ? void 0 : a === 0 ? Ub || (Ub = [0, void 0]) : [-a, void 0];
                case "string":
                    return [0, a];
                case "object":
                    return a
            }
        };
        _.Xb = function(a, b) {
            return Wb(a, b[0], b[1])
        };
        _.B = function(a, b, c) {
            return Wb(a, b, c, 2048)
        };
        Wb = function(a, b, c, d) {
            d = d === void 0 ? 0 : d;
            if (a == null) {
                var e = 32;
                c ? (a = [c], e |= 128) : a = [];
                b && (e = e & -16760833 | (b & 1023) << 14)
            } else {
                if (!Array.isArray(a)) throw Error("z");
                e = a[_.A] | 0;
                if (Yb && 1 & e) throw Error("A");
                2048 & e && !(2 & e) && Zb();
                if (e & 256) throw Error("B");
                if (e & 64) return (e | d) !== e && _.lb(a, e | d), a;
                if (c && (e |= 128, c !== a[0])) throw Error("C");
                a: {
                    c = a;e |= 64;
                    var f = c.length;
                    if (f) {
                        var g = f - 1,
                            h = c[g];
                        if (h != null && typeof h === "object" && h.constructor === Object) {
                            b = e & 128 ? 0 : -1;
                            g -= b;
                            if (g >= 1024) throw Error("E");
                            for (var k in h) f = +k, f < g &&
                                (c[f + b] = h[k], delete h[k]);
                            e = e & -16760833 | (g & 1023) << 14;
                            break a
                        }
                    }
                    if (b) {
                        k = Math.max(b, f - (e & 128 ? 0 : -1));
                        if (k > 1024) throw Error("F");
                        e = e & -16760833 | (k & 1023) << 14
                    }
                }
            }
            _.lb(a, e | 64 | d);
            return a
        };
        Zb = function() {
            if (Yb) throw Error("D");
            _.fb($b, 5)
        };
        dc = function(a, b) {
            if (typeof a !== "object") return a;
            if (Array.isArray(a)) {
                var c = a[_.A] | 0;
                a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = _.ac(a, c, !1, b && !(c & 16)) : (_.kb(a, 34), c & 4 && Object.freeze(a)));
                return a
            }
            if (a != null && a[Db] === Eb) return b = a.B, c = b[_.A] | 0, _.ob(a, c) ? a : _.bc(a, b, c) ? _.cc(a, b) : _.ac(b, c);
            if ("function" == typeof _.Sb && a instanceof _.Sb) return a
        };
        _.cc = function(a, b, c) {
            a = new a.constructor(b);
            c && (a.i = mb);
            a.v = mb;
            return a
        };
        _.ac = function(a, b, c, d) {
            d != null || (d = !!(34 & b));
            a = Ob(a, b, dc, d);
            d = 32;
            c && (d |= 2);
            b = b & 16769217 | d;
            _.lb(a, b);
            return a
        };
        _.ec = function(a) {
            var b = a.B,
                c = b[_.A] | 0;
            return _.ob(a, c) ? _.bc(a, b, c) ? _.cc(a, b, !0) : new a.constructor(_.ac(b, c, !1)) : a
        };
        _.fc = function(a) {
            if (a.i !== mb) return !1;
            var b = a.B;
            b = _.ac(b, b[_.A] | 0);
            _.kb(b, 2048);
            a.B = b;
            a.i = void 0;
            a.v = void 0;
            return !0
        };
        _.hc = function(a, b) {
            b === void 0 && (b = a[_.A] | 0);
            b & 32 && !(b & 4096) && _.lb(a, b | 4096)
        };
        _.bc = function(a, b, c) {
            return c & 2 ? !0 : c & 32 && !(c & 4096) ? (_.lb(b, c | 2), a.i = mb, !0) : !1
        };
        _.ic = function(a, b, c, d) {
            if (b === -1) return null;
            var e = b + (c ? 0 : -1),
                f = a.length - 1;
            if (!(f < 1 + (c ? 0 : -1))) {
                if (e >= f) {
                    var g = a[f];
                    if (g != null && typeof g === "object" && g.constructor === Object) {
                        c = g[b];
                        var h = !0
                    } else if (e === f) c = g;
                    else return
                } else c = a[e];
                if (d && c != null) {
                    d = d(c);
                    if (d == null) return d;
                    if (!Object.is(d, c)) return h ? g[b] = d : a[e] = d, d
                }
                return c
            }
        };
        _.jc = function(a, b, c, d, e) {
            var f = c + (e ? 0 : -1),
                g = a.length - 1;
            if (g >= 1 + (e ? 0 : -1) && f >= g) {
                var h = a[g];
                if (h != null && typeof h === "object" && h.constructor === Object) return h[c] = d, b
            }
            if (f <= g) return a[f] = d, b;
            if (d !== void 0) {
                var k;
                g = ((k = b) != null ? k : b = a[_.A] | 0) >> 14 & 1023 || 536870912;
                c >= g ? d != null && (f = {}, a[g + (e ? 0 : -1)] = (f[c] = d, f)) : a[f] = d
            }
            return b
        };
        lc = function(a, b, c) {
            var d = a[_.A] | 0,
                e = d & 128 ? _.kc : void 0,
                f = _.ic(a, c, e);
            if (f != null && f[Db] === Eb) {
                if (!_.ob(f)) return _.fc(f), f.B;
                var g = f.B
            } else Array.isArray(f) && (g = f, d & 2 && _.kb(g, 34));
            if (g) {
                var h = g[_.A] | 0;
                h & 2 && (g = _.ac(g, h))
            }
            g = _.Xb(g, b);
            g !== f && _.jc(a, d, c, g, e);
            return g
        };
        _.nc = function(a, b, c, d, e) {
            var f = !1;
            d = mc(a, d, e, function(g) {
                var h = _.Fb(g, c, b);
                f = h !== g && h != null;
                return h
            });
            if (d != null) return f && !_.ob(d) && _.hc(a, b), d
        };
        oc = function() {
            var a = function() {
                throw Error();
            };
            Object.setPrototypeOf(a, a.prototype);
            return a
        };
        sc = function(a) {
            var b = pc;
            var c = c === void 0 ? _.qc : c;
            return new _.rc(a, b, c)
        };
        pc = function(a, b, c, d, e) {
            b = _.tc(b, d);
            b != null && (c = _.uc(a, c), e(b, a), _.vc(a, c))
        };
        _.zc = function(a, b, c, d) {
            var e = d[a];
            if (e) return e;
            e = {};
            e.td = d;
            e.Za = Vb(d[0]);
            var f = d[1],
                g = 1;
            f && f.constructor === Object && (e.extensions = f, f = d[++g], typeof f === "function" && f.length > 0 && (e.Pc = !0, _.wc != null || (_.wc = f), _.xc != null || (_.xc = d[g + 1]), f = d[g += 2]));
            for (var h = {}; f && Array.isArray(f) && f.length && typeof f[0] === "number" && f[0] > 0;) {
                for (var k = 0; k < f.length; k++) h[f[k]] = f;
                f = d[++g]
            }
            for (k = 1; f !== void 0;) {
                typeof f === "number" && (k += f, f = d[++g]);
                var l = void 0;
                if (f instanceof _.rc) var n = f;
                else n = yc, g--;
                f = void 0;
                if ((f = n) == null ?
                    0 : f.j) {
                    f = d[++g];
                    l = d;
                    var p = g;
                    typeof f === "function" && (f = f(), l[p] = f);
                    l = f
                }
                f = d[++g];
                p = k + 1;
                typeof f === "number" && f < 0 && (p -= f, f = d[++g]);
                for (; k < p; k++) {
                    var q = h[k];
                    l ? c(e, k, n, l, q) : b(e, k, n, q)
                }
            }
            return d[a] = e
        };
        _.Bc = function(a) {
            return Array.isArray(a) ? a[0] instanceof _.rc ? a : [Ac, a] : [a, void 0]
        };
        _.tc = function(a, b) {
            if (a instanceof _.D) return a.B;
            if (Array.isArray(a)) return _.Xb(a, b)
        };
        _.Cc = function(a, b, c) {
            return new _.rc(a, b, c)
        };
        _.Dc = function(a, b, c) {
            _.jc(a, a[_.A] | 0, b, c, (a[_.A] | 0) & 128 ? _.kc : void 0)
        };
        _.Fc = function(a) {
            _.Ec = a === void 0 ? "warn" : a
        };
        Hc = function(a) {
            a = Gc.get(a);
            var b = Gc.get(_.Ec);
            return a === void 0 || b === void 0 ? !1 : a >= b
        };
        Ic = function(a) {
            return a ? "[GSI_LOGGER-" + a + "]: " : "[GSI_LOGGER]: "
        };
        _.E = function(a, b) {
            try {
                Hc("debug") && window.console && window.console.log && window.console.log(Ic(b) + a)
            } catch (c) {}
        };
        _.F = function(a, b) {
            try {
                Hc("info") && window.console && window.console.info && window.console.info(Ic(b) + a)
            } catch (c) {}
        };
        _.G = function(a, b) {
            try {
                Hc("warn") && window.console && window.console.warn && window.console.warn(Ic(b) + a)
            } catch (c) {}
        };
        _.H = function(a, b) {
            try {
                Hc("error") && window.console && window.console.error && window.console.error(Ic(b) + a)
            } catch (c) {}
        };
        _.Kc = function(a) {
            if (a instanceof _.Jc) return a.h;
            throw Error("H");
        };
        Mc = function(a) {
            return new _.Lc(function(b) {
                return b.substr(0, a.length + 1).toLowerCase() === a + ":"
            })
        };
        _.Oc = function(a) {
            a instanceof _.Jc ? a = _.Kc(a) : a = Nc.test(a) ? a : void 0;
            return a
        };
        _.Pc = function(a, b) {
            b = _.Oc(b);
            b !== void 0 && a.assign(b)
        };
        _.Qc = function(a) {
            this.i = a || {
                cookie: ""
            }
        };
        _.I = function(a) {
            return !!_.Rc.h[a] || _.Sc.includes(a) && _.Tc.get("ge_" + a) === "1"
        };
        Uc = function(a, b, c) {
            for (var d in a) b.call(c, a[d], d, a)
        };
        Wc = function(a, b) {
            for (var c, d, e = 1; e < arguments.length; e++) {
                d = arguments[e];
                for (c in d) a[c] = d[c];
                for (var f = 0; f < Vc.length; f++) c = Vc[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
            }
        };
        _.Yc = function(a) {
            var b = a.match(_.Xc);
            a = b[1];
            var c = b[3];
            b = b[4];
            var d = "";
            a && (d += a + ":");
            c && (d = d + "//" + c, b && (d += ":" + b));
            return d
        };
        Zc = function(a, b) {
            if (a) {
                a = a.split("&");
                for (var c = 0; c < a.length; c++) {
                    var d = a[c].indexOf("="),
                        e = null;
                    if (d >= 0) {
                        var f = a[c].substring(0, d);
                        e = a[c].substring(d + 1)
                    } else f = a[c];
                    b(f, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "")
                }
            }
        };
        _.$c = function(a) {
            this.h = this.A = this.i = "";
            this.v = null;
            this.u = this.j = "";
            this.m = !1;
            var b;
            a instanceof _.$c ? (this.m = a.m, _.ad(this, a.i), this.A = a.getUserInfo(), this.h = a.h, _.bd(this, a.v), this.j = a.j, _.cd(this, dd(a.l)), this.u = a.u) : a && (b = String(a).match(_.Xc)) ? (this.m = !1, _.ad(this, b[1] || "", !0), this.A = ed(b[2] || ""), this.h = ed(b[3] || "", !0), _.bd(this, b[4]), this.j = ed(b[5] || "", !0), _.cd(this, b[6] || "", !0), this.u = ed(b[7] || "")) : (this.m = !1, this.l = new _.fd(null, this.m))
        };
        _.gd = function() {
            this.v = this.v;
            this.u = this.u
        };
        id = function(a, b) {
            hd.call(this, a ? a.type : "");
            this.relatedTarget = this.i = this.target = null;
            this.button = this.screenY = this.screenX = this.clientY = this.clientX = this.m = this.l = 0;
            this.key = "";
            this.charCode = this.keyCode = 0;
            this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
            this.state = null;
            this.pointerId = 0;
            this.pointerType = "";
            this.h = null;
            a && this.init(a, b)
        };
        kd = function(a, b, c, d, e) {
            this.listener = a;
            this.proxy = null;
            this.src = b;
            this.type = c;
            this.capture = !!d;
            this.handler = e;
            this.key = ++jd;
            this.eb = this.rb = !1
        };
        ld = function(a) {
            this.src = a;
            this.h = {};
            this.i = 0
        };
        _.md = function() {
            _.gd.call(this);
            this.ja = new ld(this);
            this.D = this;
            this.m = null
        };
        _.od = function() {
            var a = new Uint32Array(2);
            (window.crypto || _.nd.msCrypto).getRandomValues(a);
            return a[0].toString(16) + a[1].toString(16)
        };
        _.qd = function() {
            return !_.pd() && (_.z("iPod") || _.z("iPhone") || _.z("Android") || _.z("IEMobile"))
        };
        _.pd = function() {
            return _.z("iPad") || _.z("Android") && !_.z("Mobile") || _.z("Silk")
        };
        _.rd = function() {
            return _.I("disable_fedcm_on_samsung_browsers") && navigator.userAgent.includes("SamsungBrowser") ? !1 : _.Ga() && !(_.z("Edg/") || navigator.userAgent.includes("EdgA") || navigator.userAgent.includes("EdgiOS")) && !_.z("OPR")
        };
        _.sd = function() {
            var a = window;
            return "IdentityCredential" in window || "FederatedCredential" in window && a.FederatedCredential.prototype.login
        };
        _.td = function(a, b, c) {
            a = a === void 0 ? _.I("enable_large_popup_height") ? 590 : 500 : a;
            b = b === void 0 ? _.I("enable_large_popup_height") ? 830 : 550 : b;
            a = Math.min(a, screen.width - 40);
            b = Math.min(b, screen.height - 40);
            var d = screen.width / 2 - a / 2,
                e = screen.height / 2 - b / 2;
            c !== void 0 && c >= d && c <= d + a && (d = c - d < d + a - c ? c + 8 : c - a - 8);
            return ["toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=no,copyhistory=no", "width=" + a, "height=" + b, "top=" + e, "left=" + d].join()
        };
        _.vd = function(a, b, c) {
            b = b + "_" + ud;
            var d = window,
                e = _.Oc(a);
            c = e !== void 0 ? d.open(e, b, c) : null;
            if (!c || c.closed || typeof c.closed === "undefined") return _.H("Failed to open popup window on url: " + a + ". Maybe blocked by the browser?"), null;
            c.focus();
            return c
        };
        _.wd = function(a) {
            switch (a.ux_mode) {
                case "redirect":
                    return "redirect";
                default:
                    return "popup"
            }
        };
        _.zd = function(a, b) {
            if (!b.client_id) throw new _.xd("Missing required parameter client_id.", "missing_required_parameter");
            if (!b.scope) throw new _.xd("Missing required parameter scope.", "missing_required_parameter");
            var c = {
                client_id: b.client_id,
                scope: b.scope,
                login_hint: b.login_hint || b.hint,
                state: b.state,
                hd: b.hd || b.hosted_domain,
                include_granted_scopes: b.include_granted_scopes,
                enable_granular_consent: b.enable_granular_consent === void 0 ? b.enable_serial_consent : b.enable_granular_consent,
                trigger_onepick: b.trigger_onepick,
                allow_multiple: b.allow_multiple,
                allow_folder_selection: b.allow_folder_selection,
                file_ids: b.file_ids,
                mimetypes: b.mimetypes,
                include_id_token: b.include_id_token,
                nonce: b.nonce,
                color_scheme: b.color_scheme
            };
            if (c.include_id_token) {
                if (!c.nonce) throw new _.xd("Missing required parameter nonce.", "missing_required_parameter");
                var d = c.scope.split(" "),
                    e = _.v(["openid", "email", "profile"]),
                    f = e.next();
                try {
                    for (; !f.done; f = e.next()) {
                        var g = f.value;
                        d.includes(g) || d.push(g)
                    }
                } finally {
                    _.yd(e, f)
                }
                c.scope = d.join(" ")
            }
            a === "code" ?
                (c.select_account = b.select_account, c.ux_mode = b.ux_mode, b.claims !== void 0 && (c.claims = b.claims), c.ux_mode === "redirect" && (c.redirect_uri = b.redirect_uri || [location.protocol, "//", location.host, location.pathname].join(""))) : a === "token" && (c.prompt = b.prompt, c.enable_token_refresh = b.enable_token_refresh);
            return c
        };
        _.Ad = function(a) {
            _.gd.call(this);
            this.i = a;
            this.h = {}
        };
        _.Cd = function(a, b) {
            var c = this;
            _.md.call(this);
            this.l = a || 1;
            this.j = b || _.x;
            this.A = function() {
                if (c.i) {
                    var d = Date.now() - c.C;
                    d > 0 && d < c.l * .8 ? c.h = c.j.setTimeout(c.A, c.l - d) : (c.h && (c.j.clearTimeout(c.h), c.h = null), c.dispatchEvent("tick"), c.i && (_.Bd(c), c.start()))
                }
            };
            this.C = Date.now()
        };
        Dd = function(a) {
            if (a.G) throw new TypeError("f");
            a.G = !0
        };
        Ed = function(a, b) {
            a.l = {
                Ec: b,
                Oc: !0
            };
            a.h = a.C || a.A
        };
        _.J = function(a, b) {
            a.prototype = (0, _.aa)(b.prototype);
            a.prototype.constructor = a;
            if (_.la)(0, _.la)(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.xa = b.prototype
        };
        _.Fd = function(a) {
            if (!(a instanceof Array)) {
                a = _.v(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        };
        _.yd = function(a, b) {
            var c;
            b && !b.done && (c = a["return"]) && c.call(a)
        };
        Gd = function(a) {
            this.h = new _.w;
            this.i = a
        };
        Jd = function(a, b) {
            Dd(a.h);
            var c = a.h.v;
            if (c) return Hd(a, "return" in c ? c["return"] : function(d) {
                return {
                    value: d,
                    done: !0
                }
            }, b, a.h.return);
            a.h.return(b);
            return Id(a)
        };
        Hd = function(a, b, c, d) {
            try {
                var e = b.call(a.h.v, c);
                _.pa(e);
                if (!e.done) return a.h.G = !1, e;
                var f = e.value
            } catch (g) {
                return a.h.v = null, Ed(a.h, g), Id(a)
            }
            a.h.v = null;
            d.call(a.h, f);
            return Id(a)
        };
        Id = function(a) {
            for (; a.h.h;) try {
                var b = a.i(a.h);
                if (b) return a.h.G = !1, {
                    value: b.value,
                    done: !1
                }
            } catch (c) {
                a.h.j = void 0, Ed(a.h, c)
            }
            a.h.G = !1;
            if (a.h.l) {
                b = a.h.l;
                a.h.l = null;
                if (b.Oc) throw b.Ec;
                return {
                    value: b.return,
                    done: !0
                }
            }
            return {
                value: void 0,
                done: !0
            }
        };
        Kd = function(a) {
            this.next = function(b) {
                Dd(a.h);
                a.h.v ? b = Hd(a, a.h.v.next, b, a.h.K) : (a.h.K(b), b = Id(a));
                return b
            };
            this.throw = function(b) {
                Dd(a.h);
                if (a.h.v) {
                    var c = a.h.v["throw"];
                    if (c) var d = Hd(a, c, b, a.h.K);
                    else {
                        b = a.h.v;
                        a.h.v = null;
                        try {
                            b["return"] && (d = b["return"](), _.pa(d)), Ed(a.h, new TypeError("g"))
                        } catch (e) {
                            Ed(a.h, e)
                        }
                        d = Id(a)
                    }
                } else Ed(a.h, b), d = Id(a);
                return d
            };
            this.return = function(b) {
                return Jd(a, b)
            };
            this[Symbol.iterator] = function() {
                return this
            }
        };
        Ld = function(a) {
            function b(d) {
                return a.next(d)
            }

            function c(d) {
                return a.throw(d)
            }
            return new Promise(function(d, e) {
                function f(g) {
                    g.done ? d(g.value) : Promise.resolve(g.value).then(b, c).then(f, e)
                }
                f(a.next())
            })
        };
        _.Md = function(a) {
            return Ld(new Kd(new Gd(a)))
        };
        _.Nd = function(a) {
            var b = typeof a;
            return b == "object" && a != null || b == "function"
        };
        Od = function(a, b) {
            a: {
                var c = ["WIZ_global_data", "oxN3nb"];
                for (var d = _.x, e = 0; e < c.length; e++)
                    if (d = d[c[e]], d == null) {
                        c = null;
                        break a
                    }
                c = d
            }
            a = c && c[a];
            return a != null ? a : b
        };
        _.M = function(a, b) {
            a = a.split(".");
            for (var c = _.x, d; a.length && (d = a.shift());) a.length || b === void 0 ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
        };
        _.Hb = function(a) {
            return a
        };
        _.Pd = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.xa = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.Le = function(d, e, f) {
                for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
                return b.prototype[e].apply(d, g)
            }
        };
        _.xd = function(a, b) {
            a = Error.call(this, a);
            this.message = a.message;
            "stack" in a && (this.stack = a.stack);
            Object.setPrototypeOf(this, _.xd.prototype);
            this.type = b || "unknown"
        };
        _.J(_.xd, Error);
        var ya, xa, wa;
        _.Qd = typeof TextDecoder !== "undefined";
        xa = typeof String.prototype.isWellFormed === "function";
        wa = typeof TextEncoder !== "undefined";
        var Rd = !!(_.va[0] >> 29 & 1),
            Sd = !!(_.va[0] >> 24 & 1),
            Td = !!(_.va[0] & 1),
            Ud = !!(_.va[0] >> 19 & 1);
        var Yb;
        _.Vd = Rd ? Td : Od(899588437, !1);
        Yb = Rd ? Sd || !Ud : Od(748402147, !0);
        _.Wd = String.prototype.trim ? function(a) {
            return a.trim()
        } : function(a) {
            return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
        };
        _.Qa = Array.prototype.indexOf ? function(a, b) {
            return Array.prototype.indexOf.call(a, b, void 0)
        } : function(a, b) {
            if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
            for (var c = 0; c < a.length; c++)
                if (c in a && a[c] === b) return c;
            return -1
        };
        _.Xd = Array.prototype.forEach ? function(a, b) {
            Array.prototype.forEach.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
        };
        _.Yd = Array.prototype.some ? function(a, b) {
            return Array.prototype.some.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) return !0;
            return !1
        };
        _.Zd = Array.prototype.every ? function(a, b) {
            return Array.prototype.every.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && !b.call(void 0, d[e], e, a)) return !1;
            return !0
        };
        _.$d = function(a) {
            _.$d[" "](a);
            return a
        };
        _.$d[" "] = function() {};
        var ae, ce, fe, ge;
        ae = _.Da();
        _.be = _.Ea();
        ce = _.z("Edge");
        _.de = _.z("Gecko") && !(_.Ba().toLowerCase().indexOf("webkit") != -1 && !_.z("Edge")) && !(_.z("Trident") || _.z("MSIE")) && !_.z("Edge");
        _.ee = _.Ba().toLowerCase().indexOf("webkit") != -1 && !_.z("Edge");
        fe = function() {
            var a = _.Ba();
            if (_.de) return /rv:([^\);]+)(\)|;)/.exec(a);
            if (ce) return /Edge\/([\d\.]+)/.exec(a);
            if (_.be) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
            if (_.ee) return /WebKit\/(\S+)/.exec(a);
            if (ae) return /(?:Version)[ \/]?(\S+)/.exec(a)
        };
        a: {
            var he = "",
                ie = fe();ie && (he = ie ? ie[1] : "");
            if (_.be) {
                var je, ke = _.x.document;
                je = ke ? ke.documentMode : void 0;
                if (je != null && je > parseFloat(he)) {
                    ge = String(je);
                    break a
                }
            }
            ge = he
        }
        var le = ge;
        var me = _.Fa(),
            ne = Oa() || _.z("iPod"),
            oe = _.z("iPad"),
            pe = Ia(),
            qe = _.Ga(),
            re = _.Ha() && !_.Pa();
        var Ua = {},
            Ya = null;
        var ab, bb, Za;
        _.se = typeof Uint8Array !== "undefined";
        ab = !_.be && typeof btoa === "function";
        bb = /[-_.]/g;
        Za = {
            "-": "+",
            _: "/",
            ".": "="
        };
        _.te = {};
        _.ue = function(a) {
            if (_.te !== _.te) throw Error("x");
            var b = a.h;
            b = b == null || _.se && b != null && b instanceof Uint8Array ? b : typeof b === "string" ? _.cb(b) : null;
            return b == null ? b : a.h = b
        };
        var eb = void 0;
        var ve, Kb, $b, Db;
        _.hb = typeof Symbol === "function" && typeof Symbol() === "symbol";
        ve = _.gb("jas", void 0, !0);
        _.we = _.gb(void 0, "0di");
        _.Ib = _.gb(void 0, Symbol());
        _.xe = _.gb(void 0, "0ub");
        Kb = _.gb(void 0, "0ubs");
        _.ye = _.gb(void 0, "0ubsb");
        $b = _.gb(void 0, "0actk");
        Db = _.gb("m_m", "Qe", !0);
        var jb, ib, Ae;
        jb = {
            Fd: {
                value: 0,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        };
        ib = Object.defineProperties;
        _.A = _.hb ? ve : "Fd";
        Ae = [];
        _.lb(Ae, 7);
        _.ze = Object.freeze(Ae);
        var Eb, mb;
        Eb = {};
        mb = {};
        _.Be = Object.freeze({});
        _.kc = {};
        var sb = qb(function(a) {
                return typeof a === "number"
            }),
            rb = qb(function(a) {
                return typeof a === "string"
            }),
            ub = qb(function(a) {
                return typeof a === "boolean"
            });
        var tb = typeof _.x.BigInt === "function" && typeof _.x.BigInt(0) === "bigint";
        var Ee, Ce, Fe, De;
        _.Pb = qb(function(a) {
            return tb ? a >= Ce && a <= De : a[0] === "-" ? wb(a, Ee) : wb(a, Fe)
        });
        Ee = Number.MIN_SAFE_INTEGER.toString();
        Ce = tb ? BigInt(Number.MIN_SAFE_INTEGER) : void 0;
        Fe = Number.MAX_SAFE_INTEGER.toString();
        De = tb ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;
        _.Ge = typeof Uint8Array.prototype.slice === "function";
        _.He = typeof BigInt === "function" ? BigInt.asIntN : void 0;
        _.Ie = Number.isSafeInteger;
        _.zb = Number.isFinite;
        _.Je = Math.trunc;
        var Mb;
        var Tb, Ub;
        var mc;
        _.Ke = _.vb(0);
        _.Le = {};
        _.N = function(a, b, c, d, e) {
            b = _.ic(a.B, b, c, e);
            if (b !== null || d && a.v !== mb) return b
        };
        mc = function(a, b, c, d) {
            return _.ic(a, b, c, d)
        };
        _.Me = function(a, b) {
            a = _.ic(a.B, b);
            return a != null && a[Db] === Eb || Array.isArray(a)
        };
        _.O = function(a, b, c, d) {
            var e = a.B,
                f = e[_.A] | 0;
            b = _.nc(e, f, b, c, d);
            if (b == null) return b;
            f = e[_.A] | 0;
            if (!_.ob(a, f)) {
                var g = _.ec(b);
                g !== b && (_.fc(a) && (e = a.B, f = e[_.A] | 0), b = g, f = _.jc(e, f, c, b, d), _.hc(e, f))
            }
            return b
        };
        _.Ne = function(a, b) {
            var c;
            return (c = _.Cb(_.N(a, b))) != null ? c : ""
        };
        _.P = function(a, b) {
            return _.Cb(_.N(a, b, void 0, _.Le))
        };
        _.Oe = function(a, b) {
            return _.Ab(_.N(a, b, void 0, _.Le))
        };
        _.Pe = function(a, b) {
            for (; b > 127;) a.h.push(b & 127 | 128), b >>>= 7;
            a.h.push(b)
        };
        _.Qe = function(a, b) {
            if (b >= 0) _.Pe(a, b);
            else {
                for (var c = 0; c < 9; c++) a.h.push(b & 127 | 128), b >>= 7;
                a.h.push(1)
            }
        };
        _.Re = function(a, b) {
            b.length !== 0 && (a.j.push(b), a.i += b.length)
        };
        _.uc = function(a, b) {
            _.Pe(a.h, b * 8 + 2);
            b = a.h.end();
            _.Re(a, b);
            b.push(a.i);
            return b
        };
        _.vc = function(a, b) {
            var c = b.pop();
            for (c = a.i + a.h.length() - c; c > 127;) b.push(c & 127 | 128), c >>>= 7, a.i++;
            b.push(c);
            a.i++
        };
        _.Se = function(a, b, c) {
            _.Pe(a.h, b * 8 + 2);
            _.Pe(a.h, c.length);
            _.Re(a, a.h.end());
            _.Re(a, c)
        };
        var Te, We;
        _.qc = oc();
        Te = oc();
        _.Ue = oc();
        _.Ve = oc();
        We = oc();
        _.D = function(a, b, c) {
            this.B = _.B(a, b, c)
        };
        _.D.prototype.toJSON = function() {
            return _.Rb(this)
        };
        _.D.prototype[Db] = Eb;
        _.D.prototype.toString = function() {
            return this.B.toString()
        };
        var yc, Ac;
        _.rc = function(a, b, c) {
            this.h = a;
            this.i = b;
            a = _.Hb(_.qc);
            this.j = !!a && c === a || !1
        };
        yc = sc(function(a, b, c, d, e) {
            if (a.i !== 2) return !1;
            a.m(lc(b, d, c), e);
            return !0
        });
        Ac = sc(function(a, b, c, d, e) {
            if (a.i !== 2) return !1;
            a.m(lc(b, d, c), e);
            return !0
        });
        _.Xe = Symbol();
        _.Ye = _.Cc(function(a, b, c) {
            if (a.i !== 0) return !1;
            _.Dc(b, c, a.v());
            return !0
        }, function(a, b, c) {
            b = _.yb(b);
            b != null && (_.Pe(a.h, c * 8 + 0), a.h.h.push(b ? 1 : 0))
        }, Te);
        _.Ze = _.Cc(function(a, b, c) {
            if (a.i !== 2) return !1;
            _.Dc(b, c, a.u());
            return !0
        }, function(a, b, c) {
            b = _.Cb(b);
            b != null && _.Se(a, c, _.za(b))
        }, _.Ue);
        _.$e = _.Cc(function(a, b, c) {
            if (a.i !== 0) return !1;
            _.Dc(b, c, a.A());
            return !0
        }, function(a, b, c) {
            b = _.Bb(b);
            b != null && (b = parseInt(b, 10), _.Pe(a.h, c * 8 + 0), _.Qe(a.h, b))
        }, We);
        var Gc = new Map;
        Gc.set("debug", 0);
        Gc.set("info", 1);
        Gc.set("warn", 2);
        Gc.set("error", 3);
        _.Ec = "warn";
        _.af = globalThis.trustedTypes;
        _.Jc = function(a) {
            this.h = a
        };
        _.Jc.prototype.toString = function() {
            return this.h
        };
        _.bf = new _.Jc("about:invalid#zClosurez");
        var Nc;
        _.Lc = function(a) {
            this.Id = a
        };
        _.cf = [Mc("data"), Mc("http"), Mc("https"), Mc("mailto"), Mc("ftp"), new _.Lc(function(a) {
            return /^[^:]*([/?#]|$)/.test(a)
        })];
        Nc = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
        _.df = String.prototype.repeat ? function(a, b) {
            return a.repeat(b)
        } : function(a, b) {
            return Array(b + 1).join(a)
        };
        var ef;
        _.m = _.Qc.prototype;
        _.m.h = function(a) {
            return !/[;\r\n]/.test(a)
        };
        _.m.set = function(a, b, c) {
            var d = !1;
            if (typeof c === "object") {
                var e = c.sameSite;
                d = c.secure || !1;
                var f = c.domain || void 0;
                var g = c.path || void 0;
                var h = c.Qb
            }
            if (/[;=\s]/.test(a)) throw Error("K`" + a);
            if (!this.h(b)) throw Error("L`" + b);
            h === void 0 && (h = -1);
            this.i.cookie = a + "=" + b + (f ? ";domain=" + f : "") + (g ? ";path=" + g : "") + (h < 0 ? "" : h == 0 ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Date.now() + h * 1E3)).toUTCString()) + (d ? ";secure" : "") + (e != null ? ";samesite=" + e : "")
        };
        _.m.get = function(a, b) {
            for (var c = a + "=", d = (this.i.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
                f = _.Wd(d[e]);
                if (f.lastIndexOf(c, 0) == 0) return f.slice(c.length);
                if (f == a) return ""
            }
            return b
        };
        _.m.Va = function() {
            return ef(this).keys
        };
        _.m.pa = function() {
            return ef(this).values
        };
        _.m.clear = function() {
            for (var a = ef(this).keys, b = a.length - 1; b >= 0; b--) {
                var c = a[b];
                this.get(c);
                this.set(c, "", {
                    Qb: 0,
                    path: void 0,
                    domain: void 0
                })
            }
        };
        ef = function(a) {
            a = (a.i.cookie || "").split(";");
            for (var b = [], c = [], d, e, f = 0; f < a.length; f++) e = _.Wd(a[f]), d = e.indexOf("="), d == -1 ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
            return {
                keys: b,
                values: c
            }
        };
        _.Tc = new _.Qc(typeof document == "undefined" ? null : document);
        _.Sc = "test_only enable_warm_welcome_page_type enable_itp_optimization enable_itp_support_in_oauth disable_fedcm_opt_out enable_gradient_icon_error_logging disable_evp_popup_fallback".split(" ");
        _.Q = function(a) {
            _.Rc.h[a] = !0;
            _.E("Experiment " + a + " turned on.")
        };
        _.ff = function(a, b) {
            _.Rc.h[a] = b;
            _.E("Experiment " + a + " set to " + b + ".")
        };
        _.Rc = new function() {
            this.h = {}
        };
        var Vc = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");
        _.R = function(a) {
            var b = document;
            return typeof a === "string" ? b.getElementById(a) : a
        };
        _.gf = function(a, b) {
            b = String(b);
            a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
            return a.createElement(b)
        };
        _.Xc = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");
        var ed, hf, qf, jf, lf, kf, of , mf, rf;
        _.$c.prototype.toString = function() {
            var a = [],
                b = this.i;
            b && a.push(hf(b, jf, !0), ":");
            var c = this.h;
            if (c || b == "file") a.push("//"), (b = this.getUserInfo()) && a.push(hf(b, jf, !0), "@"), a.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.v, c != null && a.push(":", String(c));
            if (c = this.j) this.h && c.charAt(0) != "/" && a.push("/"), a.push(hf(c, c.charAt(0) == "/" ? kf : lf, !0));
            (c = this.l.toString()) && a.push("?", c);
            (c = this.u) && a.push("#", hf(c, mf));
            return a.join("")
        };
        _.$c.prototype.resolve = function(a) {
            var b = new _.$c(this),
                c = !!a.i;
            c ? _.ad(b, a.i) : c = !!a.A;
            if (c) {
                var d = a.getUserInfo();
                b.A = d
            } else c = !!a.h;
            c ? b.h = a.h : c = a.v != null;
            d = a.j;
            if (c) _.bd(b, a.v);
            else if (c = !!a.j) {
                if (d.charAt(0) != "/")
                    if (this.h && !this.j) d = "/" + d;
                    else {
                        var e = b.j.lastIndexOf("/");
                        e != -1 && (d = b.j.slice(0, e + 1) + d)
                    }
                e = d;
                if (e == ".." || e == ".") d = "";
                else if (e.indexOf("./") != -1 || e.indexOf("/.") != -1) {
                    d = e.lastIndexOf("/", 0) == 0;
                    e = e.split("/");
                    for (var f = [], g = 0; g < e.length;) {
                        var h = e[g++];
                        h == "." ? d && g == e.length && f.push("") : h ==
                            ".." ? ((f.length > 1 || f.length == 1 && f[0] != "") && f.pop(), d && g == e.length && f.push("")) : (f.push(h), d = !0)
                    }
                    d = f.join("/")
                } else d = e
            }
            c ? b.j = d : c = a.l.toString() !== "";
            c ? _.cd(b, dd(a.l)) : c = !!a.u;
            c && (b.u = a.u);
            return b
        };
        _.ad = function(a, b, c) {
            a.i = c ? ed(b, !0) : b;
            a.i && (a.i = a.i.replace(/:$/, ""))
        };
        _.$c.prototype.getUserInfo = function() {
            return this.A
        };
        _.bd = function(a, b) {
            if (b) {
                b = Number(b);
                if (isNaN(b) || b < 0) throw Error("M`" + b);
                a.v = b
            } else a.v = null
        };
        _.cd = function(a, b, c) {
            b instanceof _.fd ? (a.l = b, nf(a.l, a.m)) : (c || (b = hf(b, of )), a.l = new _.fd(b, a.m))
        };
        _.pf = function(a) {
            return a instanceof _.$c ? new _.$c(a) : new _.$c(a)
        };
        ed = function(a, b) {
            return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : ""
        };
        hf = function(a, b, c) {
            return typeof a === "string" ? (a = encodeURI(a).replace(b, qf), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null
        };
        qf = function(a) {
            a = a.charCodeAt(0);
            return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
        };
        jf = /[#\/\?@]/g;
        lf = /[#\?:]/g;
        kf = /[#\?]/g; of = /[#\?@]/g;
        mf = /#/g;
        _.fd = function(a, b) {
            this.i = this.h = null;
            this.j = a || null;
            this.l = !!b
        };
        rf = function(a) {
            a.h || (a.h = new Map, a.i = 0, a.j && Zc(a.j, function(b, c) {
                a.add(decodeURIComponent(b.replace(/\+/g, " ")), c)
            }))
        };
        _.fd.prototype.add = function(a, b) {
            rf(this);
            this.j = null;
            a = sf(this, a);
            var c = this.h.get(a);
            c || this.h.set(a, c = []);
            c.push(b);
            this.i += 1;
            return this
        };
        _.tf = function(a, b) {
            rf(a);
            b = sf(a, b);
            a.h.has(b) && (a.j = null, a.i -= a.h.get(b).length, a.h.delete(b))
        };
        _.fd.prototype.clear = function() {
            this.h = this.j = null;
            this.i = 0
        };
        var uf = function(a, b) {
            rf(a);
            b = sf(a, b);
            return a.h.has(b)
        };
        _.m = _.fd.prototype;
        _.m.forEach = function(a, b) {
            rf(this);
            this.h.forEach(function(c, d) {
                c.forEach(function(e) {
                    a.call(b, e, d, this)
                }, this)
            }, this)
        };
        _.m.Va = function() {
            rf(this);
            for (var a = Array.from(this.h.values()), b = Array.from(this.h.keys()), c = [], d = 0; d < b.length; d++)
                for (var e = a[d], f = 0; f < e.length; f++) c.push(b[d]);
            return c
        };
        _.m.pa = function(a) {
            rf(this);
            var b = [];
            if (typeof a === "string") uf(this, a) && (b = b.concat(this.h.get(sf(this, a))));
            else {
                a = Array.from(this.h.values());
                for (var c = 0; c < a.length; c++) b = b.concat(a[c])
            }
            return b
        };
        _.m.set = function(a, b) {
            rf(this);
            this.j = null;
            a = sf(this, a);
            uf(this, a) && (this.i -= this.h.get(a).length);
            this.h.set(a, [b]);
            this.i += 1;
            return this
        };
        _.m.get = function(a, b) {
            if (!a) return b;
            a = this.pa(a);
            return a.length > 0 ? String(a[0]) : b
        };
        _.vf = function(a, b, c) {
            _.tf(a, b);
            c.length > 0 && (a.j = null, a.h.set(sf(a, b), _.Sa(c)), a.i += c.length)
        };
        _.fd.prototype.toString = function() {
            if (this.j) return this.j;
            if (!this.h) return "";
            for (var a = [], b = Array.from(this.h.keys()), c = 0; c < b.length; c++) {
                var d = b[c],
                    e = encodeURIComponent(String(d));
                d = this.pa(d);
                for (var f = 0; f < d.length; f++) {
                    var g = e;
                    d[f] !== "" && (g += "=" + encodeURIComponent(String(d[f])));
                    a.push(g)
                }
            }
            return this.j = a.join("&")
        };
        var dd = function(a) {
                var b = new _.fd;
                b.j = a.j;
                a.h && (b.h = new Map(a.h), b.i = a.i);
                return b
            },
            sf = function(a, b) {
                b = String(b);
                a.l && (b = b.toLowerCase());
                return b
            },
            nf = function(a, b) {
                b && !a.l && (rf(a), a.j = null, a.h.forEach(function(c, d) {
                    var e = d.toLowerCase();
                    d != e && (_.tf(this, d), _.vf(this, e, c))
                }, a));
                a.l = b
            };
        _.wf = typeof AsyncContext !== "undefined" && typeof AsyncContext.Snapshot === "function" ? function(a) {
            return a && AsyncContext.Snapshot.wrap(a)
        } : function(a) {
            return a
        };
        _.gd.prototype.v = !1;
        _.gd.prototype.Ca = function() {
            return this.v
        };
        _.gd.prototype.dispose = function() {
            this.v || (this.v = !0, this.ia())
        };
        _.gd.prototype[Symbol.dispose] = function() {
            this.dispose()
        };
        _.gd.prototype.ia = function() {
            if (this.u)
                for (; this.u.length;) this.u.shift()()
        };
        var hd = function(a, b) {
            this.type = a;
            this.i = this.target = b;
            this.defaultPrevented = this.j = !1
        };
        hd.prototype.stopPropagation = function() {
            this.j = !0
        };
        hd.prototype.preventDefault = function() {
            this.defaultPrevented = !0
        };
        _.Pd(id, hd);
        id.prototype.init = function(a, b) {
            var c = this.type = a.type,
                d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
            this.target = a.target || a.srcElement;
            this.i = b;
            b = a.relatedTarget;
            b || (c == "mouseover" ? b = a.fromElement : c == "mouseout" && (b = a.toElement));
            this.relatedTarget = b;
            d ? (this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX, this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY = d.screenY || 0) : (this.l = _.ee || a.offsetX !== void 0 ? a.offsetX : a.layerX, this.m = _.ee || a.offsetY !==
                void 0 ? a.offsetY : a.layerY, this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX, this.clientY = a.clientY !== void 0 ? a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
            this.button = a.button;
            this.keyCode = a.keyCode || 0;
            this.key = a.key || "";
            this.charCode = a.charCode || (c == "keypress" ? a.keyCode : 0);
            this.ctrlKey = a.ctrlKey;
            this.altKey = a.altKey;
            this.shiftKey = a.shiftKey;
            this.metaKey = a.metaKey;
            this.pointerId = a.pointerId || 0;
            this.pointerType = a.pointerType;
            this.state = a.state;
            this.h = a;
            a.defaultPrevented && id.xa.preventDefault.call(this)
        };
        id.prototype.stopPropagation = function() {
            id.xa.stopPropagation.call(this);
            this.h.stopPropagation ? this.h.stopPropagation() : this.h.cancelBubble = !0
        };
        id.prototype.preventDefault = function() {
            id.xa.preventDefault.call(this);
            var a = this.h;
            a.preventDefault ? a.preventDefault() : a.returnValue = !1
        };
        id.prototype.u = function() {
            return this.h
        };
        var xf = function() {
            if (!_.x.addEventListener || !Object.defineProperty) return !1;
            var a = !1,
                b = Object.defineProperty({}, "passive", {
                    get: function() {
                        a = !0
                    }
                });
            try {
                var c = function() {};
                _.x.addEventListener("test", c, b);
                _.x.removeEventListener("test", c, b)
            } catch (d) {}
            return a
        }();
        var yf;
        yf = "closure_listenable_" + (Math.random() * 1E6 | 0);
        _.zf = function(a) {
            return !(!a || !a[yf])
        };
        var jd = 0;
        var Af = function(a) {
            a.eb = !0;
            a.listener = null;
            a.proxy = null;
            a.src = null;
            a.handler = null
        };
        var Cf;
        ld.prototype.add = function(a, b, c, d, e) {
            var f = a.toString();
            a = this.h[f];
            a || (a = this.h[f] = [], this.i++);
            var g = Bf(a, b, d, e);
            g > -1 ? (b = a[g], c || (b.rb = !1)) : (b = new kd(b, this.src, f, !!d, e), b.rb = c, a.push(b));
            return b
        };
        Cf = function(a, b) {
            var c = b.type;
            if (!(c in a.h)) return !1;
            var d = _.Ra(a.h[c], b);
            d && (Af(b), a.h[c].length == 0 && (delete a.h[c], a.i--));
            return d
        };
        _.Df = function(a, b) {
            b = b && b.toString();
            var c = 0,
                d;
            for (d in a.h)
                if (!b || d == b) {
                    for (var e = a.h[d], f = 0; f < e.length; f++) ++c, Af(e[f]);
                    delete a.h[d];
                    a.i--
                }
        };
        ld.prototype.Wa = function(a, b, c, d) {
            a = this.h[a.toString()];
            var e = -1;
            a && (e = Bf(a, b, c, d));
            return e > -1 ? a[e] : null
        };
        var Bf = function(a, b, c, d) {
            for (var e = 0; e < a.length; ++e) {
                var f = a[e];
                if (!f.eb && f.listener == b && f.capture == !!c && f.handler == d) return e
            }
            return -1
        };
        var Ef, Ff, Gf, Kf, Mf, Pf, Nf, Of, Rf, Jf;
        Ef = "closure_lm_" + (Math.random() * 1E6 | 0);
        Ff = {};
        Gf = 0;
        _.If = function(a, b, c, d, e) {
            if (d && d.once) return _.Hf(a, b, c, d, e);
            if (Array.isArray(b)) {
                for (var f = 0; f < b.length; f++) _.If(a, b[f], c, d, e);
                return null
            }
            c = Jf(c);
            return _.zf(a) ? a.O(b, c, _.Nd(d) ? !!d.capture : !!d, e) : Kf(a, b, c, !1, d, e)
        };
        Kf = function(a, b, c, d, e, f) {
            if (!b) throw Error("P");
            var g = _.Nd(e) ? !!e.capture : !!e,
                h = _.Lf(a);
            h || (a[Ef] = h = new ld(a));
            c = h.add(b, c, d, g, f);
            if (c.proxy) return c;
            d = Mf();
            c.proxy = d;
            d.src = a;
            d.listener = c;
            if (a.addEventListener) xf || (e = g), e === void 0 && (e = !1), a.addEventListener(b.toString(), d, e);
            else if (a.attachEvent) a.attachEvent(Nf(b.toString()), d);
            else if (a.addListener && a.removeListener) a.addListener(d);
            else throw Error("Q");
            Gf++;
            return c
        };
        Mf = function() {
            var a = Of,
                b = function(c) {
                    return a.call(b.src, b.listener, c)
                };
            return b
        };
        _.Hf = function(a, b, c, d, e) {
            if (Array.isArray(b)) {
                for (var f = 0; f < b.length; f++) _.Hf(a, b[f], c, d, e);
                return null
            }
            c = Jf(c);
            return _.zf(a) ? a.Pb(b, c, _.Nd(d) ? !!d.capture : !!d, e) : Kf(a, b, c, !0, d, e)
        };
        Pf = function(a, b, c, d, e) {
            if (Array.isArray(b))
                for (var f = 0; f < b.length; f++) Pf(a, b[f], c, d, e);
            else d = _.Nd(d) ? !!d.capture : !!d, c = Jf(c), _.zf(a) ? a.Fa(b, c, d, e) : a && (a = _.Lf(a)) && (b = a.Wa(b, c, d, e)) && _.Qf(b)
        };
        _.Qf = function(a) {
            if (typeof a === "number" || !a || a.eb) return !1;
            var b = a.src;
            if (_.zf(b)) return Cf(b.ja, a);
            var c = a.type,
                d = a.proxy;
            b.removeEventListener ? b.removeEventListener(c, d, a.capture) : b.detachEvent ? b.detachEvent(Nf(c), d) : b.addListener && b.removeListener && b.removeListener(d);
            Gf--;
            (c = _.Lf(b)) ? (Cf(c, a), c.i == 0 && (c.src = null, b[Ef] = null)) : Af(a);
            return !0
        };
        Nf = function(a) {
            return a in Ff ? Ff[a] : Ff[a] = "on" + a
        };
        Of = function(a, b) {
            if (a.eb) a = !0;
            else {
                b = new id(b, this);
                var c = a.listener,
                    d = a.handler || a.src;
                a.rb && _.Qf(a);
                a = c.call(d, b)
            }
            return a
        };
        _.Lf = function(a) {
            a = a[Ef];
            return a instanceof ld ? a : null
        };
        Rf = "__closure_events_fn_" + (Math.random() * 1E9 >>> 0);
        Jf = function(a) {
            if (typeof a === "function") return a;
            a[Rf] || (a[Rf] = function(b) {
                return a.handleEvent(b)
            });
            return a[Rf]
        };
        _.Pd(_.md, _.gd);
        _.md.prototype[yf] = !0;
        _.m = _.md.prototype;
        _.m.addEventListener = function(a, b, c, d) {
            _.If(this, a, b, c, d)
        };
        _.m.removeEventListener = function(a, b, c, d) {
            Pf(this, a, b, c, d)
        };
        _.m.dispatchEvent = function(a) {
            var b, c = this.m;
            if (c)
                for (b = []; c; c = c.m) b.push(c);
            c = this.D;
            var d = a.type || a;
            if (typeof a === "string") a = new hd(a, c);
            else if (a instanceof hd) a.target = a.target || c;
            else {
                var e = a;
                a = new hd(d, c);
                Wc(a, e)
            }
            e = !0;
            var f;
            if (b)
                for (f = b.length - 1; !a.j && f >= 0; f--) {
                    var g = a.i = b[f];
                    e = Sf(g, d, !0, a) && e
                }
            a.j || (g = a.i = c, e = Sf(g, d, !0, a) && e, a.j || (e = Sf(g, d, !1, a) && e));
            if (b)
                for (f = 0; !a.j && f < b.length; f++) g = a.i = b[f], e = Sf(g, d, !1, a) && e;
            return e
        };
        _.m.ia = function() {
            _.md.xa.ia.call(this);
            this.ja && _.Df(this.ja);
            this.m = null
        };
        _.m.O = function(a, b, c, d) {
            return this.ja.add(String(a), b, !1, c, d)
        };
        _.m.Pb = function(a, b, c, d) {
            return this.ja.add(String(a), b, !0, c, d)
        };
        _.m.Fa = function(a, b, c, d) {
            var e = this.ja;
            a = String(a).toString();
            if (a in e.h) {
                var f = e.h[a];
                b = Bf(f, b, c, d);
                b > -1 && (Af(f[b]), Array.prototype.splice.call(f, b, 1), f.length == 0 && (delete e.h[a], e.i--))
            }
        };
        var Sf = function(a, b, c, d) {
            b = a.ja.h[String(b)];
            if (!b) return !0;
            b = b.concat();
            for (var e = !0, f = 0; f < b.length; ++f) {
                var g = b[f];
                if (g && !g.eb && g.capture == c) {
                    var h = g.listener,
                        k = g.handler || g.src;
                    g.rb && Cf(a.ja, g);
                    e = h.call(k, d) !== !1 && e
                }
            }
            return e && !d.defaultPrevented
        };
        _.md.prototype.Wa = function(a, b, c, d) {
            return this.ja.Wa(String(a), b, c, d)
        };
        _.Tf = Math.floor(Math.random() * 100);
        for (var Uf = [], Vf = 0; Vf < 63; Vf++) Uf[Vf] = 0;
        _.$f = [].concat(128, Uf);
        var ag;
        ag = function(a) {
            return (a = a.exec(_.Ba())) ? a[1] : ""
        };
        _.bg = function() {
            if (me) return ag(/Firefox\/([0-9.]+)/);
            if (_.be || ce || ae) return le;
            if (qe) {
                if (_.Pa() || _.z("Macintosh")) {
                    var a = ag(/CriOS\/([0-9.]+)/);
                    if (a) return a
                }
                return ag(/Chrome\/([0-9.]+)/)
            }
            if (re && !_.Pa()) return ag(/Version\/([0-9.]+)/);
            if (ne || oe) {
                if (a = /Version\/(\S+).*Mobile\/(\S+)/.exec(_.Ba())) return a[1] + "." + a[2]
            } else if (pe) return (a = ag(/Android\s+([0-9.]+)/)) ? a : ag(/Version\/([0-9.]+)/);
            return ""
        }();
        _.nd = window;
        var ud = _.od();
        _.Pd(_.Ad, _.gd);
        var cg = [];
        _.Ad.prototype.O = function(a, b, c, d) {
            Array.isArray(b) || (b && (cg[0] = b.toString()), b = cg);
            for (var e = 0; e < b.length; e++) {
                var f = _.If(a, b[e], c || this.handleEvent, d || !1, this.i || this);
                if (!f) break;
                this.h[f.key] = f
            }
            return this
        };
        _.Ad.prototype.Pb = function(a, b, c, d) {
            return dg(this, a, b, c, d)
        };
        var dg = function(a, b, c, d, e, f) {
            if (Array.isArray(c))
                for (var g = 0; g < c.length; g++) dg(a, b, c[g], d, e, f);
            else {
                b = _.Hf(b, c, d || a.handleEvent, e, f || a.i || a);
                if (!b) return a;
                a.h[b.key] = b
            }
            return a
        };
        _.Ad.prototype.Fa = function(a, b, c, d, e) {
            if (Array.isArray(b))
                for (var f = 0; f < b.length; f++) this.Fa(a, b[f], c, d, e);
            else c = c || this.handleEvent, d = _.Nd(d) ? !!d.capture : !!d, e = e || this.i || this, c = Jf(c), d = !!d, b = _.zf(a) ? a.Wa(b, c, d, e) : a ? (a = _.Lf(a)) ? a.Wa(b, c, d, e) : null : null, b && (_.Qf(b), delete this.h[b.key])
        };
        var eg = function(a) {
            Uc(a.h, function(b, c) {
                this.h.hasOwnProperty(c) && _.Qf(b)
            }, a);
            a.h = {}
        };
        _.Ad.prototype.ia = function() {
            _.Ad.xa.ia.call(this);
            eg(this)
        };
        _.Ad.prototype.handleEvent = function() {
            throw Error("V");
        };
        _.Pd(_.Cd, _.md);
        _.Cd.prototype.i = !1;
        _.Cd.prototype.h = null;
        _.Cd.prototype.start = function() {
            this.i = !0;
            this.h || (this.h = this.j.setTimeout(this.A, this.l), this.C = Date.now())
        };
        _.Bd = function(a) {
            a.i = !1;
            a.h && (a.j.clearTimeout(a.h), a.h = null)
        };
        _.Cd.prototype.ia = function() {
            _.Cd.xa.ia.call(this);
            _.Bd(this);
            delete this.j
        };
        var gg, kg;
        _.fg = function(a, b) {
            this.v = b.auth_url || "https://accounts.google.com/o/oauth2/v2/auth";
            this.h = _.zd(a, b);
            this.error_callback = b.error_callback;
            this.C = void 0;
            this.u = a;
            this.H = !1
        };
        _.fg.prototype.j = function() {
            this.m && (gg(this), _.E("Popup timer stopped.", "OAUTH2_CLIENT"), this.G = !0)
        };
        _.hg = function(a) {
            a.H || (a.H = !0, window.addEventListener("message", function(b) {
                try {
                    if (b.data)
                        if (b.origin !== _.Yc(a.v)) _.F("Message ignored. Different origin.", "OAUTH2_CLIENT");
                        else {
                            var c = JSON.parse(b.data).params;
                            c ? a.C && c.id === a.C ? c.clientId !== a.h.client_id ? _.F("Message ignored. Client id does not match.", "OAUTH2_CLIENT") : c.type !== "authResult" ? _.F("Message ignored. Invalid event type.", "OAUTH2_CLIENT") : (a.C = void 0, a.j(c.authResult)) : _.F("Message ignored. Request id does not match.", "OAUTH2_CLIENT") : _.F("Message ignored. No params in message.",
                                "OAUTH2_CLIENT")
                        }
                    else _.F("Message ignored. No event data.", "OAUTH2_CLIENT")
                } catch (d) {
                    _.F("Message ignored. Error in parsing event data.", "OAUTH2_CLIENT")
                }
            }, !1))
        };
        _.ig = function(a, b) {
            a.C = "auth" + Math.floor(Math.random() * 1E6 + 1);
            var c = location.protocol,
                d = location.host,
                e = c.indexOf(":");
            e > 0 && (c = c.substring(0, e));
            c = ["storagerelay://", c, "/", d, "?"];
            c.push("id=" + a.C);
            b.redirect_uri = c.join("")
        };
        _.jg = function(a) {
            a.error_callback && a.i && !a.m && (_.F("Starting popup timer.", "OAUTH2_CLIENT"), a.G = !1, a.m = new _.Cd(500), (new _.Ad(a)).O(a.m, "tick", a.L), a.m.start())
        };
        gg = function(a) {
            a.m && (_.Bd(a.m), a.m = void 0);
            a.i = void 0
        };
        kg = function(a, b) {
            _.F(b, "OAUTH2_CLIENT");
            a.error_callback && a.error_callback(new _.xd(b, "popup_closed"));
            gg(a)
        };
        _.fg.prototype.L = function() {
            _.E("Checking popup closed.", "OAUTH2_CLIENT");
            if (this.m && !this.G)
                if (this.i) {
                    if (this.i) try {
                        var a = !!this.i.closed
                    } catch (b) {
                        _.E("Failed to access popup.closed, potentially due to Cross-Origin-Opener-Policy. Treating popup as closed.", "OAUTH2_CLIENT"), a = !0
                    } else a = !0;
                    a && kg(this, "Popup window closed")
                } else kg(this, "Popup window reference is null (potentially due to Cross-Origin-Opener-Policy or popup blockers)")
        };
        _.Q("disable_fedcm_opt_out");
        _.Q("enable_browsing_session_id");
        _.Q("enable_fedcm_on_edge");
        _.Q("enable_gis_oauth_button_flow_popup");
        _.Q("enable_gis_oauth_button_flow_redirect");
        _.Q("enable_intermediate_iframe");
        _.Q("enable_itp_optimization_ui_desktop");
        _.Q("enable_itp_support_in_oauth");
        _.Q("enable_large_popup_height");
        _.ff("enable_itp_optimization", 24);
        _.Q("enable_rrm_interop");
        _.Q("enable_transform_flow_for_authz");
    } catch (e) {
        _._DumpException(e)
    }
    try {
        var wh, xh, yh, zh, Eh, Fh, Gh, Jh, Qh, vh, Rh, Sh, Uh, Mh, Nh, Yh, $h, Zh, Dh, Ch, Ah, Bh;
        wh = function(a, b) {
            if (typeof a === "string") return new vh(_.cb(a), b);
            if (Array.isArray(a)) return new vh(new Uint8Array(a), b);
            if (a.constructor === Uint8Array) return new vh(a, !1);
            if (a.constructor === ArrayBuffer) return a = new Uint8Array(a), new vh(a, !1);
            if (a.constructor === _.Sb) return b = _.ue(a) || new Uint8Array(0), new vh(b, !0, a);
            if (a instanceof Uint8Array) return a = a.constructor === Uint8Array ? a : new Uint8Array(a.buffer, a.byteOffset, a.byteLength), new vh(a, !1);
            throw Error();
        };
        xh = function() {
            throw Error("s");
        };
        yh = function(a, b) {
            b = String.fromCharCode.apply(null, b);
            return a == null ? b : a + b
        };
        zh = function(a, b, c, d) {
            var e = c.h;
            a[b] = d ? function(f, g, h) {
                return e(f, g, h, d)
            } : e
        };
        Eh = function(a, b, c, d) {
            var e = this[Ah],
                f = this[Bh],
                g = _.Xb(void 0, e.Za),
                h = _.Jb(a);
            if (h) {
                var k = !1,
                    l = e.extensions;
                if (l) {
                    e = function(y, u, C) {
                        if (C.length !== 0)
                            if (l[u]) {
                                y = _.v(C);
                                u = y.next();
                                try {
                                    for (; !u.done; u = y.next()) {
                                        var K = Ch(u.value);
                                        try {
                                            k = !0, f(g, K)
                                        } finally {
                                            Dh(K)
                                        }
                                    }
                                } finally {
                                    _.yd(y, u)
                                }
                            } else d == null || d(a, u, C)
                    };
                    if (b == null) h.xb(e);
                    else if (h != null) {
                        var n = h[b];
                        n && e(h, b, n)
                    }
                    if (k) {
                        var p = a[_.A] | 0;
                        if (p & 2 && p & 2048 && (c == null || !c.Ve)) throw Error();
                        var q = p & 128 ? _.kc : void 0,
                            r = function(y, u) {
                                if (_.ic(a, y, q) != null) switch (c == null ?
                                    void 0 : c.Ue) {
                                    case 1:
                                        return;
                                    default:
                                        throw Error();
                                }
                                u != null && (p = _.jc(a, p, y, u, q));
                                delete h[y]
                            };
                        b == null ? _.pb(g, g[_.A] | 0, function(y, u) {
                            r(y, u)
                        }) : r(b, _.ic(g, b, q))
                    }
                }
            }
        };
        Fh = function(a, b, c, d, e) {
            var f = c.h,
                g, h;
            a[b] = function(k, l, n) {
                return f(k, l, n, h || (h = _.zc(Ah, zh, Fh, d).Za), g || (g = Gh(d)), e)
            }
        };
        Gh = function(a) {
            var b = a[Bh];
            if (b != null) return b;
            var c = _.zc(Ah, zh, Fh, a);
            b = c.Pc ? function(d, e) {
                return (0, _.wc)(d, e, c)
            } : function(d, e) {
                a: {
                    Hh();
                    try {
                        for (; Ih(e) && e.i != 4;) {
                            var f = e.j,
                                g = c[f];
                            if (g == null) {
                                var h = c.extensions;
                                if (h) {
                                    var k = h[f];
                                    if (k) {
                                        var l = Jh(k);
                                        l != null && (g = c[f] = l)
                                    }
                                }
                            }
                            if (g == null || !g(e, d, f)) {
                                var n = e,
                                    p = n.l;
                                Kh(n);
                                var q = n;
                                if (q.Cc) var r = void 0;
                                else {
                                    var y = q.h.h - p;
                                    q.h.h = p;
                                    n = void 0;
                                    var u = q.h;
                                    q = y;
                                    if (q == 0) r = _.Lh();
                                    else {
                                        var C = Mh(u, q);
                                        if (u.Eb && u.m) n = u.i.subarray(C, C + q);
                                        else {
                                            var K = u.i;
                                            q = C + q;
                                            n = C === q ? new Uint8Array(0) :
                                                _.Ge ? K.slice(C, q) : new Uint8Array(K.subarray(C, q))
                                        }
                                        r = n.length == 0 ? _.Lh() : new _.Sb(n, _.te)
                                    }
                                }
                                var L = q = n = void 0,
                                    ia = d,
                                    nb = f,
                                    Wf = r;
                                Wf && ((n = (q = (L = ia[_.Ib]) != null ? L : ia[_.Ib] = new _.Nb)[nb]) != null ? n : q[nb] = []).push(Wf)
                            }
                        }
                        var Xf = _.Jb(d);
                        Xf && (Xf.h = c.td[_.Xe]);
                        var Yf = !0;
                        break a
                    } catch (Zf) {
                        if (Zf instanceof RangeError) throw new SyntaxError;
                        throw Zf;
                    } finally {
                        Nh > 0 && Nh--
                    }
                    Yf = void 0
                }
                return Yf
            };
            a[Bh] = b;
            a[_.Xe] = Eh.bind(a);
            return b
        };
        Jh = function(a) {
            a = _.Bc(a);
            var b = a[0].h;
            if (a = a[1]) {
                var c = Gh(a),
                    d = _.zc(Ah, zh, Fh, a).Za;
                return function(e, f, g) {
                    return b(e, f, g, d, c)
                }
            }
            return b
        };
        _.Oh = function(a, b) {
            return function(c, d) {
                a: {
                    var e = {
                        Wb: !0
                    };d && Object.assign(e, d);c = Ch(c, void 0, void 0, e);
                    try {
                        var f = new a,
                            g = f.B;
                        Gh(b)(g, c);
                        var h = f;
                        break a
                    } catch (k) {
                        if (k instanceof RangeError) throw new SyntaxError;
                        throw k;
                    } finally {
                        Dh(c)
                    }
                    h = void 0
                }
                return h
            }
        };
        _.Ph = function(a) {
            switch (_.Oe(a, 1)) {
                case 1:
                    _.H("The specified user is not signed in.");
                    break;
                case 2:
                    _.H("User has opted out of using Google Sign In.");
                    break;
                case 3:
                    _.H("The given client ID is not found.");
                    break;
                case 4:
                    _.H("The given client ID is not allowed to use Google Sign In.");
                    break;
                case 5:
                    _.H("The given origin is not allowed for the given client ID.");
                    break;
                case 20:
                    _.H("The given login_uri is not allowed for the given client ID.");
                    break;
                case 6:
                    _.H("Request from the same origin is expected.");
                    break;
                case 7:
                    _.H("Google Sign In is only allowed with HTTPS.");
                    break;
                case 8:
                    _.H("Parameter " + _.P(a, 2) + " is not set correctly.");
                    break;
                case 9:
                    _.H("The browser is not supported.");
                    break;
                case 12:
                    _.H("Google Sign In does not support web view.");
                    break;
                case 14:
                    _.H("The client is restricted to accounts within its organization.");
                    break;
                default:
                    _.H("An unknown error occurred.")
            }
        };
        _.Sb = function(a, b) {
            if (b !== _.te) throw Error("x");
            this.h = a;
            if (a != null && a.length === 0) throw Error("w");
        };
        _.Lh = function() {
            return Qh || (Qh = new _.Sb(null, _.te))
        };
        vh = function(a, b, c) {
            this.buffer = a;
            if (c && !b) throw Error();
            this.h = b
        };
        Rh = void 0;
        _.Nb = function() {};
        _.Nb.prototype.xb = function(a) {
            for (var b in this) !isNaN(b) && a(this, +b, this[b])
        };
        _.Nb.prototype.i = function() {
            var a = new _.Nb;
            this.xb(function(b, c, d) {
                a[c] = _.xb(d)
            });
            a.h = this.h;
            return a
        };
        var Th = [],
            Vh = function(a) {
                for (var b = 0, c = a.h, d = c + 10, e = a.i; c < d;) {
                    var f = e[c++];
                    b |= f;
                    if ((f & 128) === 0) return Uh(a, c), !!(b & 127)
                }
                throw Error();
            },
            Wh = function(a, b, c, d) {
                this.i = null;
                this.m = !1;
                this.h = this.j = this.l = 0;
                this.init(a, b, c, d)
            };
        Wh.prototype.init = function(a, b, c, d) {
            var e = d === void 0 ? {} : d;
            d = e.Eb;
            e = e.Wb;
            e = e === void 0 ? !1 : e;
            this.Eb = d === void 0 ? !1 : d;
            this.Wb = e;
            a && (a = wh(a, this.Wb), this.i = a.buffer, this.m = a.h, this.l = b || 0, this.j = c !== void 0 ? this.l + c : this.i.length, this.h = this.l)
        };
        Wh.prototype.clear = function() {
            this.i = null;
            this.m = !1;
            this.h = this.j = this.l = 0;
            this.Eb = !1
        };
        Wh.prototype.reset = function() {
            this.h = this.l
        };
        Uh = function(a, b) {
            a.h = b;
            if (b > a.j) throw Error();
        };
        Mh = function(a, b) {
            if (b < 0) throw Error();
            var c = a.h;
            b = c + b;
            if (b > a.j) throw Error();
            a.h = b;
            return c
        };
        _.Xh = function(a) {
            var b = a.i,
                c = a.h,
                d = b[c++],
                e = d & 127;
            if (d & 128 && (d = b[c++], e |= (d & 127) << 7, d & 128 && (d = b[c++], e |= (d & 127) << 14, d & 128 && (d = b[c++], e |= (d & 127) << 21, d & 128 && (d = b[c++], e |= d << 28, d & 128 && b[c++] & 128 && b[c++] & 128 && b[c++] & 128 && b[c++] & 128 && b[c++] & 128))))) throw Error();
            Uh(a, c);
            return e
        };
        Nh = 0;
        Yh = [];
        $h = function(a, b, c, d) {
            if (Th.length) {
                var e = Th.pop();
                e.init(a, b, c, d);
                a = e
            } else a = new Wh(a, b, c, d);
            this.h = a;
            this.l = this.h.h;
            this.i = this.j = -1;
            Zh(this, d)
        };
        Zh = function(a, b) {
            b = (b === void 0 ? {} : b).Cc;
            a.Cc = b === void 0 ? !1 : b
        };
        Dh = function(a) {
            a.h.clear();
            a.j = -1;
            a.i = -1;
            Yh.length < 100 && Yh.push(a)
        };
        $h.prototype.reset = function() {
            this.h.reset();
            this.l = this.h.h;
            this.i = this.j = -1
        };
        var Ih = function(a) {
                var b = a.h;
                if (b.h == b.j) return !1;
                a.l = a.h.h;
                var c = _.Xh(a.h) >>> 0;
                b = c >>> 3;
                c &= 7;
                if (!(c >= 0 && c <= 5)) throw Error();
                if (b < 1) throw Error();
                a.j = b;
                a.i = c;
                return !0
            },
            Hh = function() {
                if (Nh >= 100) throw new SyntaxError;
                Nh++
            },
            Kh = function(a) {
                try {
                    switch (a.i) {
                        case 0:
                            a.i != 0 ? Kh(a) : Vh(a.h);
                            break;
                        case 1:
                            var b = a.h;
                            Uh(b, b.h + 8);
                            break;
                        case 2:
                            if (a.i != 2) Kh(a);
                            else {
                                var c = _.Xh(a.h) >>> 0,
                                    d = a.h;
                                Uh(d, d.h + c)
                            }
                            break;
                        case 5:
                            var e = a.h;
                            Uh(e, e.h + 4);
                            break;
                        case 3:
                            Hh();
                            var f = a.j;
                            try {
                                do {
                                    if (!Ih(a)) throw Error();
                                    if (a.i == 4) {
                                        if (a.j != f) throw Error();
                                        break
                                    }
                                    Kh(a)
                                } while (1)
                            } catch (g) {
                                if (g instanceof RangeError) throw new SyntaxError;
                                throw g;
                            } finally {
                                Nh > 0 && Nh--
                            }
                            break;
                        default:
                            throw Error();
                    }
                } catch (g) {
                    if (g instanceof RangeError) throw new SyntaxError;
                    throw g;
                }
            };
        $h.prototype.m = function(a, b) {
            var c = this.h.j,
                d = _.Xh(this.h) >>> 0;
            d = this.h.h + d;
            var e = d - c;
            e <= 0 && (this.h.j = d, b(a, this, void 0, void 0, void 0), e = d - this.h.h);
            if (e) throw Error();
            this.h.h = d;
            this.h.j = c
        };
        $h.prototype.v = function() {
            return Vh(this.h)
        };
        $h.prototype.A = function() {
            return _.Xh(this.h)
        };
        $h.prototype.u = function() {
            var a = _.Xh(this.h) >>> 0,
                b = this.h,
                c = Mh(b, a);
            b = b.i;
            if (_.Qd) {
                var d = b,
                    e;
                (e = Sh) || (e = Sh = new TextDecoder("utf-8", {
                    fatal: !0
                }));
                b = c + a;
                d = c === 0 && b === d.length ? d : d.subarray(c, b);
                try {
                    var f = e.decode(d)
                } catch (l) {
                    if (Rh === void 0) {
                        try {
                            e.decode(new Uint8Array([128]))
                        } catch (n) {}
                        try {
                            e.decode(new Uint8Array([97])), Rh = !0
                        } catch (n) {
                            Rh = !1
                        }
                    }!Rh && (Sh = void 0);
                    throw l;
                }
            } else {
                a = c + a;
                f = [];
                for (var g = null, h, k; c < a;) h = b[c++], h < 128 ? f.push(h) : h < 224 ? c >= a ? xh() : (k = b[c++], h < 194 || (k & 192) !== 128 ? (c--, xh()) : f.push((h & 31) <<
                    6 | k & 63)) : h < 240 ? c >= a - 1 ? xh() : (k = b[c++], (k & 192) !== 128 || h === 224 && k < 160 || h === 237 && k >= 160 || ((e = b[c++]) & 192) !== 128 ? (c--, xh()) : f.push((h & 15) << 12 | (k & 63) << 6 | e & 63)) : h <= 244 ? c >= a - 2 ? xh() : (k = b[c++], (k & 192) !== 128 || (h << 28) + (k - 144) >> 30 !== 0 || ((e = b[c++]) & 192) !== 128 || ((d = b[c++]) & 192) !== 128 ? (c--, xh()) : (h = (h & 7) << 18 | (k & 63) << 12 | (e & 63) << 6 | d & 63, h -= 65536, f.push((h >> 10 & 1023) + 55296, (h & 1023) + 56320))) : xh(), f.length >= 8192 && (g = yh(g, f), f.length = 0);
                f = yh(g, f)
            }
            return f
        };
        Ch = function(a, b, c, d) {
            if (Yh.length) {
                var e = Yh.pop();
                Zh(e, d);
                e.h.init(a, b, c, d);
                return e
            }
            return new $h(a, b, c, d)
        };
        Ah = Symbol();
        Bh = Symbol();
        _.ai = function(a) {
            this.B = _.B(a)
        };
        _.J(_.ai, _.D);
        _.bi = function() {};
        _.bi.prototype.P = function(a) {
            var b = this;
            this.U && window.setTimeout(function() {
                b.U && b.U(a)
            }, 100)
        };
        _.ci = function(a, b, c) {
            c !== void 0 && (b.detail = c);
            a.P(b)
        };
        _.di = function(a, b, c) {
            _.ci(a, {
                timestamp: (new Date).getTime(),
                type: "ui_change",
                uiActivityType: b
            }, c)
        };
        _.ei = function(a, b, c) {
            _.ci(a, {
                timestamp: (new Date).getTime(),
                type: "error",
                errorType: b
            }, c)
        };
    } catch (e) {
        _._DumpException(e)
    }
    try {
        var gi, ji, ki, mi, oi, qi, si, ti, vi, wi, xi, Ki, Ni, Pi, Si, Zi, $i, ri, ui, zi, Li, Mi;
        _.fi = function(a) {
            a = Error(a);
            _.db(a, "warning");
            return a
        };
        gi = function() {
            return typeof BigInt === "function"
        };
        ji = function(a) {
            var b = a >>> 0;
            _.hi = b;
            _.ii = (a - b) / 4294967296 >>> 0
        };
        ki = function(a, b) {
            b = ~b;
            a ? a = ~a + 1 : b += 1;
            return [a, b]
        };
        _.li = function(a) {
            if (a < 0) {
                ji(0 - a);
                var b = _.v(ki(_.hi, _.ii));
                a = b.next().value;
                b = b.next().value;
                _.hi = a >>> 0;
                _.ii = b >>> 0
            } else ji(a)
        };
        mi = function(a) {
            a = String(a);
            return "0000000".slice(a.length) + a
        };
        _.ni = function(a, b) {
            b >>>= 0;
            a >>>= 0;
            if (b <= 2097151) var c = "" + (4294967296 * b + a);
            else gi() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + c * 6777216 + b * 6710656, c += b * 8147497, b *= 2, a >= 1E7 && (c += a / 1E7 >>> 0, a %= 1E7), c >= 1E7 && (b += c / 1E7 >>> 0, c %= 1E7), c = b + mi(c) + mi(a));
            return c
        };
        oi = function() {
            var a = _.hi,
                b = _.ii;
            b & 2147483648 ? gi() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = _.v(ki(a, b)), a = b.next().value, b = b.next().value, a = "-" + _.ni(a, b)) : a = _.ni(a, b);
            return a
        };
        _.pi = function(a) {
            if (!_.fc(a) && _.ob(a, a.B[_.A] | 0)) throw Error();
        };
        qi = function(a, b, c) {
            a[b] = c.i
        };
        si = function(a, b, c, d) {
            var e, f, g = c.i;
            a[b] = function(h, k, l) {
                return g(h, k, l, f || (f = _.zc(ri, qi, si, d).Za), e || (e = ti(d)))
            }
        };
        ti = function(a) {
            var b = a[ui];
            if (!b) {
                var c = _.zc(ri, qi, si, a);
                b = function(d, e) {
                    return vi(d, e, c)
                };
                a[ui] = b
            }
            return b
        };
        vi = function(a, b, c) {
            _.pb(a, a[_.A] | 0, function(d, e) {
                if (e != null) {
                    var f = wi(c, d);
                    f ? f(b, e, d) : d < 500 || _.fb(_.ye, 3)
                }
            });
            (a = _.Jb(a)) && a.xb(function(d, e, f) {
                _.Re(b, b.h.end());
                for (d = 0; d < f.length; d++) _.Re(b, _.ue(f[d]) || new Uint8Array(0))
            })
        };
        wi = function(a, b) {
            var c = a[b];
            if (c) return c;
            if (c = a.extensions)
                if (c = c[b]) {
                    c = _.Bc(c);
                    var d = c[0].i;
                    if (c = c[1]) {
                        var e = ti(c),
                            f = _.zc(ri, qi, si, c).Za;
                        c = a.Pc ? (0, _.xc)(f, e) : function(g, h, k) {
                            return d(g, h, k, f, e)
                        }
                    } else c = d;
                    return a[b] = c
                }
        };
        xi = function(a) {
            return Array.prototype.map.call(a, function(b) {
                b = b.toString(16);
                return b.length > 1 ? b : "0" + b
            }).join("")
        };
        _.yi = function(a, b) {
            2 & b && (a |= 2);
            return a | 1
        };
        _.Ai = function(a) {
            switch (typeof a) {
                case "bigint":
                    return !0;
                case "number":
                    return (0, _.zb)(a);
                case "string":
                    return zi.test(a);
                default:
                    return !1
            }
        };
        _.Bi = function(a) {
            var b = a.length;
            if (a[0] === "-" ? b < 20 || b === 20 && a <= "-9223372036854775808" : b < 19 || b === 19 && a <= "9223372036854775807") return a;
            if (a.length < 16) _.li(Number(a));
            else if (gi()) a = BigInt(a), _.hi = Number(a & BigInt(4294967295)) >>> 0, _.ii = Number(a >> BigInt(32) & BigInt(4294967295));
            else {
                b = +(a[0] === "-");
                _.ii = _.hi = 0;
                for (var c = a.length, d = 0 + b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), _.ii *= 1E6, _.hi = _.hi * 1E6 + d, _.hi >= 4294967296 && (_.ii += Math.trunc(_.hi / 4294967296), _.ii >>>= 0, _.hi >>>= 0);
                b && (b = _.v(ki(_.hi, _.ii)),
                    a = b.next().value, b = b.next().value, _.hi = a, _.ii = b)
            }
            return oi()
        };
        _.Ci = function(a) {
            var b = (0, _.Je)(Number(a));
            if ((0, _.Ie)(b)) return _.vb(b);
            b = a.indexOf(".");
            b !== -1 && (a = a.substring(0, b));
            return gi() ? _.vb((0, _.He)(64, BigInt(a))) : _.vb(_.Bi(a))
        };
        _.Di = function(a) {
            a = (0, _.Je)(a);
            (0, _.Ie)(a) ? a = String(a): (_.li(a), a = oi());
            return a
        };
        _.Ei = function(a) {
            var b = typeof a;
            if (a == null) return a;
            if (b === "bigint") return _.vb((0, _.He)(64, a));
            if (_.Ai(a)) return b === "string" ? _.Ci(a) : _.vb((0, _.Ie)(a) ? a : _.Di(a))
        };
        _.Fi = function(a) {
            return !!(2 & a) && !!(4 & a) || !!(256 & a)
        };
        _.Gi = function(a, b) {
            return a = (2 & b ? a | 2 : a & -3) & -273
        };
        _.Hi = function(a, b, c) {
            a = _.ic(a, b, c);
            return Array.isArray(a) ? a : _.ze
        };
        _.Ii = function(a) {
            return function(b) {
                if (b == null || b == "") b = new a;
                else {
                    b = JSON.parse(b);
                    if (!Array.isArray(b)) throw Error("G");
                    _.kb(b, 32);
                    b = new a(b)
                }
                return b
            }
        };
        _.Ji = function(a, b) {
            b = _.Oc(b);
            b !== void 0 && a.replace(b)
        };
        Ki = function() {
            this.i = -1
        };
        Ni = function(a, b) {
            this.i = -1;
            this.i = 64;
            this.l = _.x.Uint8Array ? new Uint8Array(this.i) : Array(this.i);
            this.m = this.j = 0;
            this.h = [];
            this.v = a;
            this.u = b;
            this.A = _.x.Int32Array ? new Int32Array(64) : Array(64);
            Li === void 0 && (_.x.Int32Array ? Li = new Int32Array(Mi) : Li = Mi);
            this.reset()
        };
        Pi = function() {
            Ni.call(this, 8, Oi)
        };
        _.Qi = function(a) {
            var b = new Pi;
            b.update(a, a.length);
            return xi(b.digest())
        };
        _.Ri = function(a, b) {
            var c = document.createElement("form");
            document.body.appendChild(c);
            c.method = "post";
            a = _.Oc(a);
            a !== void 0 && (c.action = a);
            if (b) {
                a = Object.keys(b);
                for (var d = 0; d < a.length; d++) {
                    var e = a[d],
                        f = document.createElement("input");
                    f.type = "hidden";
                    f.name = e;
                    f.value = b[e].toString();
                    c.appendChild(f)
                }
            }
            c.submit()
        };
        Si = function(a) {
            var b = typeof a;
            return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
        };
        _.Ti = function(a) {
            var b = Si(a);
            return b == "array" || b == "object" && typeof a.length == "number"
        };
        _.hi = 0;
        _.ii = 0;
        _.Ui = function(a, b, c) {
            _.pi(a);
            var d = a.B;
            _.jc(d, d[_.A] | 0, b, c);
            return a
        };
        _.Vi = function(a, b) {
            var c;
            return (c = _.yb(_.N(a, b))) != null ? c : !1
        };
        _.Wi = function(a, b) {
            var c = c === void 0 ? 0 : c;
            var d;
            return (d = _.Ab(_.N(a, b))) != null ? d : c
        };
        _.Xi = function(a, b) {
            return _.Cb(_.N(a, b))
        };
        _.Yi = function(a, b, c) {
            if (c != null && typeof c !== "boolean") throw Error("y`" + Si(c) + "`" + c);
            return _.Ui(a, b, c)
        };
        _.S = function(a, b, c) {
            if (c != null && typeof c !== "string") throw Error();
            return _.Ui(a, b, c)
        };
        _.T = function(a, b, c) {
            if (c != null) {
                if (!(0, _.zb)(c)) throw _.fi("enum");
                c |= 0
            }
            return _.Ui(a, b, c)
        };
        Zi = function() {
            this.h = []
        };
        Zi.prototype.length = function() {
            return this.h.length
        };
        Zi.prototype.end = function() {
            var a = this.h;
            this.h = [];
            return a
        };
        $i = function() {
            this.j = [];
            this.i = 0;
            this.h = new Zi
        };
        ri = Symbol();
        ui = Symbol();
        _.aj = [0, 2, _.$e, _.Ze, -1, 1, _.$e, _.Ze, 1, _.Ze, -2, _.Ye];
        _.bj = function(a) {
            this.B = _.B(a)
        };
        _.J(_.bj, _.D);
        _.bj.prototype.h = function(a) {
            return function() {
                var b = new $i;
                vi(this.B, b, _.zc(ri, qi, si, a));
                _.Re(b, b.h.end());
                for (var c = new Uint8Array(b.i), d = b.j, e = d.length, f = 0, g = 0; g < e; g++) {
                    var h = d[g];
                    c.set(h, f);
                    f += h.length
                }
                b.j = [c];
                return c
            }
        }(_.aj);
        _.cj = _.gb(void 0, "1oa");
        zi = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;
        _.dj = function(a, b, c, d) {
            var e = a.B,
                f = e,
                g = e[_.A] | 0;
            d = d && d !== 4 ? d !== 1 && (a ? _.ob(a, g) : 2 & g) ? 1 : d : 4;
            e = d === 3;
            var h = !(a ? _.ob(a, g) : 2 & g);
            (d === 2 || h) && a && _.fc(a) && (f = a.B, g = f[_.A] | 0);
            var k = _.Hi(f, c),
                l = k === _.ze ? 7 : k[_.A] | 0,
                n = _.yi(l, g);
            if (a = !(4 & n)) {
                var p = k,
                    q = g,
                    r = !!(2 & n);
                r && (q |= 2);
                for (var y = !r, u = !0, C = 0, K = 0; C < p.length; C++) {
                    var L = _.Fb(p[C], b, q);
                    if (L instanceof b) {
                        if (!r) {
                            var ia = _.ob(L);
                            y && (y = !ia);
                            u && (u = ia)
                        }
                        p[K++] = L
                    }
                }
                K < C && (p.length = K);
                n |= 4;
                n = u ? n & -4097 : n | 4096;
                n = y ? n | 8 : n & -9
            }
            n !== l && (_.lb(k, n), 2 & n && Object.freeze(k));
            if (h && !(8 &
                    n || !k.length && (d === 1 || (d !== 4 ? 0 : 2 & n || !(16 & n) && 32 & g)))) {
                _.Fi(n) && (k = _.xb(k), n = _.Gi(n, g), g = _.jc(f, g, c, k));
                b = k;
                h = n;
                for (l = 0; l < b.length; l++) p = b[l], n = _.ec(p), p !== n && (b[l] = n);
                h |= 8;
                n = h = b.length ? h | 4096 : h & -4097;
                _.lb(k, n)
            }
            h = b = n;
            (l = _.Fi(b)) && d === 2 && (k = _.xb(k), h = 0, b = _.Gi(b, g), g = _.jc(f, g, c, k), l = !1);
            l || (d === 1 || (d !== 4 ? 0 : 2 & b || !(16 & b) && 32 & g) ? (b |= !k.length || a && !(4096 & b) || 32 & g && !(4096 & b || 16 & b) ? 2 : 256, b !== h && _.lb(k, b), Object.freeze(k)) : (e || (b |= 16), b !== h && _.lb(k, b)));
            2 & b || !(4096 & b || 16 & b) || _.hc(f, g);
            return k
        };
        _.ej = function(a, b, c) {
            c = c === void 0 ? _.Ke : c;
            a = _.N(a, b, void 0, void 0, _.Ei);
            return a != null ? a : c
        };
        _.fj = function(a, b, c) {
            if (c != null) {
                if (typeof c !== "number") throw _.fi("int32");
                if (!(0, _.zb)(c)) throw _.fi("int32");
                c |= 0
            }
            return _.Ui(a, b, c)
        };
        _.gj = function(a, b) {
            if (a)
                if (_.zf(a)) a.ja && _.Df(a.ja, b);
                else if (a = _.Lf(a)) {
                var c = 0;
                b = b && b.toString();
                for (var d in a.h)
                    if (!b || d == b)
                        for (var e = a.h[d].concat(), f = 0; f < e.length; ++f) _.Qf(e[f]) && ++c
            }
        };
        Mi = [1116352408, 1899447441, 3049323471, 3921009573, 961987163, 1508970993, 2453635748, 2870763221, 3624381080, 310598401, 607225278, 1426881987, 1925078388, 2162078206, 2614888103, 3248222580, 3835390401, 4022224774, 264347078, 604807628, 770255983, 1249150122, 1555081692, 1996064986, 2554220882, 2821834349, 2952996808, 3210313671, 3336571891, 3584528711, 113926993, 338241895, 666307205, 773529912, 1294757372, 1396182291, 1695183700, 1986661051, 2177026350, 2456956037, 2730485921, 2820302411, 3259730800, 3345764771, 3516065817, 3600352804, 4094571909,
            275423344, 430227734, 506948616, 659060556, 883997877, 958139571, 1322822218, 1537002063, 1747873779, 1955562222, 2024104815, 2227730452, 2361852424, 2428436474, 2756734187, 3204031479, 3329325298
        ];
        _.Pd(Ni, Ki);
        Ni.prototype.reset = function() {
            this.m = this.j = 0;
            this.h = _.x.Int32Array ? new Int32Array(this.u) : _.Sa(this.u)
        };
        var hj = function(a) {
            for (var b = a.l, c = a.A, d = 0, e = 0; e < b.length;) c[d++] = b[e] << 24 | b[e + 1] << 16 | b[e + 2] << 8 | b[e + 3], e = d * 4;
            for (b = 16; b < 64; b++) d = c[b - 15] | 0, e = c[b - 2] | 0, c[b] = ((c[b - 16] | 0) + ((d >>> 7 | d << 25) ^ (d >>> 18 | d << 14) ^ d >>> 3) | 0) + ((c[b - 7] | 0) + ((e >>> 17 | e << 15) ^ (e >>> 19 | e << 13) ^ e >>> 10) | 0) | 0;
            b = a.h[0] | 0;
            d = a.h[1] | 0;
            e = a.h[2] | 0;
            for (var f = a.h[3] | 0, g = a.h[4] | 0, h = a.h[5] | 0, k = a.h[6] | 0, l = a.h[7] | 0, n = 0; n < 64; n++) {
                var p = ((b >>> 2 | b << 30) ^ (b >>> 13 | b << 19) ^ (b >>> 22 | b << 10)) + (b & d ^ b & e ^ d & e) | 0,
                    q = (l + ((g >>> 6 | g << 26) ^ (g >>> 11 | g << 21) ^ (g >>> 25 | g << 7)) | 0) + (((g & h ^
                        ~g & k) + (Li[n] | 0) | 0) + (c[n] | 0) | 0) | 0;
                l = k;
                k = h;
                h = g;
                g = f + q | 0;
                f = e;
                e = d;
                d = b;
                b = q + p | 0
            }
            a.h[0] = a.h[0] + b | 0;
            a.h[1] = a.h[1] + d | 0;
            a.h[2] = a.h[2] + e | 0;
            a.h[3] = a.h[3] + f | 0;
            a.h[4] = a.h[4] + g | 0;
            a.h[5] = a.h[5] + h | 0;
            a.h[6] = a.h[6] + k | 0;
            a.h[7] = a.h[7] + l | 0
        };
        Ni.prototype.update = function(a, b) {
            b === void 0 && (b = a.length);
            var c = 0,
                d = this.j;
            if (typeof a === "string")
                for (; c < b;) this.l[d++] = a.charCodeAt(c++), d == this.i && (hj(this), d = 0);
            else if (_.Ti(a))
                for (; c < b;) {
                    var e = a[c++];
                    if (!("number" == typeof e && 0 <= e && 255 >= e && e == (e | 0))) throw Error("T");
                    this.l[d++] = e;
                    d == this.i && (hj(this), d = 0)
                } else throw Error("U");
            this.j = d;
            this.m += b
        };
        Ni.prototype.digest = function() {
            var a = [],
                b = this.m * 8;
            this.j < 56 ? this.update(_.$f, 56 - this.j) : this.update(_.$f, this.i - (this.j - 56));
            for (var c = 63; c >= 56; c--) this.l[c] = b & 255, b /= 256;
            hj(this);
            for (c = b = 0; c < this.v; c++)
                for (var d = 24; d >= 0; d -= 8) a[b++] = this.h[c] >> d & 255;
            return a
        };
        var Oi = [1779033703, 3144134277, 1013904242, 2773480762, 1359893119, 2600822924, 528734635, 1541459225];
        _.Pd(Pi, Ni);
        _.ij = function() {
            var a = this;
            this.h = this.i = null;
            this.promise = new Promise(function(b, c) {
                a.i = b;
                a.h = c
            })
        };
        _.ij.prototype.resolve = function(a) {
            if (!this.i) throw Error("oa");
            this.i(a);
            this.dispose()
        };
        _.ij.prototype.reject = function(a) {
            if (!this.h) throw Error("oa");
            this.h(a);
            this.dispose()
        };
        _.ij.prototype.dispose = function() {
            this.h = this.i = null
        };
    } catch (e) {
        _._DumpException(e)
    }
    try {
        var hl, kl, sl, tl, ul, vl, wl, xl, yl, zl, Al, Bl, Cl, Dl, El, Ml, Ol, Pl;
        _.dl = function(a) {
            if (_.hb) {
                var b;
                return (b = a[_.cj]) != null ? b : a[_.cj] = new Map
            }
            if (_.cj in a) return a[_.cj];
            b = new Map;
            Object.defineProperty(a, _.cj, {
                value: b
            });
            return b
        };
        _.el = function(a, b, c, d, e) {
            var f = a.get(d);
            if (f != null) return f;
            for (var g = f = 0; g < d.length; g++) {
                var h = d[g];
                _.ic(b, h, e) != null && (f !== 0 && (c = _.jc(b, c, f, void 0, e)), f = h)
            }
            a.set(d, f);
            return f
        };
        _.fl = function(a, b, c, d) {
            var e = _.dl(a),
                f = _.el(e, a, b, c);
            f !== d && (f && (b = _.jc(a, b, f)), e.set(c, d));
            return b
        };
        _.gl = function(a) {
            if (!a.startsWith(")]}'\n")) throw console.error("malformed JSON response:", a), Error("pa");
            a = a.substring(5);
            return JSON.parse(a)
        };
        hl = function(a, b) {
            return a < b ? -1 : a > b ? 1 : 0
        };
        _.il = function(a, b) {
            var c = 0;
            a = (0, _.Wd)(String(a)).split(".");
            b = (0, _.Wd)(String(b)).split(".");
            for (var d = Math.max(a.length, b.length), e = 0; c == 0 && e < d; e++) {
                var f = a[e] || "",
                    g = b[e] || "";
                do {
                    f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                    g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                    if (f[0].length == 0 && g[0].length == 0) break;
                    c = hl(f[1].length == 0 ? 0 : parseInt(f[1], 10), g[1].length == 0 ? 0 : parseInt(g[1], 10)) || hl(f[2].length == 0, g[2].length == 0) || hl(f[2], g[2]);
                    f = f[3];
                    g = g[3]
                } while (c == 0)
            }
            return c
        };
        _.jl = function() {
            var a = _.Ba();
            if (_.Ea()) return _.Ka(a);
            a = _.Ca(a);
            var b = _.Ja(a);
            return _.Da() ? b(["Version", "Opera"]) : _.z("Edge") ? b(["Edge"]) : _.z("Edg/") ? b(["Edg"]) : _.z("Silk") ? b(["Silk"]) : _.Ga() ? b(["Chrome", "CriOS", "HeadlessChrome"]) : (a = a[2]) && a[1] || ""
        };
        kl = function(a, b, c) {
            if (b & 2) throw Error();
            var d = b & 128 ? _.kc : void 0,
                e = _.Hi(a, c, d),
                f = e === _.ze ? 7 : e[_.A] | 0,
                g = _.yi(f, b);
            if (2 & g || _.Fi(g) || 16 & g) g === f || _.Fi(g) || _.lb(e, g), e = _.xb(e), f = 0, g = _.Gi(g, b), _.jc(a, b, c, e, d);
            g &= -13;
            g !== f && _.lb(e, g);
            return e
        };
        _.ll = function(a, b) {
            if (!b) return a;
            var c = a.indexOf("#");
            c < 0 && (c = a.length);
            var d = a.indexOf("?");
            if (d < 0 || d > c) {
                d = c;
                var e = ""
            } else e = a.substring(d + 1, c);
            a = [a.slice(0, d), e, a.slice(c)];
            c = a[1];
            a[1] = b ? c ? c + "&" + b : b : c;
            return a[0] + (a[1] ? "?" + a[1] : "") + a[2]
        };
        _.ml = function(a) {
            switch (a) {
                case "auto":
                    return 1;
                case "user_2tap":
                    return 6;
                case "user_1tap":
                    return 5;
                case "btn":
                    return 7;
                case "btn_confirm":
                    return 8;
                case "btn_add_session":
                    return 9;
                case "btn_confirm_add_session":
                    return 10;
                case "itp":
                    return 11;
                default:
                    return 2
            }
        };
        _.nl = function(a) {
            var b = {};
            if (a) {
                var c = _.v(Object.keys(a)),
                    d = c.next();
                try {
                    for (; !d.done; d = c.next()) {
                        var e = d.value;
                        a[e] !== void 0 && a[e] !== "" && (b[e] = a[e])
                    }
                } finally {
                    _.yd(c, d)
                }
            }
            return b
        };
        _.pl = function(a, b) {
            a = new _.$c(a);
            b && _.cd(a, _.ol(_.nl(b)));
            return a.toString()
        };
        _.ql = function() {
            var a;
            if (!(a = _.Ha() || (_.z("iPad") || _.z("iPhone")) && !_.Ha() && !_.Ga() && !_.z("Coast") && !_.Fa() && _.z("AppleWebKit")) && (a = _.Pa())) {
                a = _.Ba();
                var b = "";
                _.z("Windows") ? (b = /Windows (?:NT|Phone) ([0-9.]+)/, b = (a = b.exec(a)) ? a[1] : "0.0") : _.Pa() ? (b = /(?:iPhone|iPod|iPad|CPU)\s+OS\s+(\S+)/, b = (a = b.exec(a)) && a[1].replace(/_/g, ".")) : _.z("Macintosh") ? (b = /Mac OS X ([0-9_.]+)/, b = (a = b.exec(a)) ? a[1].replace(/_/g, ".") : "10") : _.Ba().toLowerCase().indexOf("kaios") != -1 ? (b = /(?:KaiOS)\/(\S+)/i, b = (a = b.exec(a)) && a[1]) :
                    _.Na() ? (b = /Android\s+([^\);]+)(\)|;)/, b = (a = b.exec(a)) && a[1]) : _.z("CrOS") && (b = /(?:CrOS\s+(?:i686|x86_64)\s+([0-9.]+))/, b = (a = b.exec(a)) && a[1]);
                a = _.il(b || "", "14.4") >= 0
            }
            return a || _.Fa() && _.il(_.jl(), "100") >= 0
        };
        _.rl = function(a, b) {
            return _.T(a, 3, b)
        };
        sl = function(a) {
            if (a.pa && typeof a.pa == "function") return a.pa();
            if (typeof Map !== "undefined" && a instanceof Map || typeof Set !== "undefined" && a instanceof Set) return Array.from(a.values());
            if (typeof a === "string") return a.split("");
            if (_.Ti(a)) {
                for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
                return b
            }
            b = [];
            c = 0;
            for (d in a) b[c++] = a[d];
            return b
        };
        tl = function(a) {
            if (a.Va && typeof a.Va == "function") return a.Va();
            if (!a.pa || typeof a.pa != "function") {
                if (typeof Map !== "undefined" && a instanceof Map) return Array.from(a.keys());
                if (!(typeof Set !== "undefined" && a instanceof Set)) {
                    if (_.Ti(a) || typeof a === "string") {
                        var b = [];
                        a = a.length;
                        for (var c = 0; c < a; c++) b.push(c);
                        return b
                    }
                    b = [];
                    c = 0;
                    for (var d in a) b[c++] = d;
                    return b
                }
            }
        };
        ul = /^https?$/i;
        vl = ["POST", "PUT"];
        wl = [];
        xl = function(a) {
            a.Lb || (a.Lb = !0, a.dispatchEvent("complete"), a.dispatchEvent("error"))
        };
        yl = function(a, b) {
            if (a.J) {
                a.Ea && (clearTimeout(a.Ea), a.Ea = null);
                var c = a.J;
                a.J = null;
                b || a.dispatchEvent("ready");
                try {
                    c.onreadystatechange = null
                } catch (d) {}
            }
        };
        zl = function(a) {
            a.sa = !1;
            a.J && (a.Aa = !0, a.J.abort(), a.Aa = !1);
            xl(a);
            yl(a)
        };
        Al = function(a) {
            return a.J ? a.J.readyState : 0
        };
        Bl = function(a) {
            if (a.sa && typeof _.ua != "undefined")
                if (a.yb && Al(a) == 4) setTimeout(a.ad.bind(a), 0);
                else if (a.dispatchEvent("readystatechange"), Al(a) == 4) {
                a.sa = !1;
                try {
                    var b = a.Kc();
                    a: switch (b) {
                        case 200:
                        case 201:
                        case 202:
                        case 204:
                        case 206:
                        case 304:
                        case 1223:
                            var c = !0;
                            break a;
                        default:
                            c = !1
                    }
                    var d;
                    if (!(d = c)) {
                        var e;
                        if (e = b === 0) {
                            var f = String(a.Ob).match(_.Xc)[1] || null;
                            !f && _.x.self && _.x.self.location && (f = _.x.self.location.protocol.slice(0, -1));
                            e = !ul.test(f ? f.toLowerCase() : "")
                        }
                        d = e
                    }
                    d ? (a.dispatchEvent("complete"), a.dispatchEvent("success")) :
                        xl(a)
                } finally {
                    yl(a)
                }
            }
        };
        Cl = function(a, b) {
            return {
                type: b,
                lengthComputable: a.lengthComputable,
                loaded: a.loaded,
                total: a.total
            }
        };
        Dl = function(a, b, c) {
            a.dispatchEvent(Cl(b, "progress"));
            a.dispatchEvent(Cl(b, c ? "downloadprogress" : "uploadprogress"))
        };
        El = function() {
            _.md.call(this);
            this.headers = new Map;
            this.sa = !1;
            this.J = null;
            this.Ob = "";
            this.Aa = this.Mb = this.yb = this.Lb = !1;
            this.ed = 0;
            this.Ea = null;
            this.dd = "";
            this.Zd = this.Zb = !1;
            this.Gb = this.Xb = null
        };
        _.Pd(El, _.md);
        _.m = El.prototype;
        _.m.wd = function() {
            this.dispose();
            _.Ra(wl, this)
        };
        _.m.setTrustToken = function(a) {
            this.Xb = a
        };
        _.m.setAttributionReporting = function(a) {
            this.Gb = a
        };
        _.m.send = function(a, b, c, d) {
            var e = this;
            if (this.J) throw Error("R`" + this.Ob + "`" + a);
            if (typeof b === "string") var f = b;
            else b && (f = b.method, c != null || (c = b.body), d != null || (d = b.headers));
            f = f ? f.toUpperCase() : "GET";
            this.Ob = a;
            this.Lb = !1;
            this.sa = !0;
            this.J = new XMLHttpRequest;
            this.J.onreadystatechange = (0, _.wf)(function() {
                return e.ad()
            });
            this.Zd && "onprogress" in this.J && (this.J.onprogress = (0, _.wf)(function(p) {
                Dl(e, p, !0)
            }), this.J.upload && (this.J.upload.onprogress = (0, _.wf)(function(p, q) {
                return Dl(e, p, q)
            })));
            try {
                this.Mb = !0, this.J.open(f, String(a), !0), this.Mb = !1
            } catch (p) {
                zl(this);
                return
            }
            a = c || "";
            b = new Map(this.headers);
            if (d)
                if (Object.getPrototypeOf(d) === Object.prototype)
                    for (var g in d) b.set(g, d[g]);
                else if (typeof d.keys === "function" && typeof d.get === "function") {
                g = _.v(d.keys());
                c = g.next();
                try {
                    for (; !c.done; c = g.next()) {
                        var h = c.value;
                        b.set(h, d.get(h))
                    }
                } finally {
                    _.yd(g, c)
                }
            } else throw Error("S`" + String(d));
            d = Array.from(b.keys()).find(function(p) {
                return "content-type" == p.toLowerCase()
            });
            h = _.x.FormData && a instanceof _.x.FormData;
            !((0, _.Qa)(vl, f) >= 0) || d || h || b.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
            f = _.v(b);
            d = f.next();
            try {
                for (; !d.done; d = f.next()) {
                    var k = _.v(d.value),
                        l = k.next().value,
                        n = k.next().value;
                    this.J.setRequestHeader(l, n)
                }
            } finally {
                _.yd(f, d)
            }
            this.dd && (this.J.responseType = this.dd);
            "withCredentials" in this.J && this.J.withCredentials !== this.Zb && (this.J.withCredentials = this.Zb);
            if ("setTrustToken" in this.J && this.Xb) try {
                this.J.setTrustToken(this.Xb)
            } catch (p) {}
            if ("setAttributionReporting" in this.J &&
                this.Gb) try {
                this.J.setAttributionReporting(this.Gb)
            } catch (p) {}
            try {
                this.Ea && (clearTimeout(this.Ea), this.Ea = null), this.ed > 0 && (this.Ea = setTimeout(this.me.bind(this), this.ed)), this.yb = !0, this.J.send(a), this.yb = !1
            } catch (p) {
                zl(this)
            }
        };
        _.m.me = function() {
            typeof _.ua != "undefined" && this.J && (this.dispatchEvent("timeout"), this.abort(8))
        };
        _.m.abort = function() {
            this.J && this.sa && (this.sa = !1, this.Aa = !0, this.J.abort(), this.Aa = !1, this.dispatchEvent("complete"), this.dispatchEvent("abort"), yl(this))
        };
        _.m.ia = function() {
            this.J && (this.sa && (this.sa = !1, this.Aa = !0, this.J.abort(), this.Aa = !1), yl(this, !0));
            El.xa.ia.call(this)
        };
        _.m.ad = function() {
            this.Ca() || (this.Mb || this.yb || this.Aa ? Bl(this) : this.Wd())
        };
        _.m.Wd = function() {
            Bl(this)
        };
        _.m.isActive = function() {
            return !!this.J
        };
        _.m.Kc = function() {
            try {
                return Al(this) > 2 ? this.J.status : -1
            } catch (a) {
                return -1
            }
        };
        _.m.getResponseHeader = function(a) {
            if (this.J && Al(this) == 4) return a = this.J.getResponseHeader(a), a === null ? void 0 : a
        };
        _.m.getAllResponseHeaders = function() {
            return this.J && Al(this) >= 2 ? this.J.getAllResponseHeaders() || "" : ""
        };
        _.Fl = function(a) {
            try {
                return a.J ? a.J.responseText : ""
            } catch (b) {
                return ""
            }
        };
        _.Gl = function(a, b) {
            return _.el(_.dl(a), a, void 0, b)
        };
        _.Hl = function(a, b, c) {
            return _.Gl(a.B, b) === c ? c : -1
        };
        _.Il = function(a, b) {
            return _.yb(_.N(a, b, void 0, _.Le))
        };
        _.ol = function(a) {
            var b = tl(a);
            if (typeof b == "undefined") throw Error("O");
            var c = new _.fd(null);
            a = sl(a);
            for (var d = 0; d < b.length; d++) {
                var e = b[d],
                    f = a[d];
                Array.isArray(f) ? _.vf(c, e, f) : c.add(e, f)
            }
            return c
        };
        _.Jl = function(a, b, c, d, e, f) {
            var g = new El;
            wl.push(g);
            b && g.O("complete", b);
            g.Pb("ready", g.wd);
            f && (g.Zb = f);
            g.send(a, c, d, e)
        };
        _.Kl = function(a) {
            this.B = _.B(a)
        };
        _.J(_.Kl, _.D);
        _.Ll = function(a, b) {
            return _.Bb(_.N(a, b, void 0, _.Le))
        };
        Ml = new _.rc(function(a, b, c) {
            if (a.i !== 2) return !1;
            a = a.u();
            kl(b, b[_.A] | 0, c).push(a);
            return !0
        }, function(a, b, c) {
            if (Array.isArray(b)) {
                var d = b[_.A] | 0;
                if (!(d & 4)) {
                    for (var e = 0, f = 0; e < b.length; e++) {
                        var g = _.Cb(b[e]);
                        g != null && (b[f++] = g)
                    }
                    f < e && (b.length = f);
                    e = (d | 5) & -1537;
                    e !== d && _.lb(b, e);
                    e & 2 && Object.freeze(b)
                }
            } else b = void 0;
            if (b != null)
                for (d = 0; d < b.length; d++) e = a, f = c, g = b[d], g != null && _.Se(e, f, _.za(g))
        }, _.Ue);
        Ol = void 0;
        Ol = Ol === void 0 ? _.qc : Ol;
        _.Nl = new _.rc(function(a, b, c, d, e) {
            if (a.i !== 2) return !1;
            var f = a.m;
            d = _.Xb(void 0, d);
            kl(b, b[_.A] | 0, c).push(d);
            f.call(a, d, e);
            return !0
        }, function(a, b, c, d, e) {
            if (Array.isArray(b)) {
                for (var f = 0; f < b.length; f++) {
                    var g = a,
                        h = c,
                        k = e,
                        l = _.tc(b[f], d);
                    l != null && (h = _.uc(g, h), k(l, g), _.vc(g, h))
                }
                a = b[_.A] | 0;
                a & 1 || _.lb(b, a | 1)
            }
        }, Ol);
        Pl = [0, _.Ze];
        _.Ql = [0, _.Ze, -2];
        _.Rl = function(a) {
            this.B = _.B(a)
        };
        _.J(_.Rl, _.D);
        _.m = _.Rl.prototype;
        _.m.j = function() {
            return _.P(this, 1)
        };
        _.m.l = function() {
            return _.Xi(this, 1)
        };
        _.m.m = function() {
            return _.P(this, 3)
        };
        _.m.A = function() {
            return _.Xi(this, 3)
        };
        _.m.u = function() {
            return _.P(this, 4)
        };
        _.m.C = function() {
            return _.Xi(this, 4)
        };
        _.m.D = function() {
            return _.Xi(this, 6)
        };
        _.m.h = function() {
            return _.Il(this, 7)
        };
        _.Sl = [0, _.Ze, -5, _.Ye, Pl, Ml, _.Ze, _.Ye, Ml, _.Ye, -1, Ml, -1];
    } catch (e) {
        _._DumpException(e)
    }
    try {
        /*
         Copyright The Closure Library Authors.
         SPDX-License-Identifier: Apache-2.0
        */
        var Tl, $l, bm, em, fm, Ul, Zl;
        Tl = function() {
            var a = null;
            if (!_.af) return a;
            try {
                var b = function(c) {
                    return c
                };
                a = _.af.createPolicy("goog#html", {
                    createHTML: b,
                    createScript: b,
                    createScriptURL: b
                })
            } catch (c) {}
            return a
        };
        _.Vl = function() {
            Ul === void 0 && (Ul = Tl());
            return Ul
        };
        _.Xl = function(a) {
            return "function" == typeof _.Wl && a instanceof _.Wl
        };
        _.Yl = function(a) {
            if (_.Xl(a)) return a.h;
            throw Error("H");
        };
        $l = function(a) {
            var b = _.Vl();
            a = b ? b.createHTML(a) : a;
            return new Zl(a)
        };
        _.am = function(a) {
            if (a instanceof Zl) return a.h;
            throw Error("H");
        };
        bm = function(a) {
            return a instanceof Zl ? a : $l(String(a).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;"))
        };
        em = function(a, b) {
            for (var c = [], d = a.length, e = 0, f = [], g, h, k = 0; k < d;) {
                switch (e) {
                    case 0:
                        var l = a.indexOf("<", k);
                        if (l < 0) {
                            if (c.length === 0) return a;
                            c.push(a.substring(k));
                            k = d
                        } else c.push(a.substring(k, l)), h = l, k = l + 1, cm ? (dm.lastIndex = k, l = dm.exec(a)) : (dm.lastIndex = 0, l = dm.exec(a.substring(k))), l ? (f = ["<", l[0]], g = l[1], e = 1, k += l[0].length) : c.push("<");
                        break;
                    case 1:
                        l = a.charAt(k++);
                        switch (l) {
                            case "'":
                            case '"':
                                var n = a.indexOf(l, k);
                                n < 0 ? k = d : (f.push(l, a.substring(k, n + 1)), k = n + 1);
                                break;
                            case ">":
                                f.push(l);
                                c.push(b(f.join(""),
                                    g));
                                e = 0;
                                f = [];
                                h = g = null;
                                break;
                            default:
                                f.push(l)
                        }
                        break;
                    default:
                        throw Error();
                }
                e === 1 && k >= d && (k = h + 1, c.push("<"), e = 0, f = [], h = g = null)
            }
            return c.join("")
        };
        fm = function(a, b) {
            if (void 0 === b) {
                b = a + "";
                var c = b.indexOf(".");
                b = Math.min(c === -1 ? 0 : b.length - c - 1, 3)
            }
            c = Math.pow(10, b);
            return {
                Yb: b,
                f: (a * c | 0) % c
            }
        };
        _.im = function(a, b, c, d) {
            (b = b(c || _.gm, d)) && b.i && a ? b.i(a) : (b = _.hm(b), a.innerHTML = _.am(b))
        };
        _.hm = function(a) {
            return _.Nd(a) ? a.fd && (a = a.fd(), a instanceof Zl) ? a : bm("zSoyz") : bm(String(a))
        };
        _.jm = function(a) {
            var b, c, d, e;
            return {
                id: (b = a.l()) != null ? b : null,
                givenName: (c = a.C()) != null ? c : null,
                displayName: (d = a.A()) != null ? d : null,
                profilePicture: (e = a.D()) != null ? e : null
            }
        };
        Zl = function(a) {
            this.h = a
        };
        Zl.prototype.toString = function() {
            return this.h + ""
        };
        _.lm = function(a, b) {
            return (b || document).querySelectorAll("." + a)
        };
        _.mm = function(a, b) {
            var c = b || document;
            c.getElementsByClassName ? a = c.getElementsByClassName(a)[0] : (c = document, a ? a = (b || c).querySelector(a ? "." + a : "") : (b = b || c, a = (a ? b.querySelectorAll(a ? "." + a : "") : b.getElementsByTagName("*"))[0] || null));
            return a || null
        };
        _.nm = function(a) {
            for (var b; b = a.firstChild;) a.removeChild(b)
        };
        _.om = function(a) {
            return a && a.parentNode ? a.parentNode.removeChild(a) : null
        };
        _.pm = function(a, b) {
            if (!a || !b) return !1;
            if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
            if (typeof a.compareDocumentPosition != "undefined") return a == b || !!(a.compareDocumentPosition(b) & 16);
            for (; b && a != b;) b = b.parentNode;
            return b == a
        };
        _.qm = function() {
            this.h = _.x.document || document
        };
        _.qm.prototype.appendChild = function(a, b) {
            a.appendChild(b)
        };
        _.qm.prototype.i = _.om;
        _.qm.prototype.contains = _.pm;
        var um;
        _.rm = {};
        _.sm = {};
        _.tm = {};
        um = function() {
            throw Error("ta");
        };
        um.prototype.xc = null;
        um.prototype.Ua = function() {
            return this.content
        };
        um.prototype.toString = function() {
            return this.content
        };
        um.prototype.fd = function() {
            if (this.yc !== _.rm) throw Error("ua");
            return $l(this.toString())
        };
        var vm = function() {
            um.call(this)
        };
        _.Pd(vm, um);
        vm.prototype.yc = _.rm;
        var Am, Bm, Dm, Gm, cm, dm, Nm, Om, zm, Pm, ym, Qm, Lm, Fm;
        _.wm = function(a) {
            if (a != null) switch (a.xc) {
                case 1:
                    return 1;
                case -1:
                    return -1;
                case 0:
                    return 0
            }
            return null
        };
        _.V = function(a) {
            return _.xm(a, _.rm) ? a : a instanceof Zl ? (0, _.U)(_.am(a).toString()) : (0, _.U)(String(String(a)).replace(ym, zm), _.wm(a))
        };
        _.U = function(a) {
            function b(c) {
                this.content = c
            }
            b.prototype = a.prototype;
            return function(c, d) {
                c = new b(String(c));
                d !== void 0 && (c.xc = d);
                return c
            }
        }(vm);
        Am = {};
        Bm = {};
        _.Cm = function(a, b, c) {
            var d = "key_" + a + ":",
                e = Am[d];
            if (e === void 0 || b > e) Am[d] = b, Bm[d] = c;
            else if (b == e) {
                if (c === Bm[d]) throw Error("va`" + a + "`");
                throw Error("wa`" + a + "`");
            }
        };
        _.Em = function(a) {
            var b = Bm["key_" + a + ":"];
            b || (b = Bm["key_" + a + ":"]);
            return b ? b : Dm
        };
        Dm = function() {
            return ""
        };
        Gm = function(a) {
            return em(String(a), function() {
                return ""
            }).replace(Fm, "&lt;")
        };
        cm = RegExp.prototype.hasOwnProperty("sticky");
        dm = new RegExp((cm ? "" : "^") + "(?:!|/?([a-zA-Z][a-zA-Z0-9:-]*))", cm ? "gy" : "g");
        _.W = function(a) {
            return _.xm(a, _.rm) ? _.Hm(Gm(a.Ua())) : String(a).replace(ym, zm)
        };
        _.Km = function(a) {
            return String(a).replace(_.Im, _.Jm)
        };
        _.Mm = function(a) {
            _.xm(a, _.sm) || _.xm(a, _.tm) ? a = String(a).replace(_.Im, _.Jm) : a instanceof _.Jc ? a = _.Km(_.Kc(a)) : "function" == typeof _.Wl && a instanceof _.Wl ? a = _.Km(_.Yl(a).toString()) : (a = String(a), a = Lm.test(a) ? a.replace(_.Im, _.Jm) : "about:invalid#zSoyz");
            return a
        };
        _.xm = function(a, b) {
            return a != null && a.yc === b
        };
        Nm = function() {
            um.call(this)
        };
        _.J(Nm, vm);
        _.X = function(a, b) {
            a.h !== void 0 ? a.h.push(b) : a.content += b;
            return a
        };
        _.Y = function(a, b) {
            a.h !== void 0 ? a.h.push(b) : b instanceof Nm ? b.content !== void 0 ? a.content += b.Ua() : (a.h = [a.content, b], a.content = void 0) : a.content += b;
            return a
        };
        Nm.prototype.Ua = function() {
            if (this.content !== void 0) return this.content;
            var a = "",
                b = _.v(this.h),
                c = b.next();
            try {
                for (; !c.done; c = b.next()) a += c.value
            } finally {
                _.yd(b, c)
            }
            return a
        };
        Nm.prototype.toString = function() {
            return this.Ua()
        };
        _.Z = function() {
            function a() {
                this.content = ""
            }
            a.prototype = Nm.prototype;
            return function() {
                return new a
            }
        }();
        Om = {
            "\x00": "&#0;",
            "\t": "&#9;",
            "\n": "&#10;",
            "\v": "&#11;",
            "\f": "&#12;",
            "\r": "&#13;",
            " ": "&#32;",
            '"': "&quot;",
            "&": "&amp;",
            "'": "&#39;",
            "-": "&#45;",
            "/": "&#47;",
            "<": "&lt;",
            "=": "&#61;",
            ">": "&gt;",
            "`": "&#96;",
            "\u0085": "&#133;",
            "\u00a0": "&#160;",
            "\u2028": "&#8232;",
            "\u2029": "&#8233;"
        };
        zm = function(a) {
            return Om[a]
        };
        Pm = {
            "\x00": "%00",
            "\u0001": "%01",
            "\u0002": "%02",
            "\u0003": "%03",
            "\u0004": "%04",
            "\u0005": "%05",
            "\u0006": "%06",
            "\u0007": "%07",
            "\b": "%08",
            "\t": "%09",
            "\n": "%0A",
            "\v": "%0B",
            "\f": "%0C",
            "\r": "%0D",
            "\u000e": "%0E",
            "\u000f": "%0F",
            "\u0010": "%10",
            "\u0011": "%11",
            "\u0012": "%12",
            "\u0013": "%13",
            "\u0014": "%14",
            "\u0015": "%15",
            "\u0016": "%16",
            "\u0017": "%17",
            "\u0018": "%18",
            "\u0019": "%19",
            "\u001a": "%1A",
            "\u001b": "%1B",
            "\u001c": "%1C",
            "\u001d": "%1D",
            "\u001e": "%1E",
            "\u001f": "%1F",
            " ": "%20",
            '"': "%22",
            "'": "%27",
            "(": "%28",
            ")": "%29",
            "<": "%3C",
            ">": "%3E",
            "\\": "%5C",
            "{": "%7B",
            "}": "%7D",
            "\u007f": "%7F",
            "\u0085": "%C2%85",
            "\u00a0": "%C2%A0",
            "\u2028": "%E2%80%A8",
            "\u2029": "%E2%80%A9",
            "\uff01": "%EF%BC%81",
            "\uff03": "%EF%BC%83",
            "\uff04": "%EF%BC%84",
            "\uff06": "%EF%BC%86",
            "\uff07": "%EF%BC%87",
            "\uff08": "%EF%BC%88",
            "\uff09": "%EF%BC%89",
            "\uff0a": "%EF%BC%8A",
            "\uff0b": "%EF%BC%8B",
            "\uff0c": "%EF%BC%8C",
            "\uff0f": "%EF%BC%8F",
            "\uff1a": "%EF%BC%9A",
            "\uff1b": "%EF%BC%9B",
            "\uff1d": "%EF%BC%9D",
            "\uff1f": "%EF%BC%9F",
            "\uff20": "%EF%BC%A0",
            "\uff3b": "%EF%BC%BB",
            "\uff3d": "%EF%BC%BD"
        };
        _.Jm = function(a) {
            return Pm[a]
        };
        ym = /[\x00\x22\x26\x27\x3c\x3e]/g;
        Qm = /[\x00\x22\x27\x3c\x3e]/g;
        _.Im = /[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g;
        Lm = /^[^&:\/?#]*(?:[\/?#]|$)|^https?:|^filesystem:https?:|^ftp:|^data:image\/[a-z0-9+-]+;base64,[a-z0-9+\/]+=*$|^blob:/i;
        _.Hm = function(a) {
            return String(a).replace(Qm, zm)
        };
        Fm = /</g;
        _.Rm = "0".codePointAt(0);
        var Sm;
        Sm = function(a) {
            return a % 10 == 1 && a % 100 != 11 ? "one" : a % 10 == 2 && a % 100 != 12 ? "two" : a % 10 == 3 && a % 100 != 13 ? "few" : "other"
        };
        _.Tm = Sm = function(a) {
            return a == 11 || a == 8 || a == 80 || a == 800 ? "many" : "other"
        };
        var Um;
        Um = function(a, b) {
            b = fm(a, b);
            return (a | 0) == 1 && b.Yb == 0 ? "one" : "other"
        };
        _.Vm = Um = function(a, b) {
            var c = a | 0;
            a = fm(a, b);
            return c == 1 && a.Yb == 0 ? "one" : c != 0 && c % 1E6 == 0 && a.Yb == 0 ? "many" : "other"
        };
        _.Wm = RegExp("'([{}#].*?)'", "g");
        _.Xm = RegExp("''", "g");
        _.Ym = Symbol("Ja");
        _.gm = {};
        _.Zm = function(a) {
            a = a || {};
            return (a = a.identifier) ? "Acceso eseguito come " + a : "Accesso eseguito"
        };
        _.$m = function(a) {
            return (0, _.U)((a ? '<svg class="' + _.W("Bz112c") + " " + _.W("Bz112c-E3DyYd") + " " + _.W("Bz112c-uaxL4e") + '" aria-hidden=true viewBox="0 0 192 192">' : '<svg class="' + _.W("fFW7wc-ibnC6b-HiaYvf") + " " + _.W("zTETae-mzNpsf-Bz112c") + " " + _.W("n1UuX-DkfjY") + '" aria-hidden=true viewBox="0 0 192 192">') + '<path fill="#3185FF" d="M96 8C47.42 8 8 47.42 8 96s39.42 88 88 88 88-39.42 88-88S144.58 8 96 8z"/><path fill="#FFFFFF" d="M96 86c12.17 0 22-9.83 22-22s-9.83-22-22-22-22 9.83-22 22 9.83 22 22 22zM96 99c-26.89 0-48 13-48 25 10.17 15.64 27.97 26 48 26s37.83-10.36 48-26c0-12-21.11-25-48-25z"/></svg>')
        };
        _.Cm("a", 0, function(a) {
            a = a || {};
            var b = a.Uc;
            return (0, _.U)((a.Hc ? '<svg class="' + (b ? _.W("Bz112c-u2z5K") : _.W("Bz112c-E3DyYd")) + " " + _.W("Bz112c-uaxL4e") + '" xmlns="https://www.w3.org/2000/svg" viewBox="0 0 48 48">' : '<svg class="' + (b ? _.W("Bz112c-u2z5K") : _.W("Bz112c-E3DyYd")) + '" xmlns="https://www.w3.org/2000/svg" viewBox="0 0 48 48">') + '<path fill="#4285F4" d="M45.12 24.5c0-1.56-.14-3.06-.4-4.5H24v8.51h11.84c-.51 2.75-2.06 5.08-4.39 6.64v5.52h7.11c4.16-3.83 6.56-9.47 6.56-16.17z"/><path fill="#34A853" d="M24 46c5.94 0 10.92-1.97 14.56-5.33l-7.11-5.52c-1.97 1.32-4.49 2.1-7.45 2.1-5.73 0-10.58-3.87-12.31-9.07H4.34v5.7C7.96 41.07 15.4 46 24 46z"/><path fill="#FBBC05" d="M11.69 28.18C11.25 26.86 11 25.45 11 24s.25-2.86.69-4.18v-5.7H4.34C2.85 17.09 2 20.45 2 24c0 3.55.85 6.91 2.34 9.88l7.35-5.7z"/><path fill="#EA4335" d="M24 10.75c3.23 0 6.13 1.11 8.41 3.29l6.31-6.31C34.91 4.18 29.93 2 24 2 15.4 2 7.96 6.93 4.34 14.12l7.35 5.7c1.73-5.2 6.58-9.07 12.31-9.07z"/><path fill="none" d="M2 2h44v44H2z"/></svg>')
        });
        _.Cm("b", 0, function() {
            return (0, _.U)('<svg version="1.1" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48" class="' + _.W("LgbsSe-Bz112c") + '"><g><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/><path fill="none" d="M0 0h48v48H0z"/></g></svg>')
        });
    } catch (e) {
        _._DumpException(e)
    }
    try {
        var dn, hn, jn, kn;
        _.an = function() {
            return ![_.Ga() && !_.qd() && !_.pd(), _.Ga() && _.Na(), _.z("Edge")].some(function(a) {
                return a
            })
        };
        _.en = function(a, b, c, d) {
            c = c === void 0 ? !0 : c;
            d = d === void 0 ? !1 : d;
            if (b && _.Oe(b, 7) === 2) {
                c = c === void 0 ? !0 : c;
                d = d === void 0 ? !1 : d;
                var e = {};
                b && (e = {
                    Wc: _.Oe(b, 6),
                    shape: _.Oe(b, 3),
                    size: _.Oe(b, 1),
                    text: _.Oe(b, 5),
                    theme: _.Oe(b, 2),
                    width: _.Ll(b, 4),
                    Ta: c,
                    Ba: d
                });
                _.im(a, bn, e)
            } else b && _.Oe(b, 10) === 2 && !_.I("disable_personalized_button") ? (c = c === void 0 ? !0 : c, d = d === void 0 ? !1 : d, b && _.Me(b, 8) ? (d = {}, b && (d = {
                    shape: _.Oe(b, 3),
                    text: _.Oe(b, 5),
                    theme: _.Oe(b, 2),
                    width: _.Ll(b, 4),
                    fe: _.jm(_.O(b, _.Rl, 8)),
                    ge: _.Ll(b, 9),
                    Ta: c
                }), _.im(a, cn, d)) : dn(a, b, c, d)) :
                dn(a, b, c, d)
        };
        dn = function(a, b, c, d) {
            c = c === void 0 ? !0 : c;
            d = d === void 0 ? !1 : d;
            var e = {};
            b && (e = {
                Wc: _.Oe(b, 6),
                shape: _.Oe(b, 3),
                size: _.Oe(b, 1),
                text: _.Oe(b, 5),
                theme: _.Oe(b, 2),
                width: _.Ll(b, 4),
                Ta: c,
                Ba: d
            });
            _.im(a, fn, e)
        };
        _.gn = function(a) {
            return _.Xi(a, 1)
        };
        hn = {};
        jn = function(a, b) {
            a = a.replace(/<\//g, "<\\/").replace(/\]\]>/g, "]]\\>");
            return b ? a.replace(/{/g, " \\{").replace(/}/g, " \\}").replace(/\/\*/g, "/ *").replace(/\\$/, "\\ ") : a
        };
        kn = function(a) {
            return _.xm(a, hn) ? jn(a.Ua(), !1) : a == null ? "" : jn(String(a), !0)
        };
        _.ln = function(a) {
            this.B = _.B(a)
        };
        _.J(_.ln, _.D);
        _.m = _.ln.prototype;
        _.m.m = function() {
            return _.Ab(_.N(this, 1))
        };
        _.m.A = function() {
            return _.Ab(_.N(this, 2))
        };
        _.m.l = function() {
            return _.Ab(_.N(this, 3))
        };
        _.m.D = function() {
            return _.Bb(_.N(this, 4))
        };
        _.m.u = function() {
            return _.Ab(_.N(this, 5))
        };
        _.m.h = function() {
            return _.Ab(_.N(this, 6))
        };
        _.m.C = function() {
            return _.Ab(_.N(this, 7))
        };
        _.m.j = function() {
            return _.Bb(_.N(this, 9))
        };
        var qn = function(a, b, c, d, e, f, g, h, k, l) {
                h = h === void 0 ? !0 : h;
                k = k === void 0 ? !1 : k;
                var n = l === void 0 ? !1 : l;
                l = f && f !== 1 ? _.V(mn(f)) : _.V(mn(2));
                var p = _.Z();
                h = "<div" + (h ? ' tabindex="0"' : "") + ' role="button" aria-labelledby="button-label" class="' + _.W("nsm7Bb-HzV7m-LgbsSe") + " " + (k ? _.W("Bz112c-LgbsSe") : "") + " " + (n ? _.W("TzA9Ye-LgbsSe") : "") + " ";
                n = "";
                switch (c) {
                    case 2:
                        n += "pSzOP-SxQuSe";
                        break;
                    case 3:
                        n += "purZT-SxQuSe";
                        break;
                    default:
                        n += "hJDwNd-SxQuSe"
                }
                a = _.X(_.Y(_.X(p, h + _.W(n) + " " + _.W(nn(d)) + " " + _.W(on(e)) + '"' + (g && !k ? ' style="width:' +
                    _.W(kn(g)) + 'px; max-width:400px; min-width:min-content;"' : "") + '><div class="' + _.W("nsm7Bb-HzV7m-LgbsSe-MJoBVe") + '"></div><div class="' + _.W("nsm7Bb-HzV7m-LgbsSe-bN97Pc-sM5MNb") + " " + (b === 2 ? _.W("oXtfBe-l4eHX") : "") + '">'), pn(a, d === 2 || d === 3)), (k ? "" : '<span class="' + _.W("nsm7Bb-HzV7m-LgbsSe-BPrWId") + '">' + _.V(mn(f)) + "</span>") + '<span class="' + _.W("L6cTce") + '" id="button-label">' + l);
                _.Y(a, ". Si apre in una nuova scheda");
                _.X(a, "</span></div></div>");
                return a
            },
            nn = function(a) {
                var b = "";
                switch (a) {
                    case 2:
                        b += "MFS4be-v3pZbf-Ia7Qfc MFS4be-Ia7Qfc";
                        break;
                    case 3:
                        b += "MFS4be-JaPV2b-Ia7Qfc MFS4be-Ia7Qfc";
                        break;
                    case 5:
                        b += "i5vt6e-to915-Ia7Qfc i5vt6e-Ia7Qfc";
                        break;
                    default:
                        b += "i5vt6e-Ia7Qfc"
                }
                return b
            },
            on = function(a) {
                var b = "";
                switch (a) {
                    case 2:
                        b += "JGcpL-RbRzK";
                        break;
                    case 4:
                        b += "JGcpL-RbRzK";
                        break;
                    default:
                        b += "uaxL4e-RbRzK"
                }
                return b
            },
            mn = function(a) {
                var b = "";
                switch (a) {
                    case 1:
                        b += "Accedi";
                        break;
                    case 3:
                        b += "Registrati con Google";
                        break;
                    case 4:
                        b += "Continua con Google";
                        break;
                    default:
                        b += "Accedi con Google"
                }
                return b
            },
            rn = function(a, b) {
                var c = "";
                if (b) switch (a) {
                    case 4:
                        c +=
                            "Continua come " + b;
                        break;
                    default:
                        c += "Accedi come " + b
                } else c += mn(a);
                return c
            },
            pn = function(a, b) {
                b = b === void 0 ? !1 : b;
                return _.Y(_.Z(), b ? _.X(_.Y(_.X(_.Z(), '<div class="' + _.W("nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf") + '"><div class="' + _.W("nsm7Bb-HzV7m-LgbsSe-Bz112c") + '">'), _.Em("b")(null, a)), "</div></div>") : _.X(_.Y(_.X(_.Z(), '<div class="' + _.W("nsm7Bb-HzV7m-LgbsSe-Bz112c") + '">'), _.Em("b")(null, a)), "</div>"))
            };
        var fn = function(a, b) {
                a = a || {};
                var c = a.Ta,
                    d = a.Ba,
                    e = a.Wc,
                    f = a.shape,
                    g = a.size,
                    h = a.text,
                    k = a.theme;
                a = a.width;
                c = c === void 0 ? !0 : c;
                d = d === void 0 ? !1 : d;
                return _.Y(_.Z(), qn(b, e, g, k, f, h, a, c, void 0, d))
            },
            bn = function(a, b) {
                a = a || {};
                var c = a.Ta,
                    d = a.Ba,
                    e = a.shape,
                    f = a.size,
                    g = a.text;
                a = a.theme;
                c = c === void 0 ? !0 : c;
                d = d === void 0 ? !1 : d;
                return _.Y(_.Z(), qn(b, void 0, f, a, e, g, void 0, c, !0, d))
            },
            cn = function(a, b) {
                var c = a.Ta,
                    d = a.fe,
                    e = a.ge,
                    f = a.shape,
                    g = a.text,
                    h = a.theme;
                a = a.width;
                var k = c === void 0 ? !0 : c;
                c = _.Z();
                k = k === void 0 ? !0 : k;
                f = _.X(_.Z(), "<div" +
                    (k ? ' tabindex="0"' : "") + ' role="button" aria-labelledby="button-label" class="' + _.W("nsm7Bb-HzV7m-LgbsSe") + " " + _.W("jVeSEe") + " " + _.W(nn(h)) + " " + _.W(on(f)) + '" style="max-width:400px; min-width:200px;' + (a ? "width:" + _.W(kn(a)) + "px;" : "") + '"><div class="' + _.W("nsm7Bb-HzV7m-LgbsSe-MJoBVe") + '"></div><div class="' + _.W("nsm7Bb-HzV7m-LgbsSe-bN97Pc-sM5MNb") + '">');
                a = d.givenName ? d.givenName : d.displayName;
                d.profilePicture ? (_.X(f, '<img class="' + _.W("n1UuX-DkfjY") + '" src="' + _.W(_.Mm(d.profilePicture)) + '" alt="'), k =
                    "Immagine del profilo di " + _.W(a ? a : d.id), _.Y(f, _.Hm(k)), _.X(f, '">')) : _.Y(f, _.$m());
                _.X(_.Y(_.X(_.Y(_.X(f, '<div class="' + _.W("nsm7Bb-HzV7m-LgbsSe-BPrWId") + '"><div class="' + _.W("ssJRIf") + '">' + _.V(rn(g, a)) + '</div><div class="' + _.W("K4efff") + '"><div class="' + _.W("fmcmS") + '">' + _.V(d.id) + "</div>"), e > 1 ? (0, _.U)('<svg class="' + _.W("Bz112c") + " " + _.W("Bz112c-E3DyYd") + '" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24"><path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"></path><path fill="none" d="M0 0h24v24H0V0z"></path></svg>') :
                    ""), "</div></div>"), pn(b, h === 2 || h === 3)), '</div><div id="button-label" class="' + _.W("L6cTce") + '">' + _.V(rn(g, a)) + ", " + _.V(d.id));
                _.Y(f, ". Si apre in una nuova scheda");
                _.X(f, "</div></div>");
                return _.Y(c, f)
            };
    } catch (e) {
        _._DumpException(e)
    }
    try {
        var $r;
        _.bs = function(a) {
            if ($r && a.dataset) return a.dataset;
            var b = {};
            a = a.attributes;
            for (var c = 0; c < a.length; ++c) {
                var d = a[c];
                if (d.name.lastIndexOf("data-", 0) == 0) {
                    var e = _.as(d.name.slice(5));
                    b[e] = d.value
                }
            }
            return b
        };
        _.cs = function(a, b) {
            var c = {},
                d;
            for (d in a)
                if (a.hasOwnProperty(d)) {
                    var e = a[d];
                    if (e) {
                        var f = d.toLowerCase(),
                            g = b[f];
                        if (g) {
                            var h = window;
                            switch (g) {
                                case "bool":
                                    e.toLowerCase() === "true" ? c[f] = !0 : e.toLowerCase() === "false" ? c[f] = !1 : _.H("The value of '" + d + "' can only be true or false. Configuration ignored.");
                                    break;
                                case "num":
                                    e = Number(e);
                                    isNaN(e) ? _.H("Expected a number for '" + d + "'. Configuration ignored.") : c[f] = e;
                                    break;
                                case "func":
                                    typeof h[e] === "function" ? c[f] = h[e] : _.H("The value of '" + d + "' is not a function. Configuration ignored.");
                                    break;
                                case "str":
                                    c[f] = e;
                                    break;
                                case "origin":
                                    c[f] = e.indexOf(",") >= 0 ? e.split(",") : e;
                                    break;
                                case "claims":
                                    c[f] = e.indexOf(",") >= 0 ? e.split(",") : e;
                                    break;
                                default:
                                    _.H("Unrecognized type. Configuration ignored.")
                            }
                        }
                    }
                }
            return c
        };
        _.as = function(a) {
            return String(a).replace(/\-([a-z])/g, function(b, c) {
                return c.toUpperCase()
            })
        };
        $r = !_.be && !_.Ha();
    } catch (e) {
        _._DumpException(e)
    }
    try {
        _.ds = function(a, b, c) {
            b.sentinel = "onetap_google";
            _.E("Message sent to " + c + ". " + JSON.stringify(b), "Message Util");
            a.postMessage(b, c)
        };
    } catch (e) {
        _._DumpException(e)
    }
    try {
        var gs, is, os, ks, ss, us;
        _.fs = function(a) {
            _.ds(window.parent, a, _.es)
        };
        gs = function() {
            this.i = void 0;
            this.h = {}
        };
        _.ns = function(a, b, c) {
            hs ? _.G("A previous attempt has been made to verify the parent origin and is still being processed.") : _.es ? (_.E("Parent origin has already been verified."), b && b()) : is(a) ? (js = a, ks(), a = _.od(), _.ds(window.parent, {
                command: "intermediate_iframe_ready",
                nonce: a
            }, "*"), hs = a, ls = b, ms = c) : _.H("Invalid origin provided. Please provide a valid and secure (https) origin. If providing a list of origins, make sure all origins are valid and secure.")
        };
        is = function(a) {
            if (typeof a === "function") return !0;
            if (typeof a === "string") return os(a);
            if (Array.isArray(a)) {
                for (var b = 0; b < a.length; b++)
                    if (typeof a[b] !== "string" || !os(a[b])) return !1;
                return !0
            }
            return !1
        };
        os = function(a) {
            try {
                var b = _.pf(a);
                if (!b.h || b.i !== "https" && b.h !== "localhost") return !1;
                var c = b.h;
                if (!c.startsWith("*")) return !0;
                if (!c.startsWith("*.")) return _.H("Invalid origin pattern. Valid patterns should start with '*.'"), !1;
                a = c;
                b = "Nb";
                if (ps.Nb && ps.hasOwnProperty(b)) var d = ps.Nb;
                else {
                    var e = new ps;
                    d = ps.Nb = e
                }
                a = a.split("").reverse().join("");
                var f = qs(d.h, a),
                    g = qs(d.i, a);
                g.length > 0 && (g = g.substr(0, g.lastIndexOf(".")), g.length > f.length && (f = g));
                var h = qs(d.j, a);
                h.length > 0 && a.length > h.length && h.length != g.length &&
                    (a = a.substr(h.length + 1), h += "." + a.split(".")[0], h.length > f.length && (f = h));
                var k = f.split("").reverse().join("");
                if (c.indexOf("." + k) < 2) return _.H("Invalid origin pattern. Patterns cannot be composed of a wildcard and a top level domain."), !1
            } catch (l) {
                return !1
            }
            return !0
        };
        ks = function() {
            rs || (rs = _.If(window, "message", function(a) {
                a = a.h;
                if (a.data) {
                    var b = a.data;
                    b.sentinel === "onetap_google" && b.command === "parent_frame_ready" && (_.E("Message received: " + JSON.stringify(b)), window.parent && window.parent === a.source ? hs ? b.nonce !== hs ? _.G("Message ignored due to invalid nonce.") : (ss(a.origin) ? (_.es = a.origin, _.ts = b.parentMode || "amp_client", ls && ls()) : (_.G("Origin verification failed. Invalid origin - " + a.origin + "."), ms && ms()), ms = ls = hs = void 0, rs && (_.Qf(rs), rs = void 0)) : _.G("Message ignored. Origin verifier is not ready, or already done.") :
                        _.G("Message ignored due to invalid source."))
                }
            }))
        };
        ss = function(a) {
            return typeof js === "string" ? us(js, a) : Array.isArray(js) ? js.some(function(b) {
                return us(b, a)
            }) : !1
        };
        us = function(a, b) {
            a = _.pf(a);
            b = _.pf(b);
            if (a.i !== b.i) return !1;
            a = a.h;
            b = b.h;
            return a.startsWith("*.") ? b.endsWith(a.substr(1)) || b === a.substr(2) : a === b
        };
        _.vs = function(a) {
            _.es ? _.fs({
                command: "intermediate_iframe_resize",
                height: a
            }) : _.G("Resize command was not sent due to missing verified parent origin.")
        };
        _.ws = function() {
            _.es ? _.fs({
                command: "intermediate_iframe_close"
            }) : _.G("Close command was not sent due to missing verified parent origin.")
        };
        _.xs = function(a) {
            _.es ? _.fs({
                command: "set_tap_outside_mode",
                cancel: a
            }) : _.G("Set tap outside mode command was not sent due to missing verified parent origin.")
        };
        gs.prototype.set = function(a, b) {
            ys(this, a, b, !1)
        };
        gs.prototype.add = function(a, b) {
            ys(this, a, b, !0)
        };
        var ys = function(a, b, c, d) {
            for (var e = 0; e < b.length; e++) {
                var f = b.charAt(e);
                a.h[f] || (a.h[f] = new gs);
                a = a.h[f]
            }
            if (d && a.i !== void 0) throw Error("Sa`" + b);
            a.i = c
        };
        gs.prototype.get = function(a) {
            a: {
                for (var b = this, c = 0; c < a.length; c++)
                    if (b = b.h[a.charAt(c)], !b) {
                        a = void 0;
                        break a
                    }
                a = b
            }
            return a ? a.i : void 0
        };
        gs.prototype.pa = function() {
            var a = [];
            zs(this, a);
            return a
        };
        var zs = function(a, b) {
            a.i !== void 0 && b.push(a.i);
            for (var c in a.h) zs(a.h[c], b)
        };
        gs.prototype.Va = function(a) {
            var b = [];
            if (a) {
                for (var c = this, d = 0; d < a.length; d++) {
                    var e = a.charAt(d);
                    if (!c.h[e]) return [];
                    c = c.h[e]
                }
                As(c, a, b)
            } else As(this, "", b);
            return b
        };
        var As = function(a, b, c) {
            a.i !== void 0 && c.push(b);
            for (var d in a.h) As(a.h[d], b + d, c)
        };
        gs.prototype.clear = function() {
            this.h = {};
            this.i = void 0
        };
        var ps = function() {
                this.h = Bs("&a&0&0trk9--nx?27qjf--nx?e9ebgn--nx?nbb0c7abgm--nx??1&2oa08--nx?apg6qpcbgm--nx?hbbgm--nx?rdceqa08--nx??2&8ugbgm--nx?eyh3la2ckx--nx?qbd9--nx??3&2wqq1--nx?60a0y8--nx??4x1d77xrck--nx?6&1f4a3abgm--nx?2yqyn--nx?5b06t--nx?axq--nx?ec7q--nx?lbgw--nx??883xnn--nx?9d2c24--nx?a&a?it??b!.&gro?lim?moc?sr,ten?ude?vog?yldnerb.pohs,?abila?c?ihsot?m?n??c!.&b&a?m?n??c&b?g?q??dino,ep?fn?k&s?y??ln?no?oc,p&i-on,ohsdaerpsym,?sn?tn?un?xob,ysrab,?i&ma?r&emarp?fa??sroc???d&ats?n&eit?oh??om?sa?tl??eg?f&c?ob??g!emo?naripi?oy??hskihs?i&dem!.remarf,?hs?k!on??sa!.&nomead,snduolc,xid,???jnin?k&aso?dov?ede?usto??l!.&gro?moc?ofni?r&ep?nb,?t&en?ni??ude?vog??irgnahs?le&nisiuc?rbmuder???m!.&ca?gro?oc?sserp?ten?vog??ahokoy?e00sf7vqn--nx?m??n!.&gro?moc?oc?t&en?la??vog??av?is?olecrab?tea??p!.&bog?ca?d&em?ls??g&ni?ro??mo&c?n??oba?ten?ude??c?g7hyabgm--nx?ra!.&461e?6pi?emoh?iru?nru?rdda-ni?siri???s??q!.&eman?gro?hcs?lim?moc?ten?ude?vog???r&az?emac?f4a3abgm--nx?n!d5uhf8le58r4w--nx??ukas??s!.&bup?dem?gro?hcs?moc?ten?ude?vog??ac!.uban.iu,?iv??t&ad?elhta?led?oyot??u!.&a&cinniv?emirc?i&hzhziropaz?stynniv?ttaprakaz??s&edo?sedo??tlay?vatlop??bs?cc,d&argovorik?o!ro&ghzu?hhzu???tl,?e&hzhziropaz?nvir?t??f&i?ni,?g&l?ro??hk?i&stvinrehc?ykstyn&lemhk?vypork???k&c?m?s&na&gul?hul??t&enod?ul??v&iknarf-onavi?orteporp&end?ind?????l&iponret?opotsa&bes?ves??p??m&k?oc?s?yrk??n&c?d?i?osrehk?v?ylov??o&c,nvor??p&d?p,z??r&c?imotihz?k?ymotyhz??sk?t&en?l?z??ude?v:c?e&alokin?ik??i&alokym?hinrehc?krahk?vl?yk??k?l?o&g!inrehc??krahk??r?,xc,y&ikstinlemhk?mus?s&akrehc?sakrehc?tvonrehc???z&ib,u????v!aj?bb?et?iv??waniko?x&a?iacal??yogan?z&.&bew?c&a?i&n?rga???gro?l&im?oohcs??m&on?t??o&c?gn??radnorg?sin?t&en?la??ude?vog?wal??zip!.korgn,???b&00ave5a9iabgm--nx?1&25qhx--nx?68quv--nx?e2kc1--nx??2xtbgm--nx?3&b2kcc--nx?jca1d--nx??4&6&1rfz--nx?qif--nx??96rzc--nx??88uvor--nx?a&0dc4xbgm--nx?c?her?n?ra?t??b!.&erots?gro?moc?o&c?fni??ten?ude?v&og?t??zib??a??c&j?s??d&hesa08--nx?mi??ew?g?l!.&gro?moc?ten?ude?vog??m??s!.&gro?moc?ten?ude?vog???tc-retarebsnegmrev--nx?u&lc!.&elej,snduolc,ysrab,?smas??p!.ysrab,??wp-gnutarebsnegmrev--nx??c&1&1q54--nx?hbgw--nx??2e9c2czf--nx?4&4ub1km--nx?a1e--nx?byj9q--nx?erd5a9b1kcb--nx??8&4xx2g--nx?c9jrb2h--nx??9jr&b&2h--nx?54--nx?9s--nx??c&eg--nx?h3--nx?s2--nx???a!.&gro?hcs,kcabdeef,lim?moc?rrd,smrof,ten?ude?vog??3a09--nx!.&ca1o--nx?gva1c--nx?h&ca1o--nx?za09--nx??ta1d--nx?ua08--nx????b&a?b?ci?f76a0c7ylqbgm--nx?sh??c!.&ce,e&ugaelysatnaf,zyrs,?gnipparcs,ku,liamwt,nwaps.secnatsni,pi-duolc,revres-emag,s&nduolc,otohpym,pparevelc,seccaptf,u,?u&e,g,wcc,?xsc,?0atf7b45--nx?a1l--nx??e!.&21k?apc?b&og?up??c&isp?od??dem?e&sab,uc?yg??f&ehc?orp??g&ba?ne?ro?tkm??hcet?jol?l&a&g?iciffo,s??im?ut??m&da?oc?se??n&gd?if?o&m?rga???o&csid?fni?i&r?u??rp??pprr?qisp?r&ab?bi?tn?ut??t&al?e&n?v??n&ed?o&c?do???of?qra?ra??ude?vog?xxx??beuq?n?smoc??fdh?i&lohtac?n&agro?ilc?osanap??sum?tic??l!.&gro?moc?oc?ten?ude?vog?yo,?l??m!.&mt?ossa??p1akcq--nx??n!.&mon?ossa??i?p??relcel?s!.&gro?moc?ten?ude?vog???t!s?w??v!.&gro?lim?moc?sndym,ten?ude?v&g:.d,,og????wp?yn??d&2urzc--nx?3&1wrpk--nx?c&4b11--nx?9jrcpf--nx???5xq55--nx?697uto--nx?75yrpk--nx?9ctdvkce--nx?a!d?er?olnwod??b!.&ca?di?gro?hcs?ia?lim?moc?o&c?fni??t&en?i??ude?v&og?t???2babgm--nx??c!.&cc,vog??g9a2g2b0ae0chclc--nx??e&m!bulc??r!k??sopxe?timil?w??fc?g!.&ude?vog???h&d3tbgm--nx?p?t??i!.&ased?bew?ca?e:noz,,hcs?ia?lim?o&c?g??pok?ro?sepnop?ten?y&kft9--nx?m??zib?\u1b36\u1b2e\u1b29??b?ordna?p?rdam??l&iub!.&0v,frusdniw,yadotpihs,??og?row??m!.ri,?n&a&b?l!raas???ob?uf??o&of?rp??r&a&c&tiderc?yalcrab??ugnav??ef506w4b--nx?k!.&oc,ude,?jh3a1habgm--nx??of??s!.&dem?gro?moc?ofni?ten?ude?v&og?t???m!kcrem???t!excwkcc--nx?l??uolc!.&2k.&3s,bps-ur.&3s,bl,etisbew,?citsale,etisbew,ksm-ur.&3s,bl,etisbew,??a&bura-vnej.&1ti,abura.rue.1ti,?xo:.&ku,nt,?,?b&altam,dnevar,ewilek:.sc,,?citsalej.piv,drayknil,e&lej,mohsnd,toj,?gnitsohdnert.&ed,hc,?le&temirp:.ku,,varal,?m&edaid,ialcer.&ac,ku,su,??n&evueluk,woru,?paz,qhelbavresbo,r&e&polroov,vres-enilno,?gtsh,o&pav,tnemele,??secivres-nosinu,t&enraxa.1-se,ikcatsno.snur,lobevres,negreme,sinogatna,?ululetoj,wcs.&gnilebaltrams,koobelacs,latemerab.&1-&rap-rf,sma-ln,?2-rap-rf,?rap-rf.&3s,bd&gm,r,?cnf:.snoitcnuf,,etisbew-3s,hwtd,kfak,l&bcs,dd,?mhw,rfi,s8k:.sedon,,tipkcoc,?s&8k,ecnatsni.&bup,virp,?ma-ln.&3s,bd&gm,r,?etisbew-3s,hwtd,kfak,l&bcs,dd,?mhw,rfi,s8k:.sedon,,tipkcoc,??waw-lp.&3s,bd&gm,r,?etisbew-3s,hwtd,kfak,l&bcs,dd,?rfi,s8k:.sedon,,tipkcoc,??xe&lpciffart,vnoc:.1-ts&ae-su,ew-ue,?,?yawocne.ue,??za5cbgn--nx??e&1&53wlf--nx?7a1hbbgm--nx?ta3kg--nx??2a6a1b6b1i--nx?3ma0e1cvr--nx?418txh--nx?707b0e3--nx?a!.&ca?gro?hcs?lim?oc?ten?vog??09--nx??b!.&ca?etisbew321,gnitsohbew:.etis,,nevueluk.yxorpze,pohsdaerpsym,sn&duolc,oitulostsohretni.duolc,?ym,?ortal?ut!uoy???c&0krbd4--nx!.&a2qbd8--nx?b8adbeh--nx?c6ytdgbd4--nx?d8lhbd5--nx???a&lp!.oc,?ps!.&fh:.citats,,lla4sx,rebu,sonoi-ppa,t&cejorp,negayolped,s&afym,ohebiv,??uyieh,?artxe??sla??i!ffo??n&a&d?iler?nif?rusni!efil?srelevart???eics??rofria??d!.&1sndnyd,4&2pi-nyd,6&emoh,vpi,??7erauqs,amil4,b&ow-nrefeilgitsng--nx,rb-ni,ur,vz-nelletsebgitsng--nx,?cessnd&d,nyd,?decalpb,e&daregtmueart,luhcsvresi,mohsnd,nihcamyek,tiesbew321,?gifnocecapsbew,hcierebsnoissuksid,k&codluhcs,eegnietsi,?lsd-ni,m&oc,rofttalpluhcs,uhcob-inu-rhur:.con.oi,,?n&-i-g-o-l,e&lletsebgitsn\u00fcg,sgnutiel,?i&emtsi,lreb-n&i,yd,??norblieh-sh.ti.&hcraeser-segap,segap,?pv-ni,refeilgitsn\u00fcg,?o&c,rp-ytinummoc,?p&h21,iog:ol,,ohsdaerpsym,?re&ntrapdeeps.remotsuc,su&-lautriv,lautriv,?t&adpusnd,tub-ni,uor-ym,?vres&-e&bucl,mohym,?bew-emoh:.nyd,,luhcs,??s&nd&-&nufiat,sehcsimanyd,tenretni,?isoc.nyd,mieh,ps,vrs,?oper-&nvs,tig,?sndd:.&nyd,sndnyd,?,?vresi-&niem,tset,?xi2,y&awetag-&llawerif,ym,?m,srab,tic-amil,?zten&mitbel,sadtretteuf,??art?i&sdoow?ug??on--nx??e!.&bil?dem?eif?gro?irp?kiir?moc?pia?ude?vog??ei?ffoc?gg?r&f?ged???f&a&c?s??il??g!.&byc?cll?enilno?gro?loohcs?moc?t&en?vp??ude?vog?xnt??a&f?gtrom?p!.&grebedoc,kselp,mea,s&ndp,ruelfxued,?tsohcitats,wolfyeh,x&lh,obym,?y&cvrp,kcor,???rots?yov??elloc?na&hcxe?ro!.hcet,??roeg?ug??i!.&pohsdaerpsym,vog??tilop?v&bba?om???j!.&fo,gro?oc?ten???k!.&c&a?s??e&m?n??ibom?o&c?fni?g??ro??i&b?l?n???l&a&dmrif?s!rof???b&a?i&b?dua???c&aro?ric??dnik?g!oog??i&bom?ms??l&asal?erauqa??ppa!.tni,?uhcs?yts!efil???m!.&4&32i,p&ct,v,??66c,ailisarb,c&a?ooh.xorpes,?duolc&nepo,sd,?g&ro?s-raegelif,?k&catsegde,org,?noitatsksid,o&c?t&nigol,poh,??p&i&on,snart.etis,?ohbew,?r&aegelif,idcm,ofsnd,?s&dym,ndd,ti?umhol,?t&en?farc,s&acdnuos,ohon,??ude?v&irp?og??xobym,y&golonys,srab,??a&g?n!.&citeneek,re&ganampsi,h.togrof,?sih.togrof,???em?irp?orhc?w??n!goloc?i&lno!.&egats-oree,koob,llecpael,oree,redliubetisbew,sndmieh,ysrab,??w??o!.e&civres,tisbew,?hp?latipac?tse&gdirb?rif??z!.&amil,sporez-1grp,tikcats,???ruoblem??om?p!.&bog?gro?lim?mo&c?n??ten?ude??irg?yks??r!.&bilten,moc?nac,ossa??a&c!htlaeh??pmoc?wtfos??bc?eh?if?ots!.&e&rawpohs,saberots,?y&flles,srab,???taeht?u&ces?sni?t&inruf?necca??za???s!.&a!disnim321,?b!ibnal?rofmok??c!a??d!b?n&arb?ubroflanummok???e?f?g!ro??h!f??i!trap??k!shf??l?m!oc,t??n!mygskurbrutan??o?p!ohsdaerpsym,p??r!owebdluocti,?s!serp?yspoi,?t?u?vhf?w?x!uvmok??y?z??a&c!.vas,?el?hc??i&er?urc??nesemoh?roh?uoh??t&a&d?ts&e!laer??lla???is!.&a&mgif,vnac.ym,?bewwuoj,derauqspw,e&docyalp,lej,ni&effac,lnigol,?r&auqs,ocevon,?winmo,?l&aicosnepo,enapc,os,?n&eyb,o&iton,yc,??oc,retup,s&ihtedam,pvtsaf,?t&farcecruos,hrs,pgtahc,roppus,?vog-amgif,w&cs:.&sma,waw,?,eiverp,olfyeh,?x&evnoc:.1-ts&ae-su,ew-ue,?,obeip,?ysrab,?bew!.remarf,??ov?ra?t&ioled?ol??utitsni??u&lb?qi&nilc?tuob???v!.&21e?ai?b&ew?ib?og??ce&r?t??e&dnerpme?rots??gro?lim?m&o&c?n??rif??o&c?fni??rar?stra?t&en?ni??ude?vog??as?e3gerb2h--nx?i&l!.&mea,xlh,??rd?ssergorp??ol??w&kct--nx?r??xul?y!.&gro?lim?moc?ten?ude?vog????f&0f3rkcg--nx?198xim--nx?280xim--nx?7vqn--nx?a!.&gro?moc?ten?ude?vog???b!.vog?wa9bgm--nx??c!a1p--nx!.&a14--nx,b8lea1j--nx,c&avc0aaa08--nx,ma09--nx,?f&a1a09--nx,ea1j--nx,?gva1c--nx,nha1h--nx,pda1j--nx,zila1h--nx,??ns??ea1j--nx?g?iam?l&a1d--nx?og??n!.&bew?cer?erots?m&oc?rif??ofni?re&hto?p??stra?ten???orp?p!.&gro?moc?ude???rus?t!.hcs,w!.sndd,??w!.&hcs,zib,???g&2&4wq55--nx?8zrf6--nx??3&44sd3--nx?91w6j--nx!.&a5wqmg--nx?d&22svcw--nx?5xq55--nx??gla0do--nx?m1qtxm--nx?vta0cu--nx????455ses--nx?5mzt5--nx?69vqhr--nx?7&8a4d5a4prebgm--nx?rb2c--nx??a!.&gro?jbo,mo&c?n??oc?ten??vd??b!.&0?1?2?3?4?5?6?7?8?9?a?b?c?d?e?f?g?h?i?j?k?l?m?n?o?p?q?r?s?t?u?v?w?x?y!srab,?z???c!b?za9a0cbgm--nx??e!.&ca?em!an??gro?ics?lim?moc?nue?ofni?t&en?rops??ude?v&og?t???a??g!.&gro?hsadtob,lenap:.nomead,,oc?saak,t&en?ikcats,?ylp.6d,??i&a?v??k!.&ea,gro?lim?moc?su,ten?ude?vog?xx,??m!.&drp?gro?lim?mo&c?n??oc?ude?vog??pk??n!.&clp,dtl,eman?gro?hcs?i!bom??l&im?oc,?m&oc?rif,?neg,ogn,ten?ude?vog?zib:.&gl,ld,no,o&c,g,??,?aw?i!b!mulp??car?d&art?dew??h&sif?tolc??k&iv?oo&b?c???ls?n&aelc?iart??p!pohs??re&enigne?tac??t&ad?ekram?hgil?lusnoc?neg?ov?soh!.tfarcnepo,??vi&g?l???o!s??u&rehcisrev?smas?tarebsneg\u00f6mrev???o&d?lb?og!.&duolc,etalsnart,???r&2n084qlj--nx?ebmoolb?o!.&77ndc.c:sr,,a&remacytirucesym,t&neimip,sivretla,?xor,z,?bew-llams,cimanyd-pi,d&ab-yrev-si,e&sufnocsim,vas-si,?nuof-si,oog-yrev-si,uolc&arfniarodef,ehtgnituor,mw:.ateb,,??e&a,cin-yrev-si,grof&loot,peh,?l&as-4-ffuts,poeparodef,?m&-morf,agevres,ohruoyslles,?nozdop,r&ehwongniogyldlob,iwym,uces-77ndc.nigiro.lss,?t&adidnac-a-si,is&-ybboh,golb,???fehc-a-si,golbymdaer,k&eeg-a&-si,si,?h,nut,?l&acol-si,i&amwt,ve-yrev-si,?lawerif&-ym,ym,?sd-ni,?m&acssecca,edom-elbac,?n&af&blm,cfu,egelloc,lfn,s&citlec-a-si,niurb-a-si,tap-a-si,?xos-a-si,?ibptth,orviop,p&j,v-ni,??o&jodsnd,tp&az,oh,??p&i&-on,fles,?o&hbew,tksedeerf,?tf&e&moh,vres,?ym,??r&e&gatop,ppepteews,su-xunil-a-si,?vdmac,?s&a&ila&nyd,snd,?nymsd,?b&alfmw,bevres,?d&ikcet.3s,ylimaf,?e&gapsf,irfotatophcuoc,?j,koob-daer,ltbup,nd&-won,deerf,emoh,golb,kcud,mood,nyd:.&emoh,og,?,p&d,s,?rvd,tog,uolc,?s&a-skcik,ndd,?tnemhcattaomb,u,?t&ce&jorparodef.&duolc,gts.so.ppa,so.ppa,?riderbew,?e&ews-yrev-si,nretni&ehtfodne,fodne,??hgink-a-si,s&ixetn&od,seod,?o&h-emag,l-si,???ue:.&ac,dc,e&b,d,e,i,m,s,?g&b,n,?hc,i&f,s,?k&d,m,s,u,?l&a,i,n,p,?n&c,i,?o&n,r,ssa,?pj,r&f,g,h,k,t,?s&e,i,u,?t&a,en,i,l,m,ni,p,?u&a,de,h,l,r,?vl,y&c,m,?z&c,n,??,vresnyd,x&inuemoh,unilemoh,?y&limafxut,raidanetah,srab,???ub&mah?oj???s!.&delacsne,gro?moc?ten?ude?vog??gb639j43us5--nx??t?u!.&c&a?s??en?gro?lim?moc?o&c?g??ro?su?ude?vog???v!.ude?a1c--nx??wsa08--nx??h&0ee5a3ld2ckx--nx?4wc3o--nx!.&a&2xyc3o--nx?3j0hc3m--nx?ve4b3c0oc21--nx??id1kzuc3h--nx?l8bxi8ifc21--nx?rb0ef1c21--nx???8&8yvfe--nx?a7maabgm--nx??b!.&gro?moc?ten?ude?vog??mg??c!.&7erauqs,amil4,duolc-drayknil,e&garotstcejbo.&amr,gpl,?lacsduolc.&amr.stcejbo,gpl.stcejbo,tsuc,?tisbew321,?gniksnd,p&h21,ohsdaerpsym,?snd&tog,uolc,?wolf.e&a.1pla,nigneppa,?xi2,ytic-amil,?aoc?et!.spparevelc,?ir!euz??r&aes?uhc??sob?taw!s???d0sbgp--nx?f&2lpbgm--nx?k??g!.&gro?lim?moc?ten?ude?vog?zib???k!.&gro?moc?ten?ude?vog???m!a1j--nx??ocir?p!.&gro?i?lim?moc?ogn?snduolc,ten?ude?vog???s!.&adtob,e&grus,lbavol,?g&nabhsah,ro??lim?m&oc?roftalp.&su,tne,ue,??t&en?ropelet,?vog?won,?a&c?nom??i&d?f?ri???t!.&ca?enilno,im?ni?o&c?g??pohs,ro?ten??iaf?laeh!.arh,?orxer?rae??vo!.lopdren,?zb??i&3tupk--nx?7a0oi--nx?a!.&ffo?gro?moc?remarf,sppaolik,ten?uwu,?1p--nx?bud?dnuyh?tnihc??b!.&gro?moc?oc?ro?ude??ahduba?o!m!.&duolcsd,ysrab,???s??c!.&ayb-tropora--nx?ca?de?gro?moc?o&c?g?ssa??ro?su,t&en?ni?ropor\u00e9a??ude?vuog??cug?t??d&dk?ua??e&bhf--nx?piat??f!.&aw5-nenikkh--nx,dnala?i&ki,spak,?mroftalpduolc.if,nenikk\u00e4h,pohsdaerpsym,uvisitok321,yd,?onas??g!.&d&om?tl??gro?moc?ude?vog???h&c&atih?ra??s&abodoy?ibustim???juohs?k!.&gro?moc?ofni?ten?ude?vog?zib??b4gc--nx?iw!.remarf,?nisleh?s?uzus??l!drahcir?iamsi??maim?n!.&b&ew?og??ca?gro?lim?mo&c?n??ni?o&c?fni??pp?t&en?ni??ude?zib??airpic?i&hgrobmal?m??re??om?rarref?s!.&5f,egaptig,?ed??t&i&c?nifni??rahb??ut?v!.&21k?gro?moc?oc?ten???wik?xa&rp?t??yf??j&6pqgza9iabgm--nx?8da1tabbgl--nx?b!.&acirfa?eto?gro?m&oc?siruot??o&c!e??fni?noce?rga?tser??russa?s&etcetihcra?risiol?tacova??t&en?naruatser??ude?vinu?yenom???d?f!.&ca?di?eman?gro?lim?moc?o&fni?rp??ten?ude?vog?zib???nj?s?t!.&bew?cin?eman?gro?lim?moc?o&c?g??t&en?ni?set??ude?vog?zib???yqx94qit--nx??k&8uxp3--nx?924tcf--nx?arfel?c&a&bdeef?lb??ebdnul?ilc?rem!e???d!.&e&disemmejh321,rots,?ger,mrif,oc,pohsdaerpsym,zib,?t??e&es?samet??h!.&a&4ya0cu--nx?5wqmg--nx??b3qa0do--nx?cni,d&2&2svcw--nx?3rvcl--nx??5xq55--nx?tl,?g&a0nt--nx?la0do--nx?ro??i&050qmg--nx?7a0oi--nx?xa0km--nx??m&1qtxm--nx?oc??npqic--nx?ten?ude?v&di?og?ta0cu--nx??xva0fz--nx?\u4eba&\u4e2a?\u500b?\u7b87??\u53f8\u516c?\u5e9c\u653f?\u7d61&\u7db2?\u7f51??\u7e54&\u7d44?\u7ec4??\u7ec7&\u7d44?\u7ec4??\u7edc&\u7db2?\u7f51??\u80b2&\u654e?\u6559???n??i&tsob?vdnas??l!.&bew?c&a?os??dtl?gro?hcs?letoh?moc?nssa?ogn?prg?t&en?ni??ude?vog??at?cd?is??m!.&eman?fni?gro?moc?ten?ude?vog???n&ab!cfdh?etats?mmoc?t&en?fos??u??i!l!.&a&hcarots.sfpi,vnac,?c&iteneek,mnioj,?egarotstfn.sfpi,noyc,pepym,s3w.sfpi,ztirfym,??p???oob?p!.&b&ew?og??ca?g&og?ro??kog?m&af?oc??p&kg?og??sog?ten?ude?vog?zib???row!.&retup,yxorp-enigami,?ten!.&etirwppa,htumiza,mea,nolt,o&c,vra,????s!.gro??t?u!.&c&a?lp??dtl?e&cilop?m?tismin,?gro!.&gul:g,,sgul,yr&ettoly&lkeew,tiniffa,?tneelffar,???lenap-tnednepedni,n&noc,oissimmoc-&layor,tnednepedni,??o&c!.&bunsorter.tsuc,enilnoysrab,omida,p&i-on,ohsdaerpsym,?tfihsreyal.j,vres-hn,ysrab,??rpoc,?psoh,shn?t&en?nmyp,seuqni-tnednepedni,?vog!.&ecivres,ipa,ngiapmac,??weiver-tnednepedni,y&riuqni-&cilbup,tnednepedni,?srab,????l&04sr4w--nx?a!.&gro?lim?moc?ten?ude?vog??bolg!.etirwppa,?c?ed?g!el??i&c&nanif!.oc,lpl??os??romem?tnedurp??n&if?oitanretni??t&i&gid?p&ac?soh???ned?ot???c!.&bog?lim?oc?snduolc,vog???dil?e&datic?n&ahc?nahc!rehtaew???t!oh?ria?tam??vart??f&8f&pbgo--nx?tbgm--nx??a?n??g!.&gro?moc?oc?ten?ude???h&d?op??i!.&21k?ca?fdi?gro?inum?oc!.&egapvar,redrotibat,tibatym,??ten?vog??a&f?m&e!.&hcuotni,kwat.p,otkwat.p,??g?toh???m?r??l&a&b&esab?t&eksab!.&sua,zn,??oof???c?mt??e&d?hs??ihmailliw?j??m!.&ca?esserp?gro?moc?o&fni?ssa??rp?t&en?ra?sni??ude?v&og?uog????n!.&etisbew321,no&med,rtsic,?oc,pohsdaerpsym,retsulc-gnitsoh:.etis,,vog,yalphk,?o??o&a?btuf?l!.gmo,?o&c!.&ed,rotnemele,??hcs??rit?u??p!.&2uoy,a&cin&diws?gel??d&g,ortso?urawon??i&dem?mraw?nydg,?k&elo&guld?rtso??slopolam?tsu?ytsyrut??l&ip?o&kzs?w&-awolats?oksnok????mrifd,n&erapohs,img?zcel,?rog&-ai&bab?nelej??j?z??syn?tsaim?w&a&l&eib?i?o??zsraw??o&namil?tainop,??z&eiwolaib?mol???c&e&iw&alselob?o&nsos?rtso???le&im?zrogz???orw,p??d&em,ia?ragrats?uolc&inu,sds,??e&c&i&lrog?naibap,w&einreiks,ilg,o&hc&arats?orp??klop?tak????yzreibok??i&csjuoniws?ksromop?saldop??l&ahdop?opo??napokaz,t&atselaer?iselpmis,?z&romop?swozam???g&alble?ezrbo&lok?nrat??ro??hcyzrblaw?i&csomohcurein?grat?klawus??k&colp,e&rut?walcolw??in&byr?diws,sark,?le?o&nas?tsylaib??rob&el?lam??s&als?jazel?nadg,puls?rowezrp???l&colw?e&r?vart??i&am?m???m&o&c?dar?n?tyb??s&g?iruot??t!a???n&a&gaz?nzop,?i&bul?cezczs?lbul,molow?nok?zd&eb?obeiws???u&leiw?rot,?y&tzslo?z&rtek?seic????o&c,fni?k&celo?sleib,zdolk??lkan?n&leim?pek?t&uk?yzczs??z&copo?eing?rowaj???rga?t&nokd,ua??w&ejarg?ogarm???p&e&eb,lks!emoh,??klwwortso?ohs!-ecremmoce,daerpsym,??romophcaz?s&hqi,klofc,os??t&aiwop?en?opos,ra,sezc??ude?v&irp?og!.&a&io?p?s!w???bni&p?w??ci?dtiw?e&ko?ss&p?w???fiw?g&imu?u??hiiw?m&igu?rio?u!o???nds!ipz??o&ks?p!pu??s?wtsorats??p&a?sp!mk?pk?wk??u&m?p??wk?z??r&hcso?ksw?p?s??s&i?oiw?u?zu??talusnok?w&gzr?i&p?rg?w??m?o&o?pu??u!imzw???z&kw?ouw?????w&a&l&corw?sizdow??w??o&golg?k&ark,ul?zsurp??r&az?gew??t&rabul,sugua??z&coks?sezr????xes?y&buzsak?d&azczseib?ikseb??hcyt?n&jes?lod-zreimizak??pal?r&ogt?uzam??walup?zutrak??z&am-awar?c&aprak?iwol?zsogdyb??d&a&lezc?reis,?ol,?ib?reigz,s&i&lak?p??uklo????l??r&as?f?s??s!.&gro?moc?ten?ude?vog???t!.vog??ubnatsi?x3b689qq6--nx?yc5rb54--nx??m&00tsb3--nx?1qtxm--nx?981rvj--nx?a!.&enummoc?gro?moc?o&c?idar,?ten??c!bew??dretsma?e&rts?t!.&citsalej,esruocsid,???fma?xq--nx??b!.&gro?moc?ten?ude?vog??i??c!.&moc?oc?ten?vog???d!.&gro?moc?oc?ten?ude?vog???f!.&gro?moc?oidar,ten?ude??i??g!vu96d8syzf--nx??h?i!.&ca?gro?moc?oc!.&clp?dtl???t&en?t??vt??k?rbg4--nx??k!.&drp?e&rianiretev?sserp??gro?lim?m&o&c?n??t??nicedem?ossa?pooc?s&eriaton?neicamrahp?sa??ude?v&og?uog????l&if?ohkcots??o!.&dem?gro?m&oc?uesum??o&c?rp??ten?ude?vog??b?c!.&0x,1dna1-sppa,2aq,3pmevres,a&c&-morf,irfa,?g&-morf,oy-sehcaet,?i-morf,m&-morf,all&-a-si,amai,??p&-morf,c-a-si,?remacytirucesym,s,t&adtsudgniht,emta,?v-morf,w-morf,z,?bew&-sndnyd,arukas,draiw.segap,ottad,?c&amytirucesemoh,d-morf,esyrcs,itsalej.omed,n&-morf,vym,?p&kroweht,ytirucesemoh,?rievres,s-morf,?d&aerotffuts,e&bme-detsoh-avnac,calpb,ifitrec-&si,ton-si,?rewopenignepw:.sj,,tsoh&-scodehtdaer,2a,ecapsppa,??i&-morf,parpc,rgevissam.saap,?m-morf,n&-morf,abeht-htiw-si,?orpnonduolcwm,s-morf,uolc&-noitatsyalp,ehtgnituor,hr,iafaw.d&ej,yr,?meaeboda,n.egarotstcejbo.&gs,rk,?panqym,s&anym,metsystuo,?ved&j,pw,??vreser,wetomer,?e&butuoyhtiw,c&apsylop,i&ffo-sndnyd,vedlootx,??d:-morf,o&c&avnac,elgoog,?n&il.srebmem,neve.&1-&su,ue,?2-&su,ue,?3-&su,ue,?4-&su,ue,????,erf&-sndnyd,sndd,?filflahevres,g&arots&-77ndc,duolcn&-&nif.&etavirp.tcejbo.rk,tcejbo.rk:.etisbew-3s,,?vog.&etavirp&-rk,.tcejbo.&rk,srk,??rk,tcejbo.&rk:.etisbew-3s,,srk:.etisbew-3s,,???.&et&avirp&-rk,.tcejbo.&gs,rk,??isbew.&r&evan-rk,k,?ved-revan-rk,??r&evan-rk,k,?tcejbo.&ed:.etisbew-3s,,gs:.etisbew-3s,,rk:.etisbew-3s,,su:.etisbew-3s,,?ved-revan-rk,??pcn.&etavirp.tcejbo.&4pj.pj,5pj.pj,pj,rk,?tcejbo.&4pj.pj,5pj.pj,pj:-etisbew-3s,,rk,???de-yltsaf,nahcxeevres,rof-no,?i&hcet-a-si,p-sekil,?k&auqevres,irtsretnuocevres,?l&bitpa-no,googhtiw,?m&agevres,ina-otni-si,oh-&sndnyd,ta-sndnyd,??n&-morf,ilnoysrab,og-si,?pacsledom,r&alfduolcyrt,ehwynanohtyp:.ue,,ihcec,?srun-a-si,t&i&nuarepo,s&-ybboh,aloy,bew-evil,elpmis,rodabew,tipohs,xiw,??omer-sndnyd,ysgolb,?v&als-elcibuc-a-si,itavresnoc-a-si,?z&amkcar,eelg,iig,??fehc-a-si,g&ni&gats-&raeghtua,swennwot,?ksndd,robsikrow,tsoh&-bt.etis,edalbderiw,ovip,unyd,??o&fgp,lb&-sndnyd,anetah,sihtsetirw,???h&n-morf,o-morf,?i&fiwehtno,h-morf,kiw-sndnyd,m-morf,p&aerocne,detsoh,?r-morf,w-morf,z&ihcppa,nilppa,??jn-morf,k&a&-morf,erfocsic,?cils-si,eeg&-a&-si,si,?sndd,?h,latsnaebcitsale:.&1-&ht&ron-ue,uos-&em,fa,pa,ue,??lartnec-&ac,em,li,ue,?ts&ae&-&as,pa,su,vog-su,?ht&ron-pa,uos-pa,??ew-&ac,su,ue,vog-su,???2-&htuos-&pa,ue,?lartnec-ue,ts&ae&-su,ht&ron-pa,uos-pa,??ew-&su,ue,???3-ts&aeht&ron-pa,uos-pa,?ew-ue,?4-tsaehtuos-pa,5-tsaehtuos-pa,6-tsaehtuos-pa,7-tsaehtuos-pa,?,nil-kaerts,o-morf,r&adhtiwtliub,ow&-&sndnyd,ta-sndnyd,?ten-orehkcats,??sedal,u,?l&a&-morf,colottad,rebil-a-si,?f-morf,i&-morf,a&m&-sndnyd,detsohpw,?sthgilnozama,??lecelffaw,ru-&elpmis,taen,??m&n-morf,rof&e&pyt.orp,rerac-htlaeh,?talp-evird,?sacrasevres,uirarret-yltsaf,?n&a&cilbuper-a-si,f&-sllub-a-si,racsan-a-si,?i&cisum-a-si,ratrebil-a-si,?tarukas,?c,dc&hsums,umpw,?eerg-a-si,i&-morf,jod,?m-morf,o&ehtnaptog,isam-al-a-tse,rtap-el-tse,s&iam-al-a-tse,replausunu,??pj,t-morf,?o&c,hce-namtsop,idutsxiw,jodsnd,m&-morf,ed-baltlow,?niloxip,t&ingocnozama.&1-&ht&ron-ue.htua,uos-&em.htua,fa.htua,pa.htua,ue.htua,??lartnec-&ac.htua,em.htua,li.htua,ue.htua,xm.htua,?ts&ae&-&as.htua,pa.htua,su.&htua,spif-htua,?vog-su.spif-htua,?ht&ron-pa.htua,uos-pa.htua,??ew-&ac.htua,su.&htua,spif-htua,?ue.htua,vog-su.spif-htua,???2-&htuos-&pa.htua,ue.htua,?lartnec-ue.htua,ts&ae&-&pa.htua,su.&htua,spif-htua,??ht&ron-pa.htua,uos-pa.htua,??ew-&su.&htua,spif-htua,?ue.htua,???3-ts&aeht&ron-pa.htua,uos-pa.htua,?ew-ue.htua,?4-tsaehtuos-pa.htua,5-tsaehtuos-pa.htua,6-tsaehtuos-pa.htua,7-tsaehtuos-pa.htua,?tadym,??p&2pevres,aelutym,i&-sndnyd,fles,ogol,ruoy&esol,hctid,?ym&eerf,teg,??mirhselbmub,ohs&daerpsym,uneviv,?pa&-&emas,selucreh,?anis:piv,,esaberif,iparts:.aidem,,k1,nuspu,oifilauq,roetem:.ue,,snrettapcigam,tilmaerts,ukoreh,yfilpma,?t&fevres,thevres,??r&081,a&-morf,tskcor-a-si,?b:asnd,,e&d&iv&erp-yb-detsoh.saap,orpnwo,?ner&.ppa,no,??e&bevres,nigne-na-si,?ggolb-a-si,h&caet-a-si,pargotohp-a-si,?krow-drah-a-si,n&gised-a-si,ia&rtlanosrep-a-si,tretne-na-si,??p&acsdnal-a-si,eekkoob-a-si,?retac-a-si,subq,tn&ecysrab,iap-a-si,uh-a-si,?vres&-&ki.&cpj-rev-duolcj,duolcj,?s&ndnyd,pvtsaf,??bdym,inim,nmad,pc,sak,?y&alp-a-si,wal-a-si,?zilibomdeepsegap,?g,ituob,mgrp.nex,o&-morf,pav-no,sivdalaicnanif-a-si,t&areleccalabolgswa,c&a-na-si,od-a-si,?susaym,??p-morf,u&as-o-nyd,e&tsoh.&duolc-gar,hc-duolc-gar,?ugolb-nom-tse,?omuhevres,??s&a&apod,ila&nyd,snd,?n&duolcym,ymsd,?vnac&-sued,remarf,??b&al-ecir,bevres,?c&duolcababila,i&p&-sndnyd,evres,?tcatytiruces,??dylimaf,e&cived-anelab,itilitu3,l&ahw-eht-sevas,if-yb-detsoh,?mag-otni-si,t&i&iis,sro,?yskciuq,?ugaelyajyarg,?fpi-&eralfduolc,fc,?i&ht2tniop,murud,pa&elgoog,tneltneg,??jfac,k&-morf,aerf-ten,colb&egrof,pohsym,?nilkaerts,?m-morf,n&d&-pmet,d&-pi,unyd,yard,?golb,htiwssem,looc1,mood,rba,tog,?kselp,nyd,ootrac-otni-si,?o&-xobeerf,xobeerf,?ppa&-avnac,raeghtua,s&kcirbatad.&pcg,swa,?wa,?tneg,?r&ac-otni-si,e&ntrap-paelut,tsohmaerd,??s&e&l-rof-slles,rtca-na-si,?ibodym,?tsaeb-cihtym.&a&llicno,zno,?ilay,lacarac,re&gitnef,motsuc,?sv,toleco,x:n&ihps,yl,?,?u,wanozama.&1-&3s,ht&ron-ue&-3s,.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,tniopssecca-3s,?tniopssecca-3s,??uos-&em&-3s,.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?etisbew-3s,ipa-etucexe,kcatslaud.&3s,tniopssecca-3s,?tniopssecca-3s,??fa.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?etisbew-3s,ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,?pa&-3s,.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,yawetag-scitylana,??ue.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,???la&nretxe-3s,rtnec-&ac&-3s,.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,spif-&3s,tniopssecca-3s,?tniopssecca-3s,?spif-&3s,tniopssecca-3s,?tniopssecca-3s,??em.&3s,adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?etisbew-3s,ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,?li.&3s,9duolc&-swa.stessa-weivbew,.sfv,?adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?etisbew-3s,ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,?ue&-3s,.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,yawetag-scitylana,????ts&ae&-&as&-&3s,etisbew-3s,?.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,??pa&-3s,.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?etisbew-3s,ipa-etucexe,kcatslaud.&3s,tniopssecca-3s,?tniopssecca-3s,??su:-etisbew-3s,.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,d&etacerped-3s,orp-&iupparme,oidutsrme,skoobetonrme,??e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,spif-&3s,tniopssecca-3s,?tniopssecca-3s,?spif-&3s,tniopssecca-3s,?tniopssecca-3s,yawetag-scitylana,?,vog-su&-&3s,spif-3s,?.&3s,adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?etisbew-3s,ipa-etucexe,kcatslaud.&3s,etisbew-3s,spif-&3s,tniopssecca-3s,?tniopssecca-3s,?spif-&3s,tniopssecca-3s,?tniopssecca-3s,???ht&ron-pa&-&3s,etisbew-3s,?.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,yawetag-scitylana,??uos-pa&-&3s,etisbew-3s,?.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,yawetag-scitylana,????ew-&ac.&3s,adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?etisbew-3s,ipa-etucexe,kcatslaud.&3s,etisbew-3s,spif-&3s,tniopssecca-3s,?tniopssecca-3s,?spif-&3s,tniopssecca-3s,?tniopssecca-3s,?su&-&3s,etisbew-3s,?.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,spif-&3s,tniopssecca-3s,?tniopssecca-3s,?spif-&3s,tniopssecca-3s,?tniopssecca-3s,??ue&-&3s,etisbew-3s,?.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,d&etacerped-3s,orp-&iupparme,oidutsrme,skoobetonrme,??e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,yawetag-scitylana,??vog-su&-&3s,etisbew-3s,spif-3s,?.&3s,adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,spif-&3s,tniopssecca-3s,?tniopssecca-3s,?spif-&3s,tniopssecca-3s,?tniopssecca-3s,?????2-&htuos-&pa.&3s,adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,?ue.&3s,adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,??lartnec-ue.&3s,adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?etisbew-3s,ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,?ts&ae&-su&-3s,.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,d&etacerped-3s,orp-&iupparme,oidutsrme,skoobetonrme,??e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,spif-&3s,tniopssecca-3s,?tniopssecca-3s,?spif-&3s,tniopssecca-3s,?tniopssecca-3s,yawetag-scitylana,??ht&ron-pa&-3s,.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,yawetag-scitylana,??uos-pa&-&3s,etisbew-3s,?.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,yawetag-scitylana,????ew-&su&-&3s,etisbew-3s,?.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,d&etacerped-3s,orp-&iupparme,oidutsrme,skoobetonrme,??e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,spif-&3s,tniopssecca-3s,?tniopssecca-3s,?spif-&3s,tniopssecca-3s,?tniopssecca-3s,yawetag-scitylana,??ue&-3s,.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,tniopssecca-3s,?tniopssecca-3s,?????3&-ts&aeht&ron-pa&-3s,.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?etisbew-3s,ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,??uos-pa.&3s,adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?etisbew-3s,ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,??ew-ue&-3s,.&3s,9duolc&-swa.stessa-weivbew,.s&fv,tessa-weivbew,??adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,???s,?4-tsaehtuos-pa.&3s,adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?etisbew-3s,ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,?5-tsaehtuos-pa.&3s,adbmal-tcejbo-3s,detacerped-3s,e&roctnega-kcordeb.latrop-tnesnoc,tisbew-3s,?ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,?7-tsaehtuos-pa.eroctnega-kcordeb.latrop-tnesnoc,labolg-3s.tniopssecca.parm,?yasdrocsid,?t&arcomed-a-si,c&-morf,e&jorpelbavol,tedatad.&ecnatsni,omed,???e&el&-si,rebu-si,?notlacol,?hgilfhtiwletoh,i:batym,nelp-1&al,su,ue,?,m-morf,n&atnuocca-na-si,e&duts-a-si,ga&tnegreme.weiverp,yolped,?r-ot-ecaps,tnocresu&ahcom,buhtig,e&capsppa,d&onil.pi,ualc:.emarf,,?lbavresbo.citats,vat,?kaerts,pl,???ops&edoc,golb,ppa,?s&i&hcrana-&a-si,na-si,?laicos-a-si,pareht-a-si,tra-na-si,xetn&od,seod,??oh&-ecapsbew,piym,sfn,??u&-morf,nyekcoh-asi,?v-morf,?u&-rof-slles,4,e,oynahtretramssi,r:ug&-a-si,sndd,?,?v&ed-selucreh,n-morf,rdlf,w-morf,?w&eiverp-emas,o&lpwons-yrt,zok,??x&bsbf.sppa,em,inuemoh,obdnas-44esab,t-morf,unilemoh,?y&a&lerottad,p-csbus,wetag-llawerif,?d&nacsekil,uts-tcejorp.ved,?fipohsym,k&-morf,niksisnd,?r&aidanetah,otceridevitcaym,?ugoo,w-morf,x&alagkeeg,orpmapson.duolc:.563o,,??z&esdrocsid,tilbcitats-&proc-w,ssellaitnederc-w,w,???inu??m?or?tsla??p!.&eman,nwo,??raf!etats??s?t!.&gro?lim?mo&c?n??oc?ten?ude?vog???u&esum?rof??z!.&ca?gro?hcs?lim?moc?o&c?fni??ten?ude?vog?zib????n&315rmi--nx?a&brud?cilbuper?f!.mkm,?grompj?hkaga?m?ol?ssin?u&hix?qna??varac?yalo??b!.&gro?moc?oc,ten?ude?vog??c??c!.&ah?bh?c&a?s??d&5xq55--nx?g?s?uolcpanqym,?e&doc-avnac,h?tisavnac.ym,?g&la0do--nx?ro??h&a?q?s!.sa,??i&7a0oi--nx?h??j&b?f?shk,t?x?z??kh?l&h?im?j??m&n?oc!.&rekamegas.1-&htron-nc.&koobeton,oiduts,?tsewhtron-nc.&koobeton,oiduts,??s&ecivresbewnozama.no.1-&htron-nc.ppabew-refsnart,tsewhtron-nc.ppabew-refsnart,?wanozama.&1-&htron-nc.&3s,adbmal-tcejbo-3s,d&etacerped-3s,orp-&iupparme,oidutsrme,skoobetonrme,??etisbew-3s,ipa-etucexe,kcatslaud.&3s,etisbew-3s,tniopssecca-3s,?tniopssecca-3s,?tsewhtron-nc.&3s,adbmal-tcejbo-3s,dorp-&iupparme,oidutsrme,skoobetonrme,?etisbew-3s,ipa-etucexe,kcatslaud.&3s,tniopssecca-3s,?tniopssecca-3s,??be.1-&htron-nc,tsewhtron-nc,??????n&h?l?s?y??om?qc?s&g?j?ppa-avnac,?t&cennockciuq.tcerid,en??ude?vog?wt?x&g?j?n?s??z&g?x??\u53f8\u516c?\u7d61\u7db2?\u7edc\u7f51??b??d&g!.ypnc,?ka??e&drag?erg?fuak?hctik?i&libommi?w??m?po?r!ednaalv??sier?ves??g!.&ca?gro?moc?ten?ude?vog??is&ed!.&cihparg,ssb,??irev???h!.&bog?gro?lim?moc?ten?ude???i!.&ac?b&ew,u??c&a?in??dni?e&m?sabapus,?g&5?6?p?ro??i&a?hled?nmula??k&nab?u??l&evart?im?oohcs??m&a?oc?rif??n&c?eg?if??o&c?fni?i?r&ea?p???p&ooc?u??r&ahib?d?e??s&c?er?nduolc,senisub?u?vedni,?t&arajug?en!retni??ni?sop??ude?v&og?t??ysrab,zib??elknivlac?griv?ks?lreb!.sndd,?p?v?w?x??k!.&gro?ten?ude?vog???l&eok?ocnil??m!.&cyn,gro?ude?vog???o&dnol?i&hsaf?n&o?utiderc??siv!orue??t&a&cude!.oc,?dnuof?tsyalp??c&etorp?u&a?rtsnoc?????kin?las?mrom?nac?p&q?uoc??s&iam?pe?scire??t&ron?sob??zama??p!.&gro?oc?ten?ude?vog??k??r&e&c?yab??op??s!.&gro?moc?tra?ude?v&inu?uog????t!.&d&ni?uolcegnaro,?gro?ltni?m&oc!nim??siruot??nif?o&fni?srep??sne?t&an?en??vog??m??u&f!.&pci&v,y,z,?sm,??r!.&a&rail:.nari,,vnac,?bdnevar,duolc,el&bavol,deen,?l&av:.bew,,ecrev,per,?retropno,t&ikcats,nempoleved,?xiw,??stad?xamay?y??v!.&a&lnos?ohhnah&k?t???c&a?ouhphnib?uhphniv??di?e&man?rtneb?uh!neihtauht???g&n&a&boac?ig&ah?cab?n&a?ei&k?t???uah??nad?rtcos?uqneyut??o&dmal?hpiah?lhniv?nkad?ud&hnib?iah????ro??h&ni&b&aoh?gnauq?hnin?iaht??d&hnib?man??mihcohohphnaht?n&cab?gnauq?yat??tah?vart??tlaeh??i&a!bney?coal?gngnauq?laig?ngnod??onah?rtgnauq??kalkad?m&an&ah?gnauq??oc?utnok??n&a&ehgn?gnol?kcab?uhthni&b?n???e&ibneid?y&gnuh?u&gniaht?hp????osgnal??o&fni?ht&nac?uhp??i?rp??pahtgnod?t&en?ni??u&a&hcial?mac?tgnuv-airab??de?eilcab??vog?zib???wo&rc?t!epac????o&76i4orfy--nx?a!.&bp?de?g&o?ro??oc?ti?ude?v&g?og???boat??b!.&a&ci&sum?tilop??i!c&arcomed?neic??golo&ce?ncet??m&edaca?onoce??rt&ap?sudni??vilob??n&egidni?icidem??serpme?tsiver?vitarepooc??b&ew?og??dulas?e&rbmon?tr&a?op&ed?snart????g&olb?ro??ikiw?l&a&noi&canirulp?seforp??rutan??im??moc?o&fni?lbeup?rga?tneimivom??saiciton?t&askt?en?ni??ude?vt??h?iew?olg??c!.&dr&c,rac,?esabapus:.e&garots,mitlaer,?,gro?ipym,l&im?per:.di,,?mo&c?n??osmu,s&egap&dael,l,?ndih,?t&en?ilperdellawerif:.di,,?ude?vog??a?e?in?mara?s&edarb?ic???d!.&b&ew?og??dls?gro?lim?moc?t&en?ra??ude?vog??agoba?if?zd7acbgm--nx??e&c?d&iv?or???f!ni!.&dlawttim,e&g&delwonk-fo-l&errab,lerrab,?ellocevoli,?ht-skorg,rom-rof-ereh,tadpusn:d,,?llatiswonk,macrvd,ofni-v,p&i&-on,fles,?ohbew,?r&evres&3opyt,dlawttim,?uo-rof,?s&iht-skorg,nd&-cimanyd,nyd,uolc,??tsrifyam,ysrab,zmurof,???g&el?n!am?ib???hwsohw?i!.&0pci,1pci,8302,a&minifed,tad-b,?b&altig,uhtig,?citeneek,d&etpyrcs.tneilc,raobelgaeb,uolcropav,?e&civedniser,don&ppad.sndnyd,repyh,?egipa,l&bbub.ndc,ej,?nilnigol,sufxob,t&i&beulb,snoehtnap,?newtu,ybeeb.saap,?varb,?g&n&alkrad,i&gatsniser.secived,tsoh&-br.etis,ytsoh,???ro??k&coregrof.di,o&obtig,rgn:.&as,ni,p&a,j,?su,u&a,e,??,?ramytefasresworb,?lim?m&o&c?n??roftalp-evird,?n&aicisum,mtsp:.kcom,,yded,?o&c?idutsxiw,toq,?p&opilol,pa&-arusah,etybeeb.1dkes,??r&ddaym,e&tsneum-hf,vres&cisab,lautriv,??ial.sppa,?s&codehtdaer,gnihtbew,nemeis-om,ppa&elbbub,olik,revelc,?t&acdnas,ekcit,??t&e&kcubtib,n??i&belet,gude,?netnocresuseebduolc,raedon.egats,s&etwolfbew,udgniht.&cersid.&dvreser,tsuc,?dorp.tsuc,gnitset.&dvreser,tsuc,?ved.&dvreser,tsuc,????ude?vog?wolfbew,x&bdrym,cq,rotide,?ysrab,zzq,?b?d&ar?u&a?ts!.ia,???j?r?syhp??j!.&dhp?g&ne?ro??hcs?i&a?rga??lim?m&f?oc??rep?ten?ude?v&og?t????ll&ag?o??m!.&gro?moc?ten?ude?vog??g?il?mi?orp??n!.&a&0&b-ekhgnark--nx?c-iehsrgev--nx?g-lksedlig--nx?k-negnanvk--nx??1&p-nedragy--nx?q-&asierrs--nx?grebsnt--nx?lado-rs--nx?n&egnidl--nx?orf-rs--nx??regnayh--nx?ssofenh--nx??r-datsgrt--nx?s-ladrjts--nx?v-y&senner--nx?vrejks--nx???3g-datsobegh--nx?4&5-&dnaleprj--nx?goksnerl--nx?tednalyh--nx??6-neladnjm--nx?s-&antouvachb--nx?impouvtalm--nx??y-&agrjnevvad--nx?ikhvlaraeb--nx???7k-antouvacchb--nx?8&k-rekie-erv--nx?l-ladrua-rs--nx?m-darehsdrk--nx??a!.sg??bct-eimeuvejsemn--nx?d&do?iisevvad?l&eig?ov??narts?uas??f&1-&l--nx?s--nx??2-h--nx??g&10aq0-ineve--nx?av?ev?lot?r&ajn&evvad?u??\u00e1jn&evvad?u????h?iz-lf--nx?j&ddadab?sel??k&el?hoj&sarak?\u0161\u00e1r\u00e1k??iiv&ag&na&el?g??\u014b&ael?\u00e1g???ran???l&f?lahrevo?o&ms?s??sennev?t-&ilm--nx?tom--nx??u&-edr--nx?s??\u00f8ms??muar?n&0-tsr--nx?2-dob--nx?5-&asir--nx?tals--nx??a&r!-i-om?f?t??t??douvsatvid?kiv?m&os?\u00f8s??n&od?\u00f8d??ra?sen?t&aouvatheig?ouv&a&c&ch&ab?\u00e1b??h&ab?\u00e1b???n??i&ag?\u00e1g??sa&mo?ttvid??\u00e1n???z-rey--nx?\u00e6r&f?t???o&p-&ladr--nx?sens--nx??q-nagv--nx?r-asns--nx?s-kjks--nx?v-murb--nx?w-&anr&f--nx?t--nx??ublk--nx???ppol?q&0-t&baol--nx?soum--nx?veib--nx??x-&ipphl--nx?r&embh--nx?imph--nx???y-tinks--nx??r&f-atsr--nx?g-&an&ms--nx?nd--nx??e&drf--nx?ngs--nx??murs--nx?netl--nx?olmb--nx?sorr--nx??h-&a&lms--nx?yrf--nx??emjt--nx??i&-&lboh--nx?rsir--nx?y&d&ar--nx?na--nx??ksa--nx?lem--nx?r&ul--nx?yd--nx????stu??j-&drav--nx?rolf--nx?sdav--nx??kua?l-&drojf--nx?lares--nx??m-tlohr--nx?n-esans--nx?olf?p-sdnil--nx?s-ladrl--nx?tih?v-rvsyt--nx??s&a&ns?ons??i&ar?er&dron?r&os?\u00f8s???\u00e1r??la&g?h??mor!t??sir?uf?\u00e5ns??t&koulo&nka?\u014bk\u00e1??la?p-raddjb--nx?r-agrjnu--nx?s&aefr&ammah?\u00e1mm\u00e1h??orf?r&o?\u00f8???u-vreiks--nx??u&h-dnusel--nx?i-&drojfk--nx?vleslm--nx??j-ekerom--nx?k-rekrem--nx?u-&dnalr--nx?goksr--nx?sensk--nx??v-nekyr--nx?w-&k&abrd--nx?ivjg--nx??oryso--nx??y-y&dnas--nx?mrak--nx?n&art--nx?nif--nx??reva--nx??z-smort--nx??v!.sg?ledatskork?reiks??wh-antouvn--nx?x&9-dlofts--nx.aoq-relv--nx?d-nmaherk--nx?f-dnalnks--nx?h-neltloh--nx?i-drgeppo--nx?j-gve&gnal--nx?lreb--nx??m-negnilr--nx?n-drojfvk--nx??y&7-ujdaehal--nx?8-antouvig--nx?b-&dlofrs--nx?goksmr--nx?kivryr--nx?retslj--nx??e-nejsom--nx?f-y&r&amah--nx?e&dni--nx?tso--nx???s&lrak--nx?tivk--nx???g-regark--nx?orf?\u00f8rf??z9-drojfstb--nx??b&25-akiivagael--nx?53ay7-olousech--nx?a&iy-gv--nx?le-tl&b--nx?s--nx??n0-ydr--nx??c&0-dnal-erdns--nx?z-netot-erts--nx??g&g-regnarav-rs--nx?o-nejssendnas--nx??ju-erdils-ertsy--nx?nj-dnalh-goksrua--nx?q&q-ladsmor-go-erm--nx.&ari-yreh--nx?ednas??s-neslahsladrjts--nx???ca&4s-atsaefrmmh--nx?8m-dnusynnrb--nx?il-tl--nx?le-slg--nx?n5-rdib--nx?op-drgl--nx?uw-ynnrb--nx??d&a&qx-tggrv--nx?reh!nnivk?sd&ork?\u00f8rk??uas??ts&e&bi?kkar?llyh?nnan??g&ort?\u00f8rt??k&alf?irderf??levev?mirg?obeg&ah?\u00e6h??r&ah?ejg????barm-jdddb--nx?ie!rah?s&etivk?ladman???lof&r&os?\u00f8s??ts&ev.ednas?o.relav?\u00f8.rel\u00e5v???n&a&l&-erd&n&os?\u00f8s??ron??adroh.so?dron.&a&g5-b--nx?ri-yreh--nx??ob?y&oreh?\u00f8reh??\u00f8b??e&m!lejh??pr&oj?\u00f8j??vi??gyb?n&aks?\u00e5ks??o&h-goksrua?rf??r&o?ua?\u00f8??tros?\u00f8h-goksrua??rts!e&devt?lab?mloh???s&ellil?naitsirk?rof???u&l!os??s!d&im?lejt??e&guah?l&a?\u00e5???kkoh?lavk?naitsirk?r&af?eg&e?ie???tef?y&onnorb?\u00f8nn\u00f8rb?????r&a&blavs!.sg??g&eppo?la???o&j&f&a!dniv?k?vk??die?e&dnas?kkelf??llins?r&iel?ots??s&lab?t&ab?\u00e5b??yt??\u00e5!k??\u00e6vk??les??ts??\u00e5g&eppo?l\u00e5???ureksub.sen??e&ayb-yrettn--nx?d&ar?isemmejh321,lom?r&of?\u00f8f??\u00e5r??g&gyr?nats?roneu??i&meuv&ejsem&aan?\u00e5\u00e5n??sekaal??rjea??j&d&ef?oks??les??k&er&aom?\u00e5om??hgna&ark?\u00e5rk??iregnir?kot!s??s&ig?uaf???l&bmab?kyb?l&av?ehtats??oh??m&it?ojt?\u00f8jt??n&arg?g&os?\u00f8s??meh?reil?te?ummok?yrb??r!dils-erts&ev?y&o?\u00f8???ua?vod??sa&ans?\u00e5ns??t&leijt?robraa?spaav??urg??f&62ats-ugsrop--nx?a&10-ujvrekkhr--nx?7k-tajjrv-attm--nx??o!.sg?h??s!.sg??v!.sg???g&5aly-yr&n--nx?v--nx??a&llor?ve&gnal?lreb???n&av!snellu??org??oks&die?m&or?\u00f8r??ner&ol?\u00f8l??r&o?\u00f8???r&eb!adnar?edyps?s&die?elf?gnok?n&ot?\u00f8t????obspras??uahatsla?\u00e5ve&gnal?lreb???h&0alu-ysm--nx?7&4ay8-akiivagg--nx?5ay7-atkoulok--nx??a!.sg???i&ehsr&agev?\u00e5gev??k&h&avlaraeb?\u00e1vlaraeb??s??lm&a?\u00e5??mpouvtal&am?\u00e1m??pph&al?\u00e1l??rrounaddleid?ssaneve?\u0161\u0161\u00e1neve??j&0aoq-ysgv--nx?94bawh-akhojrk--nx??k&a&b&ord?\u00f8rd??jks?lleis??iv!aklejps?l&am?evs?u??mag?nel?ojg?r&a&l?n??epok?iel?y&or?\u00f8r???s&ah?kel??\u00f8jg??kabene?ojsarak?ram&deh.&aoq-relv--nx?rel&av?\u00e5v??so??e&let.&ag5-b--nx?ob?\u00f8b??ra???\u00e5jks??l&a!d&anrus?d&numurb?ron??e&gnard?n&dua?te??s&meh?sin??ttin??g&is?nyl??kro?l&em?l&ejfttah?of??u&ag-ertdim?s???n&am?era?gos?i&b?nroh?r??kos?nus?oj??o-&dron?r&os?\u00f8s???ppo?r&a!l?nram??e&gne?l?v??is?o&jts?ts??u&a-&dron?r&os?\u00f8s???h??\u00e5?\u00e6l?\u00f8jts??s&e&jg?nivk?ryf??kav?mor-go-er&om.&ednas?yoreh??\u00f8m.&ednas?y\u00f8reh???uag??t&las?rajh?suan??v&l&a?e-rots??u-go-eron??yt??ksedlig?res&a?\u00e5???bib&eklof?seklyf??es!dah??h!.sg??i&m?syrt??l&ejf?ov&etsua?gnit?ksa?sdie???n!.sg??o!.sg?boh?g?h??r!.sg??\u00e5!ksedlig??\u00f8boh??m&a&rah?vk??f!.sg??h!.sg??i&e&h&dnort?rtsua?ssej??rkrejb??ksa??ol?t!.sg??u&dom?esum?r&ab?drejg?evle?os?uh?\u00e6b?\u00f8s??ttals???n&a&g&av?okssman?\u00e5v??jlis?khous?or?r&g?rev???e&d&do&sen?ton??lah?r&agy&o?\u00f8??ojfsam???g&iets?n&a&l&as?lab??n&avk?\u00e6vk??t&arg?ddosen??v&al?essov???i&d&ol?\u00f8l??l&ar?\u00e6r???yl??reb??iks?k&srot?y&or?\u00f8r???l&a&d&gnos?n&er?ojm?\u00f8jm??om??tloh??ug?\u00e5tloh??mmard?ojs&om?sendnas??ppolg?s&lahsladr&ojts?\u00f8jts??o??t&o&l?t-erts&ev?o?\u00f8???roh?\u00f8l??vly&kkys?nav??yam-naj!.sg??\u00f8js&om?sendnas???g&orf?ujb??i&dnaort?etslu?vnarg??kob?maherk&a?\u00e5??n&it?urgsrop??orf-&dron?r&os?\u00f8s???r&aieb?evats??sfev?uaks?yrts??o&6axi-ygvtsev--nx?c,d&ob?rav??ievs?kssouf?l&m&ob?\u00f8b??ous&adna?ech&ac?\u00e1\u010d???so!.sg???msdeks?niekotuak?r&egark?olf?y&oso?\u00f8so???s&dav?mort???p&ed?ohsdaerpsym,p&akdron?elk???r&a&d&dj&ab?\u00e1b??iab??jtif?luag?mah?vsyt??e&gn&a&k&iel?ro??merb?n&at?mas??rav-r&os?\u00f8s??srop?talf?v&ats?el??y&oh?\u00f8h???ivsgnok??il?jkniets?k&a&nvej?rem?s&gnir?nellu???ie-er&den?v&o?\u00f8???ram?sa?\u00e5rem??la&jf?vh??m&b&ah?\u00e1h??mahellil??nnul?ts&l&oj?\u00f8j??ul??y&o?\u00f8???imp&ah?\u00e1h??m!.sg??osir?t!.sg??\u00e1di\u00e1b?\u00e6vsyt?\u00f8sir??s&adnil?en&dnas?e&dga?k&ri&b?k??som??ve??me&h?jg??nroh-go-ejve?s&a?ednil?k&o?\u00f8??of?yt?\u00e5??tsev??gv?hf?igaval?o&r&or?\u00f8r??sman??so&fen&oh?\u00f8h??m?v??uh&lem?sreka.sen??\u00e5!dnil???t&a&baol?g&aov?grav??jjr&av-attam?\u00e1v-att\u00e1m??l&a&b?s??\u00e1s??soum?ts?v&eib?our???e&dnaly&oh?\u00f8h??f?s&nyt?rokomsdeks?sen??vtpiks??in&aks?\u00e1ks??loh&ar?\u00e5r??n!.sg??om&a?\u00e5??s!.sg?efremmah?or?\u00f8r??terdi?\u00e1&baol?ggr\u00e1v?l\u00e1&b?s??soum?veib???u&b!.sg?alk?e&dna?gnir?nner??les?\u00e6lk??dra&b?eb??g&nasrop?vi?\u014b\u00e1srop??j&daehal&a?\u00e1??jedub?v&arekkhar?\u00e1rekkh\u00e1r???ksiouf?n&diaegadvoug?taed???v&irp?lesl&am?\u00e5m???y&b&essen?nart?sebel?tsev??o&d&ar?na!s??or??gavtsev?ksa?lem?mrak?n&art?n&if?orb???r&a&mah?n?v??e&dni?t&so?ton??va??ul?yd??s&am?enner?gav?lrak?tivk??vrejks??\u00f8&d&ar?na!s??\u00f8r??g\u00e5vtsev?ksa?lem?mrak?n&art?n&if?\u00f8rb???r&amah?e&dni?t&so?t\u00f8n??va??ul?yd?\u00e6&n?v???s&enner?g\u00e5v?lrak?tivk?\u00e5m??vrejks???\u00e1&sl\u00e1g?tl\u00e1?vreiks??\u00e5&g\u00e5v?h?jdd\u00e5d\u00e5b?lf??\u00f8&d&ob?rav??r&egark?olf??s&dav?mort????aki?i&sac?tal??u??o&b?f?hay?o?ttat??r!.&cer?erots?gro?m&o&c?n??rif?t??o&c,fni??pohs,stra?tn?www?ysrab,?e&a!.&a&ac?cgd?idem??bulc!orea??ci&ffartria?taborea??e&c&alptekram?n&a&l&lievrus-ria?ubma??netniam?rusni??erefnoc???gnahcxe?mordorea?ni&gne?lria?zagam??rawtfos??gni&d&art?ilg!arap?gnah???l&dnahdnuorg?ledom??noollab?retac?sael?t&lusnoc?uhcarap??vidyks??hcraeser?ixat?l&anruoj?euf?icnuoc?ortnoc!-ciffart-ria???n&gised?oi&nu?t&a&cifitrec?ercer?gi&tsevni-tnedicca?van??i&cossa!-regnessap??valivic??redef??cudorp?neverp-tnedicca????ograc?p&ihsnoipmahc?uorg!gnikrow???r&e&dart?enigne?korb?niart?trahc??o&htua?tacude???s&citsigol?e&civres?r??krow?serp!xe??tnega??t&farcr&ia?otor??hgi&erf?l&f?orcim???liubemoh?n&atlusnoc?e&duts?m&n&iatretne?revog??piuqe????olip?ropria?si&lanruoj?tneics???w&erc?ohs??y&cnegreme?dobper?tefas????rref?z??p!.&a&aa?ca?pc??citeneek,dem?gne?korgn,r&ab?uj??snduolc,t&acova?cca?hcer??wal?ysrab,???s!.&em?gro?moc?syevrus,ten?ude?vog???t!.&0x,116,gro?lim?moc?sulpnpv,t&cennockciuq.tcerid,en?ten,?ude?vog??o&hp?m?v?yk??tol?ua??v&iv?lov??xas?ykot??p&a&ehc?g?m?s??eej?g!.&gro?ibom?moc?ossa?ten?ude???i&r!.nalc,?v!.sndih,?z??j!.&0&g0,j0,o0o,t0,?a&3&5xq6f--nx?xqi0ostn--nx??5wtb6--nx?85uwuu--nx?9xtlk--nx?ad,b&ats,ihc!.&a&bihciakoy?don?ma&him?ye&ragan?tat???r&a&bom?gan?hihci??u&agedos?kas?ustak???s&os?ufomihs??t&amihcay?iran??w&a&g&im&anah?o??omak??kihci?zustum??ihsak??y&agamak?imonihci???e&akas?nagot??i&azni?esohc?h&asa?s&abanuf?ohc???ka&to?zok??musi?orihs?r&akihabihsokoy?o&dim?tak??ukujuk??usihs??nano&hc?yk??o&d&iakustoy?ustam??hsonhot?k&a&rihs?t??iba??nihsaran?sobimanim?tas&arihsimao?imot??uhc?yihcay??u&kujno?s&ayaru?t&imik?tuf???zarasik?????c&cah,ed,?g&as!.&a&gas?m&a&tamah?yik??ihsak??rat?t&a&gatik?hatik??ira!ihsin????e&kaira?nimimak??i&akneg?g&aruyk?o??h&c&amo?uo??siorihs??kaznak?modukuf?ra&gonihsoy?mi???nezih?u&k&at?ohuok??s&ot?tarak?????ihs!.&a&kok?m&a&hagan?yirom??ihsakat??rabiam?wagoton??e&miharot?nokih??houyr?i&azaihsin?esok?kustakat?moihsagih??na&mihcahimo?nok??o&hsia?mag?t&asoyot?ok?tir???us&ay?t&asuk?o??????k&aso!.&a&d&awihsik?eki??k&a&noyot?s&akaayahihc?oihsagih???oadat?uziak??m&ayas!akaso??odak??r&a&bustam?wihsak??ediijuf??t&akarih?i&k?us???wag&ayen?odoyihsagih???e&son?tawanojihs??honim?i&akas?h&cugirom?s&ayabadnot?i&a&kat?t??n??oyimusihsagih???k&a&rabi?sim??ustakat??muzi?r&ijat?otamuk???nan&ak?n&ah?es???o&ay?n&a&ganihcawak?simuzi?tak??eba?ikibah?oyot??t&anim?iad?omamihs??uhc??ust&oimuzi?tes????ou&kuf!.&a&d&amay?eos??g&no?ok?usak??hiku?k&awayim?uzii??ma&kan?y&asih?im???rawak?t&a&gon?ka&h?num?t???umo??wa&g&a&kan?nay?t??ias??ko!rih???y&ihsa?usak???e&m&ay?uruk??taruk?us??i&a&nohs?raihcat??goruk?h&cukuf?s&a&gih?hukuy??in???k&a&gako?muzim??iust?o?ustani??m&anim?otihsoynihs?u??r&ogo?ugasas??usu??ne&siek?zu&b?kihc???o&gukihc?h&ak?ot?ukihc??j&ono?ukihc??kayim?nihsukihc?to?uhc??u&fiazad?gnihs?stoyot????zihs!.&a&bmetog?d&amihs?eijuf?ihsoy?omihs??kouzihs?mihsim?ra&biah?honikam??tawi?wa&g&ekak?ukik??kijuf??yimonijuf??i&a&ra?sok??hcamirom?juf?kaz&eamo?ustam??ma&nnak?ta??nukonuzi?orukuf??nohenawak?o&nosus?ti??u&stamamah?z&a&mun?wak??i!ay?i&hs&agih?in??manim??mihs????????m&a&tias!.&a&d&ihsoy?ot?usah??k&a&dih?sa??o&arihs?s???m&a&tias?y&as?o&rom?tah??ustamihsagih???i&hsagurust?jawak??uri??ni?wa&g&e&ko?man??ikot?o??k&ara?i&hsoy?mak???ru?zorokot??y&a&g&amuk?ihsok?otah??kuf??imo??ziin??e&bakusak?ogawak?sogo?ttas?zokoy??i&baraw?h&cugawak?s&oyim?ubustam???iroy?k&ato?ihs?u&k?stawi???m&akoyr?i&hsoy?juf??uziimak???naznar?o&dakas?ihsay?jnoh?n&a&go?nim??imijuf?nah?oy??r&ihsayim?otagan??t&asim!ak??igus?omatik??zak??u&bihcihc!ihsagih??sonuok?ynah????y&ak&aw!.&a&d&ira?notimak??kadih?ma&h&arihs?im??y&a&kaw?tik??oduk???ru&ustakihcan?y??sauy?wa&g&a&dira?zok??orih??konik??yok?zok??e&banat?dawi??i&garustak?jiat?mani??naniak?o&bog?nimik?t&asim?omihs&ah?uk????ugnihs???o!.&a&jos?koasak?m&ay&ako?ust??ihsayah??r&abi?ukawaihsin??wi&aka?nam???e&gakay?kaw??i&gan?h&cu&kasa?otes??sahakat??k&asim?ihsaruk??miin??n&anemuk?ezib??o&hsotas?jnihs?n&amat?imagak??ohs?uhcibik?????ot!.&a&damay?got?koakat?may&etat?ot??nahoj?riat?waki&inakan?reman???eb&ayo?oruk??i&h&asa?ciimak?sahanuf??kuzanu?m&an&i?ot??ih???nezuyn?otnan?u&hcuf?stimukuf?z&imi?ou???????ihs&o&gak!.&a&m&ayuok?ihsogak??si?yonak??e&banawak?n&at&akan?imanim??uka??tomoonihsin??i&adnesamustas?k&azarukam?oih??m&ama?uzi??usuy??nesi?o&knik?os?tomustam??uzimurat???rih!.&a&ka&n?s??m&ayukuf?i&hsorihihsagih?j&ate?imakikaso????r&a&bohs?h&ekat?im???es??tiak?wiad??e&kato?ruk??i&h&ci&akustah?mono?nihs??s&inares?oyim???manimasa?uk??negokikesnij?o&gnoh?namuk??uhcuf????uk&ot!.&a&bihci?mi&hsu&kot?stamok??m??wagakan??egihsustam?i&gum?h&coganas?soyim??kijaw?m&anim?uzia??ukihsihs??nan&a?iak??o&nati?turan????uf!.&a&batuf?m&a&to?y&enak?irok???ihs&im?ukuf??os?uko??r&aboihsatik?uganat??ta&katik?mawak?rih??w&a&g&akus?emas?uy??k&a&mat?rihs?sa??ihsi??nah??ohs???e&gnabuzia?iman?ta&d?tii???i&adnab?enet?hs&agih?iimagak??k&a&wi?zimuzi??ubay??minuk?r&ook?ustamay???nihsiat?o&g&etomo?ihsin?nan?omihs??no!duruf?rih??rihsawani?ta&may?simuzia???u&rahim?stamakawuzia?zia&ihsin?nay???????nug!.&a&bawak?doyihc?k&anna?oi&hsoy?juf?mot???m&ayakat?ustagaihsagih??n&ihsatak?nak??r&ahonagan?nak?o?u&kati?mamat???t&amun?inomihs?o??w&akubihs?iem?ohs???i&hsa&beam?yabetat??kas&akat?esi??m&akanim?uzio??ogamust?rodim??o&jonakan?n&eu?oyikust??tnihs??u&komnan?stasuk?yrik????rep,?n&ibmab,nog,ob,?ppacihc,ra&n!.&a&bihsak?d&akatotamay?u!o???guraki?m&ay&atik&imak?omihs??irokotamay??oki??ra&hihsak?n??wa&geson?knet???e&kayim?ozamay?sog?ustim??i&a&rukas?wak??garustak?h&ciomihs?sinawak??jo?ka&mnak?toruk??makawak?nos?r&net?otakat?ugeh???o&d&na?oyo??gnas?jnihs?nihsoy!ihsagih??tomarawat?yrok????rikik,?t&ag&amay!.&a&dihsio?k&atarihs?ourust??may&a&kan?rum??enak?onimak??rukho?ta&ga&may?nuf??hakat?kas??wa&g&ekas?orumam??ki&hsin?m??z&anabo?enoy?ot???zuy??e&agas?bonamay?dii?nihsagih?o??i&a&gan?nohs??h&asa?sinawak??nugo??o&dnet?jnihs?ynan??ukohak???iin!.&a&ga?k&ium?oagan??munou!imanim??t&a&bihs?giin??ioy??w&a&gioti?kikes?zuy??irak??yijo??e&kustim?mabust??i&aniat?hcamakot?kaz&awihsak?omuzi??m&a&gat?karum??o???n&anust?esog??o&das?ihcot?jnas?k&ihay?oym??mak?naga?ries??u&ories?steoj?????i&k&a!.&a&go?k&asok?oimak??t&ago!rihcah??ika!atik???w&aki?oyk???e&mojog?natim?suranihsagih?t&ado?okoy???i&hsoyirom?magatak?naokimak??nesiad?o&hakin?jnoh!iruy??nuzak?rihson?tasi&juf?m??yjnoh??u&kobmes?oppah????in,?o!.&a&dakatognub?m&asah?ihsemih??su?t&ekat?i&h?o????e&onokok?ustimak??i&jih?k&asinuk?ias?usu??mukust??onoognub?u&fuy?juk?ppeb?suk?????nayn,?wa&ga&k!.&a&mihsoan?rihotok?waga&kihsagih?ya???emaguram?i&j&nonak?ustnez??kunas?monihcu??o&hsonot?nnam?yotim??u&st&amakat?odat??zatu????nak!.&a&dustam?kus&okoy?tarih??maz?nibe?r&a&gihsaimanim?h&esi?imagas??wa&do?guy???u&im?kamak???tikamay?wa&k&ia?oyik?umas??sijuf??yimonin??e&nokah?saya??i&akan?esiak?gusta?hsuz?kasagihc?o?ukust??o&nadah?sio?tamay?????kihsi!.&a&danihcu?gak?kihs?mijaw?t&abust?ikawak??wazanak??i&gurust?hcionon?mon?ukah??nasukah?o&anan?ton!akan???u&kohak?stamok?z&imana?us?????niko!.&a&han?m&arat?ijemuk?uru??n&e&dak?zi??no??ra&hihsin?rih??wa&kihsi?niko??yehi?zonig??e&osaru?seay??i&hsagih?jomihs?k&a&gihsi?not??ihsakot??m&a&ginuk?kihsug?maz??igo?otekat??nuga!noy???n&a&moti?timoy?wonig??i&jikan?k???o&gan?jnan?tiad&atik?imanim???u&botom?kusug&akan!atik??imot??rab&anoy?eah??????yp,zomim,?bus,c&204ugv--nx?462a0t7--nx?678z7vq5d--nx?94ptr5--nx?a?mpopilol,?d&-2,17sql1--nx?3thr--nx?5&20xbz--nx?40sj5--nx??7&87tlk--nx?ptlk--nx??861ti4--nx?a?e!tfarcdnah,?n&eirf&lrig,yob,?om,?ooftac,?e&16thr--nx?5&1a4m2--nx?9ny7k--nx??damydaer,eweep,garotsarukas.&10ksi.3s,20ksi.3s,?i&bmoz,m!.&a&bot?k&asustam?uzus??m&a&him?y&emak?im???ihs??nawuk?wi&em?k???e&bani?ogawak?si!imanim???i&arataw?gusim?h&asa?ciakkoy??k&a&mat?sosik?t??iat??raban??o&dat?hik?n&amuk?ihseru?o&du?mok????ust????kilbew,lasrepus,mihe!.&a&m&a&h&ataway?iin??yustam??ij&awu?imak???taki!man???ebot?i&anoh?kasam?rabami??n&ania?egokamuk?oot??o&jias?kihcu?nustam?uhcukokihs?yi!es???u&kohik?zo????n!.&arukas,lapo,n&erukom,riheg,?omomus,stnim,teniesa.resu,xob-liam,yrovi,zapot,?amihs!.&a&d&amah?ho?usam??kustay?m&a?ihsoni&hsin?ko???wakih??e&namihs?ustam??i&g&aka?usay??konikak?mikih??nannu?o&mu&kay?zi!ihsagih?uko???nawust?tasim??u&stog?yamat????nep,?rotsnoihsaf,srev,t&awi!.&a&bahay?d&amay?on??koirom?t&a&honat?katnezukir??imus??w&as&ijuf?uzim??ihs???e&hon&i&hci?n??uk??tawi??i&a&duf?murak?wak??h&custo?si&amak?ukuzihs???j&oboj?uk??k&a&m&anah?uzuk??sagenak??esonihci??m&akatik?uzia&rih?wi????o&kayim?no&rih?t??tanufo??uhso???isarap,saman,tococ,?ulbybab,?g&3zsiu--nx?71qstn--nx?jw,l?olb&anetah,looc,??h&03pv23--nx?13ynr--nx?22tsiu--nx?61qqle--nx?o-hu,sulb,?i&54urkm--nx?azosbew,ced,g&ayim!.&a&dukak?m&a&goihs?kihs??ihsustam!ihsagih??unawi??r&awago?iho??ta&bihs?rum??w&a&gano?kuruf??iat??y&imot?ukaw???e&mot?nimes??i&hsiorihs?ka&monihsi?s&awak?o???mak?r&ataw?o&muram?tan????o&az?jagat?t&asim?omamay???u&fir?k&irnasimanim?uhsakihcihs?????ihcot!.&a&g&a&h?kihsa??ust??kom?m&ay&o?usarak??unak??r&a&boihsusan?watho??iho?ukas??t&akihsin?iay??wa&konimak?zenakat??y&imonustu?oihs???e&iiju?kustomihs?nufawi??i&akihci?g&etom?ihcot?on???o&k&ihsam?kin??nas?sioruk?tab??u&bim?san?????h&c&ia!.&a&dnah?m&a!h&akat?im??yuni??ihs&ibot?ust???r&a&hat?tihs??ik?u&ihsagih?kawi???t&ihc?o&k?yot???wa&koyot?zani??yi&monihci?rak???e&inak?k&aoyot?usa??manokot?noyot??i&a&gusak?kot?sia??eot?h&asairawo?cugo?s&ahoyot?oyim???k&a&mok?zako??ihssi??motay?rogamag??n&an&ikeh?ok??ihssin??o&got?ihsin?jna?rihsnihs?suf?tes??u&bo?raho?s&oyik?takihs??yrihc?zah????ok!.&a&dusay?kadih?mayotom?r&ah&im?usuy??umakan??sot!ihsin??wa&g&atik?odoyin??k&as?o????i&esieg?hco!k??jamu?k&a!sus??usto??ma&gak?k??rahan??o&mukus?n&i?ust!ihsagih???torum?yot!o???u&koknan?zimihsasot????ugamay!.&a&m&ayukot?ihso??toyot??e&bu?subat??i&gah?kesonomihs?nukawi?rakih??nanuhs?otagan?u&ba?foh?otim?stamaduk?uy?????s&anamay!.&a&dihsoyijuf?mayabat?r&ahoneu?ustakihsin??w&a&k&ayah?ijuf??suran??ohs???egusok?i&ak?h&cimakan?s&anamay?od???k&asarin?u&feuf?sto????o&k&akanamay?ihcugawakijuf??nihso?t&asimawakihci?ukoh??uhc??spla-imanim?u&b&nan?onim??fok?hsok?rust????ubon,??ix,ka&rabi!.&a&bukust?gok?kan!ihcatih??m&a&sak?timo?wi??ihsak?ustomihs??ni?r&a&hihcu?way??u&agimusak?ihcust???t&ag&amay?eman??oihcatih??w&ag&arukas?o??os??yi&moihcatih?rom???e&bomot?dirot?not?tadomihs??i&a&k&as?ot??rao??esukihc?gahakat?h&asa?catih??k&a&rabi?saguyr??ihsani?uy??ma?rukustamat??o&dnab?giad?him?kati?rihsijuf?soj?t&asorihs?im??yihcay??u&fius?kihsu?simak????sagan!.&a&m&abo?ihsust??natawak?r&abamihs?u&mo?ustam???wijihc?yahasi??i&akias?hies?k&asagan?i??masah??neznu?o&besas?darih?t&eso?og!imaknihs????ust&igot?onihcuk?uf????zayim!.&a&biihs?guyh?k&oebon?ustorom??mihsuk?r&emihsin?uatik??ta&katik?mim??wag&atik?odak??ya??e&banakat?sakog??i&hsayabok?kaza&kat?yim??m&animawak?ot&inuk?nihs????nanihcin?o&j&ik?onokayim??n&ibe?ust??tias??urahakat????ro&cep,moa!.&a&dawot?turust?wasim??e&hon&ihc&ah?ihs??nas?og?ukor??sario??i&anarih?ganayati?hsioruk?jehon?kasorih?makihsah?nawo?r&amodakan?omoa???o&gnihs?kkat??u&ragust?stum????ttot!.&a&r&ahawak?uotok??sa&kaw?sim???egok?irottot?nanihcin?o&ganoy?nih?tanimiakas??u&bnan?z&ay?ihc??????ukuf!.&a&deki?gurust?ma&bo?h&akat?im??yustak??sakaw??eabas?i&akas?ho?jiehie?ukuf??nezihce!imanim??ono????k&26rtl8--nx?4&3qtr5--nx?ytjd--nx??522tin--nx?797ti4--nx?ci&gid,ht,sevol,?ee,limybab,n&at,upatilol,??l&33ussp--nx?e&ccabew.&resu,sr,?llarap,?lik,oof,rigetuc,?m&11tqqq--nx?41s3c--nx?a0,ef,sioge,?n&30sql1--nx?65zqhe--nx?a&ebyllej,i&lognom,viv,??iam,n7p7qrt0--nx?o&o&las,mflah,?ruk,staw,??o&131rot--nx?7qrbk--nx?aic,c?d&iakkoh!.&a&deki?gakihset?hcebihs?k&adih?u&fib?narihs???m&ayiruk?hot?ihs&orihatik?ukuf??oras?usta??r&ib&a!ka??o?uruf??ozo?u&gakihsagih?oyot???sakim?ta&gikust?mun??w&a&ga&k&an?uf??nus!imak???k&aru?i&h&asa?sagih??kat?mak??omihs?um??zimawi??ine?oyk??yot??e&a&mustam?nan??b&a&kihs?yak??o&noroh?to???ian?k&ihsam?ufoto??nakami?ppoko!ihsin??sotihc?tad!okah??uonikat??i&a&bib?mokamot?n&a&k&kaw?oroh??wi??eomak?ihsatu?okik?usta&moruk?sakan????eib?h&c&ioy?u&bmek?irihs???s&ase?ekka?oknar?uesom???jufirihsir?k&amamihs?i&at?n???m&atik?otoyot??oa&kihs?rihs??r&a&hs?kihsi?mot??ihs&aba?ir??otarib???n&a&hctuk?rorum?se?tokahs??uber??o&kayot?m&ire?ukay??naruf!ima&k?nim???orih?r&ih&ibo?suk??o&bah?h&i&b?hsimak??sa??pnan?yan??umen??t&asoyik?eko?ukoh???u&bassa?kotnihs?m&assaw?uo??pp&akiin?en&ioto?nuk??ip??rato?s&akat?t&eb&e?i&a?hs!a??robon??m&e?o&m?takan???no&h?tamah??o&mik?s?t??u&kir?ppihc?st???onihsnihs?ufuras??uaru??yru!koh??zimihs!ok?????nu,?g!iti,oyh!.&a&bmat?dnas?gusak?k&at?o&oyot?y??uzarakat??m&ayasas?irah??wa&g&ani?okak??k&i&hci?mak??oy???yi&hsa?monihsin???i&asak?hs&aka?i&at?nawak???j&awa!imanim??emih??k&a&goa?s&agama?ukuf??wihsin??i&hsog?m???mati?oia?rogimak??n&annas?esnonihs??o&gasa!kat??ka?n&ikat?o?ustat??rihsay?sihs?tomus?yas??u&bay?gnihs?????hih,konip,l&b&etah,s,?ik,?mol,nagan!.&a&bukah?d&a&w?yim??e&ki?u??ii??k&a&s&ay?uki??zus??ihsoo?ousay??m&ay&akat?ii??i&hsukufosik?jii??ukihc??n&i!hsetat??uzii??r&ah?ugot??saim?t&agamay?oyim??w&a&g&a&kan?n??o??kustam?ziurak??onim!imanim??u&koo?s!omihs????ya&ko?rih???e&akas?nagamok?subo??i&gakat?h&asa?c&a!mo!nanihs???uonamay??sukagot??k&a&kas?mimanim?to??ia&atik?imanim??oa?uzihcom??m&akawak?ijuf?o!t???r&ato?ijoihs?omakat???n&ana?esnoawazon??o&hukas?n&a&gan?kan??i&hc?muza??ustat??romok?si&gan?k??tomustam??u&k&as?ohukihc??stamega????o&b,m,pac,?to&mamuk!.&a&gamay?rahihsin?sukama!imak??tamanim??enufim?i&hcukik?k&ihsam?u??nugo!imanim??romakat??o&ara?rihsustay?sa?t&amay?om&amuk?us??u!koyg???yohc??u&sagan?zo????yk!.&a&bmatoyk?k&ies?oemak?uzaw??mayi&h&cukuf?sagih??muk??nihsamay?rawatiju?t&away?ik???e&ba&nat!oyk??ya??di?ni??i&ju?kazamayo?manim??natnan?o&gnatoyk?kum?mak?rihsamayimanim?y&gakan?ka&koagan?s??oj???u&ruziam?z&ayim?ik??????wtc1--nx?ykot!.&a&d&i&hcam?mus??oyihc??k&atim?ihsustak??m&a&t!uko??yarumihsa&gih?sum???i&hs&agoa?ika?o!t??uzuok??ren???r&a&honih?wasago??iadok?umah??ssuf?t&ik?o??wa&g&anihs?ode??k&ara?ihcat???y&agates?ubihs???e&amok?donih?m&o?urukihsagih??soyik??i&enagok?gani?h&ca&da?tinuk??sabati??j&nubukok?oihcah??manigus??o&huzim?jihcah?n&akan?ih!sasum??urika??rugem?t&a&mayihsagih?nim??iat?ok??uhc?yknub??u&fohc?hcuf?kujnihs?????p&a&ehc,rc,?o&hs&eht,iiawak,yub,?lf,p&evol,ydnac,?rd&kcab,niar,???r&2xro6--nx?atselttil,e&d&nu,wohc,?h,ilf,pp&ep,irts,u,?t&aerg,tib,??g!r,?ks,o!on,?ufekaf,?s&9nvfe--nx?dom,ndym,p&ihc,oo,?remagten,sikhcnerf,u&bloohcs,ruci,srev,?xvp4--nx??t&a&cyssup,obgip,?e&rces,vlev,?hginyad,netnocresu,sidas,u&b,ollihc,??u&4rvp8--nx?fig!.&a&d&eki?ih??kimot?m&ayakat?ihsah??ne?raha&gi&kes?makak??sak??taga&may?tik??wa&g&ibi?ustakan??karihs!ihsagih????e&katim?uawak??i&gohakas?hc&apna?uonaw??k&ago?es?ot??m&anuzim?ijat??nak?urat??nanig?o&dog?jug?makonim?nim?roy?sihcih??u&fig?s&otom?t&amasak?oay??????hc,pup,stoknot,ynup,?w&gp,onsetihw,?x&5ytlk--nx?irtam,?y&adynnus,dr,knarc,l&oh,rig,?moolg,ob,pp&ih,olf,?r&aidanetah,gn&a,uh,??u6d27srjd--nx?vaeh,?z&72thr--nx?e&ej,lur,??\u4e95\u798f?\u4eac\u6771?\u5206\u5927?\u53d6\u9ce5?\u53e3\u5c71?\u57ce&\u5bae?\u8328??\u5a9b\u611b?\u5c71&\u5bcc?\u5ca1?\u6b4c\u548c??\u5ca1&\u798f?\u9759??\u5cf6&\u5150\u9e7f?\u5e83?\u5fb3?\u798f??\u5d0e&\u5bae?\u9577??\u5ddd&\u5948\u795e?\u77f3?\u9999??\u5eab\u5175?\u5f62\u5c71?\u624b\u5ca9?\u6728\u6803?\u672c\u718a?\u6839\u5cf6?\u68a8\u5c71?\u68ee\u9752?\u6f5f\u65b0?\u7389\u57fc?\u7530\u79cb?\u77e5&\u611b?\u9ad8??\u7e04\u6c96?\u826f\u5948?\u8449\u5343?\u8cc0&\u4f50?\u6ecb??\u9053\u6d77\u5317?\u90fd\u4eac?\u91cd\u4e09?\u91ce\u9577?\u961c\u5c90?\u962a\u5927?\u99ac\u7fa4???k!.&art?gro?moc?per?ude?vog???l&eh?l??m!.uj,ac!.fme.ta,?j??nd?o&g?h&pih?s!.&e&nilnoysrab,rawpohs,sab,?xilpoh,ysrab,???oc?t!.lldtn,??pa!.&44esab,a&hcom,rusah,?b&2e,ew,sc:.weiverp,,u&htig,lckcah,??deepseroc,e&dualc,erf-korgn,gatskrelc,lbavol,nilnigol,ralfduolc,sabnwaps,tupmocegde,varb,?frusdniw,hsadtob,i&lressem,nayul,?k&eelf-no,orgn,relc,?l&aw,e&crev,napysae,?lecpael,ooter,?maerdepyt,n&aecolatigidno,e&pedoc,rim,via,??opxe:.&gnigats:.no,,no,?,poon,r&cne:.dnetnorf,,e&m&arf,saw,?tup,?ubaez,?s&e&lucrehno,tirps,?jasudem,nrettapcigam,oedilg,?t&ayn,egdag,i&belet,l&maerts,per:.di,,??luavreve.yaler,xenw,?w&eiverptekcor,olfrettulf,?x&evnoc,lpp,?y&a&dotpihs,wliar.pu,?filten,???ra&a?hs??u&ekam?llag?org!.esruocsid,cts?kouk?nayalo???vsr?xece4ibgm--nx??q&a!3a9y--nx??g?i!.&gro?lim?moc?ten?ude?vog???m?se??r&a!.&a&cisum?sanes??bog?g&es?ro??l&autum?im??moc?pooc?rut?t&e&b?n??ni??ude?vog??4d5a4prebgm--nx?b!.evloser,?c?eydoog?los?t&at?s!uen???ugaj??b!.&21g?a&b&a&coros?iuc??itiruc??cnogoas?dicerapa?gniram?i!naiog?ramatnas??n&erom?irdnol??op?p&acam?irolf?ma&j?s???rief?tsivaob??b!aj?ib?mi?sb??c&ba?e&r?t??js?sp?t!e???d&em?mb?n&f?i??rt??e&dnarganipmac?ficer?h&ct,t??llivnioj?rdnaotnas??f&dj?ed?gg?n&e?i???g&e&l!.&a&b,m,p,?bp,c&a,s,?e&c,p,s,?fd,gm,ip,jr,la,ma,nr,o&g,r,t,?p&a,s,?r&p,r,?s&e,m,r,?tm,??s??l&s?z??n&c?e?o??ol!b?f?v??pp?ro??hvp?i&du?kiw?nana?oretin?pa?r&c?eurab??sp?te?xat??l&a&icos?t&an?rof???el?im?sq??m&a?da?e&gatnoc?leb??f?ic?oc!.etiselpmis,??nce?o&a&liel?riebir??c&e?narboir?saso??d&o?ranreboas??e&g?t??i&b?dar?ecam?r??rp?t&a?erpoir???p&er?m!e?t??ooc?pa?se??qra?r&af?ga?o&davlas?j??tn?ut??s&a&ixac?mlap?nipmac??ed?u&anam?j?m???t&am?e&b?d?n?v??nc?o&f?n??ra?sf??u&caug9?de?ja?rg??v&da?ed?og!.&a&b?m?p??bp?c&a?s??e&c?p?s??fd?gm?ip?jr?la?ma?nr?o&g?r?t??p&a?s??r&p?r??s&e?m?r??tm???rs?t??xiv?z&hb?ls?o&c?f??yx????c!.&as?ca?de?if?o&c?g??ro???e&bew?ccos?e&b?n&igne?oip??rac??gni&arg?rheob??h&sok?t&aew?orb???itnorf?k&col?o&p?rb???l&aed?ffeahcs??mal?nes?t&a&eht?rebsneg\u00f6mrev??law?nec?s&nom?ubkcolb??upmoc??v&o&csid?rdnal??resbo??wulksretlow?ywal?zifp??f!.&aterg?bew&-no,etis321,?drp?e&c&itsuj-reissiuh?narf-ne-setsitned-sneigrurihc,?lipuog,rianiretev,?hny,i&cc?rgabmahc,?m&o&c?n??t??n&eicamrahp,icedem,?ossa?pohsdaerpsym,s&e&lbatpmoc-strepxe,riaton,tsitned-sneigrurihc,uova??ndk,o&-x&bf,obeerf,?x&bf,obeerf,???t&acova,rop:orea,,?vuog?xobided,?avc7ylqbgm--nx?s??g!.&etiselpmis,gro?moc?ten?ude?vog?ysrab,??h!.&eman?mo&c?rf??yldnerb.pohs,zi??ur??i!.&a&61f4a3abgm--nx?rf4a3abgm--nx??ca?di?egdenavra,g&olbatsiv,ro??hcs?oc?ten?vog?\u0646\u0627\u0631&\u064a\u0627?\u06cc\u0627???a&h?per??ew?lf??k!.&10c,c&a?s??e&m?n?p?r??gk?i&a?ggnoeyg?kv,pa-vile,?kub&gn&oeyg?uhc??noej??l&im?uoes??man&gn&oeyg?uhc??noej??n&as&lu?ub??dc-vile,o&e&hcni?jead??wgnag???o&c?g?i??ro?s&e?h?m?nd-vile,?ti?u&gead?j&ej?gnawg???vmm,?cilf??l!.&gro?moc?ten?ude?vog???m!.vog??n!.&gro?moc?ofni?ten?ude?vog?zib???o&htua?t&c&a?od??laer???p!.&alsi?ca?eman?forp?gro?moc?o&fni?rp??t&en?se??ude?vog?zib???s?t!.&21k?bew?cn!.vog??eman?gro?kst?l&e&b?t??im?op??moc?neg?ofni?pek?rd?sbb?ten?ude?v&a?og?t??zib??f?m??vd??s&8sqif--nx?9zqif--nx?a!.vog?birappnb?gev?lliv?mtsirhc?s??b!.&ew,gro?moc?ten?ude?vog??oj?s?u??c&i&hparg?p?tylana??od??d&a?d?ik?l?n&iwriaf?omaid??oogemoh?rac??e!.&b&ewim321,og??gro?mo&c?n??pohsdaerpsym,ude??civres!.enilnigol,?d&d2bgm--nx?oc??h&ctaw?guh??i&lppus?rtsudni?treporp!yrrek???jaiv?l&aw?cycrotom?gnis?pats??m&ag!.y&elp,zeehs,??oh?reh??nut?ohs?picer?r&it?ut&cip!.7331,?nev???s&i&rpretne?urc??ruoc??taicossa?vig??g!nidloh??h5c822qif--nx?i!a09--nx?nnet?rap?targ??k&c&or!.&ecapsbew,snddym,tikcats,ytic-amil,??us??hxda08--nx?row??l!.&c&a?s??gro?o&c?fni??ten?ude?vog?zib??a&ed?tner??e&ssurb?toh!yrrek???lahsram?m?oot!.rdda&.nyd,ym,???m!.&etisinim,gro?moc?ten?ude?vog??b?etsys!.nerim,?ialc??n&a&f?gorf?ol??i&a&grab?mod??giro??o&it&acav?cudorp?ulos??puoc???o&dnoc?geuj?ppaz?t&ohp!.remarf,?ua???p!.&ces?gro?moc?olp?ten?ude?vog??i&hsralohcs?lihp?t??u??r!.&ca?gro?ni?oc?ude?vog?xo,y&ldnerb.pohs,srab,??a&c?p?tiug??c?e&dliub!.etisduolc,?erac?gor?levart?mraf?n&niw?trap??wolf??ot&cartnoc?omatat??pj?uot??s!.&em?gro?hcs?moc?oc?ten?ude?vog?zib??alg?e&n&isub!.oc,?tif??rp!xe!nacirema???xnal??iws??t&a&eb?ob??ek&cit?ram??fig?h&cay?gilf??n&atnuocca?e&mt&rapa?sevni??ve!.&nibook,oc,????rap??u!.&a&c!.&21k?bil?cc???g!.&21k?bil?cc???i!.&21k?bil?cc???l!.&21k?bil?cc???m!.&21k!.&hcorap?rthc?tvp???bil?cc???p!.&21k?bil?cc???si?v!.&21k?bil?cc???w!.&21k?a&es,i&lartnec,pmylo,??bil?cc?d&n&esnwot-trop,omder,?rahcro-trop,?e&l&adrevlis,ttaes,?uvelleb,?lsi-egdirbniab,m&aiuqoh,iuqes,?n&eedreba,ot&lehs,ner,remerb,sgnik,??obsluop,robrah-gig,s&elegna-trop,ilahehc,krof,?t&niop-worray,ropyek,?woldul-trop,???c&d!.&21k?bil?cc???n!.&21k?bil?cc???s!.&21k?bil?cc????d&elacsne.xhp,i!.&21k?bil?cc???m!.&21k?bil?cc???n?s!.&bil?cc???uolcrim,?e&d!.cc??las-4-&dnal,ffuts,?m!.&21k?bil?cc??anrevres,?n!.&21k?bil?cc????h&n!.&21k?bil?cc???o!.&21k?bil?cc????i&h!.&bil?cc???m!.&21k?bil?c&c?et??goc?n&eg?otae??robra-nna?sum?tsd?wanethsaw???nd?pa-eruza,r!.&bil?cc???v!.&21k?bil?cc???w!.&21k?bil?cc????jn!.&21k?bil?cc???k&a!.&21k?bil?cc???o!.&21k?bil?cc????l&a!.&21k?bil?cc???f!.&21k?bil?cc???i!.&21k?bil?cc????mn!.&21k?bil?cc???n&afflog,i!.&21k?bil?cc???m!.&21k?bil?cc???sn?t!.&21k?bil?cc????o&c!.&21k?bil?cc???gn,m!.&21k?bil?cc???ttniop,?pion,r&a!.&21k?bil?cc???o!.&21k?bil?cc???p!.&21k?bil?cc????s&a!.&21k?bil?cc???etisbeweruza,k!.&21k?bil?cc???m!.&21k?cc???nd&deerf,uolc,?ppaskcirbatad.vog-swa,?t&c!.&21k?bil?cc???m!.&21k?bil?cc???sohoileh,u!.&21k?bil?cc???v!.&21k?bil?cc????ug!.&21k?bil?cc???v&n!.&21k?bil?cc???rs:.&hg,lg,?,w!.cc???xt!.&21k?bil?cc???y&b-si,k!.&21k?bil?cc???n!.&21k?bil?cc???w!.&21k?bil?cc????za!.&21k?bil?cc????ah!uab??bria?col?e!.ytrap.resu,?ineserf?lp!.tiyalp:.htiw,,?xe&l?n???vt?w!.&66duolc,gro?moc?s&ndnyd,tepym,?ten?ude?vog??a!.&no.&1-&ht&ron-ue.&lru-adbmal,ppabew-refsnart,?uos-&em.&lru-adbmal,ppabew-refsnart,?fa.&lru-adbmal,ppabew-refsnart,?pa.&lru-adbmal,ppabew-refsnart,?ue.&lru-adbmal,ppabew-refsnart,???lartnec-&ac.&lru-adbmal,ppabew-refsnart,?em.ppabew-refsnart,li.ppabew-refsnart,ue.&lru-adbmal,ppabew-refsnart,?xm.ppabew-refsnart,?ts&ae&-&as.&lru-adbmal,ppabew-refsnart,?pa.&lru-adbmal,ppabew-refsnart,?su.&lru-adbmal,ppabew-refsnart,?vog-su.&ppabew-refsnart,spif-ppabew-refsnart,??ht&ron-pa.&lru-adbmal,ppabew-refsnart,?uos-pa.&lru-adbmal,ppabew-refsnart,???ew-&ac.ppabew-refsnart,su.&lru-adbmal,ppabew-refsnart,?ue.&lru-adbmal,ppabew-refsnart,?vog-su.&ppabew-refsnart,spif-ppabew-refsnart,????2-&htuos-&pa.ppabew-refsnart,ue.ppabew-refsnart,?lartnec-ue.ppabew-refsnart,ts&ae&-&pa.ppabew-refsnart,su.&lru-adbmal,ppabew-refsnart,??ht&ron-pa.&lru-adbmal,ppabew-refsnart,?uos-pa.&lru-adbmal,ppabew-refsnart,???ew-&su.&lru-adbmal,ppabew-refsnart,?ue.&lru-adbmal,ppabew-refsnart,????3-ts&aeht&ron-pa.&lru-adbmal,ppabew-refsnart,?uos-pa.&lru-adbmal,ppabew-refsnart,??ew-ue.&lru-adbmal,ppabew-refsnart,??4-tsaehtuos-pa.ppabew-refsnart,5-tsaehtuos-pa.ppabew-refsnart,6-tsaehtuos-pa.ppabew-refsnart,7-tsaehtuos-pa.ppabew-refsnart,?rekamegas.&1-&ht&ron-ue.&koobeton,oiduts,?uos-&em.&koobeton,oiduts,?fa.&koobeton,oiduts,?pa.&gnilebal,koobeton,oiduts,?ue.&koobeton,oiduts,???lartnec-&ac.&gnilebal,koobeton,oiduts,spif-koobeton,?em.&koobeton,oiduts,?li.&koobeton,oiduts,?ue.&gnilebal,koobeton,oiduts,??ts&ae&-&as.&koobeton,oiduts,?pa.&koobeton,oiduts,?su.&gnilebal,koobeton,oiduts,spif-koobeton,?vog-su.&koobeton,oiduts,spif-&koobeton,oiduts,???ht&ron-pa.&gnilebal,koobeton,oiduts,?uos-pa.&gnilebal,koobeton,oiduts,???ew-&ac.&koobeton,spif-koobeton,?su.&koobeton,oiduts,spif-koobeton,?ue.&gnilebal,koobeton,oiduts,?vog-su.&koobeton,oiduts,spif-&koobeton,oiduts,?????2-&htuos-&pa.koobeton,ue.&koobeton,oiduts,??lartnec-ue.&koobeton,oiduts,?ts&ae&-su.&gnilebal,koobeton,oiduts,spif-koobeton,?ht&ron-pa.&gnilebal,koobeton,oiduts,?uos-pa.&gnilebal,koobeton,oiduts,???ew-&su.&gnilebal,koobeton,oiduts,spif-koobeton,?ue.&gnilebal,koobeton,oiduts,????3-ts&aeht&ron-pa.&koobeton,oiduts,?uos-pa.&koobeton,oiduts,??ew-ue.&koobeton,oiduts,??4-tsaehtuos-pa.koobeton,???e&iver!.mea,?n!.elbaeciton,??odniw??y&alcrab?ot???t&0srzc--nx?a!.&4,amil4,ca!.hts??e&mohsnd,tiesbew321,?gni&liamerutuf,tsoherutuf,?oc?p&h21,ohsdaerpsym,?r&euefknuf.neiw,o??v&g?irp,?xi2,y&m,tic-amil,??c?e!s??hc?l?mami?rcomed??b!.&gro?moc?ten?ude?vog??b?gl??c&atnoc?e&les?rid!.p2pbil,txen????dimhcs?e!.&eman?gro?moc?ofni?ten?ude?vog?zib??b?em?grat?id?k&circ?ram??n!.&1dna1-sppa,46vpi,5&ed,inu,?6vnyd,7&7ndc.r,erauqs,?a&l&-morf,moob,?minifed,remacytirucesym,tadsyawla,z,?b&boi,ewdarym,g,lyltsaf:.pam,,?c&baz,i&manyd-snd,nagro-gnitae,tats-oieboda,?paidemym,?d&e&calpb,ziamaka,?feruza,hiamaka,irgevissam.saap.&1-&gs,nol,rf,yn,?2-&nol,yn,??nab-eht-ni,uolc&-snd,ehtgnituor,ftc,meaeboda,nievas.c&di-etsedron,itsalej,?xednay:.e&garots,tisbew,?,??e&c&narusnihtlaehezitavirp,rofelacs.j,?gde&eruza,iamaka,?ht-no-eciffo,l&acsnoom,ibom-eruza,omlennut,?m&antenym.ns,ecnuob,itnuroieboda,ohtanyd,tcerider,?n&ilno-evreser,ozdop,?r&alfduolc:.ndc,,ehurht,?s:abapus,,ti&s-repparcs,usegde,?zam&aym,kcar,??f&aeletis,crs.&cos,resu,?ehc-a-si,fgg,?g&ni&gats-&d&eziamaka,hiamaka,?e&gdeiamaka,tiusegde,?iamaka,nigiroiamaka,yekegde,?reesnes,sirkcilc,?olbevres,?hsadtob,i&amaka,nayul,pa&-eruza,duolcvogsu.&eroc.&b&ew,olb,?elif,?subecivres,???k&eeg-a&-si,si,?ipo,u,?l&a&bolgeralfduolc.ndc,colottad,?iamwt,meteh,s&d-ni,s-77ndc,??m&ac&asac,ih,?urofniem,?n&a&f&agp,lhn,?i&bed,llerk,??ceralfduolc.ndc,dcduabkcalb,i:giroiamaka,,o-&drowyek,evil,revres,?pv-ni,srh.spv,?o&c-morf,duppa,jodsnd,lefam,n&ed:.xobdnas,,refnino,?rp-ytinummoc,ttadym,?p&i&-&etsef,on,sndd,?emoh,fles,nwo,?j,mac-dnab-ta,o&-oidar-mah,h&bew,sdaerpsym,??paduolc:vogsu,,tfe&moh,vres,?usnd,?r&e&ganamciffart:vogsu,,tsulcyduolc,vres-xnk,?vdslennahc:.u,,?s&a&ila&nyd,snd,?nymsd,?bbevres,dylimaf,e&gde-ndc,rauqs,suohsyub,t&isbeweruza:.10-&2&lartnecailartsua,su&lartnechtuos,ts&ae,ew,???3suts&ae,ew,?5sutsaeht&ron,uos,?ai&dni&htuos,lartnec,tsew,?satsae:htuos,,?e&gats&aisatsae,sulartnechtron,?porue&htron,tsew,??ht&ron&acirfahtuos,dnal&aezwen,reztiws,?eau,nawiat,y&lati,namreg,??uos&aerok,ecnarf,ku,lizarb,nedews,??lartnec&a&danac,erok,i&dnioij,lartsua,senodni,??dnalop,e&au,cnarf,lihc,?htuosaidni,learsi,muigleb,n&edews,iaps,?ocixem,rataq,tsewynamreg,?paue&2sutsae,sulartnec,?su&lartnec:ht&ron,uos,?tsew,,ts&ae,ew,??ts&ae&a&danac,i&lartsua,rtsua,??htuos&ailartsua,lizarb,?kramned,napaj,yawron,?ew&a&cirfahtuos,i&dnioij,syalam,??dnalreztiws,htron&learsi,nawiat,?ku,napaj,yawron,???,ys,??kekokohcs,n&d&-won,aka,d:unyd,,golb,npv,?oitcnufduolc,?ppacitatseruza:.&1,2:suts&ae,ew,?,3,4,5,6,7,aisatsae,eporuetsew,sulartnec,?,s&a-skcik,ecca&-citats,duolc,??t,wodniw.&eroc.&b&ew,olb,?elif,?subecivres,??t&adies,ce&ffeym,jorprot:.segap,,lespohs,?e&nretnifodne,smem,?farcenimevres,i-&ekorb,s&eod,lles,teg,??n&e&ssidym,tnocresuv,?orfduolc,?reclacol,s&acynaeralfduolc.ndc,ixetnod,oh&-spv:.citsalej.&cir,lta,sjn,?,gnik,??yrps,?u&h,nyd,r,?ved-&anafarg,naissalta.dorp.ndc,?x&inuemoh,spym,tsale.&1ots-slj,2ots-slj,3ots-slj,?unilemoh,?y&a&p-csbus,wetag-llawerif,?ekegde,ffijduolc:.&ed-1arf,su-1tsew,?,golonysym,ltsaf.&dorp.&a,labolg,?lss.&a,b,labolg,?pam,slteerf,?n&-morf,ofipi,?srab,?z&a-morf,tirfym,???p?tcip?v??f&ig?osorcim??g!.&bog?dni?gro?lim?moc?ten?ude???h!.&dem?gro?l&er?op??m&oc?rif??o&fni?rp?s&rep?sa???po&hs?oc??t&en?luda?r:a?,?ude?vuog???i!.&a&2n-loritds--nx?7e-etsoaellav--nx?8&c-aneseclrof--nx?i-lrofanesec--nx??at?b?c!cul??dv?i&blo&-oipmet?oipmet??cserb?drabmol?g&gof?urep??l&gup?i&cis?me&-oigger?oigger???uig&-&aizenev&-iluirf?iluirf??ev&-iluirf?iluirf??v&-iluirf?iluirf???aizenev&-iluirf?iluirf??ev&-iluirf?iluirf??v&-iluirf?iluirf????n&a&brev?cul?pmac?tac??idras?obrac&-saiselgi?saiselgi??resi??otsip?r&b&alac!-oigger?oigger??mu??dna&-&attelrab-inart?inart-attelrab??attelrabinart?inartattelrab?ssela??epmi?ugil??tnelav&-obiv?obiv??vap?z&e&nev?ps&-al?al???irog???l&iuqal?leib?osso-oisuc-onabrev??m&or?rap??n!acsot?e&dom?is?sec&-&ilrof?\u00eclrof??ilrof?\u00eclrof???g&amor&-ailime?ailime??edras!-dus?dus??olob??i&ssem?tal??ne!var??o&cna?merc?rev?vas???oneg?p?r!a&csep?rr&ac&-assam?assam??ef??von??etam?tsailgo!-lled?lled???s!ip?sam&-ararrac?ararrac??u&caris?gar???t!a&cilisab?recam??resac?soa!-&d&-&ellav?lav??ellav?lav??ellav??d&-&ellav?lav??ellav??ellav??te&lrab&-&airdna-inart?inart-airdna??airdnainart?inartairdna??ssinatlac???udap?v!o&dap?neg?tnam???zn&airb&-a&lled-e-aznom?znom??a&lledeaznom?znom??eaznom??e&c&aip?iv??soc?top??om???b&-&23,46,61,?3c-lorit-ds-onitnert--nx?be-etsoa&-ellav--nx?dellav--nx??c!f-anesec-lrof--nx?m-lrof-anesec--nx??he-etsoa-d-ellav--nx?m!u??o2-loritds-nezob--nx?sn-loritds&-nasl&ab--nx?ub--nx??nitnert--nx??v!6-lorit-dsnitnert--nx?7-loritds&-nitnert--nx?onitnert--nx???z&r-lorit-ds&-nitnert--nx?onitnert--nx??s-loritds-onitnert--nx???c&f?is?l?m?p?r?v??d&p?u!olcnys,??e&c!cel?inev?nerolf??f?g!apemoh321,ida&-&a&-onitnert?onitnert??otla!-onitnert?onitnert???a&-onitnert?onitnert??otla!-on&azlob?itnert??onitnert????hcram?l?m!o&hsnd,r???n&idu?o&n&edrop?isorf??torc???p?r?s&erav?ilom??t!nomeip?s&eirt?oa!-&d-e&ellav?\u00e9llav??e&ellav?\u00e9llav???de&ellav?\u00e9llav??e&ellav?\u00e9llav?????v?znerif??g&a?b?f?il?o?p?r?up?vf??hc?i&b?c?dol?f?l!lecrev?opan?rof&-anesec?anesec???m?n&a&part?rt&-attelrab-airdna?attelrabairdna???imir?ret??p?r!a&b?ilgac?ssas???s!idnirb??t&ei&hc?r??sa??v??l&a!c??b?c?o&m?rit&-&d&eus&-&nitnert?onitnert??nitnert?onitnert??us&-&nitnert?onitnert??nitnert?onitnert??\u00fcs&-&nitnert?onitnert??nitnert?onitnert???s&-onitnert?onitnert???d&eus!-&n&asl&ab?ub??ezob?itnert??onitnert??nitnert?onitnert??us&-&n&asl&ab?ub??ezob?itnert??onitnert??nitnert??\u00fcs!-&n&asl&ab?ub??ezob?itnert??onitnert??nitnert?onitnert???s&-onitnert?onitnert?????m&ac?f?i?ol?r??n&a!lim?sl&ab?ub???b?c?e!en.cj,v?zob??irut?m!p??p?r?t??o&a!v??b!retiv??c!cel??enuc?g!ivor??i&dem&-onadipmac?onadipmac??pmet&-aiblo?aiblo??rdnos?zal??l?m!a&greb?ret??oc?re&f?lap???n!a&dipmac&-oidem?oidem??lim?tsiro?zlob??ecip&-ilocsa?ilocsa??i&bru&-orasep?orasep??lleva?rot?tnert??r&elas?ovil??ulleb??p?r!a&sep&-onibru?onibru??znatac??oun??s!ivert?sabopmac??t!arp?e&nev?ssorg??n&arat?e&girga?rt?veneb????zz&era?urba???p&a?ohsdaerpsym,s?t??qa?r&a!m?s??b!a??c?f?g?k?me?o?p?s?t?v??s&a&b?iselgi&-ainobrac?ainobrac???b?c?elpan?i?m?o&t?x&bi,obdaili,??s?t?v??t&a?b?c?l?m?nomdeip?o?p?v??u&de?l?n?p?s??v&a?og?p?s?t?v??y&drabmol?ellav&-atsoa?atsoa??licis?nacsut??z&al?b?c?p??\u00eclrof&-anesec?anesec???derc?er?f?m?utni??je3a3abgm--nx?kh?l!.vog?uda??m!.&gro?moc?ten?ude???n&a&morockivdnas?ruatser?tnuocca??e&g?m&eganam?piuqe??r??i!.ue?m?opdlog??opud?uocsid??o&b?cs!.&em,gro,oc,vog:.ecivres,ym,,??d?g?h?j?oferab?p&edemoh?s???p!.&bewanigap321,emon?gro?lbup?moc?t&en?ni??ude?vog???r&a!m&law?s???epxe?op&er?pus!.ysrab,?s???s!.&a&daxiabme?rarik,?e&motoas?picnirp?rots??gro?lim?moc?o&c?dalusnoc?ho&ileh,n,??ten?ude??af?e&b?r?uq??i!rolf?tned??o&h!.&2pw,duolcrim,e&lej,tiseerf,?flah,l&enapysae,rupmet,?s&pvtsaf,seccaduolc,?t&egdag,lob,negreme,safym,?v&edumpw,resi,???p!sua???urt??t!.&eman?gro?lim?moc?o&c?fni?rp??ten?ude?vog?zib??ayh?n?o!bba?irram???uognah?xen?y!.gro,?ztej??u&2&5te9--nx?yssp--nx??a!.&a&s?w??civ?d&i?lq??fnoc?gro?moc!.&pohsdaerpsym,stelduolc.lem,??nsa?sat?t&ca?en?n??ude!.&a&s?w??ci&lohtac?v??dlq?sat?t&ca?n??wsn???vog!.&a&s?w??civ?dlq?sat???wsn?zo??ti??c!.&bog?fni?gro?moc?t&an?en??ude??i??d&e!.tir.segap-tig,?iab??e!.&emohsnd,odagod.citsalej,pwtcerid,s&ecivresbewnozama.no.1-tsae-ed-csue.p&di-otingoc.htua,pabew-refsnart,?nd&ps,uolc,?ruelfxued,?wvrp,ysrab,??g!.&bew?gro?m&aug?oc??ofni?ten?ude?vog???h!.&0002?a&citore?idem?kitore??edszot?gro?ilus?letoh?m&alker?lif?t?urof??naltagni?o&c?ediv?fni?levynok?nisac??pohs?rarga?s&a&kal?zatu??emag?wen??t&lob?rops??virp?xe&s?zs??ytic?zsagoj??os?sut??l!.etisbew321,?m!.&ca?gro?moc?oc?ro?ten?vog???n!.&duolcesirpretne,eni&esrem,m,?tenkcahs,?em!.&enilnoysrab,ysrab,???o&ggnaw?y!c???r!.&a&i&kymlak,rikhsab,vodrom,?yegyda,?bps,ca,duolcrim,e&niram,rpcm,?g&bc,ro,?ianatsuk,k&ihclan,s&m,rogitayp,??li&amdlc.bh,m,?moc,natsegad,onijym,pp,ri&b,d&cm:.spv,,orue,?midalv,?s&ar,itym,?t&en,ni,?u&4an,de,?vo&g,n,?ynzorg,zakvakidalv,?myc?p?ug??s!.&a&d&golov,nagarak,?gulak,i&groeg,kymlak,lerak,nemra,rikhsab,ssakahk,vodrom,zahkba,?lut,rahkub,vut,yegyda,znep,?bps,da&baghsa,rgonilest,?gunel,i&anatsuk,hcos,ovan,ttailgot,?k&alhsygnam,ihclan,s&legnahkra,m,n&a&mrum,yrb,?i&buytka,nbo,??tiort,vorkop,??l&ocarak,ybmaj,?na&gruk,jiabreza,ts&egad,hkazak-&htron,tsae,???ovonavi,r&adonsark,imidalv,?t&enxe,nek&hsat,mihc,??vo&hsalab,n,?ynzorg,z&akvakidalv,emret,??t&amok?i&juf?masih????v!.&gro?moc?ten?ude???ykuyr??v&b?c!.&di?e&mon?rots,?gro?lbup?moc?t&en?ni??ude?ved,??ed!.&2r,a-&si,ton-si,?codeberg,d&aolyap,oog-a-si,?e&erf-korgn,garots.3t,nilnigol,varb,?g&nigats-oned,olbraeb,?h&cetaidem,sadtob,?ipaegarots.3t,k&catslluf-a-si,orgn,?l&e&crev,nap,?lecpael,ooc-si,?n&epedoc,srh,?oned,p&l:.&ipa,stcejbo,?,ohsuneviv,pa-rettalp,re:.bew,,?r&ddaym,eyalplacol,?s&egap,re&krow,niatnocnur,??t&imx,luavreve.yaler,?vresi,weiverpbuhtig,x&dom,obdnas-ahcom,?y&lf,srab,???ih?l!.&di?fnoc?gro?lim?moc?nsa?ten?ude?vog???m!.&eman?gro?lim?m&oc?uesum??o&fni?r&ea?p???pooc?t&en?ni??ude?vog?zib???o&g?m??rt?s!.&bog?der?gro?moc?ude???t!.&arukas,bew-eht-no,morf,naht-&esrow,retteb,?sndnyd,?d?i?won??uqhv--nx??w&a!.moc?l??b!.&ca?gro?oc?ten?vog???c!.&gro?moc?ten?ude??cp??e&iver?n?s??g!.xn,?k!.&bme?dni?gro?moc?ten?ude?vog???m!.&ca?gro?moc?oc?pooc?t&en?ni??ude?vog?zib??b??o&csom?h!s!.sm,??n!.&ereh,nyd,pmt,??w??p!.&344x,snduolc,vog???r!.&ca?gro?lim?oc?pooc?ten?vog??n??t!.&bulc?emag?gro?l&im?ru,?moc!.reliamym,?sndym,ten?ude?v&di?og??zibe???z!.&ca?gro?lim?oc?vog????x&a!t??c!.&dehcraeser,hta,ofni,s&ezziuq,lennuf,nduolc,rotaluclac,t&nemssessa,set,??vog?wonyap,??e&d&ef?nay??ma!nab??rof?s??ilften?jt?m!.&bog?gro?moc?ten?ude??g?ma2ibgy--nx??o&b!x??f?rex??rbgn--nx?s!.vog??x&am&jt?kt??x???y&4punu--nx?7rr03--nx?a&d!i&loh?rfkcalb??ot!.emyfilauqerp,??g!.segap,?lp?p!ila??rot?ssin?wdaorb??b!.&fo?hcetaidem,lim?moc?vog??ab?gur??c!.&ca?dtl?gro?lim?m&oc!.ecrofelacs.j,?t??orp?s&egolke?serp??ten?vog?zib??amrahp?nega??d&dadog?uts??e&kcoh?n&dys?om?rotta??snikcm??g!.&gro?moc?oc?ten?ude?vog??olonhcet!.oc,?rene??hpargotohp?id!.e&nigami,sruocsid,??k!.&gro?moc?ten?ude??s??l!.&clp?d&em?i??gro?hcs?moc?ten?ude?vog??f?imaf!nacirema??l&a?il??ppus??m!.&eman?gro?lim?moc?ten?ude?vog?zib??edaca!.laiciffo,?ra??n&apmoc!.xobym,?os??o&j?s??p!.&gro?lim?moc?pooc?ten?ude?vog???r&e&corg?grus?llag?viled??lewej?otcerid?tnuoc?uxul??s!.&gro?lim?moc?ten?ude?vog???t&efas?i&c?ledif?nummoc!.&bdnevar,gon,murofym,??r&ahc?uces??srevinu??laer?r&ap?eporp??uaeb??u!.&bug?gro?lim?moc?ten?ude?vg,?b!tseb???van?xes??z&a!.&eman?gro?lim?moc?o&c?fni?rp??pp?t&en?ni??ude?vog?zib???b!.&az,gro?jsg,moc?oc?sndym,ten?ude?vog???c!.&4e,9yxorptnetnoc.csr,inum.duolc.&rsu,tlf,?m&laer,urtnecatem.motsuc,?oc,vog???d!.&cos?gro?lop?m&oc?t??ossa?t&en?ra??ude?vog???ib!.&duolcsd,e&ht-rof,mos-rof,rom-rof,?izoj,liartevitca,nafamm,p&i&-&duolc,on,?fles,?ohbew,tfym,?retteb-rof,snd&nyd,uolc,?xro,?g??k!.&duolcj,gro?lim?moc?ten?ude?vog???m!.&ca?gro?lim?oc?ten?ude?v&da?og????n!.&asq-irom--nx?ca?gro?htlaeh?i&r&c?o&am?\u0101m???wi!k???keeg?l&im?oohcs??neg?oc?snduolc,t&en?nemailrap?vog???a!niflla???rawhcs?s!.&ca?gro?oc???t!.&c&a?s??e&m?n??ibom?l&etoh?im??o&c?fni?g??ro?vt???u!.&gro?moc?oc?ten??rwon??yx!.&e&nieffac,xe,?hsadtob,lennutnepo,??zub??\u03bb\u03b5?\u03c5\u03b5?\u0430\u0432\u043a\u0441\u043e\u043c?\u0431\u0440\u0441!.&\u0433\u0440\u043e?\u0434\u043e?\u043a\u0430?\u0440&\u0431\u043e?\u043f!\u0443?????\u0433&\u0431?\u0440\u043e??\u0434\u043a\u043c?\u0437\u0430\u049b?\u0438\u0442\u0435\u0434?\u043a\u0438\u043b\u043e\u0442\u0430\u043a?\u043b\u0435\u0431?\u043c\u043e\u043a?\u043d&\u0439\u0430\u043b\u043d\u043e?\u043e\u043c??\u0440\u043a\u0443?\u0441\u0443\u0440!.&\u0430\u0440\u0430\u043c\u0430\u0441,\u0431\u043f\u0441,\u0433\u0440\u043e,\u0437\u0438\u0431,\u0438\u0447\u043e\u0441,\u043a\u0441\u043c,\u043c&\u043e\u043a,\u044b\u0440\u043a,?\u0440\u0438\u043c,\u044f,??\u0442\u0439\u0430\u0441?\u0444\u0440?\u044e\u0435?\u0575\u0561\u0570?\u05dc\u05d0\u05e8\u05e9\u05d9!.&\u05d1\u05d5\u05e9\u05d9?\u05d4\u05d9\u05de\u05d3\u05e7\u05d0?\u05dc&\u05d4\u05e6?\u05e9\u05de\u05de????\u05dd\u05d5\u05e7?\u0627\u064a&\u0631\u0648\u0633?\u0633\u064a\u0644\u0645?\u0646\u0627\u062a\u064a\u0631\u0648\u0645??\u0628\u0631&\u0639?\u063a\u0645\u0644\u0627??\u0629&\u0643\u0628\u0634?\u064a&\u062f\u0648\u0639\u0633\u0644\u0627?\u0631\u0648\u0633??\u06cc\u062f\u0648\u0639\u0633\u0644\u0627??\u062a&\u0627\u0631\u0627\u0645\u0627?\u0631\u0627&\u0628?\u0680?\u06be\u0628???\u0631&\u0626\u0627\u0632\u062c\u0644\u0627?\u0627\u0632\u0627\u0628?\u0635\u0645?\u0637\u0642??\u0633\u0646\u0648\u062a?\u0639\u0642\u0648\u0645?\u0642\u0627\u0631\u0639?\u0643&\u062a\u064a\u0628?\u064a\u0644\u0648\u062b\u0627\u0643??\u0645\u0648\u0643?\u0646&\u0627&\u062a\u0633&\u0643\u0627\u067e?\u06a9\u0627\u067e??\u062f\u0648\u0633?\u0631&\u064a\u0627?\u06cc\u0627??\u0645\u0639?\u064a\u0644\u0639\u0644\u0627??\u062f\u0631\u0627\u0644\u0627?\u0645\u064a\u0644\u0627?\u064a&\u0631\u062d\u0628\u0644\u0627?\u0637\u0633\u0644\u0641???\u0647&\u0627\u0631\u0645\u0647?\u064a\u062f\u0648\u0639\u0633\u0644\u0627??\u0648\u0643\u0645\u0627\u0631\u0627?\u064a\u0628\u0638\u0648\u0628\u0627?\u06c3\u06cc\u062f\u0648\u0639\u0633\u0644\u0627?\u091f\u0947\u0928?\u0924&\u0930\u093e\u092d?\u094b\u0930\u093e\u092d??\u0928\u0920\u0917\u0902\u0938?\u092e\u0949\u0915?\u094d\u092e\u0924\u0930\u093e\u092d?\u09a4&\u09b0\u09be\u09ad?\u09f0\u09be\u09ad??\u09be\u09b2\u0982\u09be\u09ac?\u0a24\u0a30\u0a3e\u0a2d?\u0aa4\u0ab0\u0abe\u0aad?\u0b24\u0b30\u0b3e\u0b2d?\u0bbe\u0baf\u0bbf\u0ba4\u0bcd\u0ba8\u0b87?\u0bc8\u0b95\u0bcd\u0b99\u0bb2\u0b87?\u0bcd\u0bb0\u0bc2\u0baa\u0bcd\u0baa\u0b95\u0bcd\u0b99\u0bbf\u0b9a?\u0c4d\u0c24\u0c30\u0c3e\u0c2d?\u0ca4\u0cb0\u0cbe\u0cad?\u0d02\u0d24\u0d30\u0d3e\u0d2d?\u0dcf\u0d9a\u0d82\u0dbd?\u0e21\u0e2d\u0e04?\u0e22\u0e17\u0e44!.&\u0e08\u0e34\u0e01\u0e23\u0e38\u0e18?\u0e15\u0e47\u0e19\u0e40?\u0e23&\u0e01\u0e4c\u0e04\u0e07\u0e2d?\u0e32\u0e2b\u0e17??\u0e25\u0e32\u0e1a\u0e10\u0e31\u0e23?\u0e32\u0e29\u0e01\u0e36\u0e28???\u0ea7\u0eb2\u0ea5?\u10d4\u10d2?\u306a\u3093\u307f?\u30a2\u30c8\u30b9?\u30c8\u30f3\u30a4\u30dd?\u30c9\u30a6\u30e9\u30af?\u30e0\u30b3?\u30eb&\u30b0\u30fc\u30b0?\u30fc\u30bb??\u30f3&\u30be\u30de\u30a2?\u30e7\u30b7\u30c3\u30a1\u30d5??\u4e1a\u4f01?\u4e1c\u5e7f?\u4e50\u5a31?\u4f60\u7231\u6211?\u4fe1\u4e2d?\u52a1\u653f?\u52a8\u79fb?\u535a\u5fae?\u5366\u516b?\u5385\u9910?\u53f8\u516c?\u54c1\u98df?\u5584\u6148?\u56e2\u96c6?\u56fd\u4e2d?\u570b\u4e2d?\u5740\u7f51?\u5761\u52a0\u65b0?\u57ce\u5546?\u5c1a\u65f6?\u5c71\u4f5b?\u5e97&\u5546?\u7f51?\u9152\u5927\u91cc\u5609??\u5e9c\u653f?\u5eb7\u5065?\u606f\u4fe1?\u620f\u6e38?\u62c9\u91cc\u683c\u9999?\u62ff\u5927?\u6559\u4e3b\u5929?\u673a\u624b?\u6784\u673a!\u7ec7\u7ec4??\u6807\u5546?\u6b4c\u8c37?\u6d66\u5229\u98de?\u6e2f\u9999!.&\u4eba\u500b?\u53f8\u516c?\u5e9c\u653f?\u7d61\u7db2?\u7e54\u7d44?\u80b2\u6559???\u6e7e\u53f0?\u7063&\u53f0?\u81fa??\u7269\u8d2d?\u754c\u4e16?\u76ca\u516c?\u770b\u70b9?\u79d1\u76c8\u8a0a\u96fb?\u7ad9\u7f51?\u7c4d\u66f8?\u7ebf\u5728?\u7edc\u7f51?\u7f51\u6587\u4e2d?\u8058\u62db?\u8ca9\u901a?\u900a\u9a6c\u4e9a?\u901a\u8054?\u91cc\u5609?\u9521\u9a6c\u6de1?\u9580\u6fb3?\u95e8\u6fb3?\u95fb\u65b0?\u96fb\u5bb6?\uad6d\ud55c?\ub137\ub2f7?\uc131\uc0bc?\ucef4\ub2f7??");
                this.i = Bs("&kc.www?pj.&a&mahokoy.ytic?yogan.ytic??ebok.ytic?i&adnes.ytic?kasawak.ytic??oroppas.ytic?uhsuykatik.ytic???");
                this.j = Bs("&ac.vedwa,bup.&di,nik,?cv.e0,duolc.&etisotnegam,ndctegeb,rehcnar-no,scitats,?e&b.lrusnart,d.&ecnatsni-so-duolcwb,tcennocnonex,yksurf,?lppa.tni.duolc:.r:.&1-&ht&ron-&pa,ue,?uos-pa,?lartnec-&su,ue,?ts&ae-su,ew-su,??2-&htuos-pa,lartnec-su,ts&ae-su,ew-su,??3-tsew-su,?,,no&.nik,z.&notirt,sporez,??t&atse.etupmoc,is.&areduolc,hsmroftalp,tst,??vil.pwe,?g&g.ylp.ta,oog.tnetnocresu,p??hc.tenerif:.cvs,,k&c?f?nil.&bewd,hte,resworbni,?rowten.secla,u.&hcs?sppaduolcvogelcaro,??ln.lrusnart,m&f.resu,j?m?oc.&d&om-vog-su-p3-naissalta,uolc&-revelc.secivres,meaeboda.ved,nevia,??e&crofselas.mroftalp.gts-redliub-edoc.tset.100,do&c.redliub:-&gts,ved,?,nil.recnalabedon,??ico-remotsuc:.&ico,pco,sco,?,klatgnid-antz,l&atropqhylauq,iasthgilnozama.sc.&1-&ht&ron-ue,uos-pa,?lartnec-&ac,ue,?ts&ae&-&as,pa,su,?ht&ron-pa,uos-pa,??ew-ue,??2-&htuos-ue,ts&ae&-su,ht&ron-pa,uos-pa,??ew-&su,ue,???3-ts&aehtuos-pa,ew-ue,?5-tsaehtuos-pa,?rihwyap,?mme0,p&3-&detalosi-naissalta,naissalta,?paukoreh.etupmoc,?ren&nurppaswa,trapqhylauq,?s&ecapsnaecolatigid,ppa&duolc&elcaro,vogelcaro,?nived,skcirbatad.eruza,?t&cejbo&edonil,rtluv,?nemelepiuq,?wanozama.&1-etupmoc,ble,etupmoc,sdr.&1-&htuos-&em,fa,pa,?lartnec-&ac,em,li,ue,xm,?ts&ae&-&as,pa,su,vog-su,?ht&ron-&pa,su,?uos-pa,??ew-&ac,su,ue,vog-su,???2-&htuos-pa,lartnec-ue,ts&ae&-&pa,su,?ht&ron-pa,uos-pa,??ew-&su,ue,???3-ts&aeht&ron-pa,uos-pa,?ew-ue,?4-tsaehtuos-pa,5-tsaehtuos-pa,6-tsaehtuos-pa,7-tsaehtuos-pa,?wolfria.&1-&ht&ron-ue,uos-&em,fa,pa,ue,??lartnec-&ac,em,li,ue,?ts&ae&-&as,pa,su,?ht&ron-pa,uos-pa,??ew-&ac,su,ue,???2-&htuos-&pa,ue,?lartnec-ue,ts&ae&-su,ht&ron-pa,uos-pa,??ew-&su,ue,???3-ts&aeht&ron-pa,uos-pa,?ew-ue,?4-tsaehtuos-pa,5-tsaehtuos-pa,7-tsaehtuos-pa,???t&netnocresu&artul,i&a&atem,o,?ua,?rosruc,?opsppa.r,???n&c.moc.s&ecivresbewnozama.no.1-&htron-nc.wolfria,tsewhtron-nc.wolfria,?wanozama.&1-&htron-nc.sdr,tsewhtron-nc.sdr,?ble,etupmoc,wolfria.1-&htron-nc,tsewhtron-nc,???ur.&dliub,e&doc,sabatad,tirwppa,?noitargim,??o&c.&apdr.s&retsulc,selrvrs,?pato,timx,?i.&0pci.war,1pci.war,e&lacsnoom,varb.s,?oir-no,reniatnoceruza,s&3k-no,olots,?xcq.sys,?mil.hte,?p&j.&a&mahokoy?yogan??ebok?i&adnes?kasawak??oroppas?uhsuykatik??n?ot.ldaw,pa.&detsoh,e&kalfwons:.kniletavirp,,varb.s,?knalfhtron,nu&r:.sltm,,spu,?repoleved,sporez,tegeb,??r&b.mon?e??s&edoc.owo,ulp.tiyalp.ta,w&.rosivda,a.&no.&1-&ht&ron-ue.wolfria,uos-&em.wolfria,fa.wolfria,pa.wolfria,ue.wolfria,??lartnec-&ac.wolfria,em.wolfria,li.wolfria,ue.wolfria,?ts&ae&-&as.wolfria,pa.wolfria,su.wolfria,?ht&ron-pa.wolfria,uos-pa.wolfria,??ew-&ac.wolfria,su.wolfria,ue.wolfria,???2-&htuos-&pa.wolfria,ue.wolfria,?lartnec-ue.wolfria,ts&ae&-su.wolfria,ht&ron-pa.wolfria,uos-pa.wolfria,??ew-&su.wolfria,ue.wolfria,???3-ts&aeht&ron-pa.wolfria,uos-pa.wolfria,?ew-ue.wolfria,?4-tsaehtuos-pa.wolfria,5-tsaehtuos-pa.wolfria,7-tsaehtuos-pa.wolfria,?rekamegas.stnemirepxe,tsoper.etavirp,???t&a.&ofnistro.&nednuk,xe,?smcerutuf:.&ni,xe,?,?en.&hvo.&gnitsoh,saapbew,?otlacol,pci,s&etisbeweruza.p,t.c,??s.nc,?u&e.&axn,lrusnart,?r.onijym.&gni&dnal,tsoh,?murtceps,spv,??ved.&e&gats&gts,lcl,?rahbew,varb.s,?gts,lcl,mrc.&a&a,p,w,?b&a,p,w,?c&a,p,w,?d:a,p,w,,e&a,p,w,?f&a,p,w,?ic,w,?resworbni,t&ilper:.smaet,,reclacol.resu,?yawetag,?wen.tekcorhtiwtliub,z&c.murtnecatem.duolc,yx.tibelet,??")
            },
            qs = function(a, b) {
                var c = -1,
                    d = a;
                a = {};
                var e = 0;
                d.i !== void 0 && (a[e] = d.i);
                for (; e < b.length; e++) {
                    var f = b.charAt(e);
                    if (!(f in d.h)) break;
                    d = d.h[f];
                    d.i !== void 0 && (a[e] = d.i)
                }
                for (var g in a) d = parseInt(g, 10), (d + 1 == b.length || b.charAt(d + 1) == ".") && a[g] == 1 && d > c && (c = d);
                return b.substr(0, c + 1)
            },
            Bs = function(a) {
                var b = new gs;
                Cs(0, a, b);
                return b
            },
            Cs = function(a, b, c) {
                for (var d; a < b.length; a++) {
                    d = b.charAt(a);
                    if (d == "!" || d == "?") {
                        c.i = !0;
                        break
                    } else if (d == ":" || d == ",") {
                        c.i = !1;
                        break
                    } else if (d == "&") break;
                    var e = d;
                    c.h[e] || (c.h[e] = new gs);
                    c = c.h[e]
                }
                a++;
                if (d == "?" || d == ",") return a;
                do a = Cs(a, b, c), d = b.charAt(a); while (d != "?" && d != ",");
                return a + 1
            };
        var js, rs, hs, ls, ms;
        _.M("google.accounts.id.intermediate.verifyParentOrigin", _.ns);
        _.M("google.accounts.id.intermediate.notifyParentResize", _.vs);
        _.M("google.accounts.id.intermediate.notifyParentClose", _.ws);
        _.M("google.accounts.id.intermediate.notifyParentDone", function() {
            _.es ? _.fs({
                command: "intermediate_iframe_done"
            }) : _.G("Done command was not sent due to missing verified parent origin.")
        });
        _.M("google.accounts.id.intermediate.notifyParentTapOutsideMode", _.xs);
    } catch (e) {
        _._DumpException(e)
    }
    try {
        var Ds = function() {
                var a = new Uint8Array(32);
                (window.crypto || _.nd.msCrypto).getRandomValues(a);
                return btoa(String.fromCharCode.apply(String, _.Fd(a))).replace(/=+$/, "")
            },
            Es = function(a) {
                var b = [];
                _.Wa(a, function(c) {
                    b.push(c)
                });
                return b
            },
            Fs = function(a) {
                if (a == null || typeof a === "number") return a;
                if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
            },
            Gs = function(a) {
                if (a != null)
                    if (typeof a === "string") a = a ? new _.Sb(a, _.te) : _.Lh();
                    else if (!(a instanceof _.Sb)) {
                    var b;
                    _.se && a != null && a instanceof Uint8Array ?
                        b = a.length ? new _.Sb(new Uint8Array(a), _.te) : _.Lh() : b = void 0;
                    a = b
                }
                return a
            },
            Hs = function(a) {
                var b = b === void 0 ? _.cf : b;
                a: if (b = b === void 0 ? _.cf : b, !(a instanceof _.Jc)) {
                    for (var c = 0; c < b.length; ++c) {
                        var d = b[c];
                        if (d instanceof _.Lc && d.Id(a)) {
                            a = new _.Jc(a);
                            break a
                        }
                    }
                    a = void 0
                }
                return a || _.bf
            },
            Js = function(a, b) {
                a.removeAttribute("srcdoc");
                if (b instanceof _.Wl) throw new Is("TrustedResourceUrl", 2);
                var c = "allow-same-origin allow-scripts allow-forms allow-popups allow-popups-to-escape-sandbox allow-storage-access-by-user-activation".split(" ");
                a.setAttribute("sandbox", "");
                for (var d = 0; d < c.length; d++) a.sandbox.supports && !a.sandbox.supports(c[d]) || a.sandbox.add(c[d]);
                b = _.Oc(b);
                b !== void 0 && (a.src = b)
            },
            Ls = function(a, b) {
                if (_.Xl(b)) a.href = _.Yl(b).toString(), a.rel = "stylesheet";
                else {
                    if (Ks.indexOf("stylesheet") === -1) throw Error("J`stylesheet");
                    b = _.Oc(b);
                    b !== void 0 && (a.href = b, a.rel = "stylesheet")
                }
            },
            Ms = function(a) {
                if (_.Sc.includes(a)) {
                    var b = parseInt(_.Tc.get("ge_" + a), 10);
                    if (b) return b
                }
                b = _.Rc;
                b.h[a] ? (a = b.h[a], a = typeof a === "number" ? a : 1) : a = 0;
                return a
            },
            Ns = function(a, b, c) {
                if (Array.isArray(b))
                    for (var d = 0; d < b.length; d++) Ns(a, String(b[d]), c);
                else b != null && c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))))
            },
            Os = function() {
                var a = Ms("enable_itp_optimization");
                switch (a === void 0 ? 0 : a) {
                    case 19:
                    case 21:
                    case 23:
                        return 6
                }
            },
            Ts = function(a, b, c, d) {
                Ps = a ? a + "/gsi/log" : "https://accounts.google.com/gsi/log";
                Qs = b;
                Rs = c;
                Ss = d || []
            },
            Vs = function(a, b) {
                if (!(_.Tf >= (b === void 0 ? 100 : b))) {
                    b = new _.$c(Ps);
                    a = _.ol({
                        client_id: Qs,
                        as: Rs,
                        bs: Us,
                        event: a.toString()
                    });
                    var c = _.v(Ss),
                        d = c.next();
                    try {
                        for (; !d.done; d = c.next()) {
                            var e = d.value;
                            a.add(e.Ad, e.Bd.toString())
                        }
                    } finally {
                        _.yd(c, d)
                    }
                    _.cd(b, a);
                    _.Jl(b.toString(), void 0, "POST", void 0, void 0, Ps !== "https://accounts.google.com/gsi/log")
                }
            },
            Ys = function(a) {
                var b = new(Function.prototype.bind.apply(Ws, [null, "onetap", a, "prompt"].concat(_.Fd(Xs.apply(1, arguments)))));
                Vs(b)
            },
            Zs = function() {
                var a = new(Function.prototype.bind.apply(Ws, [null, "onetap", void 0, "closed"].concat(_.Fd(Xs.apply(0, arguments)))));
                Vs(a)
            },
            $s = function() {
                var a = new(Function.prototype.bind.apply(Ws, [null, "id", void 0, "init"].concat(_.Fd(Xs.apply(0, arguments)))));
                Vs(a)
            },
            at = function() {
                var a = new(Function.prototype.bind.apply(Ws, [null, "onetap", void 0, "policy"].concat(_.Fd(Xs.apply(0, arguments)))));
                Vs(a)
            },
            bt = function() {
                var a = _.od().toString(),
                    b = {
                        Qb: 300,
                        path: "/",
                        secure: !0
                    },
                    c;
                if (c = _.Ga()) c = _.il(_.bg, 80) >= 0;
                c && (b.sameSite = "none");
                c = _.pf(location.origin);
                c.i === "http" && c.h === "localhost" && (b.secure = void 0, b.sameSite = void 0);
                _.Tc.set("g_csrf_token", a, b);
                return a
            },
            ct = function(a, b) {
                _.Jl(a, function(c) {
                        b(_.Fl(c.target))
                    },
                    "GET", void 0, void 0, !0)
            },
            dt = function(a, b, c, d) {
                _.Jl(a, function(e) {
                    d(_.Fl(e.target))
                }, "POST", b ? _.ol(_.nl(b)).toString() : null, void 0, c)
            },
            et = function(a, b, c) {
                dt(a, b, !0, c)
            },
            ft = function(a, b, c) {
                b.credential = c || "";
                b.g_csrf_token = bt();
                _.Ri(a, b)
            },
            gt = function(a, b) {
                return function(c) {
                    c && c.credential ? ft(a, b || {}, c.credential) : _.F("No credential found in the response.")
                }
            },
            it = function(a) {
                var b = _.pf(a);
                b.h || (_.ad(b, location.protocol), b.h = location.hostname, _.bd(b, location.port), $s("relativeLoginUri", a), _.G("Relative login_uri was provided. Use absolute url instead. Relative login_uri may be considered invalid in the future."));
                if (b.i !== "https" && b.h !== "localhost") throw $s("unsecuredLoginUri", a), new ht("Unsecured login_uri provided.");
                return b.toString()
            },
            jt = function(a) {
                try {
                    var b = _.pf(a),
                        c = b.i;
                    return !!b.h && (c === "https" || c === "http" && b.h === "localhost")
                } catch (d) {}
                return !1
            },
            kt = function() {
                var a = _.v(document.getElementsByTagName("META")),
                    b = a.next();
                try {
                    for (; !b.done; b = a.next()) {
                        var c = b.value;
                        if (c.getAttribute("name") === "google-signin-client_id") return c.getAttribute("content")
                    }
                } finally {
                    _.yd(a, b)
                }
                a = _.v(document.getElementsByTagName("IFRAME"));
                b = a.next();
                try {
                    for (; !b.done; b = a.next()) {
                        var d = b.value.getAttribute("src");
                        if (d && d.startsWith("https://accounts.google.com/o/oauth2/iframe")) return _.pf(d).l.get("client_id") || null
                    }
                } finally {
                    _.yd(a, b)
                }
                return null
            },
            lt = function(a) {
                if (!a) return null;
                var b = a.indexOf("-");
                if (b >= 0) return a.substring(0, b);
                b = a.indexOf(".");
                return b >= 0 ? a.substring(0, b) : null
            },
            mt = function(a) {
                var b = kt();
                if (a && b) {
                    var c = lt(a),
                        d = lt(b);
                    !(c && d || a !== b) || c && d && c === d || _.G("The client ids used by Google Sign In and One Tap should be same or from the same project.\nOne Tap may be blocked in the near future if mismatched.")
                }
            },
            nt = function(a, b) {
                var c = [];
                c.push(_.If(a, "click", b));
                c.push(_.If(a, "keydown", function(d) {
                    var e = d.key;
                    e !== "Enter" && e !== " " || b(d)
                }))
            },
            ot = function() {
                return !_.z("CrOS") || _.il(_.jl(), "118") >= 0 ? _.I("enable_fedcm_on_edge") && !_.qd() && !_.pd() && _.Ma("Microsoft Edge") >= 132 ? !0 : _.rd() && (_.Na() || !_.qd() && !_.pd()) && _.il(_.jl(), "108") >= 0 : !1
            },
            pt = function() {
                try {
                    return window.self !== window.top
                } catch (a) {
                    return !0
                }
            },
            qt = function() {
                var a = document;
                return a.location.ancestorOrigins && a.location.ancestorOrigins.length !== 0 ? a.location.ancestorOrigins[a.location.ancestorOrigins.length -
                    1] : a.location.origin
            },
            rt = function() {
                var a = document;
                return a.location.ancestorOrigins ? a.location.protocol + "//" + a.location.host !== qt() : !1
            },
            st = function(a, b, c) {
                c && (a[b] = c.trim())
            },
            tt = function(a, b, c) {
                var d = [a === "code" ? "code" : "token"];
                a === "token" && (c.include_id_token && _.I("enable_oauth2_id_token") && d.push("id_token"), _.I("enable_authz_token_refresh") && d.push("permission"));
                var e = c.client_id,
                    f = c.scope;
                d = d.join(" ");
                if (c.nonce) var g = c.nonce;
                if (a === "code") {
                    var h = "offline";
                    var k = c.select_account ? "select_account consent" :
                        "consent";
                    if (c.claims !== void 0) var l = c.claims
                } else c.prompt === void 0 ? k = "select_account" : c.prompt && (k = c.prompt);
                a = c.redirect_uri;
                if (c.login_hint) var n = c.login_hint;
                if (c.state) var p = c.state;
                if (c.hd) var q = c.hd;
                if (c.include_granted_scopes !== void 0) var r = c.include_granted_scopes;
                if (c.enable_granular_consent !== void 0) var y = c.enable_granular_consent;
                if (c.trigger_onepick !== void 0) var u = c.trigger_onepick;
                if (c.allow_multiple !== void 0) var C = c.allow_multiple;
                if (c.allow_folder_selection !== void 0) var K = c.allow_folder_selection;
                if (c.file_ids !== void 0) var L = c.file_ids;
                if (c.mimetypes !== void 0) var ia = c.mimetypes;
                var nb = "3";
                c.gsiwebsdk !== void 0 && (nb = c.gsiwebsdk);
                if (c.gis_params !== void 0) var Wf = c.gis_params;
                if (c.origin !== void 0) var Xf = c.origin;
                if (c.ss_domain !== void 0) var Yf = c.ss_domain;
                if (c.display !== void 0) var Zf = c.display;
                if (c.response_mode !== void 0) var Cv = c.response_mode;
                if (c.gislp !== void 0) var Dv = c.gislp;
                if (c.upstream_experiment_id !== void 0) var Ev = c.upstream_experiment_id;
                var ba;
                c = (ba = c.color_scheme) == null ? void 0 : ba.toLowerCase();
                if (c === "light" || c === "dark") var Fv = c;
                ba = {};
                st(ba, "gsiwebsdk", nb);
                st(ba, "client_id", e);
                st(ba, "scope", f);
                st(ba, "redirect_uri", a);
                st(ba, "prompt", k);
                st(ba, "login_hint", n);
                st(ba, "state", p);
                st(ba, "access_type", h);
                st(ba, "hd", q);
                st(ba, "response_type", d);
                st(ba, "nonce", g);
                st(ba, "include_granted_scopes", r === !1 ? "false" : "true");
                st(ba, "enable_granular_consent", y === !1 ? "false" : "true");
                u !== void 0 && st(ba, "trigger_onepick", u === !1 ? "false" : "true");
                C !== void 0 && st(ba, "allow_multiple", C === !1 ? "false" : "true");
                K !== void 0 && st(ba,
                    "allow_folder_selection", K === !1 ? "false" : "true");
                st(ba, "file_ids", L);
                st(ba, "mimetypes", ia);
                l !== void 0 && st(ba, "claims", l);
                st(ba, "gis_params", Wf);
                st(ba, "origin", Xf);
                st(ba, "ss_domain", Yf);
                st(ba, "display", Zf);
                st(ba, "response_mode", Cv);
                st(ba, "gislp", Dv);
                st(ba, "upstream_experiment_id", Ev);
                st(ba, "color_scheme", Fv);
                e = [];
                for (var Pp in ba) Ns(Pp, ba[Pp], e);
                return _.ll(b, e.join("&"))
            },
            ut = function(a, b) {
                b = b || {};
                b.login_hint = b.login_hint || b.hint;
                b.enable_granular_consent = b.enable_granular_consent === void 0 ? b.enable_serial_consent :
                    b.enable_granular_consent;
                return {
                    client_id: a.client_id,
                    scope: b.scope === void 0 ? a.scope : b.scope,
                    prompt: b.prompt === void 0 ? a.prompt : b.prompt,
                    login_hint: b.login_hint === void 0 ? a.login_hint : b.login_hint,
                    state: b.state === void 0 ? a.state : b.state,
                    hd: a.hd,
                    include_granted_scopes: b.include_granted_scopes === void 0 ? a.include_granted_scopes : b.include_granted_scopes,
                    enable_granular_consent: b.enable_granular_consent === void 0 ? a.enable_granular_consent : b.enable_granular_consent,
                    trigger_onepick: a.trigger_onepick,
                    allow_multiple: a.allow_multiple,
                    allow_folder_selection: a.allow_folder_selection,
                    file_ids: a.file_ids,
                    mimetypes: a.mimetypes,
                    include_id_token: b.include_id_token === void 0 ? a.include_id_token : b.include_id_token,
                    nonce: b.nonce === void 0 ? a.nonce : b.nonce,
                    enable_token_refresh: a.enable_token_refresh,
                    color_scheme: b.color_scheme === void 0 ? a.color_scheme : b.color_scheme
                }
            },
            vt = function(a) {
                a = a === null ? "null" : a === void 0 ? "undefined" : a;
                var b = _.Vl();
                a = b ? b.createScriptURL(a) : a;
                return new _.Wl(a)
            },
            xt = function(a) {
                var b = b === void 0 ? "googleidentityservice" : b;
                if (!(document.getElementById(b) && wt.get(b) && wt.get(b))) {
                    var c = new _.ij,
                        d = document.getElementsByTagName("head")[0],
                        e = document.createElement("link");
                    e.id = b;
                    e.type = "text/css";
                    e.media = "all";
                    e.onload = function() {
                        c.resolve()
                    };
                    Ls(e, vt(a));
                    d.appendChild(e);
                    wt.set(b, c)
                }
            },
            yt = function(a) {
                a && (a.style.opacity = "0", a.style.pointerEvents = "none", (a = a.parentElement) && a.id === "credential_picker_container" && (a.style.opacity = "0", a.style.pointerEvents = "none"))
            },
            zt = function(a) {
                var b = document.getElementById("credential_picker_iframe");
                return b ? (document.body.removeChild(b), !0) : a && (b = document.getElementById("credential_picker_container")) ? (a.removeChild(b), !0) : !1
            },
            Bt = function(a, b, c, d) {
                d = d === void 0 ? !1 : d;
                zt(a);
                if (c) return a = document.createElement("iframe"), a.src = b, a.id = "credential_picker_iframe", a.title = At(), a.style.display = "none", a.style.height = "360px", a.style.width = "100%", a.style.zIndex = "9999", a.style.border = "none", a.style.position = "fixed", a.style.left = "0", a.style.bottom = "0", a.classList.add("L5Fo6c-PQbLGe"), document.body.appendChild(a),
                    a;
                c = document.createElement("div");
                a !== document.body ? (c.style.position = "relative", c.style.zIndex = "9999", c.style.top = "0", c.style.left = "0", c.style.height = "auto", c.style.width = "auto") : (c.style.position = "fixed", c.style.zIndex = "9999");
                d && (c.style.top = "0", c.style.right = "0");
                c.setAttribute("id", "credential_picker_container");
                d = document.createElement("iframe");
                d.src = b;
                d.classList.add("L5Fo6c-PQbLGe");
                d.title = At();
                d.style.display = "none";
                d.style.height = "360px";
                d.style.overflow = "hidden";
                c.appendChild(d);
                a.appendChild(c);
                return d
            },
            Ct = function(a) {
                var b = document.getElementById("credential_picker_container");
                if (b) {
                    var c = b.getElementsByTagName("iframe");
                    if (c.length > 0 && (c = c.item(0), c !== null)) {
                        var d = c.clientHeight;
                        b.style.height = a + 8 + "px";
                        c.style.height = a + "px";
                        c.style.display = "";
                        return d
                    }
                } else if (b = document.getElementById("credential_picker_iframe")) return c = b.clientHeight, b.style.height = a + "px", b.style.display = "", c
            },
            Dt = function(a, b) {
                if (b) {
                    var c = b.clientHeight;
                    b.parentElement && b.parentElement !== document.body && (b.parentElement.style.height =
                        a + "px");
                    b.style.border = "none";
                    b.style.height = a + "px";
                    b.style.display = "";
                    return c
                }
            },
            Et = function(a, b, c, d, e) {
                d = d === void 0 ? !1 : d;
                var f = _.gf(document, "iframe");
                f.setAttribute("src", b);
                f.classList.add("L5Fo6c-PQbLGe");
                f.allow = "identity-credentials-get";
                f.id = c;
                _.I("enable_aria_hidden_in_button_iframe") && d && f.setAttribute("aria-hidden", "true");
                f.title = "Pulsante Accedi con Google";
                f.style.display = "block";
                f.style.position = "relative";
                f.style.top = "0";
                f.style.left = "0";
                f.style.height = "0";
                f.style.width = "0";
                f.style.border =
                    "0";
                if (d) {
                    b = _.gf(document, "div");
                    b.id = c + "-wrapper";
                    b.classList.add("L5Fo6c-sM5MNb");
                    b.style.width = "fit-content";
                    var g;
                    c = {
                        Xd: c + "-overlay"
                    };
                    var h = h === void 0 ? !1 : h;
                    c = (c || _.gm).Xd;
                    c = '<div class="' + _.W("L5Fo6c-bF1uUb") + '" id="' + _.W(c) + '" aria-label="';
                    d = _.Hm("Accedi con Google. Si apre in una nuova scheda");
                    d = (0, _.U)(c + d + '" role="button" tabindex="0"></div>');
                    a: {
                        e = h;e = e === void 0 ? !1 : e;h = _.km || (_.km = new _.qm);c = d && d.ce ? d.ce() : null;
                        if (!c) {
                            var k = _.hm(d);
                            if (e) {
                                var l;
                                d = (l = (g = h.h)[_.Ym]) != null ? l : g[_.Ym] = _.gf(h.h,
                                    "TEMPLATE");
                                d.innerHTML = _.am(k);
                                g = d.content;
                                d.textContent = "";
                                k = g.childNodes
                            } else c = _.gf(h.h, "DIV"), c.innerHTML = _.am(k), k = c.childNodes
                        }
                        if (k.length == 1 && (g = k[0], g.nodeType == 1)) break a;c || (c = _.gf(h.h, "DIV"), c.append.apply(c, _.Fd(k)));g = c
                    }
                    f.tabIndex = -1;
                    b.appendChild(f);
                    b.appendChild(g);
                    a.appendChild(b);
                    return {
                        N: f,
                        bd: g
                    }
                }
                e && a.appendChild(e);
                a.appendChild(f);
                return {
                    N: f
                }
            },
            Ft = function(a) {
                var b = document.createElement("iframe");
                b.src = a;
                b.style.display = "none";
                b.setAttribute("aria-hidden", "true");
                b.setAttribute("tabindex",
                    "-1");
                return b
            },
            Gt = function(a) {
                return typeof a === "number" && !isNaN(a) && a > 0
            },
            Ht = function() {
                return "gsi_" + Date.now() % 1E6 + "_" + Math.floor(Math.random() * 1E6)
            },
            Jt = function(a) {
                var b = _.R("g_a11y_announcement");
                b || (b = _.gf(document, "div"), b.id = "g_a11y_announcement", document.body.appendChild(b));
                var c = _.gf(document, "span");
                It(c, a);
                c.role = "alert";
                _.nm(b);
                b.appendChild(c);
                setTimeout(function() {
                    _.nm(b)
                }, 3E3)
            },
            Kt = function(a) {
                for (; a.parentNode;) {
                    if (a === document.body) return null;
                    a = a.parentNode
                }
                return a && a.host && a.mode ?
                    a : null
            },
            Lt = function(a) {
                a = Object.entries(a).filter(function(c) {
                    c = _.v(c);
                    c.next();
                    c = c.next().value;
                    return c !== void 0 && c !== null && c !== ""
                }).map(function(c) {
                    var d = _.v(c);
                    c = d.next().value;
                    d = d.next().value;
                    c = String(c);
                    if (typeof d === "string") d = '"' + d.replace(/"/g, '\\"') + '"';
                    else if (Array.isArray(d)) d = d.map(function(e) {
                        return '"' + e + '"'
                    }).join(" "), d = "(" + d + ")";
                    else {
                        if (d === null || d === void 0) return;
                        d = String(d)
                    }
                    return c + "=" + d
                });
                var b = document.querySelector('meta[http-equiv="Web-Identity-Authenticate"]');
                b || (b = document.createElement("meta"),
                    b.httpEquiv = "Web-Identity-Authenticate", document.getElementsByTagName("head")[0].appendChild(b));
                b.content = a.join(", ")
            },
            Mt = function() {
                switch (Ms("enable_itp_optimization")) {
                    case 18:
                    case 19:
                        return 1E4;
                    case 20:
                    case 21:
                    case 24:
                        return 2E4;
                    case 22:
                    case 23:
                        return 3E4
                }
            },
            Nt = function() {
                switch (Ms("enable_itp_optimization")) {
                    case 19:
                    case 21:
                    case 23:
                        return !0;
                    default:
                        return !1
                }
            },
            Ot = function() {
                var a = Ms("enable_itp_optimization");
                return a && a !== 24
            },
            Pt = function() {},
            Qt = function() {},
            Rt = function(a) {
                this.h = a;
                this.i = null
            },
            St = function() {
                var a = null;
                try {
                    a = _.x.sessionStorage || null
                } catch (b) {}
                Rt.call(this, a)
            },
            Tt = function(a, b) {
                this.i = a;
                this.h = b + "::"
            },
            Vt = function() {
                var a = new St;
                return Ut(a) ? new Tt(a, "g_state_id_") : null
            },
            Zt = function() {
                var a = _.R("g_id_onload");
                if (a) {
                    var b = _.bs(a);
                    a = _.cs(b, Wt);
                    a.auto_prompt === void 0 && (a.auto_prompt = !0);
                    a.auto_prompt && a.skip_prompt_cookie && _.Tc.get(a.skip_prompt_cookie) && (a.auto_prompt = !1);
                    delete a.skip_prompt_cookie;
                    var c = {};
                    for (d in b) b.hasOwnProperty(d) && Xt.indexOf(d.toLowerCase()) < 0 && (c[d] =
                        b[d]);
                    a.state && (c.state = a.state);
                    if (a.login_uri) {
                        a.login_uri = it(a.login_uri);
                        var d = gt(a.login_uri, c);
                        a.redirect_callback = d;
                        a.callback || (a.callback = d)
                    } else a.ux_mode === "redirect" && _.H("Missing required login_uri parameter for the redirect flow.");
                    d = a.native_login_uri;
                    delete a.native_login_uri;
                    d && a.native_callback ? _.H("Cannot set both data-native_login_uri and data-native_callback.") : d && (a.native_callback = Yt(d, c, a.native_id_param || "email", a.native_password_param || "password"));
                    return a
                }
            },
            Yt = function(a,
                b, c, d) {
                return function(e) {
                    e && e.type === "password" ? (b[c] = e.id, b[d] = e.password, _.Ri(a, b)) : _.F("No password credential returned.")
                }
            },
            au = function(a) {
                a = _.bs(a);
                return _.cs(a, $t)
            },
            gu = function(a) {
                bu.__G_ID_CLIENT__ && _.G("google.accounts.id.initialize() is called multiple times. This could cause unexpected behavior and only the last initialized instance will be used.");
                if (_.I("enable_default_callback") && a && a.login_uri) {
                    a.login_uri = it(a.login_uri);
                    var b = gt(a.login_uri);
                    a.redirect_callback = a.redirect_callback ||
                        b;
                    a.callback = a.callback || b
                }
                a = new cu(a);
                bu.__G_ID_CLIENT__ = a;
                xt(a.Yd);
                du(a);
                _.Tc.get("g_state");
                eu(a.C);
                _.I("enable_fedcm_bluedog_poc") && (b = a.o, b = {
                    client_id: b.client_id,
                    config_url: a.Oa,
                    context: b.context || "signin",
                    domain_hint: b.hosted_domain === "*" ? "any" : b.hosted_domain,
                    login_hint: b.hint,
                    nonce: b.nonce,
                    fields: ["email", "name", "picture"],
                    params: JSON.stringify(fu(b))
                }, Lt(b));
                return a
            },
            hu = function(a, b, c) {
                var d = bu.__G_ID_CLIENT__;
                d || (gu(), d = bu.__G_ID_CLIENT__);
                d.Z(a, b, c)
            },
            ju = function(a, b, c) {
                if (a && b) {
                    var d =
                        bu.__G_ID_CLIENT__;
                    d ? iu(d, a, b, c) : _.G("Failed to render button before calling initialize().")
                } else _.G("Failed to render button because there is no parent or options set.")
            },
            lu = function() {
                var a = bu.__G_ID_CLIENT__;
                a || (gu(), a = bu.__G_ID_CLIENT__);
                ku(a.h)
            },
            mu = function() {
                var a = a === void 0 ? document.readyState : a;
                for (var b = _.lm("g_id_signout"), c = 0; c < b.length; c++) _.If(b[c], "click", lu);
                try {
                    var d = Zt();
                    if (d) {
                        var e = d.auto_prompt;
                        delete d.auto_prompt;
                        var f = d.moment_callback;
                        delete d.moment_callback;
                        gu(d);
                        e && (a ===
                            "complete" ? hu(f) : _.If(window, "load", function() {
                                hu(f)
                            }, !1))
                    }
                    var g = _.lm("g_id_signin");
                    for (a = 0; a < g.length; a++) {
                        var h = au(g[a]);
                        ju(g[a], h)
                    }
                } catch (k) {
                    _.H("Error parsing configuration from HTML: " + k.message)
                }
            },
            nu = function() {
                var a = bu.onGoogleLibraryLoad;
                a && typeof a === "function" && a()
            },
            ou = function() {
                var a = a === void 0 ? document.readyState : a;
                a === "complete" ? setTimeout(function() {
                    nu()
                }, 0) : _.If(window, "load", function() {
                    nu()
                }, !1)
            },
            pu = function(a) {
                return a != null && a.error == null && typeof a.access_token === "string" && !!a.access_token.trim()
            },
            qu = function(a) {
                if (typeof a === "string") return a.trim() || void 0
            },
            uu = function(a) {
                a: {
                    var b = typeof window !== "undefined" && window.location ? window.location.origin : "";
                    if (b && b !== "null") try {
                        var c = (new URL(b)).origin;
                        var d = c && c !== "null" ? c : void 0;
                        break a
                    } catch (f) {}
                    d = void 0
                }
                if (b = d) {
                    d = ru(b, a).toString();
                    if (c = su.get(d)) {
                        var e;
                        (e = c.N) != null && e.isConnected || !document.body || c.init();
                        return c
                    }
                    a = new tu(b, a);
                    a.init();
                    su.set(d, a);
                    return a
                }
                _.H('Client origin is unavailable or opaque ("null"). IDP iframe cannot be initialized.',
                    "MESSAGE_CLIENT")
            },
            vu = function(a) {
                return (new URL("/o/oauth2/idpiframe", a && a !== "null" ? a : "https://accounts.google.com")).toString()
            },
            ru = function(a, b) {
                b = b === void 0 ? vu() : b;
                b = new URL(b, "https://accounts.google.com");
                b.searchParams.set("origin", a);
                return b
            },
            wu = function() {
                var a = Xs.apply(0, arguments),
                    b = [];
                if (a) {
                    a = _.v(a);
                    var c = a.next();
                    try {
                        for (; !c.done; c = a.next()) {
                            var d = c.value,
                                e = d && d.trim();
                            if (!e && e.indexOf(" ") >= 0) {
                                _.G("In hasGrantedAllScopes() method: invalid scope [" + d + "]. Scope should be a non-empty string without space.");
                                var f = null
                            } else f = e;
                            var g = f;
                            if (g === null) return _.G("Invalid scope found."), null;
                            g && b.push(g)
                        }
                    } finally {
                        _.yd(a, c)
                    }
                }
                return b
            },
            xu = function(a) {
                return (a = a && a.scope && a.scope.trim()) ? wu.apply(null, _.Fd(a.split(" "))) : null
            },
            yu = function(a, b) {
                b.gsiwebsdk = "gis_attributes";
                b.redirect_uri = "gis_transform";
                b.response_mode = "form_post";
                b.origin = b.origin || window.location.origin;
                b.display = "popup";
                var c = new _.bj;
                a = _.S(c, 8, a.C);
                a = _.rl(_.T(a, 7, 1), 19);
                a = _.Yi(a, 13, !0);
                c = Ds();
                a = _.S(a, 5, c);
                b.state && _.S(a, 10, b.state);
                b.gis_params =
                    _.Va(a.h(), 4)
            },
            zu = function(a) {
                _.di(a, "prompt_closed", {
                    Me: !1
                })
            },
            Au = function(a, b, c) {
                b = {
                    Re: b
                };
                c !== void 0 && (b.Se = c);
                _.di(a, "prompt_resized", b)
            },
            Xs = function() {
                for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
                return b
            },
            Bu = function(a, b) {
                _.pi(a);
                var c = a.B;
                _.fl(c, c[_.A] | 0, b, 0);
                return a
            },
            Cu = _.Oh(_.bj, _.aj),
            Du = {
                Ge: "signin",
                He: "signup",
                Je: "use",
                we: "continue"
            },
            Eu = {
                ve: "card",
                ue: "bottom_sheet"
            },
            ht = function() {
                return Error.apply(this, arguments) || this
            };
        _.J(ht, Error);
        _.Wl = function(a) {
            this.h = a
        };
        _.Wl.prototype.toString = function() {
            return this.h + ""
        };
        var Fu = {
                ze: 0,
                xe: 1,
                ye: 2,
                0: "FORMATTED_HTML_CONTENT",
                1: "EMBEDDED_INTERNAL_CONTENT",
                2: "EMBEDDED_TRUSTED_EXTERNAL_CONTENT"
            },
            Is = function(a, b) {
                b = Error.call(this, a + " cannot be used with intent " + Fu[b]);
                this.message = b.message;
                "stack" in b && (this.stack = b.stack);
                this.type = a;
                this.name = "TypeCannotBeUsedWithIframeIntentError"
            };
        _.J(Is, Error);
        var Gu = function(a) {
            this.h = a
        };
        Gu.prototype.toString = function() {
            return this.h + ""
        };
        var Ks = "alternate author bookmark canonical cite help icon license modulepreload next prefetch dns-prefetch prerender preconnect preload prev search subresource".split(" "),
            It = function(a, b) {
                if ("textContent" in a) a.textContent = b;
                else if (a.nodeType == 3) a.data = String(b);
                else if (a.firstChild && a.firstChild.nodeType == 3) {
                    for (; a.lastChild != a.firstChild;) a.removeChild(a.lastChild);
                    a.firstChild.data = String(b)
                } else _.nm(a), a.appendChild((a.nodeType == 9 ? a : a.ownerDocument || a.document).createTextNode(String(b)))
            },
            Ws = function(a, b, c) {
                var d = Xs.apply(3, arguments);
                this.l = a;
                this.j = b;
                this.h = c;
                this.i = d
            };
        Ws.prototype.toString = function() {
            var a = [this.l];
            this.j && a.push(this.j);
            this.h && a.push(this.h);
            this.i && a.push.apply(a, _.Fd(this.i));
            return a.join(".")
        };
        var Ps = "https://accounts.google.com/gsi/log",
            Qs, Rs, Us, Ss = [],
            Hu = ["debug", "info", "warn"],
            Iu = {},
            Ju = function(a) {
                this.B = _.B(a)
            };
        _.J(Ju, _.D);
        var Ku = function() {
            var a = 2;
            a = a === void 0 ? 2 : a;
            this.key = "45798992";
            this.defaultValue = !0;
            this.cd = a
        };
        Ku.prototype.h = function(a) {
            return typeof a === "boolean"
        };
        Ku.prototype.Ra = function(a) {
            return this.h(a) ? a : this.defaultValue
        };
        var Lu = function() {
            var a = 2;
            a = a === void 0 ? 2 : a;
            this.key = "45774885";
            this.defaultValue = 1807642800;
            this.cd = a
        };
        Lu.prototype.h = function(a) {
            return typeof a === "number"
        };
        Lu.prototype.Ra = function(a) {
            return this.h(a) ? a : this.defaultValue
        };
        var Mu = function(a) {
            this.B = _.B(a)
        };
        _.J(Mu, _.D);
        Mu.prototype.clearValue = function() {
            return Bu(this, Nu)
        };
        var Nu = [1, 2];
        var Ou = function(a) {
            this.B = _.B(a)
        };
        _.J(Ou, _.D);
        Ou.prototype.clearValue = function() {
            return Bu(this, Pu)
        };
        var Pu = [2, 3, 4, 5, 6, 8];
        var Qu = function(a) {
            this.B = _.B(a)
        };
        _.J(Qu, _.D);
        Qu.prototype.Jc = function() {
            var a = _.N(this, 3, void 0, void 0, Gs);
            return a == null ? _.Lh() : a
        };
        var Ru = function(a) {
            this.B = _.B(a)
        };
        _.J(Ru, _.D);
        var Su = _.Ii(Ru);
        var Tu, Uu = function() {
                this.i = !1;
                var a = null;
                this.i = !0;
                var b = window;
                b = b === void 0 ? window : b;
                b = b === void 0 ? window : b;
                b = (b = b.WIZ_global_data) && "TSDtV" in b ? b.TSDtV : null;
                if (b = typeof b !== "string" ? null : b) try {
                    var c = Su("[" + b.substring(4));
                    a = _.dj(c, Qu, 1)[0]
                } catch (K) {
                    a = JSON.parse(b);
                    var d;
                    this.h = (d = a == null ? void 0 : a.flags) != null ? d : {};
                    (a == null ? 0 : a.token) ? a = (a = a.token) ? new _.Sb(a, _.te) : _.Lh(): a = null;
                    this.token = a;
                    return
                }
                if (a) {
                    d = _.v(_.dj(a, Ou, 2));
                    c = d.next();
                    try {
                        for (; !c.done; c = d.next()) {
                            var e = c.value;
                            if (_.Me(e, _.Hl(e, Pu,
                                    6))) throw Error();
                        }
                    } finally {
                        _.yd(d, c)
                    }
                }
                if (a) {
                    e = {};
                    d = _.v(_.dj(a, Ou, 2));
                    c = d.next();
                    try {
                        for (; !c.done; c = d.next()) {
                            var f = c.value;
                            var g = _.ej(f, 1).toString();
                            switch (_.Gl(f.B, Pu)) {
                                case 3:
                                    e[g] = _.Vi(f, _.Hl(f, Pu, 3));
                                    break;
                                case 2:
                                    var h = _.ej(f, _.Hl(f, Pu, 2));
                                    (0, _.Pb)(h);
                                    var k = (0, _.Pb)(h) ? Number(h) : String(h);
                                    e[g] = k;
                                    break;
                                case 4:
                                    b = void 0;
                                    var l = f,
                                        n = _.Hl(f, Pu, 4);
                                    var p = (b = _.N(l, n, void 0, void 0, Fs)) != null ? b : 0;
                                    e[g] = p;
                                    break;
                                case 5:
                                    e[g] = _.Ne(f, _.Hl(f, Pu, 5));
                                    break;
                                case 6:
                                    e[g] = _.O(f, Ju, _.Hl(f, Pu, 6), void 0);
                                    break;
                                case 8:
                                    b =
                                        f;
                                    l = Mu;
                                    var q = _.Hl(f, Pu, 8),
                                        r = b.B,
                                        y;
                                    if (!(y = _.nc(r, r[_.A] | 0, l, q))) {
                                        var u;
                                        if (!(u = l[_.we])) {
                                            var C = new l;
                                            _.kb(C.B, 34);
                                            u = l[_.we] = C
                                        }
                                        y = u
                                    }
                                    b = y;
                                    switch (_.Gl(b.B, Nu)) {
                                        case 1:
                                            e[g] = _.Ne(b, _.Hl(b, Nu, 1));
                                            break;
                                        default:
                                            throw Error("Ta`" + _.Gl(b.B, Nu));
                                    }
                                    break;
                                default:
                                    throw Error("Ta`" + _.Gl(f.B, Pu));
                            }
                        }
                    } finally {
                        _.yd(d, c)
                    }
                    f = e
                } else f = {};
                this.h = f;
                this.token = a ? a.Jc() : null
            },
            Vu = function(a, b) {
                return b.cd === 1 || a.i && !(b.key in a.h) ? b.defaultValue : b.Ra(a.h[b.key])
            };
        Uu.prototype.Jc = function() {
            return this.token
        };
        var Wu = new Ku,
            Xu = new Lu;
        var Yu = function(a) {
            this.B = _.B(a)
        };
        _.J(Yu, _.D);
        var Zu = _.Ii(Yu);
        var $u = function(a) {
            this.B = _.B(a)
        };
        _.J($u, _.D);
        var av = _.Ii($u);
        var At = function() {
            return "Finestra di dialogo Accedi con Google"
        };
        var wt = new Map;
        var bv = function() {
                this.h = Ht()
            },
            dv = function(a, b, c) {
                c = c === void 0 ? "widget" : c;
                _.E("Starting FedCM call. Mode: " + c + " | callId: " + a.h + ".");
                navigator.credentials.get(cv(a, b, c)).then(function(d) {
                    _.E("Response received. callId: " + a.h + ".");
                    a.ga(b, c, d)
                }, function(d) {
                    _.E("Error received. callId: " + a.h + ".");
                    b.ma(c, d)
                }).finally(function() {
                    a.i = void 0
                })
            },
            cv = function(a, b, c) {
                _.E("Generating FedCM options. callId: " + a.h + ".");
                a.i = new AbortController;
                var d = {
                    url: b.Gc,
                    configURL: b.wb,
                    clientId: b.o.client_id,
                    params: b.Sa,
                    fields: ["name",
                        "email", "picture"
                    ]
                };
                b.o.nonce && (d.nonce = b.o.nonce);
                b.o.hint && (d.loginHint = b.o.hint);
                b.o.hosted_domain && (d.domainHint = b.o.hosted_domain === "*" ? "any" : b.o.hosted_domain);
                d = {
                    context: b.o.context || "signin",
                    providers: [d],
                    mode: _.Ma("Chromium") >= 131 ? c === "button" ? "active" : "passive" : c
                };
                var e = {
                    signal: a.i.signal,
                    federated: d,
                    identity: d
                };
                e.mediation = b.Ia ? "optional" : "required";
                c === "widget" && (d.autoReauthn = !!b.Ia);
                _.E("FedCM options generated. callId: " + a.h + ". " + e);
                return e
            };
        bv.prototype.ga = function(a, b, c) {
            c ? (_.E("Processing FedCM response. callId " + this.h), c.login ? c.login({
                signal: this.i.signal,
                nonce: a.o.nonce
            }).then(function(d) {
                a.ga(b, d, a.Sa)
            }, function(d) {
                a.ma(b, d)
            }) : a.ga(b, c, a.Sa)) : (_.E("FedCM credential is null. callId " + this.h), a.ma(b, Error("X")))
        };
        var ev = function() {
                this.i = !1
            },
            fv = function(a, b, c) {
                c = c === void 0 ? "widget" : c;
                a.h = new bv;
                dv(a.h, b, c)
            },
            gv = function(a, b) {
                fv(a, b, "widget")
            },
            hv = function(a, b) {
                fv(a, b, "button")
            },
            eu = function(a) {
                _.E("Evaluating FedCM mode support.");
                var b = {
                    identity: Object.defineProperty({}, "mode", {
                        get: function() {
                            _.E("FedCM mode supported.");
                            a.i = !0
                        }
                    })
                };
                try {
                    navigator.credentials.get(b).then(function() {}, function() {})
                } catch (c) {}
            },
            iv = function(a, b) {
                b = {
                    "@context": "https://schema.org",
                    "@type": "LoginAction",
                    federation: {
                        providers: [{
                            "@type": "FederatedLoginProvider",
                            configURL: a,
                            clientId: b.client_id,
                            loginHint: b.hint,
                            domainHint: b.hosted_domain === "*" ? "any" : b.hosted_domain,
                            params: fu(b),
                            fields: ["email", "name", "picture"]
                        }]
                    }
                };
                a = document.createElement("script");
                a.type = "application/ld+json";
                var c;
                b = JSON.stringify(b).replace(/</g, "\\u003C");
                b = (c = _.Vl()) ? c.createScript(b) : b;
                c = new Gu(b);
                b = {
                    Pd: !0
                };
                if (c instanceof Gu) c = c.h;
                else throw Error("H");
                a.textContent = c;
                if (b == null || !b.Pd) {
                    var d;
                    b = a.ownerDocument;
                    b = b === void 0 ? document : b;
                    var e;
                    b = (e = (d = b).querySelector) == null ? void 0 : e.call(d,
                        "script[nonce]");
                    (d = b == null ? "" : b.nonce || b.getAttribute("nonce") || "") && a.setAttribute("nonce", d)
                }
                document.getElementsByTagName("head")[0].appendChild(a)
            },
            jv = function(a, b) {
                a = [{
                    configURL: a,
                    clientId: b.client_id,
                    loginHint: b.hint,
                    domainHint: b.hosted_domain === "*" ? "any" : b.hosted_domain,
                    params: fu(b),
                    fields: ["email", "name", "picture"]
                }];
                b = document.createElement("login");
                var c = document.createElement("credential");
                b.appendChild(c);
                c.setAttribute("type", "federated");
                c.setAttribute("configURL", a[0].configURL);
                c.setAttribute("clientId",
                    a[0].clientId);
                a[0].loginHint && c.setAttribute("loginHint", a[0].loginHint);
                a[0].domainHint && c.setAttribute("domainHint", a[0].domainHint);
                a[0].params && c.setAttribute("params", JSON.stringify(a[0].params));
                a[0].fields && c.setAttribute("fields", a[0].fields.join(","));
                return b
            },
            fu = function(a) {
                return {
                    as: a.as,
                    top_origin: rt() ? qt() : void 0,
                    library_name: a.library_name ? a.library_name : void 0,
                    response_type: "id_token",
                    ss_domain: a.origin || location.origin,
                    scope: "email profile openid",
                    nonce: a.nonce ? a.nonce : "not_provided",
                    state: a.state,
                    claims: a.claims
                }
            };
        var kv = {
                left: 1,
                center: 2
            },
            lv = {
                rectangular: 1,
                square: 3,
                pill: 2,
                circle: 4
            },
            mv = {
                large: 1,
                medium: 2,
                small: 3
            },
            nv = {
                signin: 1,
                signin_with: 2,
                signup_with: 3,
                continue_with: 4
            },
            ov = {
                outline: 1,
                outline_dark: 5,
                filled_blue: 2,
                filled_black: 3
            },
            pv = {
                standard: 1,
                icon: 2
            },
            rv = function(a, b, c) {
                this.container = a;
                this.i = c;
                this.h = !1;
                this.j = function(d) {
                    (d = d.target) && d.classList && d.classList.contains("QCZ2Re-l4eHX-n5VRYe") && (d.style.visibility = "hidden", _.G('Failed to load Google logo gradient. Add "data:" to your Content Security Policy (CSP) img-src directive to allow data:image URIs.'),
                        _.I("enable_gradient_icon_error_logging") && Vs(new Ws("button", void 0, "policy", "gradientError")))
                };
                this.Ha = qv(b);
                this.startTime = performance.now()
            };
        rv.prototype.dispose = function() {
            if (!this.h) {
                this.container.removeEventListener("error", this.j, !0);
                var a = _.mm("nsm7Bb-HzV7m-LgbsSe", this.container);
                a && _.om(a);
                this.h = !0;
                this.m = performance.now()
            }
        };
        var sv = function(a) {
                var b = _.mm("nsm7Bb-HzV7m-LgbsSe", a.container);
                b && a.i && nt(b, function() {
                    a.i && a.i.call(a)
                })
            },
            qv = function(a) {
                var b = new _.ln;
                if (!a) return b;
                a.logo_alignment && _.T(b, 6, kv[a.logo_alignment]);
                a.shape && _.T(b, 3, lv[a.shape]);
                a.size && _.T(b, 1, mv[a.size]);
                a.text && _.T(b, 5, nv[a.text]);
                a.theme && _.T(b, 2, ov[a.theme]);
                a.type && _.T(b, 7, pv[a.type]);
                if (a.width)
                    if (typeof a.width === "number" && !isNaN(a.width)) _.fj(b, 4, Number(a.width));
                    else if (typeof a.width === "string") try {
                    var c = a.width;
                    _.fj(b, 4, Number(c.endsWith("px") ?
                        c.slice(0, -2) : c))
                } catch (d) {
                    _.G("Provided button width is invalid: " + a.width)
                }
                return b
            };
        var tv = function(a) {
            this.h = a
        };
        _.m = tv.prototype;
        _.m.getMomentType = function() {
            return this.h
        };
        _.m.isDisplayMoment = function() {
            return this.h === "display"
        };
        _.m.isDisplayed = function() {
            return this.isDisplayMoment() && !!this.i
        };
        _.m.isNotDisplayed = function() {
            return this.isDisplayMoment() && !this.i
        };
        _.m.getNotDisplayedReason = function() {
            return this.isNotDisplayed() ? this.l : void 0
        };
        _.m.isSkippedMoment = function() {
            return this.h === "skipped"
        };
        _.m.getSkippedReason = function() {
            return this.isSkippedMoment() ? this.m : void 0
        };
        _.m.isDismissedMoment = function() {
            return this.h === "dismissed"
        };
        _.m.getDismissedReason = function() {
            return this.isDismissedMoment() ? this.j : void 0
        };
        var uv = function(a, b) {
                this.A = a;
                this.m = this.j = this.sessionId = null;
                this.H = 0;
                this.h = this.D = null;
                this.state = 0;
                this.C = !1;
                this.l = this.v = this.i = this.u = null;
                this.F = b;
                this.G = _.Yc(this.F)
            },
            zv = function(a) {
                _.E("RrmManager initialized");
                a.state !== 0 ? _.G("RrmManager already initialized or in progress.") : (a.sessionId = crypto.randomUUID(), a.j = qt(), a.j ? (a.D = function(b) {
                    if (a.sessionId)
                        if (a.state === 1) b.origin === a.j && b.data && b.data.type === "RRM_GIS_ACK" && b.data.sessionId === a.sessionId && (_.E("Received RRM_GIS_ACK: " + JSON.stringify(b.data)),
                            a.m && (clearTimeout(a.m), a.m = null), vv(a));
                        else if (a.h && b.source === a.h.contentWindow && b.origin === a.G && b.data && b.data.sessionId === a.sessionId) switch (_.E("Received message from RRM iframe: " + JSON.stringify(b.data)), b.data.type) {
                        case "RRM_GIS_IFRAME_LOADED_GIS":
                            wv(a);
                            break;
                        case "RRM_GIS_YIELD":
                            _.E("Received RRM_GIS_YIELD.");
                            a.C = !0;
                            a.l && (clearTimeout(a.l), a.l = null);
                            xv(a);
                            break;
                        case "RRM_GIS_REDIRECT_OK":
                            _.E("Received RRM_GIS_REDIRECT_OK.");
                            a.v && (clearTimeout(a.v), a.v = null);
                            a.i && (a.A(a.i), a.i = null);
                            break;
                        case "RRM_GIS_ERROR":
                            _.H("Received RRM_GIS_ERROR: " + JSON.stringify(b.data.message));
                            a.state = 4;
                            xv(a);
                            break;
                        default:
                            _.G("Received unknown message type from RRM iframe")
                    }
                }, window.addEventListener("message", a.D), yv(a)) : (_.H("Could not determine top level origin. Cannot start RRM handshake."), a.state = 4))
            },
            yv = function(a) {
                _.E("Starting RRM handshake");
                a.state = 1;
                a.m = setTimeout(function() {
                    Av(a)
                }, 12E4);
                Bv(a)
            },
            Bv = function(a) {
                if (a.state === 1 && a.j && a.sessionId) {
                    var b = {
                        type: "RRM_GIS_PING",
                        sessionId: a.sessionId
                    };
                    _.E("Sending RRM_GIS_PING: " + JSON.stringify(b));
                    try {
                        window.top.postMessage(b, a.j)
                    } catch (c) {
                        _.H("Failed to postMessage to window.top", String(c));
                        Av(a);
                        return
                    }
                    a.H++;
                    setTimeout(function() {
                        a.state === 1 && Bv(a)
                    }, Math.min(Math.pow(2, a.H - 1) * 100, 3E4))
                }
            },
            Av = function(a) {
                a.state === 1 && (_.H("RRM handshake timed out."), a.state = 4, xv(a))
            },
            vv = function(a) {
                if (a.sessionId) {
                    _.E("Creating RRM communication iframe");
                    a.state = 2;
                    var b = new _.$c(a.F);
                    b.l.set("sessionId", a.sessionId);
                    b.l.set("role", "GIS");
                    a.h = Ft(b.toString());
                    document.body.appendChild(a.h);
                    setTimeout(function() {
                        a.state === 2 && (_.H("RRM communication iframe failed to load within timeout."), a.state = 4, xv(a))
                    }, 6E4)
                } else _.H("Session ID not available, cannot create RRM iframe.")
            },
            wv = function(a) {
                a.state === 2 && (_.E("RRM communication iframe loaded and ready."), a.state = 3, window.top.postMessage({
                    type: "RRM_GIS_READY_GIS",
                    sessionId: a.sessionId
                }, a.j), a.l = setTimeout(function() {
                    a.C || _.G("Still waiting for RRM_GIS_YIELD after 10 minutes.");
                    a.l = null
                }, 6E5))
            },
            xv = function(a) {
                a.u &&
                    (_.E("Executing queued prompt function."), a.u(), a.u = null)
            },
            Gv = function(a) {
                return a.state !== 4 && !a.C
            },
            Hv = function(a, b) {
                Gv(a) ? (a.u = b, _.E("Prompt function queued, waiting for RRM yield.")) : (_.G("setQueuedPrompt called in unexpected state: " + a.state), b())
            },
            Iv = function(a, b) {
                a.state === 3 && a.h && a.h.contentWindow && a.sessionId ? (_.E("Sending RRM_GIS_ID_TOKEN to RRM iframe."), a.i = b, a.h.contentWindow.postMessage({
                        type: "RRM_GIS_ID_TOKEN",
                        sessionId: a.sessionId,
                        idToken: b.credential,
                        clientId: b.client_id
                    }, a.G), a.v =
                    setTimeout(function() {
                        _.G("No RRM_GIS_REDIRECT_OK received after 1 minute.");
                        a.i && (a.A(a.i), a.i = null)
                    }, 6E4)) : (_.G("notifyIdToken called in unexpected state or without iframe: " + a.state), a.A(b))
            };
        var Jv = [0, 7200, 86400, 604800, 2419200],
            Kv = ["enable_itp_optimization"],
            Lv = function(a, b, c) {
                b = b === void 0 ? "i_" : b;
                c = c === void 0 ? "g_state" : c;
                this.j = a;
                this.h = b;
                this.i = c;
                this.l = new Uu
            },
            Mv = function(a) {
                if (a = _.Tc.get(a.i)) try {
                    return JSON.parse(a)
                } catch (b) {}
                return {}
            },
            Ov = function(a) {
                var b = Mv(a),
                    c = b[a.h + "l"],
                    d = typeof c === "number" && !isNaN(c);
                c = {
                    prompt_suppress_level: d && d && c >= 0 && c <= 4 ? c : Nv() ? 1 : 0
                };
                d = b[a.h + "p"];
                d !== void 0 && (c.disable_auto_prompt = d);
                d = b[a.h + "t"];
                d !== void 0 && (c.disable_auto_select_to = d);
                d = b[a.h + "u"];
                d !==
                    void 0 && (c.prompt_ui = d);
                d = b[a.h + "x"];
                d !== void 0 && (c.mini_prompt_right = d);
                d = b[a.h + "y"];
                d !== void 0 && (c.mini_prompt_bottom = d);
                d = b[a.h + "ll"];
                d !== void 0 && (c.last_library_load_time = d);
                d = b[a.h + "b"];
                d !== void 0 && (c.browsing_session_id = d);
                d = b[a.h + "e"];
                d !== void 0 && (c.experiment_values = d);
                a = b[a.h + "et"];
                a !== void 0 && (c.experiment_cache_time = a);
                return c
            },
            Pv = function(a, b) {
                var c = a.h + "p",
                    d = a.h + "t",
                    e = a.h + "l",
                    f = a.h + "u",
                    g = a.h + "x",
                    h = a.h + "y",
                    k = a.h + "ll",
                    l = a.h + "b",
                    n = a.h + "e",
                    p = a.h + "et",
                    q = Mv(a);
                b.disable_auto_prompt === void 0 ?
                    delete q[c] : q[c] = b.disable_auto_prompt;
                b.disable_auto_select_to === void 0 ? delete q[d] : q[d] = b.disable_auto_select_to;
                q[e] = b.prompt_suppress_level;
                b.prompt_ui === void 0 ? delete q[f] : q[f] = b.prompt_ui;
                b.mini_prompt_right === void 0 ? delete q[g] : q[g] = b.mini_prompt_right;
                b.mini_prompt_bottom === void 0 ? delete q[h] : q[h] = b.mini_prompt_bottom;
                b.last_library_load_time === void 0 ? delete q[k] : q[k] = b.last_library_load_time;
                b.browsing_session_id === void 0 ? delete q[l] : q[l] = b.browsing_session_id;
                b.experiment_values === void 0 ?
                    delete q[n] : q[n] = b.experiment_values;
                b.experiment_cache_time === void 0 ? delete q[p] : q[p] = b.experiment_cache_time;
                b = JSON.stringify(q);
                c = _.Na() && _.Ga() && _.il(_.jl(), "67") >= 0;
                _.Tc.set(a.i, b, {
                    Qb: 15552E3,
                    path: "/",
                    domain: a.j || void 0,
                    secure: c ? !0 : void 0,
                    sameSite: c ? "none" : void 0
                })
            },
            Rv = function(a) {
                var b = Ov(a);
                delete b.disable_auto_prompt;
                b.prompt_suppress_level && Vs(new Ws("onetap", void 0, "resetCooldown", b.prompt_suppress_level.toString()));
                Nv() ? b.prompt_suppress_level = 1 : b.prompt_suppress_level = 0;
                Pv(a, b);
                a.Ia();
                Qv(a)
            },
            Sv = function(a) {
                var b = b === void 0 ? !1 : b;
                var c = Ov(a);
                if (b) {
                    _.E("Prompt ignored. Suppressing prompt for 30 minutes.");
                    b = (new Date).getTime() + 18E5;
                    var d;
                    c.disable_auto_prompt = Math.max((d = c.disable_auto_prompt) != null ? d : 0, b)
                } else c.prompt_suppress_level = Math.min(c.prompt_suppress_level + 1, 4), c.disable_auto_prompt = (new Date).getTime() + Jv[c.prompt_suppress_level] * 1E3, Vs(new Ws("onetap", void 0, "startCooldown", c.prompt_suppress_level.toString()));
                Pv(a, c)
            },
            Tv = function(a) {
                a = Ov(a).disable_auto_prompt;
                return a !==
                    void 0 && a > (new Date).getTime()
            },
            ku = function(a) {
                var b = Ov(a);
                b.disable_auto_select_to = Date.now() + 864E5;
                Pv(a, b)
            };
        Lv.prototype.Ia = function() {
            var a = Ov(this);
            delete a.disable_auto_select_to;
            Pv(this, a)
        };
        var Uv = function(a) {
                var b = Ov(a);
                if (!b.experiment_cache_time) return !0;
                a = Vu(a.l, Xu);
                return a ? b.experiment_cache_time < a * 1E3 ? (_.E("Experiment cache expired."), !0) : !1 : !1
            },
            Qv = function(a) {
                var b = Ov(a);
                delete b.browsing_session_id;
                _.E("Reset browsing session id.");
                Pv(a, b)
            },
            Nv = function() {
                switch (Ms("enable_itp_optimization")) {
                    case 14:
                    case 15:
                    case 16:
                    case 17:
                    case 24:
                        return _.ql();
                    default:
                        return !1
                }
            },
            Vv = function() {
                switch (Ms("enable_itp_optimization")) {
                    case 13:
                    case 15:
                    case 24:
                        return 86400;
                    case 16:
                        return 43200;
                    case 17:
                        return 21600;
                    default:
                        return 0
                }
            };
        var Wv = RegExp("^((?!\\s)[a-zA-Z0-9\u0080-\u3001\u3003-\uff0d\uff0f-\uff60\uff62-\uffffFF-]+[\\.\\uFF0E\\u3002\\uFF61])+(?!\\s)[a-zA-Z0-9\u0080-\u3001\u3003-\uff0d\uff0f-\uff60\uff62-\uffffFF-]{2,63}$");
        Pt.prototype.next = function() {
            return Xv
        };
        var Xv = {
            done: !0,
            value: void 0
        };
        Pt.prototype.Ga = function() {
            return this
        };
        var aw = function(a) {
                if (a instanceof Yv || a instanceof Zv || a instanceof $v) return a;
                if (typeof a.next == "function") return new Yv(function() {
                    return a
                });
                if (typeof a[Symbol.iterator] == "function") return new Yv(function() {
                    return a[Symbol.iterator]()
                });
                if (typeof a.Ga == "function") return new Yv(function() {
                    return a.Ga()
                });
                throw Error("Ua");
            },
            Yv = function(a) {
                this.h = a
            };
        Yv.prototype.Ga = function() {
            return new Zv(this.h())
        };
        Yv.prototype[Symbol.iterator] = function() {
            return new $v(this.h())
        };
        Yv.prototype.i = function() {
            return new $v(this.h())
        };
        var Zv = function(a) {
            this.h = a
        };
        _.J(Zv, Pt);
        Zv.prototype.next = function() {
            return this.h.next()
        };
        Zv.prototype[Symbol.iterator] = function() {
            return new $v(this.h)
        };
        Zv.prototype.i = function() {
            return new $v(this.h)
        };
        var $v = function(a) {
            Yv.call(this, function() {
                return a
            });
            this.j = a
        };
        _.J($v, Yv);
        $v.prototype.next = function() {
            return this.j.next()
        };
        var bw = function() {};
        _.Pd(bw, Qt);
        bw.prototype[Symbol.iterator] = function() {
            return aw(this.Ga(!0)).i()
        };
        bw.prototype.clear = function() {
            var a = Array.from(this);
            a = _.v(a);
            var b = a.next();
            try {
                for (; !b.done; b = a.next()) this.j(b.value)
            } finally {
                _.yd(a, b)
            }
        };
        _.Pd(Rt, bw);
        var Ut = function(a) {
            if (a.i === null) {
                var b = a.h;
                if (b) try {
                    b.setItem("__sak", "1");
                    b.removeItem("__sak");
                    var c = !0
                } catch (d) {
                    c = d instanceof DOMException && (d.name === "QuotaExceededError" || d.code === 22 || d.code === 1014 || d.name === "NS_ERROR_DOM_QUOTA_REACHED") && b && b.length !== 0
                } else c = !1;
                a.i = c
            }
            return a.i
        };
        _.m = Rt.prototype;
        _.m.set = function(a, b) {
            cw(this);
            try {
                this.h.setItem(a, b)
            } catch (c) {
                if (this.h.length == 0) throw "Storage mechanism: Storage disabled";
                throw "Storage mechanism: Quota exceeded";
            }
        };
        _.m.get = function(a) {
            cw(this);
            a = this.h.getItem(a);
            if (typeof a !== "string" && a !== null) throw "Storage mechanism: Invalid value was encountered";
            return a
        };
        _.m.j = function(a) {
            cw(this);
            this.h.removeItem(a)
        };
        _.m.Ga = function(a) {
            cw(this);
            var b = 0,
                c = this.h,
                d = new Pt;
            d.next = function() {
                if (b >= c.length) return Xv;
                var e = c.key(b++);
                if (a) return {
                    value: e,
                    done: !1
                };
                e = c.getItem(e);
                if (typeof e !== "string") throw "Storage mechanism: Invalid value was encountered";
                return {
                    value: e,
                    done: !1
                }
            };
            return d
        };
        _.m.clear = function() {
            cw(this);
            this.h.clear()
        };
        _.m.key = function(a) {
            cw(this);
            return this.h.key(a)
        };
        var cw = function(a) {
            if (a.h == null) throw Error("Va");
            Ut(a) || _.Aa(Error("Va"))
        };
        _.Pd(St, Rt);
        _.Pd(Tt, bw);
        Tt.prototype.set = function(a, b) {
            this.i.set(this.h + a, b)
        };
        Tt.prototype.get = function(a) {
            return this.i.get(this.h + a)
        };
        Tt.prototype.j = function(a) {
            this.i.j(this.h + a)
        };
        Tt.prototype.Ga = function(a) {
            var b = this.i[Symbol.iterator](),
                c = this,
                d = new Pt;
            d.next = function() {
                var e = b.next();
                if (e.done) return e;
                for (e = e.value; e.slice(0, c.h.length) != c.h;) {
                    e = b.next();
                    if (e.done) return e;
                    e = e.value
                }
                return {
                    value: a ? e.slice(c.h.length) : c.i.get(e),
                    done: !1
                }
            };
            return d
        };
        var qw, iu, vw, xw, ww, zw, Aw, hw;
        _.ew = function(a, b) {
            b = b === void 0 ? "i_" : b;
            var c = this;
            this.M = Vt();
            this.be = b;
            this.j = a = (0, _.oa)({}, a);
            this.Fc = !1;
            this.H = !0;
            this.m = Ds();
            this.D = new Map;
            this.Bc = !1;
            this.C = new ev;
            this.uc = this.G = !1;
            dw(this, a);
            _.I("enable_rrm_interop") && a.rrm_interop && (_.E("RRM interop enabled"), this.A = new uv(function(d) {
                _.E("RRM Redirect OK. Response received: " + JSON.stringify(d));
                c.callback && c.callback.call(c, d)
            }, this.Nd), zv(this.A))
        };
        _.J(_.ew, _.bi);
        var dw = function(a, b) {
            var c = a.M ? a.M.get("ll") || void 0 : void 0;
            if (c) fw(a, c);
            else {
                if (c = b.log_level !== void 0) c = b.log_level, c = c === void 0 || (0, _.Qa)(Hu, c) >= 0;
                c && fw(a, b.log_level)
            }
            a.Od = b.button_url || "https://accounts.google.com/gsi/button";
            a.Qc = b.picker_url || "https://accounts.google.com/gsi/select";
            a.ke = b.prompt_url || "https://accounts.google.com/gsi/iframe/select";
            a.Xc = b.status_url || "https://accounts.google.com/gsi/status";
            a.L = _.Yc(a.Xc);
            a.Yd = b.container_css_url || "https://accounts.google.com/gsi/style";
            a.oe =
                b.revoke_url || "https://accounts.google.com/gsi/revoke";
            a.mc = b.fedcm_url || "https://accounts.google.com/gsi/";
            a.Oa = b.fedcm_config_url || "https://accounts.google.com/gsi/fedcm.json";
            a.lc = b.fedcm_passive_config_url || "https://accounts.google.com/gsi/fedcm/config/passive.json";
            a.ae = b.fedcm_active_config_url || "https://accounts.google.com/gsi/fedcm/config/active.json";
            a.Qa = b.oauth2_auth_url || "https://accounts.google.com/o/oauth2/v2/auth";
            a.Nd = b.rrm_iframe_path || "https://news.google.com/swg/ui/v1/rrmgisinterop";
            a.callback = b.callback;
            a.K = b.redirect_callback;
            a.W = b.ux_mode === "redirect" ? "redirect" : "popup";
            c = b.ui_mode;
            c !== void 0 && Object.values(Eu).includes(c) || (c = a.container === document.body, c = _.qd() && !_.pd() || (c === void 0 || c) && pt() && window.innerWidth < 420 ? "bottom_sheet" : "card");
            a.uiMode = c;
            a.mb = b.color_scheme;
            a.container = (b.prompt_parent ? b.prompt_parent : b.prompt_parent_id ? document.getElementById(b.prompt_parent_id) : null) || document.body;
            a.ee = 9E4;
            a.lb = b.cancel_on_tap_outside !== !1;
            a.Bc = b.itp_support !== !1;
            a.ha = b.use_fedcm_for_prompt ===
                void 0 ? void 0 : !!b.use_fedcm_for_prompt;
            a.re = b.use_fedcm_for_button === void 0 ? void 0 : !!b.use_fedcm_for_button;
            if (b.library_name && b.library_name.length > 100) throw Error("Wa");
            a.Dc = b.library_name ? b.library_name : void 0;
            c = b.state_cookie_domain;
            !c || c != null && Wv.test(c) || (c = void 0);
            a.h = new Lv(c, a.be, b.state_cookie_name);
            c = a.h;
            var d = Ov(c),
                e = Date.now();
            d.last_library_load_time && d.browsing_session_id ? e - d.last_library_load_time > 18E5 && (d.browsing_session_id = Ds(), _.E("Session expired. Setting new browsing session id.")) :
                (d.browsing_session_id = Ds(), _.E("Setting new browsing session id."));
            if (!d.experiment_values || Uv(c)) {
                var f = {},
                    g = _.v(Kv),
                    h = g.next();
                try {
                    for (; !h.done; h = g.next()) {
                        var k = h.value;
                        f[k] = Ms(k)
                    }
                } finally {
                    _.yd(g, h)
                }
                d.experiment_values = f;
                d.experiment_cache_time = e;
                _.E("Setting new experiment values.")
            }
            d.last_library_load_time = e;
            Pv(c, d);
            if (_.I("enable_browsing_session_id") && (Us = Ov(a.h).browsing_session_id, k = Ov(a.h).experiment_values)) {
                k = _.v(Object.entries(k));
                c = k.next();
                try {
                    for (; !c.done; c = k.next()) {
                        var l = _.v(c.value),
                            n = l.next().value,
                            p = l.next().value;
                        _.ff(n, p)
                    }
                } finally {
                    _.yd(k, c)
                }
            }
            Ts(a.L, b.client_id, a.m, [{
                Ad: "enable_itp_optimization",
                Bd: Ms("enable_itp_optimization")
            }]);
            a.Mc(b);
            l = {};
            b.client_id !== void 0 && (l.client_id = b.client_id);
            b.origin !== void 0 && (l.origin = b.origin);
            b.auto_select !== void 0 && (l.auto_select = b.auto_select);
            b.button_auto_select !== void 0 && (l.button_auto_select = b.button_auto_select);
            l.ux_mode = a.W;
            l.ux_mode === "redirect" && b.login_uri && (l.login_uri = b.login_uri);
            l.ui_mode = a.uiMode;
            a.mb !== void 0 && (l.color_scheme =
                a.mb);
            b.context !== void 0 && Object.values(Du).includes(b.context) && (l.context = b.context);
            if (b.login_hint !== void 0 || b.hint !== void 0) l.hint = b.login_hint || b.hint;
            if (b.hd !== void 0 || b.hosted_domain !== void 0) l.hosted_domain = b.hd || b.hosted_domain;
            b.existing !== void 0 && (l.existing = b.existing);
            b.special_accounts !== void 0 && (l.special_accounts = b.special_accounts);
            b.nonce !== void 0 && (l.nonce = b.nonce);
            b.channel_id !== void 0 && (l.channel_id = b.channel_id);
            b.state !== void 0 && (l.state = b.state);
            _.Ec !== "warn" && (l.log_level =
                _.Ec);
            b.hl !== void 0 && (l.hl = b.hl);
            b.disable_auto_focus !== void 0 && (l.disable_auto_focus = b.disable_auto_focus);
            l.as = a.m;
            _.I("enable_browsing_session_id") && (l.bs = Ov(a.h).browsing_session_id);
            if (b.library_name && b.library_name.length > 100) throw Error("Wa");
            b.library_name !== void 0 && (l.library_name = b.library_name);
            _.I("rp_cancelable_auto_select") && (l.feature = "cancelableAutoSelect");
            if (b.essential_claims !== void 0) {
                p = b.essential_claims;
                b = {};
                n = {};
                if (p)
                    for (p = p.split(","), k = 0; k < p.length; k++) n[p[k].trim()] = {
                        essential: !0
                    };
                b.id_token = n;
                l.claims = JSON.stringify(b)
            }
            a.Lc(l);
            a.o = l
        };
        _.ew.prototype.Mc = function() {};
        _.ew.prototype.Lc = function() {};
        var du = function(a) {
                a.Fc || (a.Fc = !0, _.If(window, "message", function(b) {
                    gw(a, b.h)
                }, !1))
            },
            kw = function(a) {
                setTimeout(function() {
                    a.ra = _.If(document, "click", function() {
                        a.lb && hw(a, !1) && (iw(a, "tap_outside"), jw(a), Ot() && Zs("tappedOutside"))
                    })
                })
            },
            jw = function(a) {
                a.ra && (_.Qf(a.ra), a.ra = void 0)
            };
        _.ew.prototype.sc = function() {
            return !1
        };
        var lw = function(a) {
                if (_.I("disable_fedcm") || !ot() || !_.sd()) return !1;
                if (_.I("enable_account_labels") && !Iu.accountLabelsToken) {
                    var b = document.createElement("meta");
                    b.httpEquiv = "origin-trial";
                    b.content = "A0bwwYX3EzD2AQ197RMA+kffyE2vepCTH00bYuzg+GBcNrCLbr5oXzOvpk5eehvvaGr9Mu+/rH9pKPJXR76MngoAAAB2eyJvcmlnaW4iOiJodHRwczovL2FjY291bnRzLmdvb2dsZS5jb206NDQzIiwiZmVhdHVyZSI6IkZlZENtQ29udGludWVPbkJ1bmRsZSIsImV4cGlyeSI6MTc0NDY3NTIwMCwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==";
                    document.getElementsByTagName("head")[0].appendChild(b);
                    Iu.accountLabelsToken = !0
                }
                if (a.sc() || qt() === "https://meet.google.com") return !1;
                if (_.I("enable_fedcm_global_experiment")) return _.E("In FedCM global experiment group"), !0;
                if (_.I("enable_fedcm_global_control")) return _.E("In FedCM global control group"), !1;
                if (a.o.auto_select && !(_.Ma("Chromium") >= 121)) return !1;
                if (_.I("disable_fedcm_opt_out") && _.Ma("Chromium") >= 142) return !0;
                (a = a.ha === !1) && _.G("Currently, you disable FedCM on Google One Tap. FedCM for One Tap will become mandatory soon, and you won\u2019t be able to disable it. Refer to the migration guide to update your code accordingly to ensure users will not be blocked from logging in. Learn more: https://developers.google.com/identity/gsi/web/guides/fedcm-migration");
                return !a
            },
            mw = function(a) {
                return ot() && _.sd() && a.C.i ? _.I("enable_fedcm_button_global_control") ? (_.E("In FedCM button global control group"), !1) : _.I("enable_fedcm_button_global_experiment") ? (_.E("In FedCM button global experiment group"), !0) : !!a.re : !1
            };
        _.ew.prototype.ga = function(a, b, c) {
            if (b) {
                _.E("Processing FedCM credential");
                var d = null;
                try {
                    d = JSON.parse(b.token).id_token
                } catch (e) {
                    d = b.token
                }
                d = {
                    credential: d,
                    state: c && c.state
                };
                d.select_by = a === "widget" ? b.isAutoSelected ? "fedcm_auto" : "fedcm" : b.isAutoSelected ? "fedcm_button_auto" : "fedcm_button";
                nw({
                    data: {
                        announcement: _.Zm({})
                    }
                });
                _.E("FedCM response :" + JSON.stringify(d));
                a === "widget" ? (this.callback ? this.callback.call(this, d) : _.E("No callback found for FedCM widget flow"), ow(this, "credential_returned")) : this.W ===
                    "popup" ? this.callback ? this.callback.call(this, d) : _.E("No callback found for FedCM button popup flow") : c && c.login_uri ? (a = {}, c && c.state && (a.state = c.state), ft(c.login_uri, a, d.credential)) : this.K ? this.K.call(this, d) : _.E("No callback found for FedCM button redirect flow.");
                Qv(this.h)
            } else _.E("FedCM credential is null")
        };
        _.ew.prototype.ma = function(a, b) {
            _.H("FedCM get() rejects with " + b);
            a === "widget" && iw(this, "unknown_reason")
        };
        var pw = function(a) {
            a.G = !0;
            var b = {
                as: a.m,
                top_origin: rt() ? qt() : void 0,
                library_name: a.o.library_name ? a.o.library_name : void 0,
                response_type: "id_token",
                ss_domain: a.o.origin || location.origin,
                scope: "email profile openid",
                nonce: a.o.nonce ? a.o.nonce : "not_provided",
                state: a.o.state
            };
            a.o.claims && (b.claims = a.o.claims);
            gv(a.C, {
                Gc: a.mc,
                wb: a.lc,
                o: a.o,
                Ia: !!a.o.auto_select,
                ga: a.ga.bind(a),
                ma: function(c, d) {
                    Ts(a.L, a.j.client_id, a.m);
                    var e = document.location.ancestorOrigins ? document.location.ancestorOrigins.length : 0;
                    e =
                        e > 0 ? document.location.ancestorOrigins[e - 1] : "";
                    var f = [document.location.protocol, "//", document.location.host].join("");
                    d.message.indexOf("identity-credentials-get") >= 0 && at("failedWithIframeGetPermission", "iframeOrigin=" + f, "path=" + document.location.pathname, "topOrigin=" + e);
                    d.message.indexOf("Content Security Policy") >= 0 && at("failedWithCsp", "iframeOrigin=" + f, "path=" + document.location.pathname, "topOrigin=" + e);
                    a.ma(c, d)
                },
                Vd: function() {
                    a.G = !1
                },
                Sa: b
            });
            kw(a)
        };
        _.ew.prototype.Z = function(a, b, c) {
            var d = this;
            this.A && Gv(this.A) ? (_.E("RRM interop active, deferring prompt"), Hv(this.A, function() {
                qw(d, a, b, c)
            })) : qw(this, a, b, c)
        };
        qw = function(a, b, c, d) {
            c = (0, _.oa)({}, a.j, c);
            dw(a, c);
            c = a.o.ui_mode === "bottom_sheet" ? "bottomSheet" : "card";
            Ot() && Ys(c, "apiCall");
            pt() && _.G("Your client application may not display Google One Tap when FedCM becomes mandatory. Opt-in to FedCM to test that you have the proper cross-origin permission policy set up. Ignore this message if One Tap is displayed after opt-in to FedCM. Learn more: (https://developers.google.com/identity/gsi/web/guides/fedcm-migration?s=dc#cross_origin)");
            if (window.location.href.startsWith("chrome-extension://")) _.G("Attempted to start sign in flow inside chrome extension."),
                Ys(c, "chromeExtension");
            else if (hw(a, !0) && (ow(a, "flow_restarted"), Ot() && Zs("flowRestarted")), b && !a.uc && (_.G("Your client application uses one of the Google One Tap prompt UI status methods that may stop functioning when FedCM becomes mandatory. Refer to the migration guide to update your code accordingly and opt-in to FedCM to test your changes. Learn more: https://developers.google.com/identity/gsi/web/guides/fedcm-migration?s=dc#display_moment and https://developers.google.com/identity/gsi/web/guides/fedcm-migration?s=dc#skipped_moment"),
                    a.uc = !0), a.u = b, a.nc = d, a.o.client_id)
                if (_.I("unsupported_browser")) _.F("One Tap is not supported in this User Agent."), a.l("browser_not_supported"), _.ei(a, "prompt_display_failed", {
                    cause: "Unsupported user agent for one tap."
                }), Ys(c, "unsupportedBrowser");
                else if (Tv(a.h)) _.F("User has closed One Tap before. Still in the cool down period."), a.l("suppressed_by_user"), _.ei(a, "prompt_display_failed", {
                cause: "Prompt disabled by the user."
            }), Ys(c, "cooldown", (Ov(a.h).prompt_suppress_level || 0).toString());
            else if (lw(a)) rw(a,
                function(f) {
                    f && _.yb(_.N(f, 9)) ? (_.E("All accounts are opted out."), a.l("opt_out_or_no_session"), _.ei(a, "prompt_display_failed", {
                        cause: "All accounts are opted out."
                    })) : pw(a)
                });
            else {
                var e = _.ql() && a.Bc;
                a.o.is_itp = e;
                _.ql() && a.uiMode === "bottom_sheet" && (a.o.prompt_ui = Os(), a.o.auto_dismiss_duration_ms = Mt());
                rw(a, function(f) {
                    delete a.o.is_itp;
                    if (f)
                        if (_.Me(f, 2)) _.Ph(_.O(f, _.ai, 2)), f = _.O(f, _.ai, 2), f = _.Oe(f, 1), a.l(f === 2 ? "opt_out_or_no_session" : f === 7 ? "secure_http_required" : f === 5 ? "unregistered_origin" : f === 3 || f ===
                            4 ? "invalid_client" : f === 9 ? "browser_not_supported" : f === 12 ? "web_view_not_supported" : "unknown_reason"), _.ei(a, "prompt_display_failed", {
                            cause: "Error while checking for the credential status."
                        });
                        else if (_.yb(_.N(f, 3))) _.O(f, _.Kl, 1) && (a.o.as = _.gn(_.O(f, _.Kl, 1)) || a.o.as), sw(a), Nt() || tw(a), uw(a), kw(a);
                    else {
                        var g = _.I("enable_itp_flag_on_check_credential_status");
                        g = !g || g && _.yb(_.N(f, 4));
                        e && g ? (_.O(f, _.Kl, 1) && (a.o.as = _.gn(_.O(f, _.Kl, 1)) || a.o.as), a.o.is_itp = !0, sw(a), Nt() || tw(a), uw(a), kw(a), delete a.o.is_itp) : (_.E("No sessions found in the browser."),
                            a.l("opt_out_or_no_session"), _.ei(a, "prompt_display_failed", {
                                cause: "No signed in Google accounts available."
                            }))
                    } else _.E("Invalid response from check credential status."), a.l("unknown_reason"), _.ei(a, "prompt_display_failed", {
                        cause: "A network error was encountered while checking for the credential status."
                    })
                })
            } else _.H("Missing required parameter: client_id."), a.l("missing_client_id"), _.ei(a, "prompt_display_failed", {
                cause: "Missing required parameter: client_id."
            }), Ys(c, "noClientId")
        };
        iu = function(a, b, c, d) {
            var e = (0, _.oa)({}, c);
            Tu = Tu || new Uu;
            Vu(Tu, Wu) || e.theme !== "outline_dark" || (delete e.theme, _.E("Outline dark theme is not enabled."));
            _.nm(b);
            _.gj(b);
            var f = Ht();
            c = new _.$c(a.Od);
            var g = (0, _.oa)({}, e),
                h = _.gf(document, "div");
            h.classList.add("S9gUrf-YoZ4jf");
            h.style.position = "relative";
            b.appendChild(h);
            b = vw(a, h, e, f);
            d = {
                iframeId: f,
                handler: d,
                vc: e.click_listener,
                Ba: b,
                data: {
                    nonce: g.nonce || a.j.nonce,
                    state: g.state || a.j.state
                }
            };
            a.D.set(f, d);
            delete g.nonce;
            delete g.state;
            g.hint = g.login_hint ||
                g.hint || a.j.login_hint || a.j.hint;
            g.hint || delete g.hint;
            delete g.login_hint;
            g.hosted_domain = g.hd || g.hosted_domain || a.j.hd || a.j.hosted_domain;
            g.hosted_domain || delete g.hosted_domain;
            delete g.hd;
            g.is_fedcm_supported = ot() && a.C.i;
            if (_.I("enable_fedcm_button_global_control") || _.I("enable_fedcm_button_global_experiment")) g.fedcm_button_experiment_arm = _.I("enable_fedcm_button_global_experiment") ? 1 : 0;
            b = _.ol(g);
            b.set("client_id", a.j.client_id);
            b.set("iframe_id", f);
            b.set("cas", a.m);
            g.locale && (b.set("hl", g.locale),
                _.tf(b, "locale"));
            _.Ec !== "warn" && b.set("log_level", _.Ec);
            _.cd(c, b);
            var k = void 0;
            _.I("enable_fedcm_bluedog_poc") && (k = jv(a.Oa, a.o), _.If(k, "ontoken", function() {
                var l = k.credential();
                l ? a.callback || a.K ? (l = {
                    credential: l,
                    select_by: "fedcm"
                }, a.callback ? (a.callback.call(a, l), _.E("Returning token to callback.", "Login element")) : a.K && (a.K.call(a, l), _.E("Redirecting with token.", "Login element"))) : _.G("No callback provided to handle token.", "Login element") : _.G("Token is empty.", "Login element")
            }));
            g = _.an();
            c =
                Et(h, c.toString(), f, g, k);
            d.N = c.N;
            g && c.bd && nt(c.bd, function(l) {
                l.preventDefault();
                l.stopPropagation();
                ww(a, f)
            });
            _.I("enable_fedcm_bluedog_poc") && a.D.size === 1 && iv(a.Oa, a.o)
        };
        vw = function(a, b, c, d) {
            var e = _.gf(document, "div");
            b.appendChild(e);
            if (Kt(b)) {
                var f = _.R("googleidentityservice_button_styles");
                b = Kt(b);
                f && b && !b.getElementById("googleidentityservice_button_styles") && b.appendChild(f.cloneNode(!0))
            }
            c = new rv(e, c, function() {
                ww(a, d)
            });
            c.h || (c.container.addEventListener("error", c.j, !0), _.en(c.container, c.Ha, !0, !0), sv(c), c.l = performance.now());
            return c
        };
        xw = function(a, b) {
            var c = a.D.get(b);
            if (c && c.Ba) {
                var d = c.Ba;
                requestAnimationFrame(function() {
                    requestAnimationFrame(function() {
                        d.dispose();
                        c.Ba = void 0;
                        a: {
                            if (performance && performance.getEntriesByType) {
                                var e = performance.getEntriesByType("navigation");
                                if (e.length > 0) {
                                    e = e[0].domComplete;
                                    break a
                                }
                            }
                            e = performance && performance.timing && performance.timing.domComplete && performance.timeOrigin ? performance.timing.domComplete - performance.timeOrigin : void 0
                        }
                        e && Vs(new Ws("button", void 0, "rendered", "latency", Math.floor(d.l -
                            e).toString(), Math.floor(d.m - e).toString(), Math.floor(d.startTime - e).toString()), 1)
                    })
                })
            }
        };
        ww = function(a, b) {
            _.E("Processing click for button: " + b + ".");
            if (b) {
                var c = _.R(b),
                    d = a.D.get(b);
                c || _.F("The iframe containing the button was not found within the page.");
                d ? d.handler ? (d.handler(d.data), _.E("Custom handler called for button: " + b + ".")) : (b = {}, d.data.nonce && (b.nonce = d.data.nonce), d.data.state && (b.state = d.data.state), _.yw(a, b, d.data ? d.data.sessionId : void 0), d.vc && d.vc((0, _.oa)({}, d.data))) : _.H("A button entry was not found for the given id.")
            }
        };
        _.yw = function(a, b, c) {
            hw(a, !0) && (ow(a, "flow_restarted"), Zs("buttonFlowStarted"));
            b = (0, _.oa)({}, a.j, b);
            dw(a, b);
            mw(a) ? (a.G = !0, hv(a.C, {
                Gc: a.mc,
                wb: a.ae,
                o: a.o,
                Ia: !!a.o.button_auto_select,
                ga: a.ga.bind(a),
                ma: a.ma.bind(a),
                Vd: function() {
                    a.G = !1
                },
                Sa: {
                    as: c || a.m,
                    state: b.state,
                    login_uri: a.o.login_uri,
                    response_type: "id_token",
                    ss_domain: a.o.origin || location.origin,
                    scope: "email profile openid",
                    nonce: a.o.nonce ? a.o.nonce : "not_provided"
                }
            })) : a.W === "redirect" ? zw(a, c) : Aw(a, c)
        };
        zw = function(a, b) {
            a.o.as = b || a.m;
            a.o.login_uri || (a.o.login_uri = location.protocol + "//" + location.host + location.pathname);
            a.o.g_csrf_token = bt();
            a.o.origin = a.o.origin || location.origin;
            if (_.I("enable_gis_oauth_button_flow_redirect")) {
                b = {
                    as: a.o.as,
                    client_id: a.o.client_id,
                    scope: "openid email profile",
                    response_type: "id_token",
                    nonce: a.o.nonce,
                    gsiwebsdk: "gis_attributes",
                    redirect_uri: a.o.login_uri,
                    response_mode: "form_post",
                    display: "page"
                };
                a.o.state && (b.state = a.o.state);
                a.o.hint && (b.login_hint = a.o.hint);
                a.o.hosted_domain &&
                    (b.hd = a.o.hosted_domain);
                _.I("disable_prompt_select_account") || (b.prompt = "select_account");
                a.o.claims && (b.claims = a.o.claims);
                if (a.o.color_scheme === "light" || a.o.color_scheme === "dark") b.color_scheme = a.o.color_scheme;
                var c = _.rl(new _.bj, _.ml("btn"));
                c = _.S(c, 4, a.o.g_csrf_token);
                c = _.S(c, 5, a.o.as);
                c = _.T(c, 7, 2);
                c = _.S(c, 11, window.location.href);
                a.o.state && _.S(c, 10, a.o.state);
                a.o.library_name && (_.S(c, 12, a.o.library_name), b.library_name = a.o.library_name);
                b.gis_params = _.Va(c.h(), 4);
                _.Ji(top.location, Hs(_.pl(a.Qa,
                    b)))
            } else _.Ji(top.location, Hs(_.pl(a.Qc, a.o)))
        };
        Aw = function(a, b) {
            a.v = _.od();
            a.o.as = b || a.m;
            a.o.channel_id = _.Qi(a.v);
            a.o.origin = a.o.origin || location.origin;
            if (_.I("enable_gis_oauth_button_flow_popup")) {
                b = {
                    as: a.o.as,
                    client_id: a.o.client_id,
                    scope: "openid email profile",
                    response_type: "id_token",
                    nonce: a.o.nonce,
                    gsiwebsdk: "gis_attributes",
                    redirect_uri: "gis_transform",
                    response_mode: "form_post",
                    origin: a.o.origin,
                    display: "popup"
                };
                a.o.state && (b.state = a.o.state);
                a.o.hint && (b.login_hint = a.o.hint);
                a.o.hosted_domain && (b.hd = a.o.hosted_domain);
                _.I("disable_prompt_select_account") ||
                    (b.prompt = "select_account");
                a.o.claims && (b.claims = a.o.claims);
                if (a.o.color_scheme === "light" || a.o.color_scheme === "dark") b.color_scheme = a.o.color_scheme;
                var c = _.rl(new _.bj, _.ml("btn"));
                c = _.S(c, 4, a.o.g_csrf_token);
                c = _.S(c, 5, a.o.as);
                c = _.T(c, 7, 1);
                c = _.S(c, 8, a.o.channel_id);
                a.o.state && _.S(c, 10, a.o.state);
                a.o.library_name && (_.S(c, 12, a.o.library_name), b.library_name = a.o.library_name);
                b.gis_params = _.Va(c.h(), 4);
                c = a.o.channel_id;
                var d = a.o.g_csrf_token,
                    e = a.o.as,
                    f = Es(b.gis_params);
                try {
                    var g = Cu(f);
                    var h = g ? _.Ne(g,
                        4) === (d ? d : "") && _.Ne(g, 5) === (e ? e : "") && _.Wi(g, 7) === 1 && _.Ne(g, 8) === (c ? c : "") : !1
                } catch (k) {
                    _.G("validateTransformLayerPayload failed"), h = !1
                }
                h || Vs(new Ws("button", "popup", "clicked", "base64_gis_params_validation_failed", "origin=" + a.o.origin, "clientId=" + a.o.client_id, "gisParams=" + b.gis_params));
                _.I("enable_large_popup_height") ? (b.gislp = "1", b.upstream_experiment_id = "117788636") : _.I("enable_large_popup_height_control") && (b.gislp = "0", b.upstream_experiment_id = "117788635");
                if (_.vd(_.pl(a.Qa, b), "g_credential_picker",
                        _.td())) return;
                Vs(new Ws("button", "popup", "clicked", "oauthPopupNotOpened"))
            }
            _.vd(_.pl(a.Qc, a.o), "g_credential_picker", _.td()) || Vs(new Ws("button", "popup", "clicked", "popupNotOpened"))
        };
        hw = function(a, b) {
            if (a.G) return b = a.C, _.E("Aborting current FedCM flow."), b.h ? (b = b.h, _.E("Aborting FedCM flow. callId " + b.h), b.i ? (b.i.abort(), _.E("FedCM flow aborted. callId " + b.h), b.i = void 0, b = !0) : (_.E("No FedCM flow to abort. callId " + b.h), b = !1)) : (_.E("No FedCM flow to abort."), b = !1), b ? (jw(a), !0) : !1;
            if (Kt(a.container)) var c = !a.F;
            else c = a.container, c = !(document.getElementById("credential_picker_iframe") || c && document.getElementById("credential_picker_container"));
            if (c) return !1;
            if (!b && a.H) return _.F("Cancel prompt request ignored. The prompt is in a protected state."), !1;
            Kt(a.container) ? ((b = a.F) && b.parentElement ? (b.parentElement.id === "credential_picker_container" && b.parentElement.parentElement ? b.parentElement.parentElement.removeChild(b.parentElement) : b.parentElement.removeChild(b), b = !0) : b = !1, b = !b) : b = !zt(a.container);
            if (b) return _.F("Failed to remove prompt iframe."), !1;
            zu(a);
            a.H = !0;
            a.F = void 0;
            jw(a);
            return !0
        };
        _.ew.prototype.l = function(a) {
            Bw(this, !1, a)
        };
        var uw = function(a) {
                if (a.uiMode === "bottom_sheet") {
                    var b = a.h;
                    a: switch (Ms("enable_itp_optimization")) {
                        case 13:
                        case 15:
                        case 16:
                        case 17:
                        case 24:
                            var c = _.ql();
                            break a;
                        default:
                            c = !1
                    }
                    if (c) {
                        _.E("Starting minimum gap.");
                        c = Ov(b);
                        var d = Vv();
                        d = (new Date).getTime() + d * 1E3;
                        var e;
                        c.disable_auto_prompt = Math.max((e = c.disable_auto_prompt) != null ? e : 0, d);
                        Pv(b, c)
                    }
                }
                Bw(a, !0)
            },
            Bw = function(a, b, c) {
                if (a.u) {
                    var d = a.u;
                    b || (a.u = void 0);
                    var e = new tv("display");
                    e.i = b;
                    b || (e.l = c || "unknown_reason");
                    d.call(a, e)
                }
            },
            iw = function(a, b) {
                if (a.u) {
                    var c =
                        a.u;
                    a.u = void 0;
                    var d = new tv("skipped");
                    d.m = b;
                    c.call(a, d)
                }
            },
            ow = function(a, b) {
                if (a.u) {
                    var c = a.u;
                    a.u = void 0;
                    var d = new tv("dismissed");
                    d.j = b;
                    c.call(a, d)
                }
            },
            Cw = function(a, b) {
                a.nc && a.nc.call(a, {
                    type: b,
                    message: void 0
                })
            },
            rw = function(a, b) {
                var c = {
                    client_id: a.o.client_id
                };
                a.o.hint && (c.hint = a.o.hint);
                a.o.hosted_domain && (c.hosted_domain = a.o.hosted_domain);
                a.o.as && (c.cas = a.o.as);
                a.o.bs && (c.bs = a.o.bs);
                a.ha !== void 0 && (c.has_opted_out_fedcm = !a.ha);
                a.o.is_itp !== void 0 && (c.is_itp = a.o.is_itp);
                a.o.prompt_ui !== void 0 &&
                    (c.prompt_ui = a.o.prompt_ui);
                c = _.pl(a.Xc, c);
                ct(c, function(d) {
                    d && d !== "null" ? (d = Zu(JSON.stringify(_.gl(d))), b(d)) : (_.H("Check credential status returns invalid response."), a.l("unknown_reason"), _.ei(a, "network", {
                        cause: "invalid_response"
                    }))
                })
            },
            sw = function(a) {
                var b = a.o,
                    c;
                if (c = a.o.auto_select) {
                    c = a.h;
                    var d = Ov(c);
                    d.disable_auto_select_to && Date.now() >= d.disable_auto_select_to && (c.Ia(), d = Ov(c));
                    c = !(d.disable_auto_select_to && Date.now() < d.disable_auto_select_to)
                }
                b.auto_select = c;
                _.ql() && a.uiMode === "bottom_sheet" &&
                    (a.o.prompt_ui = Os(), a.o.auto_dismiss_duration_ms = Mt());
                a.v = _.od();
                a.o.channel_id = _.Qi(a.v);
                a.o.origin = a.o.origin || location.origin;
                a.o.oauth2_auth_url = a.Qa;
                a.Dc && (a.o.library_name = a.Dc);
                b = _.pl(a.ke, a.o);
                a.H = !0;
                a.Tc(b);
                _.di(a, "prompt_displayed")
            };
        _.ew.prototype.Tc = function(a) {
            this.F = Bt(this.container, a, this.uiMode === "bottom_sheet")
        };
        var tw = function(a) {
                a.uiMode === "bottom_sheet" && window.setTimeout(function() {
                    hw(a, !1) && (iw(a, "auto_cancel"), Ot() && Zs("autoDismissed"))
                }, a.ee)
            },
            gw = function(a, b) {
                if (b.origin === a.L && b.data && b.data.type === "readyForConnect")
                    if (_.E("Setup message received: " + JSON.stringify(b.data)), b.source) {
                        var c = b.data.iframeId;
                        if (c) {
                            if (c = a.D.get(c)) {
                                c.data.sessionId = b.data.sessionId;
                                c = new MessageChannel;
                                c.port1.onmessage = function(e) {
                                    if (e.data && e.data.type) {
                                        _.E("Message received in button channel: " + JSON.stringify(e.data));
                                        var f = e.data.type;
                                        if (f !== "command") _.G("Unknown event type (" + f + ") received in the button channel.");
                                        else switch (f = e.data.command, f) {
                                            case "clicked":
                                                f = e.data.iframeId;
                                                _.E("Clicked command received for button: " + f + ".");
                                                ww(a, f);
                                                break;
                                            case "resize":
                                                f = e.data.iframeId;
                                                _.E("Resize command received for button: " + f + ".");
                                                if (f) {
                                                    var g = a.D.get(f),
                                                        h = e.data.height,
                                                        k = e.data.width;
                                                    if (g && g.N && Gt(h) && Gt(k)) {
                                                        var l = g.N;
                                                        l.style.height = h + "px";
                                                        l.style.width = k + "px";
                                                        g = e.data.verticalMargin;
                                                        e = e.data.horizontalMargin;
                                                        typeof g !==
                                                            "number" || isNaN(g) || typeof e !== "number" || isNaN(e) || (l.style.marginTop = g + "px", l.style.marginBottom = g + "px", l.style.marginLeft = e + "px", l.style.marginRight = e + "px", xw(a, f));
                                                        Au(a, k, h)
                                                    } else l ? _.G("Unable to resize iframe. Invalid dimensions.") : _.G("Unable to resize iframe. No iframe found with id: " + (f + "."))
                                                }
                                                break;
                                            default:
                                                _.G("Unknown command type (" + f + ") received in the button channel.")
                                        }
                                    }
                                };
                                var d = {
                                    type: "channelConnect"
                                };
                                try {
                                    b.source.postMessage(d, a.L, [c.port2])
                                } catch (e) {
                                    _.H("Failed to send postmessage to button iframe: " +
                                        e.message)
                                }
                            }
                        } else if (b.data.channelId && a.v && (a.v && _.Qi(a.v)) === b.data.channelId) {
                            c = new MessageChannel;
                            c.port1.onmessage = function(e) {
                                a.Pa(e)
                            };
                            d = {
                                type: "channelConnect",
                                nonce: a.v
                            };
                            try {
                                b.source.postMessage(d, a.L, [c.port2])
                            } catch (e) {
                                _.H("Failed to send postmessage to iframe: " + e.message)
                            }
                        }
                    } else _.E("Source invalid. Iframe was closed during setup.")
            };
        _.ew.prototype.Pa = function(a) {
            var b = this;
            if (a.data && a.data.type) switch (_.E("Message received: " + JSON.stringify(a.data)), a.data.type) {
                case "response":
                    yt(this.F);
                    var c = a.data.response;
                    c && c.credential ? (Rv(this.h), this.o.state && (c.state = this.o.state), this.A && this.A.state === 3 && _.I("enable_rrm_iframe_token_propagation") ? (_.E("RRM interop active, notifying token"), Iv(this.A, c)) : this.callback && (this.callback.call(this, c), _.E("Response received: " + JSON.stringify(c))), mt(this.o.client_id), setTimeout(function() {
                        hw(b, !0) && (ow(b, "credential_returned"), zu(b))
                    }, 2E3)) : hw(this, !0) && (iw(this, "issuing_failed"), Zs("issuingFailed"), zu(this));
                    nw(a);
                    break;
                case "activity":
                    a.data.activity && this.P(a.data.activity);
                    break;
                case "command":
                    if (c = a.data.command) switch (c) {
                        case "close":
                            a.data.suppress && Sv(this.h);
                            hw(this, !0) && (iw(this, "user_cancel"), zu(this), Ot() && Zs("userCancelled"));
                            break;
                        case "auto_dismiss":
                            hw(this, !0) && (iw(this, "auto_cancel"), zu(this), Ot() && Zs("autoDismissed"));
                            break;
                        case "resize":
                            a = a.data.height;
                            Gt(a) && (c = this.container !==
                                document.body && Kt(this.container) ? Dt(a, this.F) : Ct(a), Au(this, a, c));
                            break;
                        case "cancel_protect_start":
                            this.H = !0;
                            break;
                        case "cancel_protect_end":
                            this.H = !1;
                            break;
                        case "start_auto_select":
                            Cw(this, "auto_select_started");
                            break;
                        case "cancel_auto_select":
                            ku(this.h), Cw(this, "auto_select_canceled")
                    }
            }
        };
        var nw = function(a) {
                a.data.announcement && Jt(a.data.announcement)
            },
            Dw = function(a, b, c) {
                var d = {
                        successful: !1
                    },
                    e = a.o.client_id;
                e ? "IdentityCredential" in window && _.Ma("Chromium") >= 123 ? window.IdentityCredential.disconnect({
                    configURL: a.lc,
                    clientId: e,
                    accountHint: b
                }).then(function() {
                    d.successful = !0;
                    _.F("set result successful to: ' + " + !!d.successful);
                    c && c(d)
                }, function(f) {
                    _.H("FedCM disconnect failed with error: " + JSON.stringify(f));
                    d.error = "fedcm_disconnect_failed: " + JSON.stringify(f);
                    c && c(d)
                }) : (b = {
                    client_id: e,
                    hint: b
                }, a.m && (b.as = a.m), et(a.oe, b, function(f) {
                    if (f && f !== "null") {
                        if (f = av(JSON.stringify(_.gl(f))), d.successful = !!_.Il(f, 3), _.F("Revoke XHR status: " + !!d.successful), !d.successful)
                            if (_.Me(f, 2)) {
                                f = _.O(f, _.ai, 2);
                                _.Ph(f);
                                switch (_.Oe(f, 1)) {
                                    case 1:
                                    case 2:
                                        f = "opt_out_or_no_session";
                                        break;
                                    case 3:
                                        f = "client_not_found";
                                        break;
                                    case 4:
                                        f = "client_not_allowed";
                                        break;
                                    case 5:
                                        f = "invalid_origin";
                                        break;
                                    case 6:
                                        f = "cross_origin_request_not_allowed";
                                        break;
                                    case 7:
                                        f = "secure_http_required";
                                        break;
                                    case 8:
                                        f = "invalid_parameter";
                                        break;
                                    case 9:
                                        f = "browser_not_supported";
                                        break;
                                    case 12:
                                        f = "web_view_not_supported";
                                        break;
                                    default:
                                        f = "unknown_error"
                                }
                                d.error = f
                            } else d.error = "unknown_error"
                    } else _.H("Invalid response is returned for revoke request."), d.error = "invalid_response";
                    c && c(d)
                })) : (_.H("Failed to revoke. Missing config parameter client_id."), c && (d.error = "missing_client_id", c(d)))
            },
            fw = function(a, b, c) {
                (c === void 0 ? 0 : c) && a.M && (b ? a.M.set("ll", b) : a.M.j("ll"));
                _.Fc(b)
            };
        var Wt = {
                client_id: "str",
                auto_select: "bool",
                button_auto_select: "bool",
                ux_mode: "str",
                ui_mode: "str",
                color_scheme: "str",
                context: "str",
                nonce: "str",
                hd: "str",
                hosted_domain: "str",
                login_hint: "str",
                hint: "str",
                login_uri: "str",
                existing: "bool",
                special_accounts: "bool",
                state: "str",
                disable_auto_focus: "bool",
                log_level: "str",
                callback: "func",
                prompt_parent_id: "str",
                prompt_lifetime_sec: "num",
                cancel_on_tap_outside: "bool",
                state_cookie_domain: "str",
                itp_support: "bool",
                itp_mode: "str",
                use_fedcm_for_prompt: "bool",
                use_fedcm_for_button: "bool",
                rrm_interop: "bool",
                rrm_iframe_path: "str",
                essential_claims: "claims",
                native_callback: "func",
                moment_callback: "func",
                intermediate_iframe_close_callback: "func",
                auto_prompt: "bool",
                allowed_parent_origin: "str",
                library_name: "str",
                native_login_uri: "str",
                native_id_param: "str",
                native_password_param: "str",
                skip_prompt_cookie: "str"
            },
            Xt = Object.keys(Wt),
            $t = {
                parent_id: "str",
                size: "str",
                theme: "str",
                text: "str",
                shape: "str",
                width: "num",
                min_width: "num",
                logo_alignment: "str",
                type: "str",
                locale: "str",
                nonce: "str",
                state: "str",
                click_listener: "func"
            };
        var cu = function(a) {
            a = (0, _.oa)({}, window.__G_ID_OPTIONS__, a);
            _.ew.call(this, a);
            this.X = a && a.native_callback;
            _.I("enable_intermediate_iframe") && (this.i = a && a.allowed_parent_origin);
            this.Ic = !1;
            this.T = !!this.i;
            this.oc = a && a.intermediate_iframe_close_callback;
            if (this.i && this.i)
                if (typeof this.i === "string") {
                    if (!jt(this.i)) throw Error("Xa");
                } else if (Array.isArray(this.i))
                for (a = 0; a < this.i.length; a++)
                    if (typeof this.i[a] !== "string" || !jt(this.i[a])) throw Error("Ya");
        };
        _.J(cu, _.ew);
        cu.prototype.Mc = function(a) {
            this.X = a.native_callback
        };
        cu.prototype.l = function(a) {
            _.E("Prompt will not be displayed");
            this.X && Ew(this);
            _.ew.prototype.l.call(this, a)
        };
        var Ew = function(a) {
            a.Ic || (a.Ic = !0, "credentials" in navigator && navigator.credentials.get({
                password: !0,
                mediation: "required"
            }).then(function(b) {
                a.X && a.X(b)
            }))
        };
        cu.prototype.Z = function(a, b, c) {
            var d = this;
            this.T && this.i ? (_.E("Verifying parent origin."), _.ns(this.i, function() {
                _.es ? _.fs({
                    command: "set_ui_mode",
                    mode: d.uiMode
                }) : _.G("Set ui mode command was not sent due to missing verified parent origin.");
                _.xs(!1);
                d.Rc = !1;
                _.ew.prototype.Z.call(d, a, b, c)
            })) : _.ew.prototype.Z.call(this, a, b, c)
        };
        cu.prototype.Pa = function(a) {
            _.ew.prototype.Pa.call(this, a);
            if (this.T && a.data && a.data.type) switch (a.data.type) {
                case "response":
                    a.data.response && a.data.response.credential && (this.Rc = !0, _.vs(0));
                    break;
                case "command":
                    switch (a.data.command) {
                        case "close":
                            this.Rc ? _.vs(0) : this.oc ? (_.vs(0), this.oc()) : _.ws();
                            break;
                        case "resize":
                            a = a.data.height;
                            typeof a === "number" && !isNaN(a) && a > 0 && _.vs(a);
                            break;
                        case "cancel_protect_start":
                            _.xs(!1);
                            break;
                        case "cancel_protect_end":
                            _.xs(this.lb)
                    }
            }
        };
        cu.prototype.Tc = function(a) {
            this.F = Bt(this.container, a, this.uiMode === "bottom_sheet", this.T)
        };
        cu.prototype.Lc = function(a) {
            if (this.T) switch (_.ts) {
                case "intermediate_client":
                    a.flow_type = 1;
                    break;
                case "amp_client":
                    a.flow_type = 2
            }
        };
        var bu = window;
        (function(a) {
            a = a === void 0 ? document.readyState : a;
            a !== "loading" ? (mu(), ou()) : _.If(document, "DOMContentLoaded", function() {
                mu();
                ou()
            }, !1)
        })();
        _.M("google.accounts.id.cancel", function() {
            var a = bu.__G_ID_CLIENT__;
            a && hw(a, !0) && (ow(a, "cancel_called"), Ot() && Zs("flowCancelled"))
        });
        _.M("google.accounts.id.disableAutoSelect", lu);
        _.M("google.accounts.id.initialize", gu);
        _.M("google.accounts.id.prompt", hu);
        _.M("google.accounts.id.PromptMomentNotification", tv);
        _.M("google.accounts.id.renderButton", ju);
        _.M("google.accounts.id.revoke", function(a, b) {
            var c = bu.__G_ID_CLIENT__;
            c ? Dw(c, a, b) : _.H("Attempt to call revoke() before initialize().")
        });
        _.M("google.accounts.id.storeCredential", function(a, b) {
            "credentials" in navigator ? navigator.credentials.store(a).then(function() {
                b && b()
            }).catch(function(c) {
                _.H("Store credential failed: " + JSON.stringify(c))
            }) : b && b()
        });
        _.M("google.accounts.id.setLogLevel", function(a) {
            var b = bu.__G_ID_CLIENT__;
            b || (gu(), b = bu.__G_ID_CLIENT__);
            a = a ? a.toLowerCase() : void 0;
            a === void 0 || (0, _.Qa)(Hu, a) >= 0 ? fw(b, a, !0) : (_.H("Log level is invalid. Supported log levels are: info, warn, error. Log level set to warn by default"), fw(b, void 0, !0))
        });
        var Fw = function(a) {
            _.fg.call(this, "code", a);
            this.callback = a.callback;
            this.W = _.wd(a);
            _.F("Instantiated.", "CODE_CLIENT")
        };
        _.J(Fw, _.fg);
        Fw.prototype.j = function(a) {
            _.F("Handling response. " + JSON.stringify(a), "CODE_CLIENT");
            _.fg.prototype.j.call(this, a);
            this.callback && this.callback.call(this, a)
        };
        Fw.prototype.requestCode = function() {
            var a = this.h;
            this.W === "redirect" ? (_.F("Starting redirect flow.", "CODE_CLIENT"), a = tt(this.u, this.v, a), _.Pc(window.location, a)) : (_.F("Starting popup flow.", "CODE_CLIENT"), _.hg(this), _.ig(this, a), _.I("enable_transform_flow_for_authz") && yu(this, a), _.I("enable_large_popup_height") ? (a.gislp = "1", a.upstream_experiment_id = "117788636") : _.I("enable_large_popup_height_control") && (a.gislp = "0", a.upstream_experiment_id = "117788635"), this.i = _.vd(tt(this.u, this.v, a), "g_auth_code_window",
                _.td()), !this.i && this.error_callback ? this.error_callback(new _.xd("Failed to open popup window", "popup_failed_to_open")) : _.jg(this))
        };
        var Gw = function(a, b) {
            var c = this;
            this.origin = a;
            this.j = b;
            this.ta = new Map;
            this.h = new Map;
            this.i = function(d) {
                if (d.origin === c.origin) {
                    if (c.j) {
                        var e = c.j();
                        if (!e || d.source !== e) return
                    }
                    var f = d.data;
                    if (f && f.id && f.type) {
                        d = f.id;
                        e = f.type;
                        f = f.data;
                        _.E("Handling message [type: " + e + ", id: " + d + "]", "MESSAGE_DISPATCHER");
                        var g = !1,
                            h = c.h.get(e);
                        if (h && h.length > 0) {
                            g = !0;
                            h = _.v(h);
                            var k = h.next();
                            try {
                                for (; !k.done; k = h.next()) {
                                    var l = k.value;
                                    try {
                                        l(f, d)
                                    } catch (n) {
                                        _.E("Error executing listener for " + e + ": " + n, "MESSAGE_DISPATCHER")
                                    }
                                }
                            } finally {
                                _.yd(h,
                                    k)
                            }
                        } else if (l = c.ta.get(d)) {
                            g = !0;
                            c.ta.delete(d);
                            try {
                                l(f)
                            } catch (n) {
                                _.E("Error executing callback for request " + d + ": " + n, "MESSAGE_DISPATCHER")
                            }
                        }
                        g || _.E("No listener or callback registered for [type: " + e + ", id: " + d + "]", "MESSAGE_DISPATCHER")
                    } else _.E("Ignored message due to missing id or type", "MESSAGE_DISPATCHER")
                }
            };
            this.O()
        };
        Gw.prototype.O = function() {
            window.addEventListener("message", this.i)
        };
        Gw.prototype.dispose = function() {
            window.removeEventListener("message", this.i);
            this.ta.clear();
            this.h.clear()
        };
        var Hw = function(a, b) {
            var c = a.h.get("onTokenRefresh");
            c || (c = [], a.h.set("onTokenRefresh", c));
            c.push(b)
        };
        Gw.prototype.send = function(a, b, c, d, e) {
            e || (e = new Uint32Array(2), window.crypto.getRandomValues(e), e = e[0].toString(36) + e[1].toString(36));
            this.ta.set(e, d);
            c.postMessage({
                id: e,
                type: a,
                data: b
            }, this.origin);
            return e
        };
        var su = new Map,
            tu = function(a, b) {
                var c = this;
                b = b === void 0 ? vu() : b;
                this.h = this.Ca = this.m = !1;
                this.i = [];
                this.u = new Map;
                this.j = new Map;
                a = ru(a, b);
                this.v = a.toString();
                this.l = new Gw(a.origin, function() {
                    var d;
                    return (d = c.N) == null ? void 0 : d.contentWindow
                });
                Hw(this.l, function(d, e) {
                    e = e ? c.j.get(e) : void 0;
                    if (e !== void 0 && (e = c.u.get(e))) {
                        var f = d == null ? void 0 : d.tokenResponse;
                        if ((d == null ? void 0 : d.error) == null && f != null && pu(f)) e(f);
                        else {
                            var g, h;
                            _.G("Background token refresh failed: " + ((h = (g = qu(d == null ? void 0 : d.error)) !=
                                null ? g : qu(f == null ? void 0 : f.error)) != null ? h : "invalid token response"), "MESSAGE_CLIENT")
                        }
                    }
                })
            };
        tu.prototype.init = function() {
            var a = this;
            this.h && this.N && document.body ? (this.h = !1, document.body.appendChild(this.N)) : (this.N && this.N.parentNode && this.N.parentNode.removeChild(this.N), this.h = this.Ca = this.m = !1, this.i.length = 0, this.l.O(), this.N = document.createElement("iframe"), this.N.id = "gsi_idp_iframe", this.N.style.display = "none", Js(this.N, this.v), this.N.onload = function() {
                a.m = !0;
                _.E("Processing " + a.i.length + " queued request(s)", "MESSAGE_CLIENT");
                var b = _.v(a.i),
                    c = b.next();
                try {
                    for (; !c.done; c = b.next()) {
                        var d =
                            c.value;
                        d()
                    }
                } finally {
                    _.yd(b, c)
                }
                a.i.length = 0
            }, document.body ? document.body.appendChild(this.N) : (this.h = !0, window.addEventListener("DOMContentLoaded", function() {
                a.h = !1;
                if (!a.Ca && a.N && !a.N.isConnected) {
                    var b;
                    (b = document.body) == null || b.appendChild(a.N)
                }
            }, {
                once: !0
            })))
        };
        var Iw = function(a, b, c) {
            a.u.set(b, c)
        };
        tu.prototype.dispose = function() {
            this.Ca = !0;
            this.h = !1;
            this.l.dispose();
            this.i.length = 0;
            this.u.clear();
            this.j.clear();
            this.N && this.N.parentNode && this.N.parentNode.removeChild(this.N);
            this.N = void 0;
            this.m = !1;
            su.get(this.v) === this && su.delete(this.v)
        };
        var Kw = function(a, b, c) {
                Jw(a, "monitorClient", b, c)
            },
            Lw = function(a, b, c) {
                Jw(a, "getToken", b, c)
            },
            Mw = function(a, b) {
                Jw(a, "setSession", b, function() {})
            },
            Jw = function(a, b, c, d) {
                if (a.Ca) _.H("Cannot send request: IDP iframe or contentWindow is unavailable.", "MESSAGE_CLIENT");
                else if (a.m)
                    if (a.N && a.N.contentWindow) {
                        _.E("Sending request [type: " + b + "] to IDP iframe", "MESSAGE_CLIENT");
                        var e = a.l.send(b, c, a.N.contentWindow, d);
                        (b === "getToken" || b === "setSession") && "enableTokenRefresh" in c && c.enableTokenRefresh && e && Nw(a, e,
                            c.clientId)
                    } else _.H("Cannot send request: IDP iframe or contentWindow is unavailable.", "MESSAGE_CLIENT");
                else _.E("IDP iframe not ready. Queueing request [type: " + b + "]", "MESSAGE_CLIENT"), a.i.push(function() {
                    Jw(a, b, c, d)
                })
            },
            Nw = function(a, b, c) {
                var d = _.v(a.j),
                    e = d.next();
                try {
                    for (; !e.done; e = d.next()) {
                        var f = _.v(e.value),
                            g = f.next().value,
                            h = f.next().value,
                            k = g;
                        h === c && a.j.delete(k)
                    }
                } finally {
                    _.yd(d, e)
                }
                a.j.set(b, c)
            };
        var Ow = new Set(["https://accounts.google.com", "https://accounts.sandbox.google.com"]),
            Pw = window,
            Rw = function(a) {
                _.fg.call(this, "token", a);
                this.D = [];
                this.callback = a.callback;
                this.enableTokenRefresh = !!a.enable_token_refresh && _.I("enable_authz_token_refresh");
                if (a.session_root_domain) {
                    var b = a.session_root_domain,
                        c = window.location.hostname;
                    if (b !== c && (!c.endsWith("." + b) || b.split(".").length < 2)) throw Error("Za");
                    this.ssDomain = "https://" + a.session_root_domain
                }
                this.enableTokenRefresh && Qw(this);
                _.F("Instantiated.",
                    "TOKEN_CLIENT")
            };
        _.J(Rw, _.fg);
        var Qw = function(a) {
                if (!a.l && (a.l = uu(Sw(a)), a.l && a.h.client_id)) {
                    var b = a.l;
                    a.enableTokenRefresh ? Iw(b, a.h.client_id, function(d) {
                        if (pu(d)) _.F("Background token refresh received.", "TOKEN_CLIENT"), a.j(d, !0);
                        else {
                            var e;
                            _.G("Background token refresh failed: " + ((e = qu(d == null ? void 0 : d.error)) != null ? e : "invalid token response"), "TOKEN_CLIENT")
                        }
                    }) : b.u.delete(a.h.client_id);
                    var c = window.setTimeout(function() {
                        a.A === void 0 && (_.G("IDP Iframe monitoring timed out.", "TOKEN_CLIENT"), a.A = !1, Tw(a))
                    }, 5E3);
                    Kw(b, {
                            clientId: a.h.client_id
                        },
                        function(d) {
                            clearTimeout(c);
                            _.E("monitorClient response: " + JSON.stringify(d), "TOKEN_CLIENT");
                            a.A = !!d.valid;
                            d.valid ? a.F && Mw(b, a.F) : _.G("Invalid client.", "TOKEN_CLIENT");
                            a.F = void 0;
                            Tw(a)
                        })
                }
            },
            Tw = function(a) {
                for (; a.D.length > 0;) {
                    var b = a.D.shift();
                    try {
                        var c = void 0;
                        (c = b) == null || c()
                    } catch (d) {
                        _.H("Error executing delayed task: " + (d instanceof Error ? d.message : String(d)), "TOKEN_CLIENT")
                    }
                }
            },
            Sw = function(a) {
                try {
                    var b = new URL(a.v);
                    if (Ow.has(b.origin) || (b.protocol === "https:" || b.protocol === "http:") && b.hostname.endsWith(".corp.google.com")) return vu(b.origin);
                    _.G("Untrusted IDP iframe origin: " + b.origin, "TOKEN_CLIENT")
                } catch (c) {
                    _.G("Failed to resolve the IDP iframe origin.", "TOKEN_CLIENT")
                }
                return vu()
            };
        Rw.prototype.j = function(a, b) {
            b = b === void 0 ? !1 : b;
            _.F("Handling response. " + JSON.stringify(a), "TOKEN_CLIENT");
            b || _.fg.prototype.j.call(this, a);
            _.F("Trying to set gapi client token.", "TOKEN_CLIENT");
            if (a.access_token)
                if (Pw.gapi && Pw.gapi.client && Pw.gapi.client.setToken) try {
                    Pw.gapi.client.setToken.call(this, a)
                } catch (c) {
                    _.H("Set token failed. Exception encountered.", "TOKEN_CLIENT"), console.error(c)
                } else _.F("The OAuth token was not passed to gapi.client, since the gapi.client library is not loaded in your page.",
                    "TOKEN_CLIENT");
                else _.G("Set token failed. No access token in response.", "TOKEN_CLIENT");
            !b && _.I("enable_authz_token_refresh") && this.h.client_id && a.access_token && (b = (0, _.oa)({}, {
                clientId: this.h.client_id,
                loginHint: a.login_hint
            }, this.ssDomain ? {
                ssDomain: this.ssDomain
            } : {}, this.enableTokenRefresh ? {
                scope: a.scope,
                expiresIn: a.expires_in,
                enableTokenRefresh: !0
            } : {}), this.l && this.A ? Mw(this.l, b) : this.A === void 0 && (this.F = b));
            this.callback && this.callback.call(this, a)
        };
        Rw.prototype.loadExistingAccessToken = function(a) {
            var b = this;
            a = ut(this.h, a);
            var c = _.zd(this.u, a);
            _.I("enable_authz_token_refresh") ? (Qw(this), this.l ? this.A === void 0 ? this.D.length >= 10 ? Uw(this, "IDP Iframe not ready", "idp_iframe_not_initialized") : this.D.push(function() {
                Vw(b, c)
            }) : Vw(this, c) : Uw(this, "IDP Iframe failed to initialize", "idp_iframe_not_initialized")) : Uw(this, "IDP Iframe failed to initialize", "idp_iframe_not_initialized")
        };
        var Vw = function(a, b) {
                a.l && a.A ? (b = (0, _.oa)({}, {
                    clientId: b.client_id || "",
                    scope: b.scope || "",
                    loginHint: b.login_hint || "",
                    state: b.state || "",
                    hostedDomain: b.hosted_domain || "",
                    enableTokenRefresh: !!a.enableTokenRefresh
                }, a.ssDomain ? {
                    ssDomain: a.ssDomain
                } : {}), Lw(a.l, b, function(c) {
                    var d = c == null ? void 0 : c.tokenResponse;
                    if ((c == null ? void 0 : c.error) == null && d != null && pu(d)) a.j(d, !0);
                    else if (d != null && d.error != null) switch (c = d.error, c) {
                        case "USER_LOGGED_OUT":
                            Uw(a, "User logged out", "user_logged_out");
                            break;
                        case "IMMEDIATE_FAILED":
                            Uw(a,
                                "Request could not be auto-approved", "immediate_failed");
                            break;
                        default:
                            Uw(a, c || "unknown_error", "unknown")
                    } else if ((c == null ? void 0 : c.error) != null) switch (c.error) {
                        case "invalid_request":
                            Uw(a, "Invalid request", "bad_request");
                            break;
                        case "account_selection_required":
                        case "not_approved":
                            Uw(a, "No single approved session", "no_user_bound");
                            break;
                        case "issue_token_failed":
                            Uw(a, "Request could not be auto-approved", "immediate_failed");
                            break;
                        default:
                            Uw(a, c.error || "unknown_error", "unknown")
                    } else Uw(a, (c == null ?
                        void 0 : c.error) || "unknown_error", "unknown")
                })) : Uw(a, "IDP Iframe failed to initialize", "idp_iframe_not_initialized")
            },
            Uw = function(a, b, c) {
                c = c === void 0 ? "unknown" : c;
                _.H("Error: " + b, "TOKEN_CLIENT");
                a.error_callback && a.error_callback(new _.xd(b, c))
            };
        Rw.prototype.requestAccessToken = function(a) {
            a = ut(this.h, a);
            a = _.zd(this.u, a);
            _.F("Starting popup flow.", "TOKEN_CLIENT");
            _.hg(this);
            _.ig(this, a);
            _.I("enable_transform_flow_for_authz") && yu(this, a);
            if (this.ssDomain || a.origin) a.ss_domain = this.ssDomain || a.origin;
            _.I("enable_large_popup_height") ? (a.gislp = "1", a.upstream_experiment_id = "117788636") : _.I("enable_large_popup_height_control") && (a.gislp = "0", a.upstream_experiment_id = "117788635");
            this.i = _.vd(tt(this.u, this.v, a), "g_auth_token_window", _.td());
            !this.i &&
                this.error_callback ? this.error_callback(new _.xd("Failed to open popup window", "popup_failed_to_open")) : _.jg(this)
        };
        _.M("google.accounts.oauth2.GoogleIdentityServicesError", _.xd);
        _.M("google.accounts.oauth2.GoogleIdentityServicesErrorType", {
            Ie: "unknown",
            Ce: "missing_required_parameter",
            Fe: "popup_failed_to_open",
            Ee: "popup_closed",
            Ke: "user_logged_out",
            Be: "immediate_failed",
            Ae: "idp_iframe_not_initialized",
            te: "bad_request",
            De: "no_user_bound"
        });
        _.M("google.accounts.oauth2.initCodeClient", function(a) {
            return new Fw(a)
        });
        _.M("google.accounts.oauth2.CodeClient", Fw);
        _.M("google.accounts.oauth2.initTokenClient", function(a) {
            return new Rw(a)
        });
        _.M("google.accounts.oauth2.TokenClient", Rw);
        _.M("google.accounts.oauth2.hasGrantedAllScopes", function(a) {
            var b = Xs.apply(1, arguments),
                c = xu(a);
            return c && c.length ? (b = wu.apply(null, _.Fd(b))) && b.length ? (0, _.Zd)(b, function(d) {
                return (0, _.Qa)(c, d) >= 0
            }) : !1 : !1
        });
        _.M("google.accounts.oauth2.hasGrantedAnyScope", function(a) {
            var b = Xs.apply(1, arguments),
                c = xu(a);
            return c && c.length ? (b = wu.apply(null, _.Fd(b))) && b.length ? (0, _.Yd)(b, function(d) {
                return (0, _.Qa)(c, d) >= 0
            }) : !1 : !1
        });
        _.M("google.accounts.oauth2.revoke", function(a, b) {
            _.E("Revoke request initiated");
            a = {
                token: a
            };
            _.E("Making revoke request without credentials.");
            dt("https://oauth2.googleapis.com/revoke", a, !1, function(c) {
                b && (_.F("callback with response: " + c), c = c ? JSON.parse(c) : {}, c.successful = !c.error, b(c))
            })
        });
    } catch (e) {
        _._DumpException(e)
    }
}).call(this, this.default_gsi);
// Google Inc.

(() => {
    const head = document.head;
    const css = ".qJTHM\x7b-moz-user-select:none;-webkit-user-select:none;-ms-user-select:none;color:#202124;direction:ltr;-webkit-touch-callout:none;font-family:Roboto-Regular,arial,sans-serif;-webkit-font-smoothing:antialiased;font-weight:400;margin:0;overflow:hidden;-webkit-text-size-adjust:100%\x7d.ynRLnc\x7bleft:-9999px;position:absolute;top:-9999px\x7d.L6cTce\x7bdisplay:none\x7d.bltWBb\x7boverflow-wrap:break-word;word-break:break-word\x7d.hSRGPd\x7bcolor:#1a73e8;cursor:pointer;font-weight:500;text-decoration:none\x7d.Bz112c-W3lGp\x7bheight:16px;width:16px\x7d.Bz112c-E3DyYd\x7bheight:20px;width:20px\x7d.Bz112c-r9oPif\x7bheight:24px;width:24px\x7d.Bz112c-u2z5K\x7bheight:36px;width:36px\x7d.Bz112c-uaxL4e\x7bborder-radius:10px\x7d.LgbsSe-Bz112c\x7bdisplay:block\x7d.S9gUrf-YoZ4jf\x7bborder:none;margin:0;padding:0\x7d.S9gUrf-YoZ4jf *\x7bborder:none;margin:0;padding:0\x7d.fFW7wc-ibnC6b\x3e.aZ2wEe\x3ediv\x7bborder-color:#4285f4\x7d.P1ekSe-ZMv3u\x7btransition:height .2s linear\x7d.P1ekSe-ZMv3u\x3ediv:first-child\x7bbackground-color:#1a73e8!important;transition:width .3s linear\x7d.P1ekSe-ZMv3u\x3ediv:nth-child(2)\x7bbackground-image:linear-gradient(90deg,rgba(255,255,255,.7),rgba(255,255,255,.7)),linear-gradient(90deg,#1a73e8,#1a73e8)!important\x7d.P1ekSe-ZMv3u\x3ediv:nth-child(3)\x7bbackground-image:linear-gradient(90deg,rgba(255,255,255,.7),rgba(255,255,255,.7)),linear-gradient(90deg,#1a73e8,#1a73e8)!important\x7d.haAclf\x7bdisplay:inline-block\x7d.nsm7Bb-HzV7m-LgbsSe\x7bborder-radius:4px;box-sizing:border-box;transition:background-color .218s,border-color .218s;-moz-user-select:none;-webkit-user-select:none;-ms-user-select:none;-webkit-appearance:none;background-color:#fff;background-image:none;border:1px solid #dadce0;color:#3c4043;cursor:pointer;font-family:Google Sans,arial,sans-serif;font-size:.875rem;height:40px;letter-spacing:.25px;outline:none;overflow:hidden;padding:0 12px;position:relative;text-align:center;vertical-align:middle;white-space:nowrap;width:auto\x7d.nsm7Bb-HzV7m-LgbsSe.TzA9Ye-LgbsSe\x7bfont-size:14px\x7d@media screen and (-ms-high-contrast:active)\x7b.nsm7Bb-HzV7m-LgbsSe\x7bborder:2px solid windowText;color:windowText\x7d\x7d@media screen and (preferes-contrast:more)\x7b.nsm7Bb-HzV7m-LgbsSe\x7bcolor:#000\x7d\x7d.nsm7Bb-HzV7m-LgbsSe.pSzOP-SxQuSe\x7bfont-size:.875rem;height:32px;letter-spacing:.25px;padding:0 10px\x7d.nsm7Bb-HzV7m-LgbsSe.pSzOP-SxQuSe.TzA9Ye-LgbsSe\x7bfont-size:14px\x7d.nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe\x7bfont-size:.6875rem;height:20px;letter-spacing:.3px;padding:0 8px\x7d.nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe.TzA9Ye-LgbsSe\x7bfont-size:11px\x7d.nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe\x7bpadding:0;width:40px\x7d.nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe.pSzOP-SxQuSe\x7bwidth:32px\x7d.nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe.purZT-SxQuSe\x7bwidth:20px\x7d.nsm7Bb-HzV7m-LgbsSe.JGcpL-RbRzK\x7bborder-radius:20px\x7d.nsm7Bb-HzV7m-LgbsSe.JGcpL-RbRzK.pSzOP-SxQuSe\x7bborder-radius:16px\x7d.nsm7Bb-HzV7m-LgbsSe.JGcpL-RbRzK.purZT-SxQuSe\x7bborder-radius:10px\x7d.nsm7Bb-HzV7m-LgbsSe.i5vt6e-to915-Ia7Qfc\x7bborder:1px solid #8e918f;background-color:#131314;color:#e3e3e3\x7d.nsm7Bb-HzV7m-LgbsSe.MFS4be-Ia7Qfc\x7bborder:none;color:#fff\x7d.nsm7Bb-HzV7m-LgbsSe.MFS4be-v3pZbf-Ia7Qfc\x7bbackground-color:#1a73e8\x7d.nsm7Bb-HzV7m-LgbsSe.MFS4be-JaPV2b-Ia7Qfc\x7bbackground-color:#202124;color:#e8eaed\x7d@media screen and (prefers-contrast:more)\x7b.nsm7Bb-HzV7m-LgbsSe.MFS4be-JaPV2b-Ia7Qfc\x7bcolor:#fff\x7d\x7d.nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c\x7bheight:18px;margin-right:8px;min-width:18px;width:18px\x7d.nsm7Bb-HzV7m-LgbsSe.pSzOP-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c\x7bheight:14px;min-width:14px;width:14px\x7d.nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c\x7bheight:10px;min-width:10px;width:10px\x7d.nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-Bz112c\x7bmargin-left:8px;margin-right:-4px\x7d.nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c\x7bmargin:0;padding:10px\x7d.nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe.pSzOP-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c\x7bpadding:8px\x7d.nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe.purZT-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c\x7bpadding:4px\x7d.nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf\x7bborder-top-left-radius:3px;border-bottom-left-radius:3px;display:flex;justify-content:center;align-items:center;background-color:#fff;height:36px;margin-left:-10px;margin-right:12px;min-width:36px;width:36px\x7d.nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf .nsm7Bb-HzV7m-LgbsSe-Bz112c,.nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf .nsm7Bb-HzV7m-LgbsSe-Bz112c\x7bmargin:0;padding:0\x7d.nsm7Bb-HzV7m-LgbsSe.pSzOP-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf\x7bheight:28px;margin-left:-8px;margin-right:10px;min-width:28px;width:28px\x7d.nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf\x7bheight:16px;margin-left:-6px;margin-right:8px;min-width:16px;width:16px\x7d.nsm7Bb-HzV7m-LgbsSe.Bz112c-LgbsSe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf\x7bborder-radius:3px;margin-left:2px;margin-right:0;padding:0\x7d.nsm7Bb-HzV7m-LgbsSe.JGcpL-RbRzK .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf\x7bborder-radius:18px\x7d.nsm7Bb-HzV7m-LgbsSe.pSzOP-SxQuSe.JGcpL-RbRzK .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf\x7bborder-radius:14px\x7d.nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe.JGcpL-RbRzK .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf\x7bborder-radius:8px\x7d.nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-bN97Pc-sM5MNb\x7bdisplay:flex;align-items:center;flex-direction:row;justify-content:space-between;flex-wrap:nowrap;height:100%;position:relative;width:100%\x7d.nsm7Bb-HzV7m-LgbsSe .oXtfBe-l4eHX\x7bjustify-content:center\x7d.nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-BPrWId\x7bflex-grow:1;font-family:Google Sans,arial,sans-serif;font-weight:500;overflow:hidden;text-overflow:ellipsis;vertical-align:top\x7d.nsm7Bb-HzV7m-LgbsSe.purZT-SxQuSe .nsm7Bb-HzV7m-LgbsSe-BPrWId\x7bfont-weight:300\x7d.nsm7Bb-HzV7m-LgbsSe .oXtfBe-l4eHX .nsm7Bb-HzV7m-LgbsSe-BPrWId\x7bflex-grow:0\x7d.nsm7Bb-HzV7m-LgbsSe .nsm7Bb-HzV7m-LgbsSe-MJoBVe\x7btransition:background-color .218s;bottom:0;left:0;position:absolute;right:0;top:0\x7d.nsm7Bb-HzV7m-LgbsSe:focus,.nsm7Bb-HzV7m-LgbsSe:hover\x7bbox-shadow:none;border-color:rgb(210,227,252);outline:none\x7d.nsm7Bb-HzV7m-LgbsSe:focus-within\x7boutline:2px solid #00639b;border-color:transparent\x7d.nsm7Bb-HzV7m-LgbsSe:hover .nsm7Bb-HzV7m-LgbsSe-MJoBVe\x7bbackground:rgba(66,133,244,.08)\x7d.nsm7Bb-HzV7m-LgbsSe:active .nsm7Bb-HzV7m-LgbsSe-MJoBVe,.nsm7Bb-HzV7m-LgbsSe:focus .nsm7Bb-HzV7m-LgbsSe-MJoBVe\x7bbackground:rgba(66,133,244,.1)\x7d.nsm7Bb-HzV7m-LgbsSe.i5vt6e-to915-Ia7Qfc:hover .nsm7Bb-HzV7m-LgbsSe-MJoBVe\x7bbackground:rgba(255,255,255,.08)\x7d.nsm7Bb-HzV7m-LgbsSe.i5vt6e-to915-Ia7Qfc:active .nsm7Bb-HzV7m-LgbsSe-MJoBVe,.nsm7Bb-HzV7m-LgbsSe.i5vt6e-to915-Ia7Qfc:focus .nsm7Bb-HzV7m-LgbsSe-MJoBVe\x7bbackground:rgba(255,255,255,.12)\x7d.nsm7Bb-HzV7m-LgbsSe.MFS4be-Ia7Qfc:hover .nsm7Bb-HzV7m-LgbsSe-MJoBVe\x7bbackground:rgba(255,255,255,.24)\x7d.nsm7Bb-HzV7m-LgbsSe.MFS4be-Ia7Qfc:active .nsm7Bb-HzV7m-LgbsSe-MJoBVe,.nsm7Bb-HzV7m-LgbsSe.MFS4be-Ia7Qfc:focus .nsm7Bb-HzV7m-LgbsSe-MJoBVe\x7bbackground:rgba(255,255,255,.32)\x7d.nsm7Bb-HzV7m-LgbsSe .n1UuX-DkfjY\x7bborder-radius:50%;display:flex;height:20px;margin-left:-4px;margin-right:8px;min-width:20px;width:20px\x7d.nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId\x7bfont-family:Roboto;font-size:12px;text-align:left\x7d.nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff .fmcmS,.nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId .ssJRIf\x7boverflow:hidden;text-overflow:ellipsis\x7d.nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff\x7bdisplay:flex;align-items:center;color:#5f6368;fill:#5f6368;font-size:11px;font-weight:400\x7d.nsm7Bb-HzV7m-LgbsSe.jVeSEe.i5vt6e-to915-Ia7Qfc .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff\x7bcolor:#c4c7c5;fill:#c4c7c5\x7d.nsm7Bb-HzV7m-LgbsSe.jVeSEe.MFS4be-Ia7Qfc .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff\x7bcolor:#e8eaed;fill:#e8eaed\x7d@media screen and (prefers-contrast:more)\x7b.nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff,.nsm7Bb-HzV7m-LgbsSe.jVeSEe.MFS4be-Ia7Qfc .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff\x7bcolor:#000;fill:#000\x7d\x7d.nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-BPrWId .K4efff .Bz112c\x7bheight:18px;margin:-3px -3px -3px 2px;min-width:18px;width:18px\x7d.nsm7Bb-HzV7m-LgbsSe.jVeSEe .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf\x7bborder-top-left-radius:0;border-bottom-left-radius:0;border-top-right-radius:3px;border-bottom-right-radius:3px;margin-left:12px;margin-right:-10px\x7d.nsm7Bb-HzV7m-LgbsSe.jVeSEe.JGcpL-RbRzK .nsm7Bb-HzV7m-LgbsSe-Bz112c-haAclf\x7bborder-radius:18px\x7d.L5Fo6c-sM5MNb\x7bborder:0;display:block;left:0;position:relative;top:0\x7d.L5Fo6c-bF1uUb\x7bborder-radius:4px;bottom:0;cursor:pointer;left:0;position:absolute;right:0;top:0\x7d.L5Fo6c-bF1uUb:focus\x7bborder:none;outline:none\x7dsentinel\x7b\x7d";
    const styleId = 'googleidentityservice_button_styles';
    if (head && css && !document.getElementById(styleId)) {
        const style = document.createElement('style');
        style.id = styleId;
        style.appendChild(document.createTextNode(css));
        if (document.currentScript.nonce) style.setAttribute('nonce', document.currentScript.nonce);
        head.appendChild(style);
    }
})();
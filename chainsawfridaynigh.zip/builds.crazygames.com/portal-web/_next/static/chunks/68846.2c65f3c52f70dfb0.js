! function() {
    try {
        var e = "u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof globalThis ? globalThis : "u" > typeof self ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[(new e.Error).stack] = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var a = arguments[t];
                if (null != a)
                    for (var n in a) a.hasOwnProperty(n) && (e[n] = a[n])
            }
            return e
        }({}, e._sentryModuleMetadata[(new e.Error).stack], {
            "_sentryBundlerPluginAppKey:crazygames-portal": !0
        });
        var t = (new e.Error).stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = "9827830b-a068-4e8b-98bf-bb60ed4e691a", e._sentryDebugIdIdentifier = "sentry-dbid-9827830b-a068-4e8b-98bf-bb60ed4e691a")
    } catch (e) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [68846], {
        68846: (e, t, a) => {
            "use strict";
            a.r(t), a.d(t, {
                default: () => u
            });
            var n, o, r = a(6029),
                i = a(75155),
                l = a(55729),
                s = {
                    default: 120,
                    mqdefault: 320,
                    hqdefault: 480,
                    sddefault: 640,
                    maxresdefault: 1280
                };
            (n = {})[n.UNSTARTED = -1] = "UNSTARTED", n[n.ENDED = 0] = "ENDED", n[n.PLAYING = 1] = "PLAYING", n[n.PAUSED = 2] = "PAUSED", n[n.BUFFERING = 3] = "BUFFERING", n[n.CUED = 5] = "CUED", (o = {})[o.INVALID_PARAM = 2] = "INVALID_PARAM", o[o.HTML5_ERROR = 5] = "HTML5_ERROR", o[o.VIDEO_NOT_FOUND = 100] = "VIDEO_NOT_FOUND", o[o.NOT_EMBEDDABLE = 101] = "NOT_EMBEDDABLE", o[o.NOT_EMBEDDABLE_DISGUISED = 150] = "NOT_EMBEDDABLE_DISGUISED";
            var c = l.forwardRef(function(e, t) {
                    var a, n;
                    let [o, i] = l.useState(!1), [c, d] = l.useState(e.alwaysLoadIframe || e.autoplay || !1), u = encodeURIComponent(e.id), p = "string" == typeof e.playlistCoverId ? encodeURIComponent(e.playlistCoverId) : null, y = e.title, b = e.poster || "hqdefault", f = e.announce || "Watch", h = !e.alwaysLoadIframe && !e.autoplay || e.autoplay && e.muted, m = l.useMemo(() => {
                        let t = new URLSearchParams({ ...e.muted ? {
                                mute: "1"
                            } : {},
                            ...h ? {
                                autoplay: "1"
                            } : {},
                            ...e.enableJsApi ? {
                                enablejsapi: "1"
                            } : {},
                            ...e.enableJsApi && "u" > typeof window ? {
                                origin: window.location.origin
                            } : {},
                            ...e.playlist ? {
                                list: u
                            } : {}
                        });
                        return e.params && ("string" == typeof e.params ? new URLSearchParams(e.params.startsWith("&") ? e.params.slice(1) : e.params).forEach((e, a) => {
                            t.append(a, e)
                        }) : Object.entries(e.params).forEach(([e, a]) => {
                            t.append(e, String(a))
                        })), t
                    }, [e.muted, h, e.enableJsApi, e.playlist, u, e.params]), g = l.useMemo(() => e.cookie ? "https://www.youtube.com" : "https://www.youtube-nocookie.com", [e.cookie]), w = l.useMemo(() => e.playlist ? `${g}/embed/videoseries?${m.toString()}` : `${g}/embed/${u}?${m.toString()}`, [e.playlist, g, u, m]), E = !e.thumbnail && !e.playlist && "maxresdefault" === b, k = e.webp ? "webp" : "jpg", v = e.webp ? "vi_webp" : "vi", D = E ? ((e, t, a, n = "maxresdefault") => {
                        let [o, r] = (0, l.useState)("");
                        return (0, l.useEffect)(() => {
                            let o = `https://img.youtube.com/${t}/${e}/${n}.${a}`,
                                i = `https://img.youtube.com/${t}/${e}/hqdefault.${a}`,
                                l = s[n],
                                c = new Image;
                            c.onload = () => {
                                c.width < l ? r(i) : r(o)
                            }, c.onerror = () => r(i), c.src = o
                        }, [e, t, a, n]), o
                    })(e.id, v, k, b) : null, C = l.useMemo(() => e.thumbnail || D || `https://i.ytimg.com/${v}/${e.playlist?p:u}/${b}.${k}`, [e.thumbnail, D, v, e.playlist, p, u, b, k]), N = e.activatedClass || "lyt-activated", j = e.adNetwork || !1, I = e.aspectHeight || 9, S = e.aspectWidth || 16, P = e.iframeClass || "", R = e.playerClass || "lty-playbtn", _ = e.wrapperClass || "yt-lite", $ = l.useCallback(e.onIframeAdded || function() {}, [e.onIframeAdded]), L = e.rel ? "prefetch" : "preload", T = e.containerElement || "article", x = !1 !== e.noscriptFallback, A = () => {
                        c || d(!0)
                    };
                    return l.useEffect(() => {
                        c && ($(), e.focusOnLoad && "object" == typeof t && t ? .current && t.current.focus())
                    }, [c, $, e.focusOnLoad, t]), l.useEffect(() => {
                        if (!c || !e.enableJsApi || !(e.onReady || e.onStateChange || e.onError || e.onPlay || e.onPause || e.onEnd || e.onBuffering || e.onPlaybackRateChange || e.onPlaybackQualityChange)) return;
                        let a = !1,
                            n = !1,
                            o = n => {
                                let o;
                                if ("https://www.youtube.com" === n.origin || "https://www.youtube-nocookie.com" === n.origin) {
                                    try {
                                        o = "string" == typeof n.data ? JSON.parse(n.data) : n.data
                                    } catch {
                                        return
                                    }
                                    switch (o.event) {
                                        case "onReady":
                                            a || (a = !0, e.onReady && e.onReady({
                                                videoId: e.id,
                                                title: y
                                            }));
                                            break;
                                        case "infoDelivery":
                                            if (o.info ? .playerState !== void 0) {
                                                let a = o.info.playerState;
                                                switch (e.onStateChange && e.onStateChange({
                                                    state: a,
                                                    currentTime: o.info.currentTime,
                                                    duration: o.info.duration
                                                }), a) {
                                                    case 1:
                                                        e.onPlay ? .();
                                                        break;
                                                    case 2:
                                                        e.onPause ? .();
                                                        break;
                                                    case 0:
                                                        e.onEnd ? .(), e.stopOnEnd && "object" == typeof t && t ? .current ? .contentWindow && t.current.contentWindow.postMessage('{"event":"command","func":"stopVideo","args":""}', "*");
                                                        break;
                                                    case 3:
                                                        e.onBuffering ? .()
                                                }
                                            }
                                            o.info ? .playbackRate !== void 0 && e.onPlaybackRateChange ? .(o.info.playbackRate), o.info ? .playbackQuality !== void 0 && e.onPlaybackQualityChange ? .(o.info.playbackQuality);
                                            break;
                                        case "onStateChange":
                                            if (o.info ? .playerState !== void 0) {
                                                let a = o.info.playerState;
                                                switch (e.onStateChange && e.onStateChange({
                                                    state: a,
                                                    currentTime: o.info.currentTime,
                                                    duration: o.info.duration
                                                }), a) {
                                                    case 1:
                                                        e.onPlay ? .();
                                                        break;
                                                    case 2:
                                                        e.onPause ? .();
                                                        break;
                                                    case 0:
                                                        e.onEnd ? .(), e.stopOnEnd && "object" == typeof t && t ? .current ? .contentWindow && t.current.contentWindow.postMessage('{"event":"command","func":"stopVideo","args":""}', "*");
                                                        break;
                                                    case 3:
                                                        e.onBuffering ? .()
                                                }
                                            }
                                            break;
                                        case "onError":
                                            {
                                                let t = o.info,
                                                    a;
                                                if ("number" == typeof t || "string" == typeof t) {
                                                    let e = Number(t);
                                                    Number.isNaN(e) || (a = e)
                                                } else "object" == typeof t && t && "errorCode" in t && "number" == typeof t.errorCode && (a = t.errorCode);void 0 !== a && e.onError && e.onError(a);
                                                break
                                            }
                                        case "onPlaybackRateChange":
                                            o.info ? .playbackRate !== void 0 && e.onPlaybackRateChange ? .(o.info.playbackRate);
                                            break;
                                        case "onPlaybackQualityChange":
                                            o.info ? .playbackQuality !== void 0 && e.onPlaybackQualityChange ? .(o.info.playbackQuality)
                                    }
                                }
                            };
                        window.addEventListener("message", o);
                        let r = [],
                            i = () => {
                                "object" == typeof t && t ? .current ? .contentWindow && t.current.contentWindow.postMessage('{"event":"listening","id":"' + u + '"}', "*")
                            },
                            l = () => {
                                n || (n = !0, i(), [100, 300, 600, 1200, 2400].forEach(e => {
                                    r.push(setTimeout(i, e))
                                }))
                            };
                        return "object" == typeof t && t ? .current ? (t.current.addEventListener("load", l), t.current.contentDocument ? .readyState === "complete" && l()) : [200, 500, 1e3, 2e3, 3e3].forEach(e => {
                            r.push(setTimeout(i, e))
                        }), () => {
                            window.removeEventListener("message", o), r.forEach(clearTimeout), "object" == typeof t && t ? .current && t.current.removeEventListener("load", l)
                        }
                    }, [c, e.enableJsApi, e.onReady, e.onStateChange, e.onError, e.onPlay, e.onPause, e.onEnd, e.onBuffering, e.onPlaybackRateChange, e.onPlaybackQualityChange, e.stopOnEnd, e.id, u, y, t]), (0, r.jsxs)(r.Fragment, {
                        children: [!e.lazyLoad && (0, r.jsx)("link", {
                            rel: L,
                            href: C,
                            as: "image"
                        }), (0, r.jsx)(r.Fragment, {
                            children: o && (0, r.jsxs)(r.Fragment, {
                                children: [(0, r.jsx)("link", {
                                    rel: "preconnect",
                                    href: g
                                }), (0, r.jsx)("link", {
                                    rel: "preconnect",
                                    href: "https://www.google.com"
                                }), j && (0, r.jsxs)(r.Fragment, {
                                    children: [(0, r.jsx)("link", {
                                        rel: "preconnect",
                                        href: "https://static.doubleclick.net"
                                    }), (0, r.jsx)("link", {
                                        rel: "preconnect",
                                        href: "https://googleads.g.doubleclick.net"
                                    })]
                                })]
                            })
                        }), e.seo && !e.playlist && (0, r.jsx)("script", {
                            type: "application/ld+json",
                            dangerouslySetInnerHTML: {
                                __html: (a = e.id, n = e.seo, JSON.stringify({
                                    "@context": "https://schema.org",
                                    "@type": "VideoObject",
                                    name: n ? .name || y,
                                    thumbnailUrl: [n ? .thumbnailUrl || C],
                                    embedUrl: n ? .embedUrl || `${g}/embed/${a}`,
                                    contentUrl: n ? .contentUrl || `https://www.youtube.com/watch?v=${a}`,
                                    ...n ? .description && {
                                        description: n.description
                                    },
                                    ...n ? .uploadDate && {
                                        uploadDate: n.uploadDate
                                    },
                                    ...n ? .duration && {
                                        duration: n.duration
                                    }
                                }))
                            }
                        }), x && !e.playlist && (0, r.jsx)("noscript", {
                            children: (0, r.jsxs)("a", {
                                href: `https://www.youtube.com/watch?v=${e.id}`,
                                "aria-label": `Watch ${y} on YouTube`,
                                children: ['Watch "', y, '" on YouTube']
                            })
                        }), (0, r.jsxs)(T, {
                            onPointerOver: () => {
                                o || i(!0)
                            },
                            onClick: A,
                            className: `${_} ${c?N:""}`,
                            "data-title": y,
                            role: c || e.lazyLoad ? void 0 : "img",
                            "aria-label": c ? void 0 : `${y} - YouTube video preview`,
                            style: { ...!e.lazyLoad && {
                                    backgroundImage: `url(${C})`
                                },
                                "--aspect-ratio": `${I/S*100}%`,
                                ...e.style || {}
                            },
                            children: [e.lazyLoad && !c && (0, r.jsx)("img", {
                                src: C,
                                alt: `${y} - YouTube thumbnail`,
                                className: "lty-thumbnail",
                                loading: "lazy"
                            }), e.playlist && !c && (0, r.jsx)("div", {
                                className: "lty-playlist-icon",
                                "aria-hidden": "true"
                            }), !(e.hideButtonOnActivate && c) && (0, r.jsx)("button", {
                                type: "button",
                                className: R,
                                "aria-label": `${f} ${y}`,
                                "aria-hidden": c || void 0,
                                tabIndex: c ? -1 : 0,
                                onClick: A,
                                children: (0, r.jsx)("span", {
                                    className: "lty-visually-hidden",
                                    children: f
                                })
                            }), c && (0, r.jsx)("iframe", {
                                ref: t,
                                className: P,
                                title: y,
                                width: "560",
                                height: "315",
                                allow: "accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture",
                                allowFullScreen: !0,
                                src: w,
                                referrerPolicy: e.referrerPolicy || "strict-origin-when-cross-origin"
                            })]
                        })]
                    })
                }),
                d = a(27066);
            a(76380);
            let u = e => {
                let t, a, n = (0, i.c)(5),
                    {
                        videoId: o,
                        playLabel: l
                    } = e;
                n[0] !== o ? (t = o.split("/").pop(), n[0] = o, n[1] = t) : t = n[1];
                let s = t;
                return n[2] !== s || n[3] !== l ? (a = s ? (0, r.jsx)("div", {
                    "data-testid": "game-video",
                    children: (0, r.jsx)(c, {
                        id: s,
                        title: l,
                        aspectHeight: d._,
                        aspectWidth: d.Z,
                        webp: !0,
                        lazyLoad: !0
                    })
                }) : null, n[2] = s, n[3] = l, n[4] = a) : a = n[4], a
            }
        },
        76380: () => {}
    }
]);
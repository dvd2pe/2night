! function() {
    try {
        var e = "u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof globalThis ? globalThis : "u" > typeof self ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[(new e.Error).stack] = function(e) {
            for (var a = 1; a < arguments.length; a++) {
                var n = arguments[a];
                if (null != n)
                    for (var t in n) n.hasOwnProperty(t) && (e[t] = n[t])
            }
            return e
        }({}, e._sentryModuleMetadata[(new e.Error).stack], {
            "_sentryBundlerPluginAppKey:crazygames-portal": !0
        });
        var a = (new e.Error).stack;
        a && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[a] = "d44a890c-9056-4685-bc71-0e16dd4ab14c", e._sentryDebugIdIdentifier = "sentry-dbid-d44a890c-9056-4685-bc71-0e16dd4ab14c")
    } catch (e) {}
}();
"use strict";
(self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [49378], {
        49378: (e, a, n) => {
            n.r(a), n.d(a, {
                default: () => h
            });
            var t = n(6029),
                r = n(75155),
                s = n(55729),
                i = n(98417),
                c = n(79942),
                o = n(50212),
                l = n(33165),
                d = n(14886),
                u = n(93800),
                g = n(71684),
                y = n(37434),
                f = n(81930),
                m = n(78339),
                b = n.n(m);
            let h = e => {
                let a, n, m, h, _, v, p, k, x, w, A, j, E, M, N = (0, r.c)(31),
                    {
                        width: B,
                        height: C
                    } = e,
                    {
                        openDrawer: F
                    } = s.useContext(l.lv),
                    {
                        user: z
                    } = s.useContext(d.R),
                    {
                        crazyAnalyticsService: I
                    } = s.useContext(g.A).services;
                N[0] !== I ? (a = () => {
                    I.notificationActionEvent("banner-cta-friends", "shown")
                }, n = [I], N[0] = I, N[1] = a, N[2] = n) : (a = N[1], n = N[2]), s.useEffect(a, n), N[3] !== I || N[4] !== F || N[5] !== z ? (m = e => {
                    e.preventDefault(), e.stopPropagation(), (0, i.O)(z) ? F("friends", {
                        clickOrigin: "banner-cta-friends"
                    }) : F("friendsGuest"), I.notificationActionEvent("banner-cta-friends", "clicked")
                }, N[3] = I, N[4] = F, N[5] = z, N[6] = m) : m = N[6];
                let S = m;
                N[7] === Symbol.for("react.memo_cache_sentinel") ? (h = (0, f.Ay)("crazygames/ziggy_friends.svg"), N[7] = h) : h = N[7];
                let D = h,
                    U = B && C ? B / C : 1,
                    T = (0, c.uB)(),
                    O = T._("game.adUnitFriends.title", {
                        yourfriends: T._("game.adUnitFriends.yourFriends")
                    }).length > 30 ? 20 : 28,
                    P = U > 2 && b().wide;
                N[8] !== P ? (_ = (0, o.A)(b().adUnitAlternative, b().secondLayout, P), N[8] = P, N[9] = _) : _ = N[9], N[10] !== C || N[11] !== B ? (v = {
                    width: B,
                    height: C
                }, N[10] = C, N[11] = B, N[12] = v) : v = N[12];
                let q = b()[`fontSize${O}`];
                return N[13] !== q ? (p = (0, o.A)(b().placeholderTitle, q), N[13] = q, N[14] = p) : p = N[14], N[15] === Symbol.for("react.memo_cache_sentinel") ? (k = (0, t.jsx)(c.x6, {
                    id: "game.adUnitFriends.title",
                    values: {
                        yourFriends: (0, t.jsx)("span", {
                            children: (0, t.jsx)(c.x6, {
                                id: "game.adUnitFriends.yourFriends"
                            })
                        })
                    }
                }), N[15] = k) : k = N[15], N[16] !== p ? (x = (0, t.jsx)("div", {
                    className: p,
                    children: k
                }), N[16] = p, N[17] = x) : x = N[17], N[18] === Symbol.for("react.memo_cache_sentinel") ? (w = (0, t.jsx)(u.A, {
                    name: "arrow-full-right"
                }), N[18] = w) : w = N[18], N[19] !== S ? (A = (0, t.jsx)(y.A, {
                    height: 34,
                    variant: "contained",
                    color: "white",
                    onClick: S,
                    className: b().iconButton,
                    dataTestId: "ad-friends-cta",
                    children: w
                }), N[19] = S, N[20] = A) : A = N[20], N[21] === Symbol.for("react.memo_cache_sentinel") ? (j = (0, t.jsx)("img", {
                    className: b().image,
                    src: D,
                    alt: ""
                }), N[21] = j) : j = N[21], N[22] !== U ? (E = U > 2 ? (0, t.jsx)("img", {
                    src: (0, f.Ay)("crazygames/bannerHorBackground.svg"),
                    alt: "",
                    className: b().horBackground
                }) : (0, t.jsx)("img", {
                    src: (0, f.Ay)("crazygames/bannerSquareBackground.svg"),
                    alt: "",
                    className: b().squareBackground
                }), N[22] = U, N[23] = E) : E = N[23], N[24] !== S || N[25] !== x || N[26] !== A || N[27] !== E || N[28] !== _ || N[29] !== v ? (M = (0, t.jsxs)("div", {
                    className: _,
                    style: v,
                    onClick: S,
                    children: [x, A, j, E]
                }), N[24] = S, N[25] = x, N[26] = A, N[27] = E, N[28] = _, N[29] = v, N[30] = M) : M = N[30], M
            }
        }
    }
]);
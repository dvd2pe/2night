! function() {
    try {
        var t = "u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof globalThis ? globalThis : "u" > typeof self ? self : {};
        t._sentryModuleMetadata = t._sentryModuleMetadata || {}, t._sentryModuleMetadata[(new t.Error).stack] = function(t) {
            for (var n = 1; n < arguments.length; n++) {
                var e = arguments[n];
                if (null != e)
                    for (var r in e) e.hasOwnProperty(r) && (t[r] = e[r])
            }
            return t
        }({}, t._sentryModuleMetadata[(new t.Error).stack], {
            "_sentryBundlerPluginAppKey:crazygames-portal": !0
        });
        var n = (new t.Error).stack;
        n && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[n] = "7955f030-a8a4-4787-b164-387a9af230ad", t._sentryDebugIdIdentifier = "sentry-dbid-7955f030-a8a4-4787-b164-387a9af230ad")
    } catch (t) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [11591, 99414], {
        10614: (t, n, e) => {
            "use strict";
            e.d(n, {
                A: () => i
            });
            var r = e(75155),
                o = e(55729),
                a = e(88047),
                l = e(44884);
            let i = () => {
                let t, n, e, i, c, d, u, s = (0, r.c)(18),
                    p = (0, a.x$)(),
                    [_, y] = o.useState(!1),
                    [S, I] = o.useState(!0);
                s[0] !== p ? (t = async () => {
                    try {
                        let t = await p.webpush.pushSubscribed();
                        return y(t), t
                    } catch {
                        return y(!1), !1
                    }
                }, s[0] = p, s[1] = t) : t = s[1];
                let O = t;
                s[2] !== O ? (n = () => {
                    let t = !0;
                    return (async () => {
                        await O(), t && I(!1)
                    })(), () => {
                        t = !1
                    }
                }, e = [O], s[2] = O, s[3] = n, s[4] = e) : (n = s[3], e = s[4]), o.useEffect(n, e), s[5] !== p ? (i = () => p.webpush.notificationPermission(), s[5] = p, s[6] = i) : i = s[6];
                let h = i;
                s[7] !== O || s[8] !== p ? (c = async () => {
                    try {
                        await p.webpush.registerPush()
                    } catch {}
                    return O()
                }, s[7] = O, s[8] = p, s[9] = c) : c = s[9];
                let z = c;
                s[10] !== p ? (d = async () => {
                    try {
                        return await (0, l.e3)(p), y(!1), !0
                    } catch {
                        return !1
                    }
                }, s[10] = p, s[11] = d) : d = s[11];
                let v = d;
                return s[12] !== h || s[13] !== _ || s[14] !== S || s[15] !== z || s[16] !== v ? (u = {
                    isSubscribed: _,
                    loading: S,
                    getNotificationPermission: h,
                    subscribe: z,
                    unsubscribe: v
                }, s[12] = h, s[13] = _, s[14] = S, s[15] = z, s[16] = v, s[17] = u) : u = s[17], u
            }
        },
        11591: (t, n, e) => {
            "use strict";
            e.d(n, {
                A: () => s
            });
            var r = e(6029),
                o = e(75155);
            e(55729);
            var a = e(50212),
                l = e(56760),
                i = e(69386),
                c = e(85893),
                d = e(82026),
                u = e.n(d);
            let s = t => {
                let n, e, d, s, p = (0, o.c)(12),
                    {
                        open: _,
                        blurred: y,
                        onClose: S,
                        children: I,
                        className: O
                    } = t;
                if ((0, i.K)(_), !_) return null;
                let h = void 0 !== y && y && u().blurred;
                if (p[0] !== O || p[1] !== h ? (n = (0, a.A)(u().modal, h, O), p[0] = O, p[1] = h, p[2] = n) : n = p[2], p[3] !== S || p[4] !== _ ? (e = (0, r.jsx)(c.k, {
                        open: _,
                        onClick: S
                    }), p[3] = S, p[4] = _, p[5] = e) : e = p[5], p[6] !== I ? (d = (0, r.jsx)("div", {
                        className: u().modalContent,
                        children: I
                    }), p[6] = I, p[7] = d) : d = p[7], p[8] !== n || p[9] !== e || p[10] !== d) {
                    let t = (0, r.jsxs)("div", {
                        className: n,
                        children: [e, d]
                    });
                    s = (0, l.createPortal)(t, document.body), p[8] = n, p[9] = e, p[10] = d, p[11] = s
                } else s = p[11];
                return s
            }
        },
        62273: (t, n, e) => {
            "use strict";
            e.d(n, {
                A: () => p
            });
            var r = e(6029),
                o = e(75155),
                a = e(55729),
                l = e(79942),
                i = e(50293),
                c = e(4230),
                d = e(81930),
                u = e(66017),
                s = e.n(u);
            let p = () => {
                let t, n, e, u, p = (0, o.c)(6),
                    _ = a.useContext(c.A);
                p[0] !== _ ? (t = (0, i.Gz)(_), p[0] = _, p[1] = t) : t = p[1];
                let y = t;
                return p[2] === Symbol.for("react.memo_cache_sentinel") ? (n = (0, r.jsx)("figure", {
                    className: s().icon,
                    children: (0, r.jsx)("img", {
                        src: (0, d.Ay)("crazygames/bell-icon.png", {}, !1),
                        alt: "Bell icon"
                    })
                }), p[2] = n) : n = p[2], p[3] === Symbol.for("react.memo_cache_sentinel") ? (e = (0, r.jsx)("h2", {
                    className: s().title,
                    children: (0, r.jsx)(l.x6, {
                        id: "common.suprsend.optInOverlay.title"
                    })
                }), p[3] = e) : e = p[3], p[4] !== y ? (u = (0, r.jsx)("div", {
                    className: s().suprSendOptInOverlayContainer,
                    children: (0, r.jsxs)("div", {
                        className: s().content,
                        children: [n, e, (0, r.jsx)("p", {
                            className: s().description,
                            children: y ? (0, r.jsx)(l.x6, {
                                id: "common.suprsend.optInOverlay.mobileDescription"
                            }) : (0, r.jsx)(l.x6, {
                                id: "common.suprsend.optInOverlay.description"
                            })
                        })]
                    })
                }), p[4] = y, p[5] = u) : u = p[5], u
            }
        },
        66017: t => {
            t.exports = {
                czyButton: "SuprSendOptInOverlay_czyButton__O7IAw",
                "czyButton--contained--purple": "SuprSendOptInOverlay_czyButton--contained--purple__oolub",
                "czyButton--contained--white": "SuprSendOptInOverlay_czyButton--contained--white__SY8ow",
                "czyButton--contained--grey": "SuprSendOptInOverlay_czyButton--contained--grey__yOA2e",
                "czyButton--contained--warning": "SuprSendOptInOverlay_czyButton--contained--warning__8U_vi",
                "czyButton--contained--alert": "SuprSendOptInOverlay_czyButton--contained--alert__XkO4a",
                "czyButton--contained--success": "SuprSendOptInOverlay_czyButton--contained--success__7woyq",
                "czyButton--contained--black": "SuprSendOptInOverlay_czyButton--contained--black__4Sntm",
                "czyButton--contained--green-gradient": "SuprSendOptInOverlay_czyButton--contained--green-gradient__IPu7Y",
                "czyButton--contained--animated-green-gradient": "SuprSendOptInOverlay_czyButton--contained--animated-green-gradient__zKtps",
                "scroll-gradient": "SuprSendOptInOverlay_scroll-gradient__mkaO1",
                "czyButton--outlined--purple": "SuprSendOptInOverlay_czyButton--outlined--purple__hqPFR",
                "czyButton--link--purple": "SuprSendOptInOverlay_czyButton--link--purple__wOZz5",
                "czyButton--outlined--white": "SuprSendOptInOverlay_czyButton--outlined--white__IxhtY",
                "czyButton--link--white": "SuprSendOptInOverlay_czyButton--link--white__SuybG",
                "czyButton--outlined--grey": "SuprSendOptInOverlay_czyButton--outlined--grey__PAv_2",
                "czyButton--link--grey": "SuprSendOptInOverlay_czyButton--link--grey__KKrKA",
                "czyButton--outlined--warning": "SuprSendOptInOverlay_czyButton--outlined--warning__dQu3O",
                "czyButton--link--warning": "SuprSendOptInOverlay_czyButton--link--warning__Jt3SF",
                "czyButton--outlined--alert": "SuprSendOptInOverlay_czyButton--outlined--alert__tWR1M",
                "czyButton--link--alert": "SuprSendOptInOverlay_czyButton--link--alert__kjDCz",
                "czyButton--outlined--success": "SuprSendOptInOverlay_czyButton--outlined--success__hSDqa",
                "czyButton--link--success": "SuprSendOptInOverlay_czyButton--link--success__PGwnw",
                "czyButton--outlined": "SuprSendOptInOverlay_czyButton--outlined__bs40g",
                "czyButton--disabled": "SuprSendOptInOverlay_czyButton--disabled__zliUw",
                "czyButton--height50": "SuprSendOptInOverlay_czyButton--height50__SMBvB",
                "czyButton--height34": "SuprSendOptInOverlay_czyButton--height34__d01AD",
                "czyButton--height28": "SuprSendOptInOverlay_czyButton--height28__tilJs",
                "czyButton--fullWidth": "SuprSendOptInOverlay_czyButton--fullWidth__ca_zK",
                "czyButton--headerIcon": "SuprSendOptInOverlay_czyButton--headerIcon__5VWb_",
                "czyButton--headerIcon--desktop": "SuprSendOptInOverlay_czyButton--headerIcon--desktop__pjI_8",
                "czyButton--headerIcon--mobile": "SuprSendOptInOverlay_czyButton--headerIcon--mobile__O6OUD",
                "czyButton--headerIcon--withLabel": "SuprSendOptInOverlay_czyButton--headerIcon--withLabel__P6u9d",
                suprSendOptInOverlayContainer: "SuprSendOptInOverlay_suprSendOptInOverlayContainer__apxiS",
                content: "SuprSendOptInOverlay_content__TlC_I",
                icon: "SuprSendOptInOverlay_icon__QZfa1",
                title: "SuprSendOptInOverlay_title__9zJbm",
                description: "SuprSendOptInOverlay_description___JoNQ"
            }
        },
        77506: t => {
            t.exports = {
                optInModalContainer: "SuprSendOptInModal_optInModalContainer__FSksa",
                isTransparent: "SuprSendOptInModal_isTransparent__rqopY",
                optInModalIcon: "SuprSendOptInModal_optInModalIcon__AsCi1",
                optInModalTitle: "SuprSendOptInModal_optInModalTitle__jSPkF",
                optInModalDescription: "SuprSendOptInModal_optInModalDescription__V5_Xv",
                optInModalActions: "SuprSendOptInModal_optInModalActions__jsK_l",
                optInModalError: "SuprSendOptInModal_optInModalError__9usE_"
            }
        },
        99414: (t, n, e) => {
            "use strict";
            e.r(n), e.d(n, {
                default: () => m
            });
            var r = e(6029),
                o = e(55729),
                a = e(7842),
                l = e(79942),
                i = e(50212),
                c = e(14886),
                d = e(28478),
                u = e(37434),
                s = e(4230),
                p = e(81930),
                _ = e(93800),
                y = e(71684),
                S = e(11591),
                I = e(10614),
                O = e(44884),
                h = e(62273),
                z = e(77506),
                v = e.n(z);
            let B = "push-notification-OptIn",
                g = "ss_allowing",
                m = () => {
                    let {
                        crazyAnalyticsService: t
                    } = (0, o.useContext)(y.A).services, {
                        user: n,
                        isNewUser: e
                    } = (0, o.useContext)(c.R), z = (0, o.useContext)(s.A), m = (0, O.$K)(z), {
                        isSubscribed: w,
                        loading: x,
                        getNotificationPermission: f,
                        subscribe: b
                    } = (0, I.A)(), [M, j] = o.useState(!1), [k, A] = o.useState(!1), [C, N] = o.useState(!1), [E, D] = o.useState(!1), P = d.A.LocalStorage, K = P.getItem("ss_distinct_id"), T = `ss_shown_${K}`, Y = P.getItem(T), F = P.getItem(g);
                    o.useEffect(() => {
                        (async () => {
                            m && ("true" !== Y || F) && n && "no" === e && !x && await (0, O.NY)() ? A(!w) : A(!1)
                        })()
                    }, [Y, F, n, m, e, w, x]), o.useEffect(() => {
                        k && t.notificationActionEvent(B, "shown")
                    }, [t, k, P]);
                    let q = () => {
                            t.notificationActionEvent(B, "ignored"), A(!1), P.setItem(T, "true")
                        },
                        J = async () => {
                            if ("denied" === f()) return void D(!0);
                            P.setItem(T, "true"), P.setItem(g, "true"), j(!0);
                            try {
                                if (!await (0, O.NY)()) return;
                                "default" === f() && N(!0), await b() && t.notificationActionEvent(B, "accepted")
                            } catch (t) {
                                console.warn("handleEnable: ", t)
                            } finally {
                                P.removeItem(g), N(!1), j(!1), A(!1)
                            }
                        };
                    return k ? (0, r.jsxs)(r.Fragment, {
                        children: [(0, r.jsx)(S.A, {
                            open: !C,
                            onClose: q,
                            children: (0, r.jsxs)("div", {
                                className: (0, i.A)(v().optInModalContainer),
                                children: [(0, r.jsx)("figure", {
                                    className: v().optInModalIcon,
                                    children: (0, r.jsx)("img", {
                                        src: (0, p.Ay)("crazygames/bell-icon.png", {}, !1),
                                        alt: "Bell icon"
                                    })
                                }), (0, r.jsx)("h2", {
                                    className: v().optInModalTitle,
                                    children: (0, r.jsx)(l.x6, {
                                        id: "common.suprsend.optInModal.title"
                                    })
                                }), (0, r.jsx)("p", {
                                    className: v().optInModalDescription,
                                    children: (0, r.jsx)(l.x6, {
                                        id: "common.suprsend.optInModal.description"
                                    })
                                }), (0, r.jsxs)("div", {
                                    className: v().optInModalActions,
                                    children: [(0, r.jsx)(u.A, {
                                        variant: "outlined",
                                        color: "white",
                                        height: 50,
                                        onClick: () => q(),
                                        children: (0, r.jsx)(l.x6, {
                                            id: "common.suprsend.optInModal.dismiss"
                                        })
                                    }), (0, r.jsx)(u.A, {
                                        variant: "contained",
                                        color: M ? "grey" : "purple",
                                        height: 50,
                                        onClick: () => J(),
                                        disabled: !!M,
                                        children: M && "granted" === f() ? (0, r.jsx)(a.y, {
                                            size: "small",
                                            tone: "neutral"
                                        }) : (0, r.jsx)(l.x6, {
                                            id: "common.suprsend.optInModal.allow"
                                        })
                                    })]
                                }), E && (0, r.jsxs)("div", {
                                    className: v().optInModalError,
                                    children: [(0, r.jsx)(_.A, {
                                        name: "warning",
                                        size: 16
                                    }), (0, r.jsx)("span", {
                                        children: (0, r.jsx)(l.x6, {
                                            id: "friends.upDrawer.notificationPreferences.pushNotificationsDenied"
                                        })
                                    })]
                                })]
                            })
                        }), C && (0, r.jsx)(h.A, {})]
                    }) : null
                }
        }
    }
]);
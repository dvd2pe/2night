! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "63e8378a-d0ae-5109-9ef1-861e04af7864")
    } catch (e) {}
}();
(function() {
    try {
        var e = typeof window < `u` ? window : typeof global < `u` ? global : typeof globalThis < `u` ? globalThis : typeof self < `u` ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[new e.Error().stack] = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                if (n != null)
                    for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r])
            }
            return e
        }({}, e._sentryModuleMetadata[new e.Error().stack], {
            "_sentryBundlerPluginAppKey:crazygames-gameframe": !0
        });
        var t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = `13b25d96-a2c5-4cc3-baa5-13537577df8b`, e._sentryDebugIdIdentifier = `sentry-dbid-13b25d96-a2c5-4cc3-baa5-13537577df8b`)
    } catch {}
})();
import {
    Bt as e,
    D as t,
    Dt as n,
    E as r,
    Et as i,
    It as a,
    O as o,
    Ot as s,
    Qt as c,
    Sn as l,
    Yt as u,
    an as d,
    gn as f,
    n as p,
    on as m,
    pn as h,
    t as g,
    tn as _,
    w as v,
    yn as y
} from "../../bundle.js";
import {
    t as b
} from "./ByF0oZf9.js";
import {
    t as x
} from "./DesdDbnn.js";
var S = l(y()),
    C = f(),
    w = v(o(t(class extends S.Component {
        constructor(e) {
            super(e), h(this, `config`, void 0), h(this, `options`, void 0), h(this, `progressTracker`, void 0), h(this, `iframe`, null), h(this, `detachRenderScale`, null), h(this, `processMessage`, e => {
                let {
                    type: t
                } = e.data;
                t === `focusStealAttempt` && this.focusOnIframe()
            }), h(this, `onIframeLoad`, () => {
                this.progressTracker.trackLoadFinished(), this.onLoad(), this.focusOnIframe()
            }), h(this, `disableIframe`, () => {
                this.iframe && = (this.detachRenderScale ? .(), this.detachRenderScale = null, this.iframe.remove(), null)
            }), h(this, `restartGame`, () => {
                window.location.reload()
            }), h(this, `onLoad`, () => {
                this.state.state !== `loaded` && (this.setState({
                    state: `loaded`
                }), setTimeout(() => {
                    this.setState({
                        showLoadingBar: !1
                    })
                }, 600), this.props.onLoadFinished(), g())
            }), h(this, `onFullscreenClose`, async () => {
                this.startLoading()
            }), h(this, `onAdFinished`, () => {
                this.focusOnIframe()
            }), this.config = m(), this.options = this.config.loaderOptions, this.state = {
                state: `checking`,
                showLoadingBar: !1
            }, this.progressTracker = new x
        }
        componentDidMount() {
            let t = _();
            this.config.fullscreen === `REQUIRED` && !t && !this.props.isFullscreen ? this.setState({
                state: `fullscreen`
            }) : this.startLoading(), e().addAdFinishedListener(this.onAdFinished), window.addEventListener(`message`, this.processMessage)
        }
        componentWillUnmount() {
            e().removeAdFinishedListener(this.onAdFinished), p(), this.detachRenderScale ? .(), this.detachRenderScale = null
        }
        componentDidUpdate(e) {
            e.isFullscreen !== this.props.isFullscreen && this.focusOnIframe(), !e.isGameDisabled && this.props.isGameDisabled ? this.disableIframe() : e.isGameDisabled && !this.props.isGameDisabled && this.restartGame()
        }
        renderForState() {
            let {
                state: e
            } = this.state;
            switch (e) {
                case `checking`:
                    return this.renderChecking();
                case `fullscreen`:
                    return this.renderFullscreenOverlay();
                case `loaded`:
                    return this.renderLoaded();
                default:
                    throw Error(`[IFrameLoader] unexpected state ${e}`)
            }
        }
        render() {
            return (0, C.jsxs)(C.Fragment, {
                children: [this.renderForState(), this.state.showLoadingBar && this.renderLoading()]
            })
        }
        renderChecking() {
            return (0, C.jsx)(r, {
                showProgress: !1
            })
        }
        renderFullscreenOverlay() {
            return (0, C.jsx)(b, {
                warning: `force-fullscreen`,
                close: this.onFullscreenClose
            })
        }
        renderLoading() {
            return (0, C.jsx)(r, {
                showProgress: !1
            })
        }
        renderLoaded() {
            return null
        }
        loadIframe() {
            if (this.props.isGameDisabled) return;
            let {
                scrolling: e
            } = this.options, {
                sandbox: t
            } = this.config, r = document.createElement(`iframe`);
            r.id = i, r.src = this.getIframeUrl(), r.onload = this.onIframeLoad, r.style.border = `0`, r.style.outline = `0`, r.style.backgroundColor = `#fff`, e && r.setAttribute(`scrolling`, e), r.style.width = `10px`, r.style.height = `10px`, r.style.minWidth = `100%`, r.style.minHeight = `100%`, r.setAttribute(`allow`, s({
                src: r.src,
                extra: this.config.allowWebCam ? [`camera`] : []
            })), r.setAttribute(`webkitallowfullscreen`, `true`), r.setAttribute(`mozallowfullscreen`, `true`), r.setAttribute(`msallowfullscreen`, `true`), r.setAttribute(`allowfullscreen`, `true`), r.setAttribute(`data-testid`, `inner-iframe`), t && (r.setAttribute(`sandbox`, ``), r.sandbox.add(...n)), this.iframe = r, d().appendChild(r), c() && (this.detachRenderScale = u(r))
        }
        async startLoading() {
            this.setState({
                showLoadingBar: !0
            });
            try {
                await a.Instance.waitForAPS()
            } catch {} finally {
                this.loadIframe(), this.progressTracker.trackLoadStarted(), setTimeout(() => {
                    this.onLoad()
                }, 10 * 1e3)
            }
        }
        getIframeUrl() {
            let e = new URL(this.options.url);
            return new URLSearchParams(window.location.search).forEach((t, n) => {
                n !== `v` && e.searchParams.append(n, t)
            }), e.toString()
        }
        focusOnIframe() {
            this.iframe && this.iframe.contentWindow && this.iframe.contentWindow.focus(), window.getSelection() ? .removeAllRanges()
        }
    })));
export {
    w as
    default
};
//# debugId=63e8378a-d0ae-5109-9ef1-861e04af7864
! function() {
    try {
        var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof globalThis ? globalThis : "undefined" != typeof self ? self : {},
            n = (new e.Error).stack;
        n && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[n] = "b32643d4-3d36-587c-9fe8-54be7504c28d")
    } catch (e) {}
}();
(function() {
    try {
        var e = typeof window < `u` ? window : typeof global < `u` ? global : typeof globalThis < `u` ? globalThis : typeof self < `u` ? self : {};
        e._sentryModuleMetadata = e._sentryModuleMetadata || {}, e._sentryModuleMetadata[new e.Error().stack] = function(e) {
            for (var t = 1; t < arguments.length; t++) {
                var n = arguments[t];
                if (n != null)
                    for (var r in n) n.hasOwnProperty(r) && (e[r] = n[r])
            }
            return e
        }({}, e._sentryModuleMetadata[new e.Error().stack], {
            "_sentryBundlerPluginAppKey:crazygames-gameframe": !0
        });
        var t = new e.Error().stack;
        t && (e._sentryDebugIds = e._sentryDebugIds || {}, e._sentryDebugIds[t] = `b41f056e-30a7-4682-b606-d0834c44be0a`, e._sentryDebugIdIdentifier = `sentry-dbid-b41f056e-30a7-4682-b606-d0834c44be0a`)
    } catch {}
})();
import {
    a as e,
    n as t,
    r as n,
    t as r
} from "./B64wT94t.js";
import {
    $ as i,
    At as a,
    C as o,
    Ft as s,
    Ht as c,
    J as l,
    Jt as u,
    Nt as d,
    Q as f,
    Sn as p,
    T as m,
    Wt as h,
    _n as g,
    at as _,
    bn as v,
    cn as y,
    ft as b,
    gn as x,
    hn as S,
    i as C,
    it as w,
    ln as T,
    mn as E,
    mt as D,
    nt as O,
    on as k,
    pn as A,
    qt as j,
    r as ee,
    tn as te,
    tt as M,
    un as N,
    v as ne,
    vn as re,
    yn as ie
} from "../../bundle.js";
import {
    t as P
} from "./CKRfKwc82.js";
var F = p(ie()),
    I = y(),
    L = {
        inviteButton: `_inviteButton_1sjys_7`,
        isActive: `_isActive_1sjys_7`,
        "horizontal-shaking": `_horizontal-shaking_1sjys_1`
    },
    R = x(),
    ae = () => {
        let e = (0, I.c)(7),
            {
                showInviteButton: t,
                inviteButtonActive: n,
                inviteLink: r,
                onInviteButtonClick: i
            } = F.useContext(ne),
            {
                gameLoadStatus: o
            } = F.useContext(a),
            s = o === `GAME_LOADED`,
            c = r;
        if (!s) return null;
        let u;
        e[0] !== n || e[1] !== c || e[2] !== i || e[3] !== t ? (u = (t || n) && (0, R.jsx)(l, {
            size: `xs`,
            icon: {
                position: `left`,
                code: `friends`
            },
            label: g._(`inviteFriends.footer.button`),
            "data-testid": `footer-invite-button`,
            disabled: !c,
            onClick: i,
            className: D(L.inviteButton, n && c && L.isActive)
        }), e[0] = n, e[1] = c, e[2] = i, e[3] = t, e[4] = u) : u = e[4];
        let d;
        return e[5] === u ? d = e[6] : (d = (0, R.jsx)(R.Fragment, {
            children: u
        }), e[5] = u, e[6] = d), d
    },
    z = {
        root: `_root_14sac_7`,
        closeIcon: `_closeIcon_14sac_20`,
        action: `_action_14sac_26`,
        tooltip: `_tooltip_14sac_31`
    },
    oe = e => {
        let t = (0, I.c)(15),
            {
                enabled: n,
                onExit: r
            } = e,
            {
                disableFullscreen: i,
                isFullscreen: a
            } = F.useContext(m),
            o;
        t[0] !== i || t[1] !== a || t[2] !== r ? (o = function() {
            a && i(), h.feedback(`dislike`), r()
        }, t[0] = i, t[1] = a, t[2] = r, t[3] = o) : o = t[3];
        let s = o,
            c;
        t[4] === r ? c = t[5] : (c = function() {
            r(), d()
        }, t[4] = r, t[5] = c);
        let l = c;
        if (!n) return null;
        let u;
        t[6] === l ? u = t[7] : (u = (0, R.jsx)(b, {
            name: `close`,
            className: z.closeIcon,
            onClick: l
        }), t[6] = l, t[7] = u);
        let f;
        t[8] === Symbol.for(`react.memo_cache_sentinel`) ? (f = (0, R.jsx)(w, {
            id: `dislikeFeedback.title`
        }), t[8] = f) : f = t[8];
        let p;
        t[9] === Symbol.for(`react.memo_cache_sentinel`) ? (p = (0, R.jsx)(w, {
            id: `dislikeFeedback.action`
        }), t[9] = p) : p = t[9];
        let g;
        t[10] === s ? g = t[11] : (g = (0, R.jsx)(O, {
            variant: `contained`,
            className: z.action,
            onClick: s,
            children: p
        }), t[10] = s, t[11] = g);
        let _;
        return t[12] !== u || t[13] !== g ? (_ = (0, R.jsxs)(`div`, {
            className: z.root,
            onMouseDown: B,
            children: [u, f, g]
        }), t[12] = u, t[13] = g, t[14] = _) : _ = t[14], _
    };

function B(e) {
    e.stopPropagation(), e.preventDefault()
}
var V = t => {
        let n = (0, I.c)(25),
            {
                initialRating: r
            } = t,
            [a, o] = F.useState(r),
            {
                vote: s,
                setVote: c
            } = F.useContext(ee),
            [l, u] = F.useState(!1),
            p, m;
        if (n[0] !== r || n[1] !== c || n[2] !== s) {
            m = () => {
                s === C.POSITIVE ? e(C.CANCEL) : e(C.POSITIVE), d()
            }, p = async () => {
                s === C.NEGATIVE ? e(C.CANCEL) : e(C.NEGATIVE), d()
            };
            let e = e => {
                c(e);
                bb10: switch (e) {
                    case C.NEGATIVE:
                        h.dislike(), o({
                            upVotes: r.upVotes,
                            downVotes: r.downVotes + 1
                        }), u(!0);
                        break bb10;
                    case C.POSITIVE:
                        h.like(), o({
                            upVotes: r.upVotes + 1,
                            downVotes: r.downVotes
                        }), u(!1);
                        break bb10;
                    case C.CANCEL:
                        h.neutral(), o({
                            upVotes: r.upVotes,
                            downVotes: r.downVotes
                        }), u(!1)
                }
            };
            n[0] = r, n[1] = c, n[2] = s, n[3] = p, n[4] = m
        } else p = n[3], m = n[4];
        let _;
        n[5] === Symbol.for(`react.memo_cache_sentinel`) ? (_ = (0, R.jsx)(w, {
            id: `tooltip.like`
        }), n[5] = _) : _ = n[5];
        let v;
        n[6] === a.upVotes ? v = n[7] : (v = isNaN(a.upVotes) ? void 0 : g.number(a.upVotes, {
            notation: `compact`
        }), n[6] = a.upVotes, n[7] = v);
        let y = s === C.POSITIVE,
            b = s === C.POSITIVE ? `success` : void 0,
            x;
        n[8] !== m || n[9] !== v || n[10] !== y || n[11] !== b ? (x = (0, R.jsx)(f, {
            title: _,
            placement: `top`,
            tooltipClassName: z.tooltip,
            children: (0, R.jsx)(e, {
                icon: `like`,
                label: v,
                onClick: m,
                isActive: y,
                status: b,
                segment: `start`,
                testId: `footer-like-button`
            })
        }), n[8] = m, n[9] = v, n[10] = y, n[11] = b, n[12] = x) : x = n[12];
        let S;
        n[13] === Symbol.for(`react.memo_cache_sentinel`) ? (S = (0, R.jsx)(w, {
            id: `tooltip.dislike`
        }), n[13] = S) : S = n[13];
        let T = s === C.NEGATIVE,
            E = s === C.NEGATIVE ? `error` : void 0,
            D;
        n[14] !== p || n[15] !== T || n[16] !== E ? (D = (0, R.jsx)(f, {
            title: S,
            placement: `top`,
            tooltipClassName: z.tooltip,
            children: (0, R.jsx)(e, {
                icon: `dislike`,
                onClick: p,
                isActive: T,
                status: E,
                segment: `end`,
                testId: `footer-dislike-button`
            })
        }), n[14] = p, n[15] = T, n[16] = E, n[17] = D) : D = n[17];
        let O;
        n[18] === Symbol.for(`react.memo_cache_sentinel`) ? (O = () => {
            u(!1)
        }, n[18] = O) : O = n[18];
        let k;
        n[19] === l ? k = n[20] : (k = (0, R.jsx)(oe, {
            enabled: l,
            onExit: O
        }), n[19] = l, n[20] = k);
        let A;
        return n[21] !== k || n[22] !== x || n[23] !== D ? (A = (0, R.jsxs)(`div`, {
            className: i.ratingGroup,
            children: [x, D, k]
        }), n[21] = k, n[22] = x, n[23] = D, n[24] = A) : A = n[24], A
    },
    H = p(re()),
    U = {
        popper: `_popper_7yhp4_15`,
        positioned: `_positioned_7yhp4_21`,
        content: `_content_7yhp4_25`,
        arrow: `_arrow_7yhp4_35`,
        timerBar: `_timerBar_7yhp4_49`,
        "timer-grow": `_timer-grow_7yhp4_1`
    },
    W = 3,
    G = 8,
    K = e => {
        let t = (0, I.c)(29),
            {
                anchorElement: n,
                open: r,
                onAutoClose: i,
                children: a,
                duration: o
            } = e,
            [s, c] = (0, F.useState)(null),
            l = (0, F.useRef)(null),
            u = o || W,
            d, f;
        t[0] !== i || t[1] !== r || t[2] !== u ? (d = () => {
            if (!r) return;
            let e = setTimeout(() => {
                i()
            }, u * 1e3);
            return () => {
                window.clearTimeout(e)
            }
        }, f = [r, i, u], t[0] = i, t[1] = r, t[2] = u, t[3] = d, t[4] = f) : (d = t[3], f = t[4]), (0, F.useEffect)(d, f);
        let p;
        t[5] === n ? p = t[6] : (p = () => {
            if (!n || !l.current) return;
            let e = n.getBoundingClientRect(),
                t = l.current.getBoundingClientRect(),
                r = e.left + e.width / 2 - t.width / 2,
                i = Math.max(0, window.innerWidth - t.width);
            c({
                top: e.top - t.height - G,
                left: Math.min(Math.max(r, 0), i)
            })
        }, t[5] = n, t[6] = p);
        let m = p,
            h, g;
        if (t[7] !== n || t[8] !== r || t[9] !== m ? (h = () => {
                if (!(!r || !n)) return m(), window.addEventListener(`scroll`, m, !0), window.addEventListener(`resize`, m), () => {
                    window.removeEventListener(`scroll`, m, !0), window.removeEventListener(`resize`, m)
                }
            }, g = [r, n, m], t[7] = n, t[8] = r, t[9] = m, t[10] = h, t[11] = g) : (h = t[10], g = t[11]), (0, F.useLayoutEffect)(h, g), !r || !n) return null;
        let _ = s && U.positioned,
            v;
        t[12] === _ ? v = t[13] : (v = D(U.popper, _), t[12] = _, t[13] = v);
        let y = s ? .top ? ? 0,
            b = s ? .left ? ? 0,
            x;
        t[14] !== y || t[15] !== b ? (x = {
            top: y,
            left: b
        }, t[14] = y, t[15] = b, t[16] = x) : x = t[16];
        let S = `${u}s`,
            C;
        t[17] === S ? C = t[18] : (C = {
            "--timer-duration": S
        }, t[17] = S, t[18] = C);
        let w = C,
            T;
        t[19] === w ? T = t[20] : (T = (0, R.jsx)(`div`, {
            className: U.timerBar,
            style: w
        }), t[19] = w, t[20] = T);
        let E;
        t[21] === Symbol.for(`react.memo_cache_sentinel`) ? (E = (0, R.jsx)(`div`, {
            className: U.arrow
        }), t[21] = E) : E = t[21];
        let O;
        t[22] !== a || t[23] !== T ? (O = (0, R.jsxs)(`div`, {
            className: U.content,
            children: [T, a, E]
        }), t[22] = a, t[23] = T, t[24] = O) : O = t[24];
        let k;
        return t[25] !== x || t[26] !== O || t[27] !== v ? (k = (0, H.createPortal)((0, R.jsx)(`div`, {
            ref: l,
            className: v,
            style: x,
            children: O
        }), document.body), t[25] = x, t[26] = O, t[27] = v, t[28] = k) : k = t[28], k
    },
    q = () => {
        let t = (0, I.c)(23),
            [n, r] = (0, F.useState)(!1),
            {
                isFullscreen: i
            } = (0, F.useContext)(m),
            {
                accountId: a,
                isFavouriteGame: o,
                removeFromFavourite: c,
                addToFavourite: l
            } = (0, F.useContext)(s),
            [p, h] = (0, F.useState)(null),
            g;
        t[0] !== a || t[1] !== l || t[2] !== o || t[3] !== i || t[4] !== c ? (g = () => {
            if (!a && i) {
                r(!0), d();
                return
            }
            o ? (c(), u.getInstance().userAction(`footer`, `favourite`, `remove`)) : (l(), u.getInstance().userAction(`footer`, `favourite`, `add`)), a && d()
        }, t[0] = a, t[1] = l, t[2] = o, t[3] = i, t[4] = c, t[5] = g) : g = t[5];
        let _ = g,
            v;
        t[6] === Symbol.for(`react.memo_cache_sentinel`) ? (v = () => {
            r(!1)
        }, t[6] = v) : v = t[6];
        let y = v,
            b;
        t[7] === Symbol.for(`react.memo_cache_sentinel`) ? (b = (0, R.jsx)(w, {
            id: `popper.signInToFavourite`
        }), t[7] = b) : b = t[7];
        let x;
        t[8] !== n || t[9] !== p ? (x = (0, R.jsx)(K, {
            anchorElement: p,
            open: n,
            duration: 2,
            onAutoClose: y,
            children: b
        }), t[8] = n, t[9] = p, t[10] = x) : x = t[10];
        let S = o ? `tooltip.removeFromFavorite` : `tooltip.addToFavorite`,
            C;
        t[11] === S ? C = t[12] : (C = (0, R.jsx)(w, {
            id: S
        }), t[11] = S, t[12] = C);
        let T = o ? `saved` : `save`,
            E = !!o,
            D;
        t[13] !== _ || t[14] !== T || t[15] !== E ? (D = (0, R.jsx)(e, {
            icon: T,
            onClick: _,
            ref: h,
            isActive: E,
            testId: `footer-favorite-button`
        }), t[13] = _, t[14] = T, t[15] = E, t[16] = D) : D = t[16];
        let O;
        t[17] !== C || t[18] !== D ? (O = (0, R.jsx)(f, {
            title: C,
            placement: `top`,
            children: D
        }), t[17] = C, t[18] = D, t[19] = O) : O = t[19];
        let k;
        return t[20] !== x || t[21] !== O ? (k = (0, R.jsxs)(R.Fragment, {
            children: [x, O]
        }), t[20] = x, t[21] = O, t[22] = k) : k = t[22], k
    },
    J = {
        card: `_card_s0h6w_1`,
        title: `_title_s0h6w_14`,
        toggleRow: `_toggleRow_s0h6w_20`,
        switch: `_switch_s0h6w_28`,
        switchOn: `_switchOn_s0h6w_41`,
        switchThumb: `_switchThumb_s0h6w_45`,
        actions: `_actions_s0h6w_59`,
        button: `_button_s0h6w_65`,
        manageButton: `_manageButton_s0h6w_69`
    },
    se = e => {
        let t = (0, I.c)(38),
            {
                enabled: n,
                onToggle: r,
                onManageAllGames: i,
                onClose: a
            } = e,
            {
                i18n: o
            } = S(),
            s;
        t[0] === a ? s = t[1] : (s = e => {
            e.target === e.currentTarget && a()
        }, t[0] = a, t[1] = s);
        let c;
        t[2] === Symbol.for(`react.memo_cache_sentinel`) ? (c = (0, R.jsx)(`h2`, {
            id: `footer-notifications-modal-title`,
            className: J.title,
            children: (0, R.jsx)(w, {
                id: `gameNotificationsModal.title`
            })
        }), t[2] = c) : c = t[2];
        let u;
        t[3] === Symbol.for(`react.memo_cache_sentinel`) ? (u = (0, R.jsx)(`span`, {
            children: (0, R.jsx)(w, {
                id: `gameNotificationsModal.toggle`
            })
        }), t[3] = u) : u = t[3];
        let d;
        t[4] === o ? d = t[5] : (d = o._(`gameNotificationsModal.toggle`), t[4] = o, t[5] = d);
        let f = n && J.switchOn,
            p;
        t[6] === f ? p = t[7] : (p = D(J.switch, f), t[6] = f, t[7] = p);
        let m;
        t[8] !== n || t[9] !== r ? (m = () => r(!n), t[8] = n, t[9] = r, t[10] = m) : m = t[10];
        let h;
        t[11] === Symbol.for(`react.memo_cache_sentinel`) ? (h = (0, R.jsx)(`span`, {
            className: J.switchThumb
        }), t[11] = h) : h = t[11];
        let g;
        t[12] !== n || t[13] !== d || t[14] !== p || t[15] !== m ? (g = (0, R.jsxs)(`div`, {
            className: J.toggleRow,
            children: [u, (0, R.jsx)(`button`, {
                type: `button`,
                role: `switch`,
                "aria-checked": n,
                "aria-label": d,
                className: p,
                onClick: m,
                children: h
            })]
        }), t[12] = n, t[13] = d, t[14] = p, t[15] = m, t[16] = g) : g = t[16];
        let v;
        t[17] === o ? v = t[18] : (v = o._(`gameNotificationsModal.manageAllGames`), t[17] = o, t[18] = v);
        let y, b;
        t[19] === Symbol.for(`react.memo_cache_sentinel`) ? (y = {
            position: `right`,
            code: `arrow_forward`
        }, b = D(J.button, J.manageButton), t[19] = y, t[20] = b) : (y = t[19], b = t[20]);
        let x;
        t[21] !== i || t[22] !== v ? (x = (0, R.jsx)(l, {
            label: v,
            tone: `alphaWhite`,
            size: `m`,
            icon: y,
            className: b,
            onClick: i
        }), t[21] = i, t[22] = v, t[23] = x) : x = t[23];
        let C;
        t[24] === o ? C = t[25] : (C = o._(`gameNotificationsModal.close`), t[24] = o, t[25] = C);
        let T;
        t[26] !== a || t[27] !== C ? (T = (0, R.jsx)(l, {
            label: C,
            tone: `green`,
            size: `m`,
            className: J.button,
            onClick: a
        }), t[26] = a, t[27] = C, t[28] = T) : T = t[28];
        let E;
        t[29] !== x || t[30] !== T ? (E = (0, R.jsxs)(`div`, {
            className: J.actions,
            children: [x, T]
        }), t[29] = x, t[30] = T, t[31] = E) : E = t[31];
        let O;
        t[32] !== E || t[33] !== g ? (O = (0, R.jsxs)(`div`, {
            className: J.card,
            role: `dialog`,
            "aria-modal": `true`,
            "aria-labelledby": `footer-notifications-modal-title`,
            onMouseDown: ce,
            children: [c, g, E]
        }), t[32] = E, t[33] = g, t[34] = O) : O = t[34];
        let k;
        return t[35] !== s || t[36] !== O ? (k = (0, R.jsx)(_, {
            onClick: s,
            children: O
        }), t[35] = s, t[36] = O, t[37] = k) : k = t[37], k
    };

function ce(e) {
    e.stopPropagation(), e.preventDefault()
}
var le = () => {
        let t = (0, I.c)(17),
            {
                gameNotificationsStatus: n,
                setGameNotifications: i,
                openGameNotificationPreferences: a
            } = (0, F.useContext)(s),
            [o, c] = F.useState(!1),
            l;
        t[0] === Symbol.for(`react.memo_cache_sentinel`) ? (l = () => {
            c(!1), d()
        }, t[0] = l) : l = t[0];
        let u = l;
        if (!n) return null;
        let p = n === `on`,
            m;
        t[1] === Symbol.for(`react.memo_cache_sentinel`) ? (m = () => {
            c(!0)
        }, t[1] = m) : m = t[1];
        let h = m,
            g = p ? `tooltip.gameNotificationsOn` : `tooltip.gameNotificationsOff`,
            _;
        t[2] === g ? _ = t[3] : (_ = (0, R.jsx)(w, {
            id: g
        }), t[2] = g, t[3] = _);
        let v;
        t[4] === p ? v = t[5] : (v = (0, R.jsx)(e, {
            onClick: h,
            testId: `footer-notifications-button`,
            children: (0, R.jsx)(r, {
                isOn: p
            })
        }), t[4] = p, t[5] = v);
        let y;
        t[6] !== _ || t[7] !== v ? (y = (0, R.jsx)(f, {
            title: _,
            placement: `top`,
            children: v
        }), t[6] = _, t[7] = v, t[8] = y) : y = t[8];
        let b;
        t[9] !== p || t[10] !== o || t[11] !== a || t[12] !== i ? (b = o && (0, H.createPortal)((0, R.jsx)(se, {
            enabled: p,
            onToggle: e => {
                i(e)
            },
            onManageAllGames: () => {
                c(!1), a()
            },
            onClose: u
        }), document.body), t[9] = p, t[10] = o, t[11] = a, t[12] = i, t[13] = b) : b = t[13];
        let x;
        return t[14] !== y || t[15] !== b ? (x = (0, R.jsxs)(R.Fragment, {
            children: [y, b]
        }), t[14] = y, t[15] = b, t[16] = x) : x = t[16], x
    },
    Y = {
        root: `_root_1egf6_7`,
        rootWithMouse: `_rootWithMouse_1egf6_12`,
        textOnlyContainer: `_textOnlyContainer_1egf6_17`,
        keyboardContainer: `_keyboardContainer_1egf6_44`,
        keyboardKey: `_keyboardKey_1egf6_65`,
        activeKey: `_activeKey_1egf6_78`,
        comboKeyContainer: `_comboKeyContainer_1egf6_82`,
        arrowKey: `_arrowKey_1egf6_103`,
        keyboardLabel: `_keyboardLabel_1egf6_115`,
        keyboardRow: `_keyboardRow_1egf6_121`,
        oddRow: `_oddRow_1egf6_136`,
        keyboardCell: `_keyboardCell_1egf6_140`,
        activeLabel: `_activeLabel_1egf6_154`,
        controlsHeader: `_controlsHeader_1egf6_158`,
        headerRow: `_headerRow_1egf6_165`,
        mouseBody: `_mouseBody_1egf6_166`,
        mouseControlRow: `_mouseControlRow_1egf6_167`,
        headerMouse: `_headerMouse_1egf6_173`,
        headerKeyboard: `_headerKeyboard_1egf6_177`,
        headerDividerCell: `_headerDividerCell_1egf6_181`,
        headerDivider: `_headerDivider_1egf6_181`,
        mouseRoot: `_mouseRoot_1egf6_189`,
        mouseGraphic: `_mouseGraphic_1egf6_202`,
        mouseLabels: `_mouseLabels_1egf6_203`,
        active: `_active_1egf6_78`,
        kids: `_kids_1egf6_221`,
        mouseControlCell: `_mouseControlCell_1egf6_225`,
        mouseButton: `_mouseButton_1egf6_229`,
        mouseBorder: `_mouseBorder_1egf6_233`,
        activeMouseButton: `_activeMouseButton_1egf6_237`,
        mouseMiddleDivider: `_mouseMiddleDivider_1egf6_242`,
        mouseLabel: `_mouseLabel_1egf6_203`
    },
    ue = e => {
        let t = (0, I.c)(6),
            {
                type: n,
                pressedKey: r
            } = e,
            i;
        t[0] === Symbol.for(`react.memo_cache_sentinel`) ? (i = [{
            key: `&#9650;`,
            pressedKey: `arrowup`
        }, {
            key: `&#9664;`,
            pressedKey: `arrowleft`
        }, {
            key: `&#9660;`,
            pressedKey: `arrowdown`
        }, {
            key: `&#9654;`,
            pressedKey: `arrowright`
        }], t[0] = i) : i = t[0];
        let a = i,
            o;
        t[1] === Symbol.for(`react.memo_cache_sentinel`) ? (o = [{
            key: `W`,
            pressedKey: `w`
        }, {
            key: `A`,
            pressedKey: `a`
        }, {
            key: `S`,
            pressedKey: `s`
        }, {
            key: `D`,
            pressedKey: `d`
        }], t[1] = o) : o = t[1];
        let s = o;
        if (n !== `arrows` && n !== `wasd`) return null;
        let c = n === `arrows` ? a : s,
            l;
        return t[2] !== c || t[3] !== r || t[4] !== n ? (l = (0, R.jsx)(`div`, {
            children: (0, R.jsx)(`div`, {
                className: Y.comboKeyContainer,
                children: c.map((e, t) => (0, R.jsx)(`div`, {
                    className: D(Y.keyboardKey, n === `arrows` && Y.arrowKey, r === e.pressedKey && Y.activeKey),
                    dangerouslySetInnerHTML: {
                        __html: e.key
                    }
                }, t))
            })
        }), t[2] = c, t[3] = r, t[4] = n, t[5] = l) : l = t[5], l
    },
    de = class extends F.Component {
        constructor(e) {
            super(e), A(this, `handleKeyboardEvent`, e => {
                this.setState({
                    pressedKey: e && e.type === `keydown` ? e.key.toLowerCase() : null
                })
            }), A(this, `checkPressedKey`, e => this.state.pressedKey !== null && (this.state.pressedKey === e || this.state.pressedKey.includes(`arrow`) && e.includes(`arrow`))), A(this, `checkedPressedKeys`, e => e.some(e => this.checkPressedKey(e.toLowerCase()))), A(this, `convertLabelToSymbol`, e => {
                if (e.toLowerCase().includes(`arrow`)) switch (e.toLowerCase()) {
                    case `arrowup`:
                        return `&#9650;`;
                    case `arrowdown`:
                        return `&#9660;`;
                    case `arrowleft`:
                        return `&#9664;`;
                    case `arrowright`:
                        return `&#9654;`;
                    default:
                        return e
                }
                return e
            }), this.state = {
                pressedKey: null
            }
        }
        componentDidMount() {
            this.props.detectPressedKeys && (document.addEventListener(`keydown`, this.handleKeyboardEvent, !1), document.addEventListener(`keyup`, this.handleKeyboardEvent, !1))
        }
        componentWillUnmount() {
            this.props.detectPressedKeys && (document.removeEventListener(`keydown`, this.handleKeyboardEvent, !1), document.removeEventListener(`keyup`, this.handleKeyboardEvent, !1))
        }
        render() {
            let {
                controls: e,
                hasMouse: t,
                locale: n
            } = this.props;
            return (0, R.jsxs)(`div`, {
                className: D(Y.root, t && Y.rootWithMouse),
                children: [(0, R.jsxs)(`div`, {
                    className: Y.headerRow,
                    children: [(0, R.jsx)(`div`, {
                        className: Y.headerKeyboard,
                        children: (0, R.jsx)(`div`, {
                            className: Y.controlsHeader,
                            children: (0, R.jsx)(w, {
                                id: `gameControls.keyboard`
                            })
                        })
                    }), (0, R.jsx)(`div`, {
                        className: Y.headerDividerCell,
                        children: (0, R.jsx)(`hr`, {
                            className: Y.headerDivider
                        })
                    })]
                }), (0, R.jsx)(`div`, {
                    className: Y.keyboardContainer,
                    children: e.map((e, t) => {
                        let r = n || `en_US`,
                            i = e.label[r] || e.label.en_US || ``;
                        return (0, R.jsxs)(`div`, {
                            className: D(Y.keyboardRow, t % 2 && Y.oddRow),
                            children: [(0, R.jsx)(`div`, {
                                className: Y.keyboardCell,
                                children: e.keys.map((e, t) => e.toLowerCase() === `wasd` || e.toLowerCase() === `arrows` ? (0, R.jsx)(ue, {
                                    type: e.toLowerCase(),
                                    pressedKey: this.state.pressedKey
                                }, t) : (0, R.jsx)(`div`, {
                                    className: D(Y.keyboardKey, this.state.pressedKey && this.checkPressedKey(e.toLowerCase()) && Y.activeKey),
                                    dangerouslySetInnerHTML: {
                                        __html: this.convertLabelToSymbol(e)
                                    }
                                }, t))
                            }), (0, R.jsx)(`div`, {
                                className: D(Y.keyboardCell, Y.keyboardLabel, e.keys.some(e => this.checkPressedKey(e.toLowerCase())) && Y.activeLabel),
                                children: i
                            })]
                        }, t)
                    })
                })]
            })
        }
    },
    fe = e => {
        let t = (0, I.c)(50),
            n = e.height,
            r;
        t[0] === Symbol.for(`react.memo_cache_sentinel`) ? (r = (0, R.jsx)(`path`, {
            id: `MouseSvgBorder`,
            className: Y.mouseBorder,
            d: `M76 53.438v23.46c0 19.356-16.2 35.192-36 35.192S4 96.254 4 76.899V39.1C4 20.44 19.062 5.054 37.889 3.977c.699-.04 1.402-.067 2.11-.067.635 0 1.264.017 1.89.049 18.93.969 34.11 16.406 34.11 35.142v14.337zM40 0c-.708 0-1.412.02-2.111.055C16.81 1.132-.001 18.234-.001 39.101v37.797c0 9.616 3.57 18.43 9.48 25.248 7.343 8.47 18.3 13.854 30.52 13.854 22.057 0 40-17.54 40-39.101V39.1C80 18.16 63.072 1.015 41.89.047A41.248 41.248 0 0 0 39.999 0z`
        }), t[0] = r) : r = t[0];
        let i = e.hasRight ? 1 : .5,
            a = e.hasRight && Y.activeMouseButton,
            o;
        t[1] === a ? o = t[2] : (o = D(Y.mouseButton, a), t[1] = a, t[2] = o);
        let s;
        t[3] === e ? s = t[4] : (s = e.hasRight ? () => e.mouseEnter(`right`) : void 0, t[3] = e, t[4] = s);
        let c;
        t[5] === e ? c = t[6] : (c = e.hasRight ? () => e.mouseLeave() : void 0, t[5] = e, t[6] = c);
        let l;
        t[7] !== i || t[8] !== o || t[9] !== s || t[10] !== c ? (l = (0, R.jsx)(`path`, {
            id: `MouseSvgRightButton`,
            opacity: i,
            className: o,
            d: `M41 8v23.156c4.56.87 8.008 4.733 8.008 9.355V54H72V39.524C72 22.735 58.263 8.969 41 8`,
            onMouseEnter: s,
            onMouseLeave: c
        }), t[7] = i, t[8] = o, t[9] = s, t[10] = c, t[11] = l) : l = t[11];
        let u = e.hasLeft ? 1 : .5,
            d = e.hasLeft && Y.activeMouseButton,
            f;
        t[12] === d ? f = t[13] : (f = D(Y.mouseButton, d), t[12] = d, t[13] = f);
        let p;
        t[14] === e ? p = t[15] : (p = e.hasLeft ? () => e.mouseEnter(`left`) : void 0, t[14] = e, t[15] = p);
        let m;
        t[16] === e ? m = t[17] : (m = e.hasLeft ? () => e.mouseLeave() : void 0, t[16] = e, t[17] = m);
        let h;
        t[18] !== f || t[19] !== p || t[20] !== m || t[21] !== u ? (h = (0, R.jsx)(`path`, {
            id: `MouseSvgLeftButton`,
            opacity: u,
            className: f,
            d: `M37 8C20.832 9.078 8 22.798 8 39.519V54h21.67V40.506c0-4.546 3.141-8.354 7.33-9.308V8z`,
            onMouseEnter: p,
            onMouseLeave: m
        }), t[18] = f, t[19] = p, t[20] = m, t[21] = u, t[22] = h) : h = t[22];
        let g = e.hasMiddle ? 1 : .5,
            _ = e.hasMiddle && Y.activeMouseButton,
            v;
        t[23] === _ ? v = t[24] : (v = D(Y.mouseButton, _), t[23] = _, t[24] = v);
        let y;
        t[25] === e ? y = t[26] : (y = e.hasMiddle ? () => e.mouseEnter(`middle`) : void 0, t[25] = e, t[26] = y);
        let b;
        t[27] === e ? b = t[28] : (b = e.hasMiddle ? () => e.mouseLeave() : void 0, t[27] = e, t[28] = b);
        let x, S;
        t[29] === Symbol.for(`react.memo_cache_sentinel`) ? (x = (0, R.jsx)(`path`, {
            d: `M39.5 35c-3.033 0-5.5 2.04-5.5 4.547V53.453C34 55.96 36.467 58 39.5 58s5.5-2.04 5.5-4.547V39.547C45 37.04 42.533 35 39.5 35`
        }), S = (0, R.jsx)(`path`, {
            className: Y.mouseMiddleDivider,
            strokeLinecap: `square`,
            d: `M40 68V51.5`
        }), t[29] = x, t[30] = S) : (x = t[29], S = t[30]);
        let C;
        t[31] !== g || t[32] !== v || t[33] !== y || t[34] !== b ? (C = (0, R.jsxs)(`g`, {
            fillRule: `evenodd`,
            id: `MouseSvgMiddleButton`,
            opacity: g,
            className: v,
            onMouseEnter: y,
            onMouseLeave: b,
            children: [x, S]
        }), t[31] = g, t[32] = v, t[33] = y, t[34] = b, t[35] = C) : C = t[35];
        let w;
        t[36] === e.hasLeft ? w = t[37] : (w = e.hasLeft && (0, R.jsx)(`text`, {
            className: Y.mouseLabel,
            children: (0, R.jsx)(`tspan`, {
                x: `21.322`,
                y: `32`,
                children: `1`
            })
        }), t[36] = e.hasLeft, t[37] = w);
        let T;
        t[38] === e.hasRight ? T = t[39] : (T = e.hasRight && (0, R.jsx)(`text`, {
            className: Y.mouseLabel,
            children: (0, R.jsx)(`tspan`, {
                x: `51.6`,
                y: `32`,
                children: `2`
            })
        }), t[38] = e.hasRight, t[39] = T);
        let E;
        t[40] === e.hasMiddle ? E = t[41] : (E = e.hasMiddle && (0, R.jsx)(`text`, {
            className: Y.mouseLabel,
            children: (0, R.jsx)(`tspan`, {
                x: `36.873`,
                y: `83`,
                children: `3`
            })
        }), t[40] = e.hasMiddle, t[41] = E);
        let O;
        return t[42] !== e.height || t[43] !== h || t[44] !== C || t[45] !== w || t[46] !== T || t[47] !== E || t[48] !== l ? (O = (0, R.jsxs)(`svg`, {
            xmlns: `http://www.w3.org/2000/svg`,
            width: `80`,
            height: n,
            viewBox: `0 0 80 116`,
            children: [r, l, h, C, w, T, E]
        }), t[42] = e.height, t[43] = h, t[44] = C, t[45] = w, t[46] = T, t[47] = E, t[48] = l, t[49] = O) : O = t[49], O
    },
    pe = class extends F.Component {
        constructor(e) {
            super(e), A(this, `mouseEnterMouseControls`, e => {
                this.setState({
                    hoveredButton: e
                })
            }), A(this, `mouseLeaveMouseControls`, () => {
                this.setState({
                    hoveredButton: null
                })
            }), A(this, `mouseEnterLabelControls`, e => {
                this.setState({
                    hoveredLabel: e
                })
            }), A(this, `mouseLeaveLabelControls`, () => {
                this.setState({
                    hoveredLabel: null
                })
            }), this.state = {
                hoveredButton: null,
                hoveredLabel: null
            }
        }
        render() {
            let {
                controls: e,
                locale: t
            } = this.props;
            return (0, R.jsxs)(`div`, {
                className: D(Y.mouseRoot, {
                    [Y.kids]: j()
                }),
                children: [(0, R.jsxs)(`div`, {
                    className: Y.headerRow,
                    children: [(0, R.jsx)(`div`, {
                        className: Y.headerMouse,
                        children: (0, R.jsx)(`div`, {
                            className: Y.controlsHeader,
                            children: (0, R.jsx)(w, {
                                id: `gameControls.mouse`
                            })
                        })
                    }), (0, R.jsx)(`div`, {
                        className: Y.headerDividerCell,
                        children: (0, R.jsx)(`hr`, {
                            className: Y.headerDivider
                        })
                    })]
                }), (0, R.jsxs)(`div`, {
                    className: Y.mouseBody,
                    children: [(0, R.jsx)(`div`, {
                        className: Y.mouseGraphic,
                        children: (0, R.jsx)(fe, {
                            height: `100%`,
                            active: this.state.hoveredLabel,
                            hasLeft: !!e.left,
                            hasRight: !!e.right,
                            hasMiddle: !!e.middle,
                            mouseEnter: this.mouseEnterMouseControls,
                            mouseLeave: this.mouseLeaveMouseControls
                        })
                    }), (0, R.jsx)(`div`, {
                        className: Y.mouseLabels,
                        children: Object.keys(e).map(n => {
                            let r = t || `en_US`,
                                i = e[n],
                                a = v(i) && (i[r] || i.en_US) || ``,
                                o = this.state.hoveredButton === n;
                            return (0, R.jsxs)(`div`, {
                                className: D(Y.mouseControlRow, o && Y.active),
                                onMouseEnter: () => this.mouseEnterLabelControls(n),
                                onMouseLeave: this.mouseLeaveLabelControls,
                                children: [(0, R.jsx)(`div`, {
                                    className: Y.mouseControlCell,
                                    children: this.convertLabelToNumber(n)
                                }), (0, R.jsx)(`div`, {
                                    className: Y.mouseControlCell,
                                    children: a
                                })]
                            }, n)
                        })
                    })]
                })]
            })
        }
        convertLabelToNumber(e) {
            switch (e) {
                case `right`:
                    return 2;
                case `middle`:
                    return 3;
                default:
                    return 1
            }
        }
    };

function X(e, t, n) {
    let r = (0, I.c)(5),
        i = (0, F.useRef)(null),
        a, o;
    return r[0] !== e || r[1] !== n || r[2] !== t ? (a = () => {
        if (!e) return;
        let r = e => {
            let r = e.target;
            r instanceof Node && (i.current ? .contains(r) || n && e.composedPath().some(e => e instanceof Element && e.matches(n)) || t(e))
        };
        return document.addEventListener(`mousedown`, r), document.addEventListener(`touchstart`, r), () => {
            document.removeEventListener(`mousedown`, r), document.removeEventListener(`touchstart`, r)
        }
    }, o = [e, t, n], r[0] = e, r[1] = n, r[2] = t, r[3] = a, r[4] = o) : (a = r[3], o = r[4]), (0, F.useEffect)(a, o), i
}
var Z = {
        root: `_root_3f8zm_23`,
        "slide-up": `_slide-up_3f8zm_1`,
        entered: `_entered_3f8zm_38`,
        exiting: `_exiting_3f8zm_42`,
        "slide-down": `_slide-down_3f8zm_1`,
        surface: `_surface_3f8zm_46`,
        closeButton: `_closeButton_3f8zm_55`,
        closeAtTop: `_closeAtTop_3f8zm_71`,
        closeIcon: `_closeIcon_3f8zm_75`,
        backdrop: `_backdrop_3f8zm_79`
    },
    me = e => {
        let t = (0, I.c)(9),
            {
                controls: n
            } = e,
            r;
        t[0] === Symbol.for(`react.memo_cache_sentinel`) ? (r = T.getLocale(), t[0] = r) : r = t[0];
        let i = r,
            a;
        t[1] === n.mouse ? a = t[2] : (a = n.mouse && (0, R.jsx)(pe, {
            controls: n.mouse,
            locale: i
        }), t[1] = n.mouse, t[2] = a);
        let o;
        t[3] !== n.keyboard || t[4] !== n.mouse ? (o = n.keyboard && (0, R.jsx)(de, {
            controls: n.keyboard,
            detectPressedKeys: !1,
            hasMouse: !!n.mouse,
            locale: i
        }), t[3] = n.keyboard, t[4] = n.mouse, t[5] = o) : o = t[5];
        let s;
        return t[6] !== a || t[7] !== o ? (s = (0, R.jsxs)(R.Fragment, {
            children: [a, o]
        }), t[6] = a, t[7] = o, t[8] = s) : s = t[8], s
    },
    he = e => {
        let t = (0, I.c)(32),
            {
                controls: n,
                close: r,
                showControlsEntered: i,
                exiting: a,
                onEntered: o
            } = e,
            s;
        t[0] !== n.keyboard || t[1] !== n.mouse ? (s = () => n.mouse !== void 0 || n.keyboard !== void 0, t[0] = n.keyboard, t[1] = n.mouse, t[2] = s) : s = t[2];
        let c = s,
            l;
        t[3] !== n.text || t[4] !== c ? (l = () => !c() && !!n.text, t[3] = n.text, t[4] = c, t[5] = l) : l = t[5];
        let u = l,
            d;
        t[6] === r ? d = t[7] : (d = () => {
            r ? .()
        }, t[6] = r, t[7] = d);
        let f = X(!0, d, `#game-controls-toggle-button`),
            p = i && Z.entered,
            m = a && Z.exiting,
            h;
        t[8] !== p || t[9] !== m ? (h = D(Z.root, p, m), t[8] = p, t[9] = m, t[10] = h) : h = t[10];
        let g;
        t[11] !== a || t[12] !== o ? (g = e => {
            e.target === e.currentTarget && !a && o ? .()
        }, t[11] = a, t[12] = o, t[13] = g) : g = t[13];
        let _;
        t[14] !== r || t[15] !== u ? (_ = r && (0, R.jsx)(`button`, {
            type: `button`,
            onClick: r,
            className: D(Z.closeButton, u() && Z.closeAtTop),
            children: (0, R.jsx)(b, {
                name: `close`,
                size: 24,
                className: Z.closeIcon
            })
        }), t[14] = r, t[15] = u, t[16] = _) : _ = t[16];
        let v;
        t[17] !== n || t[18] !== c ? (v = c() && (0, R.jsx)(me, {
            controls: n
        }), t[17] = n, t[18] = c, t[19] = v) : v = t[19];
        let y;
        t[20] !== n.text || t[21] !== u ? (y = u() && (0, R.jsx)(`div`, {
            className: Y.textOnlyContainer,
            children: (0, R.jsx)(`div`, {
                dangerouslySetInnerHTML: {
                    __html: n.text
                },
                onMouseDown: _e
            })
        }), t[20] = n.text, t[21] = u, t[22] = y) : y = t[22];
        let x;
        t[23] !== y || t[24] !== v ? (x = (0, R.jsxs)(`div`, {
            className: Z.surface,
            onMouseDown: ge,
            children: [v, y]
        }), t[23] = y, t[24] = v, t[25] = x) : x = t[25];
        let S;
        return t[26] !== f || t[27] !== x || t[28] !== h || t[29] !== g || t[30] !== _ ? (S = (0, R.jsxs)(`div`, {
            ref: f,
            id: `game-controls`,
            className: h,
            onAnimationEnd: g,
            children: [_, x]
        }), t[26] = f, t[27] = x, t[28] = h, t[29] = g, t[30] = _, t[31] = S) : S = t[31], S
    };

function ge(e) {
    e.stopPropagation(), e.preventDefault()
}

function _e(e) {
    e.stopPropagation(), e.preventDefault()
}
var ve = F.memo(() => {
        let t = (0, I.c)(19),
            [n, r] = F.useState(!1),
            [i, a] = F.useState(!1),
            {
                mounted: s,
                exiting: c
            } = o(n),
            l;
        t[0] === Symbol.for(`react.memo_cache_sentinel`) ? (l = k(), t[0] = l) : l = t[0];
        let p = l,
            m, h;
        t[1] === n ? (m = t[2], h = t[3]) : (m = () => {
            n || a(!1)
        }, h = [n], t[1] = n, t[2] = m, t[3] = h), F.useEffect(m, h);
        let g;
        t[4] !== c || t[5] !== s || t[6] !== i ? (g = () => {
            if (!s) return null;
            let {
                controls: e
            } = p;
            return (0, R.jsxs)(R.Fragment, {
                children: [(0, R.jsx)(he, {
                    close: () => {
                        r(!1), a(!1), d()
                    },
                    controls: e,
                    showControlsEntered: i,
                    exiting: c,
                    onEntered: () => a(!0)
                }), i && (0, R.jsx)(`div`, {
                    className: Z.backdrop
                })]
            })
        }, t[4] = c, t[5] = s, t[6] = i, t[7] = g) : g = t[7];
        let _ = g,
            v;
        t[8] === n ? v = t[9] : (v = () => {
            let e = !n;
            r(e), u.getInstance().userAction(`footer`, `controls`, e ? `open` : `close`)
        }, t[8] = n, t[9] = v);
        let y = v,
            b;
        t[10] === _ ? b = t[11] : (b = _(), t[10] = _, t[11] = b);
        let x;
        t[12] === Symbol.for(`react.memo_cache_sentinel`) ? (x = (0, R.jsx)(w, {
            id: `tooltip.gameControls`
        }), t[12] = x) : x = t[12];
        let S;
        t[13] !== n || t[14] !== y ? (S = (0, R.jsx)(f, {
            title: x,
            placement: `top`,
            children: (0, R.jsx)(e, {
                icon: `controls`,
                onClick: y,
                isActive: n,
                id: `game-controls-toggle-button`
            })
        }), t[13] = n, t[14] = y, t[15] = S) : S = t[15];
        let C;
        return t[16] !== b || t[17] !== S ? (C = (0, R.jsxs)(R.Fragment, {
            children: [b, S]
        }), t[16] = b, t[17] = S, t[18] = C) : C = t[18], C
    }),
    ye = F.memo(() => {
        let t = (0, I.c)(6),
            {
                isFullscreen: n,
                disableFullscreen: r
            } = F.useContext(m),
            i;
        t[0] !== r || t[1] !== n ? (i = () => {
            n && r(), h.feedback(`feedbackButton`)
        }, t[0] = r, t[1] = n, t[2] = i) : i = t[2];
        let a = i,
            o;
        t[3] === Symbol.for(`react.memo_cache_sentinel`) ? (o = (0, R.jsx)(w, {
            id: `tooltip.feedback`
        }), t[3] = o) : o = t[3];
        let s;
        return t[4] === a ? s = t[5] : (s = (0, R.jsx)(R.Fragment, {
            children: (0, R.jsx)(f, {
                title: o,
                placement: `top`,
                children: (0, R.jsx)(e, {
                    icon: `feedback`,
                    onClick: a,
                    testId: `footer-feedback-button`
                })
            })
        }), t[4] = a, t[5] = s), s
    }),
    be = F.memo(() => {
        let t = (0, I.c)(5),
            {
                isFullscreen: n,
                disableFullscreen: r,
                requestFullscreen: i
            } = F.useContext(m),
            a, o;
        if (t[0] !== r || t[1] !== n || t[2] !== i) {
            o = Symbol.for(`react.early_return_sentinel`);
            bb0: {
                let t = k(),
                    s = () => {
                        let {
                            fullscreen: e
                        } = t;
                        return e && e !== `NOT_SUPPORTED`
                    };
                if (!s()) {
                    o = null;
                    break bb0
                }
                a = s() ? (0, R.jsx)(f, {
                    title: (0, R.jsx)(w, {
                        id: n ? `tooltip.exitFullScreen` : `tooltip.fullScreen`
                    }),
                    placement: `top`,
                    children: (0, R.jsx)(e, {
                        icon: n ? `reduce` : `expand`,
                        onClick: () => {
                            u.getInstance().userAction(`footer`, `fullscreen`, n ? `exit` : `enter`), n ? r() : i()
                        },
                        testId: `footer-fullscreen-button`
                    })
                }) : null
            }
            t[0] = r, t[1] = n, t[2] = i, t[3] = a, t[4] = o
        } else a = t[3], o = t[4];
        return o === Symbol.for(`react.early_return_sentinel`) ? a : o
    }),
    xe = F.lazy(() => N(() =>
        import (`./Bduyu5g32.js`), [],
        import.meta.url)),
    Q = e => {
        let t = (0, I.c)(27),
            {
                close: n,
                slideEntered: r,
                exiting: i,
                onEntered: a
            } = e,
            o;
        t[0] === Symbol.for(`react.memo_cache_sentinel`) ? (o = k(), t[0] = o) : o = t[0];
        let s = o,
            c;
        t[1] === n ? c = t[2] : (c = () => {
            n ? .()
        }, t[1] = n, t[2] = c);
        let l = X(!0, c, `#qr-modal-toggle-button`),
            u;
        bb0: {
            if (!r && !i) {
                u = null;
                break bb0
            }
            let e;
            if (t[3] === Symbol.for(`react.memo_cache_sentinel`)) {
                let n = new URL(s.gameLink),
                    r = n.searchParams.get(`gameBuildId`);
                n.search = ``, r && n.searchParams.set(`gameBuildId`, r), n.searchParams.set(`utm_source`, `mobile-qr-code`), n.searchParams.set(`force_app_banner`, `true`), e = n.toString(), t[3] = e
            } else e = t[3];u = e
        }
        let d = u,
            f = r && Z.entered,
            p = i && Z.exiting,
            m;
        t[4] !== f || t[5] !== p ? (m = D(Z.root, f, p), t[4] = f, t[5] = p, t[6] = m) : m = t[6];
        let h;
        t[7] !== i || t[8] !== a ? (h = e => {
            e.target === e.currentTarget && !i && a ? .()
        }, t[7] = i, t[8] = a, t[9] = h) : h = t[9];
        let g;
        t[10] === n ? g = t[11] : (g = n && (0, R.jsx)(`button`, {
            type: `button`,
            onClick: n,
            className: D(Z.closeButton, Z.closeAtTop),
            children: (0, R.jsx)(b, {
                name: `close`,
                size: 24,
                className: Z.closeIcon
            })
        }), t[10] = n, t[11] = g);
        let _;
        t[12] === Symbol.for(`react.memo_cache_sentinel`) ? (_ = (0, R.jsx)(M, {
            tone: `neutral`,
            className: P.progress
        }), t[12] = _) : _ = t[12];
        let v;
        t[13] === d ? v = t[14] : (v = d && (0, R.jsx)(xe, {
            link: d
        }), t[13] = d, t[14] = v);
        let y;
        t[15] === v ? y = t[16] : (y = (0, R.jsx)(`div`, {
            className: P.code,
            children: (0, R.jsx)(F.Suspense, {
                fallback: _,
                children: v
            })
        }), t[15] = v, t[16] = y);
        let x;
        t[17] === Symbol.for(`react.memo_cache_sentinel`) ? (x = (0, R.jsx)(`div`, {
            className: P.title,
            children: (0, R.jsx)(E, {
                id: `qrMobileModal.title`
            })
        }), t[17] = x) : x = t[17];
        let S;
        t[18] === Symbol.for(`react.memo_cache_sentinel`) ? (S = (0, R.jsx)(`div`, {
            className: P.subtitle,
            children: (0, R.jsx)(E, {
                id: `qrMobileModal.subtitle`,
                values: {
                    gameTitle: (0, R.jsx)(`span`, {
                        className: P.gameTitle,
                        children: s.gameName
                    })
                }
            })
        }), t[18] = S) : S = t[18];
        let C;
        t[19] === y ? C = t[20] : (C = (0, R.jsx)(`div`, {
            className: Z.surface,
            children: (0, R.jsxs)(`div`, {
                className: P.container,
                onMouseDown: Se,
                children: [y, x, S]
            })
        }), t[19] = y, t[20] = C);
        let w;
        return t[21] !== l || t[22] !== C || t[23] !== m || t[24] !== h || t[25] !== g ? (w = (0, R.jsxs)(`div`, {
            ref: l,
            className: m,
            id: `qr-modal`,
            onAnimationEnd: h,
            children: [g, C]
        }), t[21] = l, t[22] = C, t[23] = m, t[24] = h, t[25] = g, t[26] = w) : w = t[26], w
    };

function Se(e) {
    e.stopPropagation(), e.preventDefault()
}
var $ = (e, t) => {
        u.getInstance().sendEvent({
            type: `modal`,
            campaign: `PlayOnApp`,
            action: e,
            target: `playOnApp_gameframe`,
            clickOrigin: t
        })
    },
    Ce = F.memo(() => {
        let t = (0, I.c)(22),
            [n, r] = F.useState(!1),
            [i, a] = F.useState(!1),
            {
                mounted: s,
                exiting: c
            } = o(n),
            l, u;
        t[0] === n ? (l = t[1], u = t[2]) : (l = () => {
            n || a(!1)
        }, u = [n], t[0] = n, t[1] = l, t[2] = u), F.useEffect(l, u);
        let p, m;
        t[3] === n ? (p = t[4], m = t[5]) : (p = () => {
            let e = e => {
                e.data ? .type === `showQrCodePopup` && !n && (r(!0), $(`clicked`, `gameframe`))
            };
            return window.addEventListener(`message`, e), () => {
                window.removeEventListener(`message`, e)
            }
        }, m = [n], t[3] = n, t[4] = p, t[5] = m), F.useEffect(p, m);
        let h;
        t[6] === Symbol.for(`react.memo_cache_sentinel`) ? (h = () => {
            r(!1), a(!1), d(), $(`closed`, `playOnApp_gameframe`)
        }, t[6] = h) : h = t[6];
        let g = h,
            _;
        t[7] !== c || t[8] !== s || t[9] !== i ? (_ = () => s ? (0, R.jsxs)(R.Fragment, {
            children: [(0, R.jsx)(Q, {
                close: g,
                slideEntered: i,
                exiting: c,
                onEntered: () => a(!0)
            }), i && (0, R.jsx)(`div`, {
                className: Z.backdrop,
                id: `qr-modal-backdrop`
            })]
        }) : null, t[7] = c, t[8] = s, t[9] = i, t[10] = _) : _ = t[10];
        let v = _,
            y;
        t[11] === n ? y = t[12] : (y = () => {
            n ? $(`closed`, `playOnApp_gameframe`) : $(`clicked`, `gameframe`), r(!n)
        }, t[11] = n, t[12] = y);
        let b = y,
            x;
        t[13] === v ? x = t[14] : (x = v(), t[13] = v, t[14] = x);
        let S;
        t[15] === Symbol.for(`react.memo_cache_sentinel`) ? (S = (0, R.jsx)(w, {
            id: `tooltip.QRPlayOnMobile`
        }), t[15] = S) : S = t[15];
        let C;
        t[16] !== n || t[17] !== b ? (C = (0, R.jsx)(f, {
            title: S,
            placement: `top`,
            children: (0, R.jsx)(e, {
                icon: `phone`,
                onClick: b,
                isActive: n,
                id: `qr-modal-toggle-button`
            })
        }), t[16] = n, t[17] = b, t[18] = C) : C = t[18];
        let T;
        return t[19] !== x || t[20] !== C ? (T = (0, R.jsxs)(R.Fragment, {
            children: [x, C]
        }), t[19] = x, t[20] = C, t[21] = T) : T = t[21], T
    }),
    we = F.memo(e => {
        let r = (0, I.c)(23),
            {
                initialRating: a
            } = e,
            o;
        r[0] === Symbol.for(`react.memo_cache_sentinel`) ? (o = c.isEmbeddedExternally(), r[0] = o) : o = r[0];
        let s = o,
            l, u, d, f, p, m, h;
        if (r[1] !== a) {
            let e = k(),
                t = () => e.source === `standalone-qa` || e.source === `qa` ? !1 : !j() && !s,
                o;
            r[9] === Symbol.for(`react.memo_cache_sentinel`) ? (o = () => !j() && !s, r[9] = o) : o = r[9];
            let c = o;
            l = i.toolbar, r[10] === Symbol.for(`react.memo_cache_sentinel`) ? (u = (0, R.jsx)(ae, {}), r[10] = u) : u = r[10], d = t() && (0, R.jsxs)(R.Fragment, {
                children: [(0, R.jsx)(V, {
                    initialRating: a
                }), (0, R.jsx)(q, {}), (0, R.jsx)(le, {})]
            }), r[11] === Symbol.for(`react.memo_cache_sentinel`) ? (f = (0, R.jsx)(n, {}), p = c() && (0, R.jsx)(ye, {}), r[11] = f, r[12] = p) : (f = r[11], p = r[12]), m = !j() && e.controls && Object.keys(e.controls).length > 0 && (0, R.jsx)(ve, {}), h = !te() && (e.androidFriendly || e.iosFriendly) && (0, R.jsx)(Ce, {}), r[1] = a, r[2] = l, r[3] = u, r[4] = d, r[5] = f, r[6] = p, r[7] = m, r[8] = h
        } else l = r[2], u = r[3], d = r[4], f = r[5], p = r[6], m = r[7], h = r[8];
        let g, _;
        r[13] === Symbol.for(`react.memo_cache_sentinel`) ? (_ = (0, R.jsx)(t, {}), g = (0, R.jsx)(be, {}), r[13] = g, r[14] = _) : (g = r[13], _ = r[14]);
        let v;
        return r[15] !== l || r[16] !== u || r[17] !== d || r[18] !== f || r[19] !== p || r[20] !== m || r[21] !== h ? (v = (0, R.jsxs)(`div`, {
            className: l,
            children: [u, d, f, p, m, h, _, g]
        }), r[15] = l, r[16] = u, r[17] = d, r[18] = f, r[19] = p, r[20] = m, r[21] = h, r[22] = v) : v = r[22], v
    });
export {
    we as
    default
};
//# debugId=b32643d4-3d36-587c-9fe8-54be7504c28d
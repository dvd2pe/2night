(function() {
    'use strict';
    var q, aa = Object.defineProperty;

    function ba(a) {
        a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
        for (var b = 0; b < a.length; ++b) {
            var c = a[b];
            if (c && c.Math == Math) return c
        }
        throw Error("Cannot find global object");
    }
    var ca = ba(this);

    function ea(a, b) {
        if (b) a: {
            var c = ca;a = a.split(".");
            for (var d = 0; d < a.length - 1; d++) {
                var e = a[d];
                if (!(e in c)) break a;
                c = c[e]
            }
            a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && aa(c, a, {
                configurable: !0,
                writable: !0,
                value: b
            })
        }
    }
    ea("globalThis", function(a) {
        return a || ca
    });
    ea("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    });
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var fa = fa || {},
        r = this || self;

    function ha(a, b) {
        a = a.split(".");
        b = b || r;
        for (var c = 0; c < a.length; c++)
            if (b = b[a[c]], b == null) return null;
        return b
    }

    function ia(a) {
        var b = typeof a;
        return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
    }

    function la(a) {
        var b = ia(a);
        return b == "array" || b == "object" && typeof a.length == "number"
    }

    function ma(a) {
        var b = typeof a;
        return b == "object" && a != null || b == "function"
    }

    function na(a) {
        a !== null && "removeAttribute" in a && a.removeAttribute(pa);
        try {
            delete a[pa]
        } catch (b) {}
    }
    var pa = "closure_uid_" + (Math.random() * 1E9 >>> 0),
        qa = 0;

    function ra(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    }

    function t(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.ma = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a;
        a.Nc = function(d, e, f) {
            for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
            return b.prototype[e].apply(d, g)
        }
    };

    function sa(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, sa);
        else {
            let c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        b !== void 0 && (this.cause = b)
    }
    t(sa, Error);
    sa.prototype.name = "CustomError";
    var ta;

    function va(a) {
        r.setTimeout(() => {
            throw a;
        }, 0)
    };
    var wa, xa = ha("CLOSURE_FLAGS"),
        ya = xa && xa[748402147];
    wa = ya != null ? ya : !0;

    function za(a, b) {
        return a.toLowerCase().indexOf(b.toLowerCase()) != -1
    };

    function Aa() {
        var a = r.navigator;
        return a && (a = a.userAgent) ? a : ""
    }

    function u(a) {
        return Aa().indexOf(a) != -1
    };

    function Ba() {
        return u("iPhone") && !u("iPod") && !u("iPad")
    };

    function Ca(a, b) {
        Array.prototype.forEach.call(a, b, void 0)
    }

    function Da(a, b) {
        return Array.prototype.some.call(a, b, void 0)
    }

    function Ea(a, b) {
        b = Array.prototype.indexOf.call(a, b, void 0);
        var c;
        (c = b >= 0) && Array.prototype.splice.call(a, b, 1);
        return c
    }

    function Fa(a) {
        var b = a.length;
        if (b > 0) {
            let c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };

    function Ga(a) {
        Ga[" "](a);
        return a
    }
    Ga[" "] = function() {};
    var Ha = u("Trident") || u("MSIE"),
        Ia = u("Gecko") && !(za(Aa(), "WebKit") && !u("Edge")) && !(u("Trident") || u("MSIE")) && !u("Edge"),
        Ja = za(Aa(), "WebKit") && !u("Edge"),
        Ka = Ba() || u("iPad") || u("iPod");
    var La = u("Firefox") || u("FxiOS"),
        Ma = u("Android") && !((u("Chrome") || u("CriOS")) && !u("Edge") || u("Silk") || u("Firefox") || u("FxiOS") || u("Opera") || u("Silk"));
    var Na = {},
        Oa = null;

    function Pa() {
        return typeof BigInt === "function"
    };

    function Qa(a) {
        a.Xc = !0;
        return a
    }
    var Ra = Qa(function(a) {
        return a !== null && a !== void 0
    });
    var Sa = Qa(a => typeof a === "number"),
        Ta = Qa(a => typeof a === "string"),
        Ua = Qa(a => typeof a === "boolean");
    var Va = typeof r.BigInt === "function" && typeof r.BigInt(0) === "bigint";

    function Wa(a) {
        var b = a;
        if (Ta(b)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error(String(b));
        } else if (Sa(b) && !Number.isSafeInteger(b)) throw Error(String(b));
        return Va ? BigInt(a) : a = Ua(a) ? a ? "1" : "0" : Ta(a) ? a.trim() || "0" : String(a)
    }
    var bb = Qa(a => Va ? a >= Xa && a <= Ya : a[0] === "-" ? Za(a, $a) : Za(a, ab)),
        $a = Number.MIN_SAFE_INTEGER.toString(),
        Xa = Va ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
        ab = Number.MAX_SAFE_INTEGER.toString(),
        Ya = Va ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;

    function Za(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (let c = 0; c < a.length; c++) {
            let d = a[c],
                e = b[c];
            if (d > e) return !1;
            if (d < e) return !0
        }
    };
    var v = 0,
        cb = 0;

    function db(a) {
        var b = a >>> 0;
        v = b;
        cb = (a - b) / 4294967296 >>> 0
    }

    function eb(a) {
        if (a < 0) {
            db(0 - a);
            let [b, c] = fb(v, cb);
            v = b >>> 0;
            cb = c >>> 0
        } else db(a)
    }

    function gb(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (b <= 2097151) var c = "" + (4294967296 * b + a);
        else Pa() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + c * 6777216 + b * 6710656, c += b * 8147497, b *= 2, a >= 1E7 && (c += a / 1E7 >>> 0, a %= 1E7), c >= 1E7 && (b += c / 1E7 >>> 0, c %= 1E7), c = b + hb(c) + hb(a));
        return c
    }

    function hb(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    }

    function ib() {
        var a = v,
            b = cb;
        if (b & 2147483648)
            if (Pa()) a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0));
            else {
                let [c, d] = fb(a, b);
                a = "-" + gb(c, d)
            }
        else a = gb(a, b);
        return a
    }

    function fb(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };

    function jb(a, b = !1) {
        return b && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol()
    }
    var kb = jb(),
        lb = jb(),
        mb = jb(),
        nb = jb("m_m", !0);
    var w = jb("jas", !0),
        ob, pb = [];
    pb[w] = 7;
    ob = Object.freeze(pb);

    function qb(a) {
        if (4 & a) return 512 & a ? 512 : 1024 & a ? 1024 : 0
    }

    function rb(a) {
        a[w] |= 34;
        return a
    }

    function sb(a) {
        a[w] |= 8192;
        return a
    }

    function tb(a) {
        a[w] |= 32;
        return a
    }

    function ub(a, b) {
        2 & b && (a |= 2);
        return a | 1
    };
    var vb = {};

    function z(a, b) {
        return b === void 0 ? a.i !== wb && !!(2 & (a.O[w] | 0)) : !!(2 & b) && a.i !== wb
    }
    var wb = {};
    class xb {
        constructor(a, b, c) {
            this.i = a;
            this.o = b;
            this.l = c
        }
        next() {
            var a = this.i.next();
            a.done || (a.value = this.o.call(this.l, a.value));
            return a
        }[Symbol.iterator]() {
            return this
        }
    }
    Object.freeze({});
    Object.freeze({});

    function yb(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var zb = void 0;

    function Ab(a) {
        a = Error(a);
        yb(a, "warning");
        return a
    };

    function Bb(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };
    var Cb = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        Db = Number.isSafeInteger,
        Eb = Number.isFinite,
        Fb = Math.trunc;

    function Gb(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function Hb(a) {
        if (typeof a !== "boolean") throw Error(`Expected boolean but got ${ia(a)}: ${a}`);
        return a
    }
    var Ib = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Jb(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return Eb(a);
            case "string":
                return Ib.test(a);
            default:
                return !1
        }
    }

    function Kb(a) {
        if (!Eb(a)) throw Ab("enum");
        return a | 0
    }

    function Lb(a) {
        return a == null ? a : Kb(a)
    }

    function Mb(a) {
        return a == null ? a : Eb(a) ? a | 0 : void 0
    }

    function Nb(a) {
        if (typeof a !== "number") throw Ab("int32");
        if (!Eb(a)) throw Ab("int32");
        return a | 0
    }

    function Ob(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return Eb(a) ? a | 0 : void 0
    }

    function Pb(a) {
        var b = void 0;
        b != null || (b = 1024);
        if (!Jb(a)) throw Ab("int64");
        var c = typeof a;
        switch (b) {
            case 512:
                switch (c) {
                    case "string":
                        return Qb(a);
                    case "bigint":
                        return String(Cb(64, a));
                    default:
                        return Rb(a)
                }
            case 1024:
                switch (c) {
                    case "string":
                        return Sb(a);
                    case "bigint":
                        return Wa(Cb(64, a));
                    default:
                        return Wa(Db(a) ? a : Rb(a))
                }
            case 0:
                switch (c) {
                    case "string":
                        return Qb(a);
                    case "bigint":
                        return Wa(Cb(64, a));
                    default:
                        a = Fb(a);
                        if (!Db(a)) {
                            eb(a);
                            b = v;
                            c = cb;
                            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
                            let d = c *
                                4294967296 + (b >>> 0);
                            b = Number.isSafeInteger(d) ? d : gb(b, c);
                            a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
                        }
                        return a
                }
            default:
                return Bb(b, "Unknown format requested type for int64")
        }
    }

    function Tb(a) {
        var b = a.length;
        if (a[0] === "-" ? b < 20 || b === 20 && a <= "-9223372036854775808" : b < 19 || b === 19 && a <= "9223372036854775807") return a;
        if (a.length < 16) eb(Number(a));
        else if (Pa()) a = BigInt(a), v = Number(a & BigInt(4294967295)) >>> 0, cb = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            b = +(a[0] === "-");
            cb = v = 0;
            let c = a.length;
            for (let d = 0 + b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) {
                let f = Number(a.slice(d, e));
                cb *= 1E6;
                v = v * 1E6 + f;
                v >= 4294967296 && (cb += Math.trunc(v / 4294967296), cb >>>= 0, v >>>= 0)
            }
            if (b) {
                let [d, e] = fb(v, cb);
                v = d;
                cb = e
            }
        }
        return ib()
    }

    function Rb(a) {
        a = Fb(a);
        Db(a) ? a = String(a) : (eb(a), a = ib());
        return a
    }

    function Qb(a) {
        var b = Fb(Number(a));
        if (Db(b)) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return Tb(a)
    }

    function Sb(a) {
        var b = Fb(Number(a));
        if (Db(b)) return Wa(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return Pa() ? Wa(Cb(64, BigInt(a))) : Wa(Tb(a))
    }

    function Vb(a) {
        var b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return Wa(Cb(64, a));
        if (Jb(a)) return b === "string" ? Sb(a) : Wa(Db(a) ? a : Rb(a))
    }

    function Wb(a) {
        if (typeof a !== "string") throw Error();
        return a
    }

    function Xb(a) {
        if (a != null && typeof a !== "string") throw Error();
        return a
    }

    function Yb(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function Zb(a, b, c, d) {
        if (a != null && a[nb] === vb) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? b[kb] || (b[kb] = $b(b)) : new b : void 0;
        c = a[w] | 0;
        d = c | d & 32 | d & 2;
        d !== c && (a[w] = d);
        return new b(a)
    }

    function $b(a) {
        a = new a;
        rb(a.O);
        return a
    }

    function ac(a, b, c) {
        if (b) return Wb(a);
        var d;
        return (d = Yb(a)) != null ? d : c ? "" : void 0
    };

    function bc(a) {
        return a
    };
    var cc = {},
        dc = (() => class extends Map {
            constructor() {
                super()
            }
        })();

    function ec(a) {
        return a
    }

    function fc(a) {
        if (a.Ca & 2) throw Error("Cannot mutate an immutable Map");
    }
    var jc = class extends dc {
        constructor(a, b, c = ec, d = ec) {
            super();
            this.Ca = a[w] | 0;
            this.Aa = b;
            this.Va = c;
            this.Lb = this.Aa ? hc : d;
            for (let e = 0; e < a.length; e++) {
                let f = a[e],
                    g = c(f[0], !1, !0),
                    h = f[1];
                b ? h === void 0 && (h = null) : h = d(f[1], !1, !0, void 0, void 0, this.Ca);
                super.set(g, h)
            }
        }
        ib(a) {
            return sb(Array.from(super.entries(), a))
        }
        clear() {
            fc(this);
            super.clear()
        }
        delete(a) {
            fc(this);
            return super.delete(this.Va(a, !0, !1))
        }
        entries() {
            if (this.Aa) {
                var a = super.keys();
                a = new xb(a, ic, this)
            } else a = super.entries();
            return a
        }
        values() {
            if (this.Aa) {
                var a =
                    super.keys();
                a = new xb(a, jc.prototype.get, this)
            } else a = super.values();
            return a
        }
        forEach(a, b) {
            this.Aa ? super.forEach((c, d, e) => {
                a.call(b, e.get(d), d, e)
            }) : super.forEach(a, b)
        }
        set(a, b) {
            fc(this);
            a = this.Va(a, !0, !1);
            return a == null ? this : b == null ? (super.delete(a), this) : super.set(a, this.Lb(b, !0, !0, this.Aa, !1, this.Ca))
        }
        has(a) {
            return super.has(this.Va(a, !1, !1))
        }
        get(a) {
            a = this.Va(a, !1, !1);
            var b = super.get(a);
            if (b !== void 0) {
                var c = this.Aa;
                return c ? (c = this.Lb(b, !1, !0, c, this.Vb, this.Ca), c !== b && super.set(a, c), c) : b
            }
        }[Symbol.iterator]() {
            return this.entries()
        }
    };
    jc.prototype.toJSON = void 0;

    function hc(a, b, c, d, e, f) {
        a = Zb(a, d, c, f);
        e && (a = kc(a));
        return a
    }

    function ic(a) {
        return [a, this.get(a)]
    }
    var lc;

    function mc() {
        return lc || (lc = new jc(rb([]), void 0, void 0, void 0, cc))
    };

    function nc(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        var f = [],
            g = a.length,
            h = 4294967295,
            k = !1,
            m = !!(b & 64),
            n = m ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1)) {
            var l = g && a[g - 1];
            l != null && typeof l === "object" && l.constructor === Object ? (g--, h = g) : l = void 0;
            if (m && !(b & 128) && !e) {
                k = !0;
                var p;
                h = ((p = oc) != null ? p : bc)(h - n, n, a, l, void 0) + n
            }
        }
        b = void 0;
        for (e = 0; e < g; e++)
            if (p = a[e], p != null && (p = c(p, d)) != null)
                if (m && e >= h) {
                    let x = e - n,
                        y;
                    ((y = b) != null ? y : b = {})[x] = p
                } else f[e] = p;
        if (l)
            for (let x in l) {
                a = l[x];
                if (a == null || (a = c(a, d)) == null) continue;
                g = +x;
                let y;
                if (m && !Number.isNaN(g) &&
                    (y = g + n) < h) f[y] = a;
                else {
                    let F;
                    ((F = b) != null ? F : b = {})[x] = a
                }
            }
        b && (k ? f.push(b) : f[h] = b);
        return f
    }

    function pc(a) {
        a[0] = qc(a[0]);
        a[1] = qc(a[1]);
        return a
    }

    function qc(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return bb(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    let b = a[w] | 0;
                    return a.length === 0 && b & 1 ? void 0 : nc(a, b, qc)
                }
                if (a != null && a[nb] === vb) return rc(a);
                if (a instanceof jc) return a = a.size !== 0 ? a.ib(pc) : void 0, a;
                return
        }
        return a
    }
    var oc;

    function rc(a) {
        a = a.O;
        return nc(a, a[w] | 0, qc)
    };

    function sc(a, b, c, d = 0) {
        if (a == null) {
            var e = 32;
            c ? (a = [c], e |= 128) : a = [];
            b && (e = e & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[w] | 0;
            if (wa && 1 & e) throw Error("rfarr");
            2048 & e && !(2 & e) && tc();
            if (e & 256) throw Error("farr");
            if (e & 64) return (e | d) !== e && (a[w] = e | d), a;
            if (c && (e |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;e |= 64;
                var f = c.length;
                if (f) {
                    var g = f - 1;
                    let k = c[g];
                    if (k != null && typeof k === "object" && k.constructor === Object) {
                        b = e & 128 ? 0 : -1;
                        g -= b;
                        if (g >= 1024) throw Error("pvtlmt");
                        for (var h in k)
                            if (f = +h,
                                f < g) c[f + b] = k[h], delete k[h];
                            else break;
                        e = e & -16760833 | (g & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    h = Math.max(b, f - (e & 128 ? 0 : -1));
                    if (h > 1024) throw Error("spvt");
                    e = e & -16760833 | (h & 1023) << 14
                }
            }
        }
        a[w] = e | 64 | d;
        return a
    }

    function tc() {
        if (wa) throw Error("carr");
        if (mb != null) {
            var a;
            var b = (a = zb) != null ? a : zb = {};
            a = b[mb] || 0;
            a >= 5 || (b[mb] = a + 1, b = Error(), yb(b, "incident"), va(b))
        }
    };

    function uc(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[w] | 0;
            return a.length === 0 && c & 1 ? void 0 : vc(a, c, b)
        }
        if (a != null && a[nb] === vb) return wc(a);
        if (a instanceof jc) {
            c = a.Ca;
            if (c & 2) return a;
            if (a.size) {
                b = rb(a.ib());
                if (a.Aa)
                    for (a = 0; a < b.length; a++) {
                        let d = b[a],
                            e = d[1];
                        e == null || typeof e !== "object" ? e = void 0 : e != null && e[nb] === vb ? e = wc(e) : Array.isArray(e) ? e = vc(e, e[w] | 0, !!(c & 32)) : e = void 0;
                        d[1] = e
                    }
                return b
            }
        }
    }

    function vc(a, b, c) {
        if (b & 2) return a;
        !c || 4096 & b || 16 & b ? a = xc(a, b, !1, c && !(b & 16)) : (a[w] |= 34, b & 4 && Object.freeze(a));
        return a
    }

    function yc(a, b, c) {
        a = new a.constructor(b);
        c && (a.i = wb);
        a.A = wb;
        return a
    }

    function wc(a) {
        var b = a.O,
            c = b[w] | 0;
        return z(a, c) ? a : zc(a, b, c) ? yc(a, b) : xc(b, c)
    }

    function xc(a, b, c, d) {
        d != null || (d = !!(34 & b));
        a = nc(a, b, uc, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        a[w] = b;
        return a
    }

    function kc(a) {
        var b = a.O,
            c = b[w] | 0;
        return z(a, c) ? zc(a, b, c) ? yc(a, b, !0) : new a.constructor(xc(b, c, !1)) : a
    }

    function Ac(a) {
        if (a.i !== wb) return !1;
        var b = a.O;
        b = xc(b, b[w] | 0);
        b[w] |= 2048;
        a.O = b;
        a.i = void 0;
        a.A = void 0;
        return !0
    }

    function Bc(a) {
        if (!Ac(a) && z(a, a.O[w] | 0)) throw Error();
    }

    function Cc(a, b) {
        b === void 0 && (b = a[w] | 0);
        b & 32 && !(b & 4096) && (a[w] = b | 4096)
    }

    function zc(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (b[w] = c | 2, a.i = wb, !0) : !1
    };
    var Dc = Wa(0);

    function Ec(a, b, c, d) {
        a = Fc(a.O, b, c, d);
        if (a !== null) return a
    }

    function Gc(a, b, c) {
        return Fc(a, b, void 0, c)
    }

    function Fc(a, b, c, d) {
        if (b === -1) return null;
        var e = b + (c ? 0 : -1),
            f = a.length - 1;
        if (!(f < 1 + (c ? 0 : -1))) {
            if (e >= f) {
                var g = a[f];
                if (g != null && typeof g === "object" && g.constructor === Object) {
                    c = g[b];
                    var h = !0
                } else if (e === f) c = g;
                else return
            } else c = a[e];
            if (d && c != null) {
                d = d(c);
                if (d == null) return d;
                if (!Object.is(d, c)) return h ? g[b] = d : a[e] = d, d
            }
            return c
        }
    }

    function A(a, b, c) {
        Bc(a);
        var d = a.O;
        B(d, d[w] | 0, b, c);
        return a
    }

    function B(a, b, c, d, e) {
        var f = c + (e ? 0 : -1),
            g = a.length - 1;
        if (g >= 1 + (e ? 0 : -1) && f >= g) {
            let h = a[g];
            if (h != null && typeof h === "object" && h.constructor === Object) return h[c] = d, b
        }
        if (f <= g) return a[f] = d, b;
        if (d !== void 0) {
            let h;
            g = ((h = b) != null ? h : b = a[w] | 0) >> 14 & 1023 || 536870912;
            c >= g ? d != null && (a[g + (e ? 0 : -1)] = {
                [c]: d
            }) : a[f] = d
        }
        return b
    }

    function Hc(a, b) {
        a = Fc(a.O, b);
        return a != null && a[nb] === vb || Array.isArray(a)
    }

    function Ic(a, b, c, d, e, f) {
        var g = a.O,
            h = g[w] | 0;
        d = d && d !== 4 ? d !== 1 && (a ? z(a, h) : 2 & h) ? 1 : d : 4;
        e = !!e || d === 3;
        d === 2 && Ac(a) && (g = a.O, h = g[w] | 0);
        a = Jc(g, b, f);
        var k = a === ob ? 7 : a[w] | 0,
            m = ub(k, h),
            n = !(4 & m);
        if (n) {
            let l = 0,
                p = 0;
            for (; l < a.length; l++) {
                let x = c(a[l]);
                x != null && (a[p++] = x)
            }
            p < l && (a.length = p);
            c = (m | 4) & -513;
            m = c &= -1025;
            m &= -4097
        }
        m !== k && (a[w] = m, 2 & m && Object.freeze(a));
        return a = Kc(a, m, g, h, b, f, d, n, e)
    }

    function Kc(a, b, c, d, e, f, g, h, k) {
        var m = b,
            n = Lc(b);
        n && g === 2 && (a = [...a], m = 0, b = Mc(b, d), d = B(c, d, e, a, f), n = !1);
        n || (g === 1 || (g !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? (b |= !a.length || h && !(4096 & b) || 32 & d && !(4096 & b || 16 & b) ? 2 : 256, b !== m && (a[w] = b), Object.freeze(a)) : (k || (b |= 16), b !== m && (a[w] = b)));
        2 & b || !(4096 & b || 16 & b) || Cc(c, d);
        return a
    }

    function Jc(a, b, c) {
        a = Fc(a, b, c);
        return Array.isArray(a) ? a : ob
    }

    function Lc(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function Nc(a, b, c, d) {
        var e = a.O,
            f = e[w] | 0;
        var g = z(a, f);
        a: {!g && Ac(a) && (e = a.O, f = e[w] | 0);
            var h = Fc(e, b);a = !1;
            if (h == null) {
                if (g) {
                    b = mc();
                    break a
                }
                h = []
            } else if (h.constructor === jc)
                if (h.Ca & 2 && !g) h = h.ib();
                else {
                    b = h;
                    break a
                }
            else Array.isArray(h) ? a = !!((h[w] | 0) & 2) : h = [];
            if (g) {
                if (!h.length) {
                    b = mc();
                    break a
                }
                a || (a = !0, rb(h))
            } else if (a) {
                a = !1;
                sb(h);
                h = [...h];
                for (let k = 0; k < h.length; k++) {
                    let m = h[k] = [...h[k]];
                    Array.isArray(m[1]) && (m[1] = rb(m[1]))
                }
                h = sb(h)
            }!a && f & 32 && tb(h);d = new jc(h, c, ac, d);f = B(e, f, b, d);a || Cc(e, f);b = d
        }!g && c && (b.Vb = !0);
        return b
    }

    function Pc(a, b, c, d) {
        Bc(a);
        var e = a.O;
        B(e, e[w] | 0, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    }

    function Qc(a, b, c) {
        var d = Rc;
        Bc(a);
        a = a.O;
        var e = a[w] | 0;
        if (c == null) {
            var f = Sc(a);
            if (Tc(f, a, e, d) === b) f.set(d, 0);
            else return
        } else {
            f = Sc(a);
            let g = Tc(f, a, e, d);
            g !== b && (g && (e = B(a, e, g)), f.set(d, b))
        }
        B(a, e, b, c)
    }

    function Sc(a) {
        var b;
        return (b = a[lb]) != null ? b : a[lb] = new Map
    }

    function Tc(a, b, c, d) {
        var e = a.get(d);
        if (e != null) return e;
        e = 0;
        for (let f = 0; f < d.length; f++) {
            let g = d[f];
            Fc(b, g) != null && (e !== 0 && (c = B(b, c, e)), e = g)
        }
        a.set(d, e);
        return e
    }

    function Uc(a, b, c) {
        Bc(a);
        a = a.O;
        var d = a[w] | 0,
            e = Fc(a, c);
        b = Zb(e, b, !0, d);
        b = kc(b);
        e !== b && (d = B(a, d, c, b), Cc(a, d));
        return b
    }

    function Vc(a, b, c, d) {
        var e = !1;
        d = Gc(a, d, f => {
            var g = Zb(f, c, !1, b);
            e = g !== f && g != null;
            return g
        });
        if (d != null) return e && !z(d) && Cc(a, b), d
    }

    function C(a, b, c) {
        a = a.O;
        return Vc(a, a[w] | 0, b, c) || b[kb] || (b[kb] = $b(b))
    }

    function D(a, b, c) {
        var d = a.O,
            e = d[w] | 0;
        b = Vc(d, e, b, c);
        if (b == null) return b;
        e = d[w] | 0;
        if (!z(a, e)) {
            let f = kc(b);
            f !== b && (Ac(a) && (d = a.O, e = d[w] | 0), b = f, e = B(d, e, c, b), Cc(d, e))
        }
        return b
    }

    function Wc(a, b, c) {
        var d = a.O;
        return Xc(a, d, d[w] | 0, b, c, 1)
    }

    function Xc(a, b, c, d, e, f, g, h, k) {
        f = f && f !== 4 ? f !== 1 && (a ? z(a, c) : 2 & c) ? 1 : f : 4;
        h = !!h || f === 3;
        var m = !!k && !(a ? z(a, c) : 2 & c);
        (f === 2 || m) && a && Ac(a) && (b = a.O, c = b[w] | 0);
        a = Jc(b, e, g);
        var n = a === ob ? 7 : a[w] | 0,
            l = ub(n, c);
        if (k = !(4 & l)) {
            var p = a,
                x = c;
            let y = !!(2 & l);
            y && (x |= 2);
            let F = !y,
                ja = !0,
                da = 0,
                ka = 0;
            for (; da < p.length; da++) {
                let Ub = Zb(p[da], d, !1, x);
                if (Ub instanceof d) {
                    if (!y) {
                        let Oc = z(Ub);
                        F && (F = !Oc);
                        ja && (ja = Oc)
                    }
                    p[ka++] = Ub
                }
            }
            ka < da && (p.length = ka);
            l |= 4;
            l = ja ? l & -4097 : l | 4096;
            l = F ? l | 8 : l & -9
        }
        l !== n && (a[w] = l, 2 & l && Object.freeze(a));
        if (m && !(8 & l || !a.length &&
                (f === 1 || (f !== 4 ? 0 : 2 & l || !(16 & l) && 32 & c)))) {
            Lc(l) && (a = [...a], l = Mc(l, c), c = B(b, c, e, a, g));
            d = a;
            m = l;
            for (n = 0; n < d.length; n++) p = d[n], l = kc(p), p !== l && (d[n] = l);
            m |= 8;
            l = m = d.length ? m | 4096 : m & -4097;
            a[w] = l
        }
        return a = Kc(a, l, b, c, e, g, f, k, h)
    }

    function Yc(a, b, c) {
        var d = a.O;
        return Xc(a, d, d[w] | 0, b, c, void 0, void 0, !1, !0)
    }

    function Zc(a, b, c) {
        c == null && (c = void 0);
        A(a, b, c);
        c && !z(c) && Cc(a.O);
        return a
    }

    function $c(a, b, c) {
        Bc(a);
        a = a.O;
        var d = a[w] | 0;
        if (c == null) B(a, d, b);
        else {
            var e = c === ob ? 7 : c[w] | 0,
                f = e,
                g = Lc(e),
                h = g || Object.isFrozen(c),
                k = !0,
                m = !0;
            for (let l = 0; l < c.length; l++) {
                var n = c[l];
                g || (n = z(n), k && (k = !n), m && (m = n))
            }
            g || (e = k ? 13 : 5, e = m ? e & -4097 : e | 4096);
            h && e === f || (c = [...c], f = 0, e = Mc(e, d));
            e !== f && (c[w] = e);
            d = B(a, d, b, c);
            2 & e || !(4096 & e || 16 & e) || Cc(a, d)
        }
    }

    function Mc(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function ad(a, b, c, d, e, f, g, h) {
        Bc(a);
        a = Ic(a, b, e, 2, !0, f);
        var k;
        b = (k = qb(a === ob ? 7 : a[w] | 0)) != null ? k : 1024;
        if (h)
            if (Array.isArray(d))
                for (g = d.length, h = 0; h < g; h++) a.push(c(d[h], b));
            else
                for (let m of d) a.push(c(m, b));
        else {
            if (g) throw Error();
            a.push(c(d, b))
        }
    }

    function bd(a, b, c, d) {
        Bc(a);
        var e = a.O; {
            a = Xc(a, e, e[w] | 0, c, b, 2, void 0, !0);
            d = d != null ? d : new c;
            a.push(d);
            b = c = a === ob ? 7 : a[w] | 0;
            let f = z(d);
            f ? (c &= -9, a.length === 1 && (c &= -4097)) : c |= 4096;
            c !== b && (a[w] = c);
            f || Cc(e)
        }
        return d
    }

    function cd(a, b, c, d) {
        bd(a, b, c, d);
        return a
    }

    function E(a, b) {
        a = Ec(a, b);
        a = a == null || typeof a === "boolean" ? a : typeof a === "number" ? !!a : void 0;
        return a != null ? a : !1
    }

    function G(a, b, c = 0) {
        a = Ob(Ec(a, b));
        return a != null ? a : c
    }

    function dd(a, b) {
        a = Ec(a, b, void 0, Vb);
        return a != null ? a : Dc
    }

    function ed(a) {
        a = Ec(a, 4, void 0, Gb);
        return a != null ? a : 0
    }

    function H(a, b) {
        var c;
        return (c = Yb(Ec(a, b))) != null ? c : ""
    }

    function fd(a, b) {
        a = Mb(Ec(a, b));
        return a != null ? a : 0
    }

    function gd(a, b, c) {
        A(a, b, c == null ? c : Hb(c))
    }

    function I(a, b, c) {
        return Pc(a, b, c == null ? c : Hb(c), !1)
    }

    function hd(a, b, c) {
        return Pc(a, b, c == null ? c : Nb(c), 0)
    }

    function id(a, b, c) {
        return A(a, b, c == null ? c : Pb(c))
    }

    function J(a, b, c) {
        return A(a, b, Xb(c))
    }

    function K(a, b, c) {
        return Pc(a, b, Xb(c), "")
    }

    function jd(a, b) {
        return Nc(a, b, void 0, ac)
    };
    var L = class {
        constructor(a) {
            this.O = sc(a, void 0, void 0, 2048)
        }
        toJSON() {
            return rc(this)
        }
        clone() {
            var a = this.O,
                b = a[w] | 0;
            return zc(this, a, b) ? yc(this, a, !0) : new this.constructor(xc(a, b, !1))
        }
    };
    L.prototype[nb] = vb;
    L.prototype.toString = function() {
        return this.O.toString()
    };

    function kd(a) {
        return b => {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b = new a(tb(b))
            }
            return b
        }
    };

    function ld(a) {
        a && typeof a.dispose == "function" && a.dispose()
    };

    function M() {
        this.N = this.N;
        this.X = this.X
    }
    M.prototype.N = !1;
    M.prototype.dispose = function() {
        this.N || (this.N = !0, this.o())
    };
    M.prototype[Symbol.dispose] = function() {
        this.dispose()
    };

    function md(a, b) {
        nd(a, ra(ld, b))
    }

    function nd(a, b) {
        a.N ? b() : (a.X || (a.X = []), a.X.push(b))
    }
    M.prototype.o = function() {
        if (this.X)
            for (; this.X.length;) this.X.shift()()
    };

    function od(a, b) {
        this.type = a;
        this.i = this.target = b;
        this.defaultPrevented = this.l = !1
    }
    od.prototype.stopPropagation = function() {
        this.l = !0
    };
    od.prototype.preventDefault = function() {
        this.defaultPrevented = !0
    };

    function pd(a, b) {
        od.call(this, a ? a.type : "");
        this.relatedTarget = this.i = this.target = null;
        this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
        this.key = "";
        this.keyCode = 0;
        this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
        this.state = null;
        this.pointerId = 0;
        this.pointerType = "";
        this.o = null;
        a && this.init(a, b)
    }
    t(pd, od);
    pd.prototype.init = function(a, b) {
        var c = this.type = a.type,
            d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
        this.target = a.target || a.srcElement;
        this.i = b;
        b = a.relatedTarget;
        b || (c == "mouseover" ? b = a.fromElement : c == "mouseout" && (b = a.toElement));
        this.relatedTarget = b;
        d ? (this.clientX = d.clientX !== void 0 ? d.clientX : d.pageX, this.clientY = d.clientY !== void 0 ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY = d.screenY || 0) : (this.clientX = a.clientX !== void 0 ? a.clientX : a.pageX, this.clientY = a.clientY !==
            void 0 ? a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
        this.button = a.button;
        this.keyCode = a.keyCode || 0;
        this.key = a.key || "";
        this.ctrlKey = a.ctrlKey;
        this.altKey = a.altKey;
        this.shiftKey = a.shiftKey;
        this.metaKey = a.metaKey;
        this.pointerId = a.pointerId || 0;
        this.pointerType = a.pointerType;
        this.state = a.state;
        this.o = a;
        a.defaultPrevented && pd.ma.preventDefault.call(this)
    };
    pd.prototype.stopPropagation = function() {
        pd.ma.stopPropagation.call(this);
        this.o.stopPropagation ? this.o.stopPropagation() : this.o.cancelBubble = !0
    };
    pd.prototype.preventDefault = function() {
        pd.ma.preventDefault.call(this);
        var a = this.o;
        a.preventDefault ? a.preventDefault() : a.returnValue = !1
    };
    var qd = "closure_listenable_" + (Math.random() * 1E6 | 0);

    function rd(a) {
        return !(!a || !a[qd])
    };
    var sd = 0;

    function td(a, b, c, d, e) {
        this.listener = a;
        this.proxy = null;
        this.src = b;
        this.type = c;
        this.capture = !!d;
        this.handler = e;
        this.key = ++sd;
        this.Ma = this.Ra = !1
    }

    function ud(a) {
        a.Ma = !0;
        a.listener = null;
        a.proxy = null;
        a.src = null;
        a.handler = null
    };

    function vd(a, b, c) {
        for (let d in a) b.call(c, a[d], d, a)
    }

    function wd(a) {
        var b = [],
            c = 0;
        for (let d in a) b[c++] = a[d];
        return b
    }

    function xd(a) {
        for (let b in a) delete a[b]
    }
    var yd = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" ");

    function zd(a, b) {
        for (let e = 1; e < arguments.length; e++) {
            var c = arguments[e];
            for (d in c) a[d] = c[d];
            for (let f = 0; f < yd.length; f++) {
                var d = yd[f];
                Object.prototype.hasOwnProperty.call(c, d) && (a[d] = c[d])
            }
        }
    };

    function Ad(a) {
        this.src = a;
        this.i = {};
        this.o = 0
    }
    Ad.prototype.add = function(a, b, c, d, e) {
        var f = a.toString();
        a = this.i[f];
        a || (a = this.i[f] = [], this.o++);
        var g = Bd(a, b, d, e);
        g > -1 ? (b = a[g], c || (b.Ra = !1)) : (b = new td(b, this.src, f, !!d, e), b.Ra = c, a.push(b));
        return b
    };
    Ad.prototype.remove = function(a, b, c, d) {
        a = a.toString();
        if (!(a in this.i)) return !1;
        var e = this.i[a];
        b = Bd(e, b, c, d);
        return b > -1 ? (ud(e[b]), Array.prototype.splice.call(e, b, 1), e.length == 0 && (delete this.i[a], this.o--), !0) : !1
    };

    function Cd(a, b) {
        var c = b.type;
        c in a.i && Ea(a.i[c], b) && (ud(b), a.i[c].length == 0 && (delete a.i[c], a.o--))
    }
    Ad.prototype.Ka = function(a, b, c, d) {
        a = this.i[a.toString()];
        var e = -1;
        a && (e = Bd(a, b, c, d));
        return e > -1 ? a[e] : null
    };

    function Bd(a, b, c, d) {
        for (let e = 0; e < a.length; ++e) {
            let f = a[e];
            if (!f.Ma && f.listener == b && f.capture == !!c && f.handler == d) return e
        }
        return -1
    };
    var Dd = "closure_lm_" + (Math.random() * 1E6 | 0),
        Ed = {},
        Fd = 0;

    function Gd(a, b, c, d, e) {
        if (d && d.once) return Hd(a, b, c, d, e);
        if (Array.isArray(b)) {
            for (let f = 0; f < b.length; f++) Gd(a, b[f], c, d, e);
            return null
        }
        c = Id(c);
        return rd(a) ? a.listen(b, c, ma(d) ? !!d.capture : !!d, e) : Jd(a, b, c, !1, d, e)
    }

    function Jd(a, b, c, d, e, f) {
        if (!b) throw Error("Invalid event type");
        var g = ma(e) ? !!e.capture : !!e,
            h = Kd(a);
        h || (a[Dd] = h = new Ad(a));
        c = h.add(b, c, d, g, f);
        if (c.proxy) return c;
        d = Ld();
        c.proxy = d;
        d.src = a;
        d.listener = c;
        if (a.addEventListener) e === void 0 && (e = !1), a.addEventListener(b.toString(), d, e);
        else if (a.attachEvent) a.attachEvent(Md(b.toString()), d);
        else if (a.addListener && a.removeListener) a.addListener(d);
        else throw Error("addEventListener and attachEvent are unavailable.");
        Fd++;
        return c
    }

    function Ld() {
        function a(c) {
            return b.call(a.src, a.listener, c)
        }
        var b = Nd;
        return a
    }

    function Hd(a, b, c, d, e) {
        if (Array.isArray(b)) {
            for (let f = 0; f < b.length; f++) Hd(a, b[f], c, d, e);
            return null
        }
        c = Id(c);
        return rd(a) ? a.wa(b, c, ma(d) ? !!d.capture : !!d, e) : Jd(a, b, c, !0, d, e)
    }

    function Od(a, b, c, d, e) {
        if (Array.isArray(b))
            for (let f = 0; f < b.length; f++) Od(a, b[f], c, d, e);
        else d = ma(d) ? !!d.capture : !!d, c = Id(c), rd(a) ? a.na(b, c, d, e) : a && (a = Kd(a)) && (b = a.Ka(b, c, d, e)) && Pd(b)
    }

    function Pd(a) {
        if (typeof a !== "number" && a && !a.Ma) {
            var b = a.src;
            if (rd(b)) Cd(b.I, a);
            else {
                var c = a.type,
                    d = a.proxy;
                b.removeEventListener ? b.removeEventListener(c, d, a.capture) : b.detachEvent ? b.detachEvent(Md(c), d) : b.addListener && b.removeListener && b.removeListener(d);
                Fd--;
                (c = Kd(b)) ? (Cd(c, a), c.o == 0 && (c.src = null, b[Dd] = null)) : ud(a)
            }
        }
    }

    function Md(a) {
        return a in Ed ? Ed[a] : Ed[a] = "on" + a
    }

    function Nd(a, b) {
        if (a.Ma) a = !0;
        else {
            b = new pd(b, this);
            let c = a.listener,
                d = a.handler || a.src;
            a.Ra && Pd(a);
            a = c.call(d, b)
        }
        return a
    }

    function Kd(a) {
        a = a[Dd];
        return a instanceof Ad ? a : null
    }
    var Qd = "__closure_events_fn_" + (Math.random() * 1E9 >>> 0);

    function Id(a) {
        if (typeof a === "function") return a;
        a[Qd] || (a[Qd] = function(b) {
            return a.handleEvent(b)
        });
        return a[Qd]
    };

    function N() {
        M.call(this);
        this.I = new Ad(this);
        this.Oa = this;
        this.va = null
    }
    t(N, M);
    N.prototype[qd] = !0;
    q = N.prototype;
    q.addEventListener = function(a, b, c, d) {
        Gd(this, a, b, c, d)
    };
    q.removeEventListener = function(a, b, c, d) {
        Od(this, a, b, c, d)
    };
    q.dispatchEvent = function(a) {
        var b, c = this.va;
        if (c)
            for (b = []; c; c = c.va) b.push(c);
        c = this.Oa;
        var d = a.type || a;
        if (typeof a === "string") a = new od(a, c);
        else if (a instanceof od) a.target = a.target || c;
        else {
            var e = a;
            a = new od(d, c);
            zd(a, e)
        }
        e = !0;
        var f;
        if (b)
            for (f = b.length - 1; !a.l && f >= 0; f--) {
                var g = a.i = b[f];
                e = Rd(g, d, !0, a) && e
            }
        a.l || (g = a.i = c, e = Rd(g, d, !0, a) && e, a.l || (e = Rd(g, d, !1, a) && e));
        if (b)
            for (f = 0; !a.l && f < b.length; f++) g = a.i = b[f], e = Rd(g, d, !1, a) && e;
        return e
    };
    q.o = function() {
        N.ma.o.call(this);
        if (this.I) {
            var a = this.I;
            let b = 0;
            for (let c in a.i) {
                let d = a.i[c];
                for (let e = 0; e < d.length; e++) ++b, ud(d[e]);
                delete a.i[c];
                a.o--
            }
        }
        this.va = null
    };
    q.listen = function(a, b, c, d) {
        return this.I.add(String(a), b, !1, c, d)
    };
    q.wa = function(a, b, c, d) {
        return this.I.add(String(a), b, !0, c, d)
    };
    q.na = function(a, b, c, d) {
        this.I.remove(String(a), b, c, d)
    };

    function Rd(a, b, c, d) {
        b = a.I.i[String(b)];
        if (!b) return !0;
        b = b.concat();
        var e = !0;
        for (let f = 0; f < b.length; ++f) {
            let g = b[f];
            if (g && !g.Ma && g.capture == c) {
                let h = g.listener,
                    k = g.handler || g.src;
                g.Ra && Cd(a.I, g);
                e = h.call(k, d) !== !1 && e
            }
        }
        return e && !d.defaultPrevented
    }
    q.Ka = function(a, b, c, d) {
        return this.I.Ka(String(a), b, c, d)
    };

    function Sd(a) {
        a.l = !0;
        a.dispatchEvent(new Event("became-visible"))
    }

    function Td(a) {
        a.l = !1;
        a.dispatchEvent(new Event("became-invisible"))
    }

    function Ud(a) {
        a.B || (a.B = !0, Vd(a))
    }
    var Wd = class extends N {
        constructor() {
            super();
            this.l = this.B = !1
        }
    };

    function Xd() {}

    function Yd(a) {
        function b() {
            d = r.setTimeout(c, 1E3);
            var g = f;
            f = [];
            a.apply(void 0, g)
        }

        function c() {
            d = 0;
            e && (e = !1, b())
        }
        var d = 0,
            e = !1,
            f = [];
        return function(g) {
            f = arguments;
            d ? e = !0 : b()
        }
    };

    function Zd(a, b) {
        return Math.min(Math.max(a, 0), b)
    };

    function $d(a, b) {
        this.width = a;
        this.height = b
    }
    q = $d.prototype;
    q.clone = function() {
        return new $d(this.width, this.height)
    };
    q.aspectRatio = function() {
        return this.width / this.height
    };
    q.isEmpty = function() {
        return !(this.width * this.height)
    };
    q.ceil = function() {
        this.width = Math.ceil(this.width);
        this.height = Math.ceil(this.height);
        return this
    };
    q.floor = function() {
        this.width = Math.floor(this.width);
        this.height = Math.floor(this.height);
        return this
    };
    q.round = function() {
        this.width = Math.round(this.width);
        this.height = Math.round(this.height);
        return this
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var ae = globalThis.trustedTypes,
        be;

    function ce() {
        var a = null;
        if (!ae) return a;
        try {
            let b = c => c;
            a = ae.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (b) {}
        return a
    }

    function de() {
        be === void 0 && (be = ce());
        return be
    };
    var ee = class {
        constructor(a) {
            this.i = a
        }
        toString() {
            return this.i + ""
        }
    };

    function fe(a) {
        var b = de();
        a = b ? b.createScriptURL(a) : a;
        return new ee(a)
    };
    var ge = class {
        constructor(a) {
            this.i = a
        }
        toString() {
            return this.i
        }
    };

    function he(a) {
        return new ge(a)
    };
    class ie {
        constructor(a) {
            this.dc = a
        }
    }

    function je(a) {
        return new ie(b => b.substr(0, a.length + 1).toLowerCase() === a + ":")
    }
    var ke = [je("data"), je("http"), je("https"), je("mailto"), je("ftp"), new ie(a => /^[^:]*([/?#]|$)/.test(a))],
        le = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;
    var me = class {
        constructor(a) {
            this.i = a
        }
        toString() {
            return this.i + ""
        }
    };

    function ne(a) {
        var b = de();
        a = b ? b.createHTML(a) : a;
        return new me(a)
    }

    function oe(a) {
        if (a instanceof me) return a.i;
        throw Error("");
    };

    function pe(a = document) {
        var b, c = (b = a.querySelector) == null ? void 0 : b.call(a, "script[nonce]");
        return c == null ? "" : c.nonce || c.getAttribute("nonce") || ""
    };

    function O(a) {
        function b(f, g) {
            var h = g + "  ";
            try {
                if (f === void 0) c.push("undefined");
                else if (f === null) c.push("NULL");
                else if (typeof f === "string") c.push('"' + f.replace(/\n/g, "\n" + g) + '"');
                else if (typeof f === "function") c.push(String(f).replace(/\n/g, "\n" + g));
                else if (ma(f)) {
                    f[pa] || d.push(f);
                    var k = Object.prototype.hasOwnProperty.call(f, pa) && f[pa] || (f[pa] = ++qa);
                    if (e[k]) c.push("*** reference loop detected (id=" + k + ") ***");
                    else {
                        e[k] = !0;
                        c.push("{");
                        for (let m in f) typeof f[m] !== "function" && (c.push("\n"), c.push(h),
                            c.push(m + " = "), b(f[m], h));
                        c.push("\n" + g + "}");
                        delete e[k]
                    }
                } else c.push(f)
            } catch (m) {
                c.push("*** " + m + " ***")
            }
        }
        var c = [],
            d = [],
            e = {};
        b(a, "");
        for (a = 0; a < d.length; a++) na(d[a]);
        return c.join("")
    };

    function qe(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    }

    function re(a) {
        return a.replace(RegExp("(^|[\\s]+)([a-z])", "g"), function(b, c, d) {
            return c + d.toUpperCase()
        })
    };

    function se(a) {
        return a instanceof me ? a : ne(String(a).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;"))
    };

    function te(a, ...b) {
        if (b.length === 0) return fe(a[0]);
        var c = a[0];
        for (let d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return fe(c)
    };

    function ue(a, b) {
        var c = b || document;
        c.getElementsByClassName ? a = c.getElementsByClassName(a)[0] : (c = document, a ? a = (b || c).querySelector(a ? "." + a : "") : (b = b || c, a = (a ? b.querySelectorAll(a ? "." + a : "") : b.getElementsByTagName("*"))[0] || null));
        return a || null
    }

    function ve(a, b) {
        vd(b, function(c, d) {
            d == "style" ? a.style.cssText = c : d == "class" ? a.className = c : d == "for" ? a.htmlFor = c : we.hasOwnProperty(d) ? a.setAttribute(we[d], c) : d.lastIndexOf("aria-", 0) == 0 || d.lastIndexOf("data-", 0) == 0 ? a.setAttribute(d, c) : a[d] = c
        })
    }
    var we = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    };

    function xe(a, b, c) {
        var d = arguments,
            e = document,
            f = d[1],
            g = ye(e, String(d[0]));
        f && (typeof f === "string" ? g.className = f : Array.isArray(f) ? g.className = f.join(" ") : ve(g, f));
        d.length > 2 && ze(e, g, d, 2);
        return g
    }

    function ze(a, b, c, d) {
        function e(f) {
            f && b.appendChild(typeof f === "string" ? a.createTextNode(f) : f)
        }
        for (; d < c.length; d++) {
            let f = c[d];
            !la(f) || ma(f) && f.nodeType > 0 ? e(f) : Ca(f && typeof f.length == "number" && typeof f.item == "function" ? Fa(f) : f, e)
        }
    }

    function ye(a, b) {
        b = String(b);
        a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
        return a.createElement(b)
    }

    function Ae() {
        this.i = r.document || document
    }
    q = Ae.prototype;
    q.getElementsByTagName = function(a, b) {
        return (b || this.i).getElementsByTagName(String(a))
    };
    q.createElement = function(a) {
        return ye(this.i, a)
    };
    q.appendChild = function(a, b) {
        a.appendChild(b)
    };
    q.append = function(a, b) {
        ze(a.nodeType == 9 ? a : a.ownerDocument || a.document, a, arguments, 1)
    };
    q.canHaveChildren = function(a) {
        if (a.nodeType != 1) return !1;
        switch (a.tagName) {
            case "APPLET":
            case "AREA":
            case "BASE":
            case "BR":
            case "COL":
            case "COMMAND":
            case "EMBED":
            case "FRAME":
            case "HR":
            case "IMG":
            case "INPUT":
            case "IFRAME":
            case "ISINDEX":
            case "KEYGEN":
            case "LINK":
            case "NOFRAMES":
            case "NOSCRIPT":
            case "META":
            case "OBJECT":
            case "PARAM":
            case "SCRIPT":
            case "SOURCE":
            case "STYLE":
            case "TRACK":
            case "WBR":
                return !1
        }
        return !0
    };
    var Be = /^--.+/;

    function Ce(a, b, c) {
        var d = De[c];
        if (!d) {
            var e = qe(c);
            d = e;
            a.style[e] === void 0 && (e = (Ja ? "Webkit" : Ia ? "Moz" : null) + re(e), a.style[e] !== void 0 && (d = e));
            De[c] = d
        }(c = d) && (Be.test(c) ? a.style.setProperty(c, b) : a.style[c] = b)
    }
    var De = {};

    function Ee() {
        var a = "100%";
        typeof a == "number" && (a = Math.round(a) + "px");
        return a
    }

    function Fe(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = Ja && !b && !c;
        if ((b === void 0 || d) && a.getBoundingClientRect) {
            try {
                var e = a.getBoundingClientRect()
            } catch (f) {
                e = {
                    left: 0,
                    top: 0,
                    right: 0,
                    bottom: 0
                }
            }
            a = e;
            return new $d(a.right - a.left, a.bottom - a.top)
        }
        return new $d(b, c)
    };

    function Ge(a, b, c) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, !1)
    }

    function He(a, b, c) {
        typeof a.removeEventListener === "function" && a.removeEventListener(b, c, !1)
    };

    function Ie(a) {
        if (a.prerendering) return 3;
        var b;
        return (b = {
            visible: 1,
            hidden: 2,
            prerender: 3,
            preview: 4,
            unloaded: 5,
            "": 0
        }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""]) != null ? b : 0
    }

    function Je(a) {
        var b;
        a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
        return b
    }

    function Ke(a, b) {
        if (Ie(b) === 3) return !1;
        a();
        return !0
    }

    function Le(a) {
        var b = r.document;
        if (!Ke(a, b)) {
            var c = Je(b);
            if (c) {
                var d = !1,
                    e = () => {
                        !d && Ke(a, b) && (d = !0, He(b, c, e))
                    };
                Ge(b, c, e)
            }
        }
    };

    function Vd(a) {
        if ("IntersectionObserver" in r && "IntersectionObserverEntry" in r && "isIntersecting" in r.IntersectionObserverEntry.prototype && Ie(document) !== 0) {
            (new IntersectionObserver(c => {
                for (let g of c) {
                    c = a;
                    let h = g.intersectionRatio;
                    var d = c,
                        e = g.intersectionRect.top + "-" + g.intersectionRect.left + "-" + g.intersectionRect.bottom + "-" + g.intersectionRect.right,
                        f = h;
                    let k = new Event("visibility-update");
                    k.visibleCoordinates = e;
                    k.visibleFraction = f;
                    d.dispatchEvent(k);
                    d = h >= .5;
                    Me(c) ? Ne(c, d) : Oe(c, d)
                }
            }, a.G)).observe(a.element);
            let b = Je(r.document);
            b && (Me(a) ? (Ge(r, b, () => Ne(a)), Le(() => Ne(a))) : (a.i = !1, Ge(r, b, () => Pe(a)), Le(() => Pe(a))));
            Qe(a)
        } else Re(a)
    }

    function Me(a) {
        return Array.prototype.indexOf.call(a.D, "combine_io_and_pv_functions", void 0) >= 0
    }

    function Ne(a, b = a.A) {
        a.A = b;
        b = Ie(r.document) === 1;
        Oe(a, a.A && b)
    }

    function Pe(a) {
        var b = a.i;
        a.i = Ie(r.document) === 1;
        !b && a.i && a.u ? Sd(a) : b && !a.i && Td(a)
    }

    function Qe(a) {
        var b = new Event("monitoring-started");
        a.dispatchEvent(b)
    }

    function Re(a) {
        var b = new Event("monitoring-failed");
        a.dispatchEvent(b)
    }

    function Oe(a, b) {
        var c = a.u;
        a.u = b;
        a.u && !c && a.i ? Sd(a) : !a.u && c && Td(a)
    }
    var Se = class extends Wd {
        constructor(a) {
            super();
            this.element = a;
            this.G = {
                threshold: [.5]
            };
            this.D = [];
            this.A = this.u = !1;
            this.i = !0
        }
    };
    var Te = class extends L {};
    var Ue = class extends L {};

    function Ve(a, b) {
        return A(a, 1, Lb(b))
    }

    function We(a, b) {
        return J(a, 2, b)
    }

    function Xe(a, b) {
        return J(a, 3, b)
    }
    var Ye = class extends L {};
    var Ze = class extends L {};
    var $e = class extends L {};
    var af = class extends L {};

    function bf(a) {
        var b = new cf;
        return J(b, 2, a)
    }

    function df(a, b) {
        return J(a, 9, b)
    }
    var cf = class extends L {};
    var ef = class extends L {};
    var ff = class extends L {};
    var gf = class extends L {};
    var hf = class extends L {};
    var jf = class extends L {};
    var kf = class extends L {};
    var lf = class extends L {};
    var mf = class extends L {};
    var nf = class extends L {
        getWidth() {
            return G(this, 1)
        }
        getHeight() {
            return G(this, 2)
        }
    };
    var of = class extends L {};
    var pf = class extends L {};
    var qf = class extends L {};
    var rf = class extends L {};

    function sf(a) {
        return G(a, 1)
    }

    function tf(a) {
        return G(a, 2)
    }
    var uf = class extends L {};
    var vf = class extends L {
        setVideoDuration(a) {
            return A(this, 11, a == null ? a : Nb(a))
        }
        getVideoUrl() {
            return H(this, 10)
        }
    };

    function wf(a) {
        return H(a, 3)
    }
    var xf = class extends L {};
    var yf = class extends L {};
    var zf = class extends L {};
    var Af = class extends L {},
        Bf = kd(Af);

    function Cf(a) {
        return C(a, xf, 1)
    }
    var Df = class extends L {};
    var Ef = class extends L {};
    var Ff = class extends L {};
    var Gf = class extends L {},
        Hf = kd(Gf);

    function If(a, b) {
        if (a)
            for (let c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function Jf(a) {
        try {
            var b;
            if (b = !!a && a.location.href != null) a: {
                try {
                    Ga(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch (c) {
            return !1
        }
    };

    function Kf(a, b = document) {
        return b.createElement(String(a).toLowerCase())
    };

    function Lf(a, b, c = null, d = !1, e = !1) {
        Mf(a, b, c, d, e)
    }

    function Mf(a, b, c, d, e = !1) {
        a.google_image_requests || (a.google_image_requests = []);
        var f = Kf("IMG", a.document);
        if (c || d) {
            let g = h => {
                c && c(h);
                d && Ea(a.google_image_requests, f);
                He(f, "load", g);
                He(f, "error", g)
            };
            Ge(f, "load", g);
            Ge(f, "error", g)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }

    function Nf({
        ja: a = !1
    } = {}) {
        return a ? "connect.pagead2.googlesyndication.com" : "pagead2.googlesyndication.com"
    }

    function Of(a, {
        qd: b = !1,
        ja: c = !1
    } = {}) {
        var d = `https://${Nf({ja:c})}/pagead/gen_204?id=rcs_internal`;
        If(a, (e, f) => {
            if (e || e === 0) d += `&${f}=${encodeURIComponent(String(e))}`
        });
        Pf(d, b)
    }

    function Pf(a, b = !1) {
        var c = window;
        c.fetch ? c.fetch(a, {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors"
        }) : Lf(c, a, void 0, b, !1)
    };
    var Qf = class {
        constructor(a) {
            var b = {
                context: 358,
                id: "jserror"
            };
            this.error = a;
            this.meta = {};
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror"
        }
    };
    var Rf = null;

    function Sf() {
        var a = r.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function Tf() {
        var a = r.performance;
        return a && a.now ? a.now() : null
    };
    var Uf = class {
        constructor(a, b, c, d = 0) {
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = d;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    var Vf = r.performance,
        Wf = !!(Vf && Vf.mark && Vf.measure && Vf.clearMarks),
        Xf = function(a) {
            var b = !1,
                c;
            return function() {
                b || (c = a(), b = !0);
                return c
            }
        }(() => {
            var a;
            if (a = Wf) {
                var b;
                a = window;
                if (Rf === null) {
                    Rf = "";
                    try {
                        let c = "";
                        try {
                            c = a.top.location.hash
                        } catch (d) {
                            c = a.location.hash
                        }
                        c && (Rf = (b = c.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (c) {}
                }
                b = Rf;
                a = !!b.indexOf && b.indexOf("1337") >= 0
            }
            return a
        });

    function Yf(a) {
        a && Vf && Xf() && (Vf.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), Vf.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    }
    var Zf = class {
        constructor(a) {
            this.events = [];
            this.i = a || r;
            var b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.events = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.u = Xf() || (b != null ? b : Math.random() < 1)
        }
        disable() {
            this.u = !1;
            this.events !== this.i.google_js_reporting_queue && (Xf() && Ca(this.events, Yf), this.events.length = 0)
        }
        J(a) {
            !this.u || this.events.length > 2048 || this.events.push(a)
        }
        gb(a, b, c) {
            this.u && this.J(new Uf(a, b, c, 0))
        }
        start(a, b) {
            if (!this.u) return null;
            a = new Uf(a,
                b, Tf() || Sf());
            b = `goog_${a.label}_${a.uniqueId}_start`;
            Vf && Xf() && Vf.mark(b);
            return a
        }
        end(a) {
            if (this.u && Sa(a.value)) {
                a.duration = (Tf() || Sf()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                Vf && Xf() && Vf.mark(b);
                this.J(a)
            }
        }
    };
    var $f = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function ag(a) {
        return a ? decodeURI(a) : a
    }

    function bg(a, b) {
        if (a) {
            a = a.split("&");
            for (let c = 0; c < a.length; c++) {
                let d = a[c].indexOf("="),
                    e, f = null;
                d >= 0 ? (e = a[c].substring(0, d), f = a[c].substring(d + 1)) : e = a[c];
                b(e, f ? decodeURIComponent(f.replace(/\+/g, " ")) : "")
            }
        }
    }

    function cg(a) {
        var b = a.indexOf("#");
        b < 0 && (b = a.length);
        var c = a.indexOf("?");
        if (c < 0 || c > b) {
            c = b;
            var d = ""
        } else d = a.substring(c + 1, b);
        return [a.slice(0, c), d, a.slice(b)]
    }

    function dg(a, b) {
        return b ? a ? a + "&" + b : b : a
    }

    function eg(a, b) {
        if (!b) return a;
        a = cg(a);
        a[1] = dg(a[1], b);
        return a[0] + (a[1] ? "?" + a[1] : "") + a[2]
    }

    function fg(a, b, c) {
        if (Array.isArray(b))
            for (let d = 0; d < b.length; d++) fg(a, String(b[d]), c);
        else b != null && c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))))
    }

    function gg(a, b) {
        var c = [];
        for (b = b || 0; b < a.length; b += 2) fg(a[b], a[b + 1], c);
        return c.join("&")
    }

    function hg(a) {
        var b = [];
        for (let c in a) fg(c, a[c], b);
        return b.join("&")
    }

    function ig(a, b) {
        var c = arguments.length == 2 ? gg(arguments[1], 0) : gg(arguments, 1);
        return eg(a, c)
    }
    var jg = /#|$/;

    function kg(a, b) {
        var c = a.search(jg);
        a: {
            var d = 0;
            for (var e = b.length;
                (d = a.indexOf(b, d)) >= 0 && d < c;) {
                var f = a.charCodeAt(d - 1);
                if (f == 38 || f == 63)
                    if (f = a.charCodeAt(d + e), !f || f == 61 || f == 38 || f == 35) break a;
                d += e + 1
            }
            d = -1
        }
        if (d < 0) return null;
        e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "))
    }

    function lg(a, b) {
        a = cg(a);
        var c = a[1],
            d = [];
        c && c.split("&").forEach(function(e) {
            var f = e.indexOf("=");
            b.hasOwnProperty(f >= 0 ? e.slice(0, f) : e) || d.push(e)
        });
        a[1] = dg(d.join("&"), hg(b));
        return a[0] + (a[1] ? "?" + a[1] : "") + a[2]
    };
    var mg = class extends L {};

    function ng(a, b, {
        ja: c = !1
    } = {}) {
        try {
            let d = e => [{
                [e.jc]: e.ec
            }];
            return JSON.stringify([a.filter(e => e.Db).map(d), rc(b), a.filter(e => !e.Db).map(d)])
        } catch (d) {
            return og(d, b, {
                ja: c
            }), ""
        }
    }

    function og(a, b, {
        ja: c = !1
    } = {}) {
        try {
            var d = a instanceof Error ? a : Error(String(a));
            let f = d.toString();
            d.name && f.indexOf(d.name) == -1 && (f += ": " + d.name);
            d.message && f.indexOf(d.message) == -1 && (f += ": " + d.message);
            if (d.stack) a: {
                var e = d.stack;a = f;
                try {
                    e.indexOf(a) == -1 && (e = a + "\n" + e);
                    let g;
                    for (; e != g;) g = e, e = e.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                    f = e.replace(RegExp("\n *", "g"), "\n");
                    break a
                } catch (g) {
                    f = a;
                    break a
                }
                f = void 0
            }
            Of({
                m: f,
                b: fd(b, 1) || null,
                v: H(b, 2) || null
            }, {
                ja: c
            })
        } catch (f) {}
    }

    function pg(a) {
        if (a.B) {
            var b = a.u,
                c = Set;
            var d = Ic(a.u, 3, Ob);
            c = [...(new c([...d, ...a.B()]))]; {
                Bc(b);
                let h = b.O,
                    k = h[w] | 0;
                if (c == null) B(h, k, 3);
                else {
                    d = b = c === ob ? 7 : c[w] | 0;
                    var e = Lc(b),
                        f = e || Object.isFrozen(c);
                    e || (b = 0);
                    f || (c = [...c], d = 0, b = Mc(b, k), f = !1);
                    b |= 5;
                    var g;
                    e = (g = qb(b)) != null ? g : 1024;
                    b |= e;
                    for (g = 0; g < c.length; g++) {
                        let m = c[g],
                            n = Nb(m, e);
                        Object.is(m, n) || (f && (c = [...c], d = 0, b = Mc(b, k), f = !1), c[g] = n)
                    }
                    b !== d && (f && (c = [...c], b = Mc(b, k)), c[w] = b);
                    B(h, k, 3, c)
                }
            }
        }
        a = a.u;
        c = a.O;
        g = c[w] | 0;
        return z(a, g) ? a : zc(a, c, g) ? yc(a, c) : new a.constructor(xc(c,
            g, !0))
    }
    var qg = class {
        constructor(a, b, c) {
            this.B = c;
            c = new mg;
            a = Pc(c, 1, Lb(a), 0);
            this.u = K(a, 2, b)
        }
    };

    function rg(a) {
        var b = new CompressionStream("gzip"),
            c = (new Response(b.readable)).arrayBuffer(),
            d = b.writable.getWriter(),
            e = typeof a === "string" ? (new TextEncoder).encode(a) : a;
        return d.ready.then(() => d.write(e)).then(() => d.close()).then(() => c).then(f => new Uint8Array(f))
    };

    function sg(a, b) {
        return A(a, 5, b == null ? b : Nb(b))
    }

    function tg(a, b) {
        return id(a, 2, b)
    }
    var ug = class extends L {
            getValue() {
                return dd(this, 2)
            }
            clearValue() {
                return A(this, 2)
            }
            getDuration() {
                return dd(this, 6)
            }
        },
        Rc = [1, 8, 9, 11];

    function vg(a, b) {
        id(a, 24, b)
    }
    var wg = class extends L {};

    function xg(a, b) {
        return J(a, 1, b)
    }

    function yg(a, b) {
        return J(a, 2, b)
    }
    var zg = class extends L {
        getName() {
            return H(this, 1)
        }
        getValue() {
            return H(this, 2)
        }
        clearValue() {
            return A(this, 2)
        }
    };

    function Ag(a, b) {
        return A(a, 22, b == null ? b : Nb(b))
    }
    var Bg = class extends L {
        getSlotId() {
            return G(this, 22)
        }
        l() {
            return Yc(this, zg, 28)
        }
        u(a) {
            $c(this, 28, a)
        }
        o(a) {
            cd(this, 28, zg, a)
        }
    };

    function Cg(a, b) {
        cd(a, 2, ug, b)
    }

    function Dg(a) {
        return Uc(a, wg, 12)
    }

    function Eg(a) {
        return Yc(a, Bg, 3)
    }

    function Fg(a, b) {
        cd(a, 3, Bg, b)
    }
    var Gg = class extends L {
        getCorrelator() {
            return H(this, 1)
        }
        setCorrelator(a) {
            return J(this, 1, a)
        }
        l() {
            return Yc(this, zg, 11)
        }
        u(a) {
            $c(this, 11, a)
        }
        o(a) {
            cd(this, 11, zg, a)
        }
    };
    class Hg extends qg {
        constructor() {
            super(...arguments)
        }
    }

    function Ig(a, ...b) {
        Jg(a, ...b.map(c => ({
            Db: !0,
            jc: 30,
            ec: rc(c)
        })))
    }
    var Kg = class extends Hg {};

    function Lg(a, b) {
        globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: b.length < 65536,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(() => {})
    }

    function Mg(a, b, c = 1, d = !1) {
        if (d) {
            d = typeof CompressionStream === "function";
            var e = b.length > 1024;
            typeof document !== "undefined" && document.visibilityState !== "hidden" && d && e ? rg(b).then(f => {
                var g = c === 1 ? 5 : 6,
                    h;
                h === void 0 && (h = 0);
                if (!Oa) {
                    Oa = {};
                    var k = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""),
                        m = ["+/=", "+/", "-_=", "-_.", "-_"];
                    for (var n = 0; n < 5; n++) {
                        var l = k.concat(m[n].split(""));
                        Na[n] = l;
                        for (var p = 0; p < l.length; p++) {
                            var x = l[p];
                            Oa[x] === void 0 && (Oa[x] = p)
                        }
                    }
                }
                h = Na[h];
                k = Array(Math.floor(f.length /
                    3));
                m = h[64] || "";
                for (n = l = 0; l < f.length - 2; l += 3) {
                    var y = f[l],
                        F = f[l + 1];
                    x = f[l + 2];
                    p = h[y >> 2];
                    y = h[(y & 3) << 4 | F >> 4];
                    F = h[(F & 15) << 2 | x >> 6];
                    x = h[x & 63];
                    k[n++] = p + y + F + x
                }
                p = 0;
                x = m;
                switch (f.length - l) {
                    case 2:
                        p = f[l + 1], x = h[(p & 15) << 2] || m;
                    case 1:
                        f = f[l], k[n] = h[f >> 2] + h[(f & 3) << 4 | p >> 4] + x + m
                }
                Lg(`${a}?e=${g}`, k.join(""))
            }).catch(() => {
                Lg(`${a}?e=${c}`, b)
            }) : Lg(`${a}?e=${c}`, b)
        } else Lg(`${a}?e=${c}`, b)
    };

    function Jg(a, ...b) {
        try {
            a.D && ng(a.i.concat(b), pg(a), {
                ja: a.o()
            }).length >= 65536 && Ng(a), a.i.push(...b), a.i.length >= a.I && Ng(a), a.i.length && a.l === null && (a.l = setTimeout(() => {
                Ng(a)
            }, a.G))
        } catch (c) {
            og(c, pg(a), {
                ja: a.o()
            })
        }
    }

    function Ng(a) {
        a.l !== null && (clearTimeout(a.l), a.l = null);
        if (a.i.length) {
            var b = ng(a.i, pg(a), {
                ja: a.o()
            });
            a.N(a.A(), b, 1, !1);
            a.i = []
        }
    }
    var Og = class extends Kg {
            constructor(a, b, c) {
                super(19, "1.0", void 0);
                this.N = Mg;
                this.G = a;
                this.I = b;
                this.D = c;
                this.i = [];
                this.l = null
            }
            A() {
                return "https://pagead2.googlesyndication.com/pagead/ping"
            }
            o() {
                return !1
            }
        },
        Pg = class extends Og {
            constructor(a = 1E3, b = 100, c = !1, d) {
                super(a, b, c && !0);
                this.ja = d
            }
            A() {
                return this.o() ? "https://connect.pagead2.googlesyndication.com/pagead/ping" : super.A()
            }
            o() {
                var a, b;
                return (b = (a = this.ja) == null ? void 0 : a.call(this)) != null ? b : !1
            }
        };

    function Qg() {
        var a = Rg,
            b = window.google_srt;
        b >= 0 && b <= 1 && (a.i = b)
    }
    var Sg = class {
        constructor(a, b) {
            this.domain = a;
            this.path = b;
            this.protocol = "https:";
            this.i = Math.random()
        }
    };
    var Rg;
    class Tg extends Sg {}
    var Ug = new Zf(window);
    (function(a) {
        Rg = a != null ? a : new Tg("pagead2.googlesyndication.com", "/pagead/gen_204?id=", .01);
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        Qg();
        window.document.readyState === "complete" ? window.google_measure_js_timing || Ug.disable() : Ug.u && Ge(window, "load", () => {
            window.google_measure_js_timing || Ug.disable()
        })
    })();

    function Vg(a = r) {
        var b = a.context || a.AMP_CONTEXT_DATA;
        if (!b) try {
            b = a.parent.context || a.parent.AMP_CONTEXT_DATA
        } catch (e) {}
        var c, d;
        return ((c = b) == null ? 0 : c.pageViewId) && ((d = b) == null ? 0 : d.canonicalUrl) ? b : null
    };
    wd({
        Cc: 0,
        Bc: 1,
        yc: 2,
        sc: 3,
        zc: 4,
        tc: 5,
        Ac: 6,
        wc: 7,
        xc: 8,
        rc: 9,
        uc: 10,
        Dc: 11
    }).map(a => Number(a));
    wd({
        Fc: 0,
        Gc: 1,
        Ec: 2
    }).map(a => Number(a));

    function Wg(a) {
        var b = new Xg;
        ad(b, 1, Kb, a, Mb, void 0, void 0, !0)
    }
    var Xg = class extends L {};
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    Wg([1, 8, 9, 10, 11, 12, 2, 3, 4, 5, 15, 16, 19, 20, 21, 23, 25]);
    Wg([1, 6, 7, 9, 10, 11, 12, 2, 22, 3, 4, 5, 13, 14, 18, 19, 20, 21, 23, 24]);
    Wg([1, 6, 7, 9, 10, 11, 12, 22, 26, 27, 2, 3, 4, 5, 13, 14, 17, 18, 19, 20, 21, 23, 24]);
    new Xg;

    function Yg(a, b) {
        a = lg(a, b || {});
        try {
            window.googleJsEnvironment && window.googleJsEnvironment.pinger && window.googleJsEnvironment.pinger.pingUrl ? window.googleJsEnvironment.pinger.pingUrl(a) : Lf(window, a)
        } catch (c) {}
    };

    function P(a) {
        this.o = this.I = this.u = "";
        this.D = null;
        this.A = this.l = "";
        this.B = !1;
        var b;
        a instanceof P ? (this.B = a.B, Zg(this, a.u), this.I = a.I, this.o = a.o, $g(this, a.D), this.l = a.l, ah(this, a.i.clone()), this.A = a.A) : a && (b = String(a).match($f)) ? (this.B = !1, Zg(this, b[1] || "", !0), this.I = bh(b[2] || ""), this.o = bh(b[3] || "", !0), $g(this, b[4]), this.l = bh(b[5] || "", !0), ah(this, b[6] || "", !0), this.A = bh(b[7] || "")) : (this.B = !1, this.i = new ch(null, this.B))
    }
    P.prototype.toString = function() {
        var a = [],
            b = this.u;
        b && a.push(dh(b, eh, !0), ":");
        var c = this.o;
        if (c || b == "file") a.push("//"), (b = this.I) && a.push(dh(b, eh, !0), "@"), a.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.D, c != null && a.push(":", String(c));
        if (c = this.l) this.o && c.charAt(0) != "/" && a.push("/"), a.push(dh(c, c.charAt(0) == "/" ? fh : gh, !0));
        (c = this.i.toString()) && a.push("?", c);
        (c = this.A) && a.push("#", dh(c, hh));
        return a.join("")
    };
    P.prototype.resolve = function(a) {
        var b = this.clone(),
            c = !!a.u;
        c ? Zg(b, a.u) : c = !!a.I;
        c ? b.I = a.I : c = !!a.o;
        c ? b.o = a.o : c = a.D != null;
        var d = a.l;
        if (c) $g(b, a.D);
        else if (c = !!a.l) {
            if (d.charAt(0) != "/")
                if (this.o && !this.l) d = "/" + d;
                else {
                    var e = b.l.lastIndexOf("/");
                    e != -1 && (d = b.l.slice(0, e + 1) + d)
                }
            e = d;
            if (e == ".." || e == ".") d = "";
            else if (e.indexOf("./") != -1 || e.indexOf("/.") != -1) {
                d = e.lastIndexOf("/", 0) == 0;
                e = e.split("/");
                let f = [];
                for (let g = 0; g < e.length;) {
                    let h = e[g++];
                    h == "." ? d && g == e.length && f.push("") : h == ".." ? ((f.length > 1 || f.length ==
                        1 && f[0] != "") && f.pop(), d && g == e.length && f.push("")) : (f.push(h), d = !0)
                }
                d = f.join("/")
            } else d = e
        }
        c ? b.l = d : c = a.i.toString() !== "";
        c ? ah(b, a.i.clone()) : c = !!a.A;
        c && (b.A = a.A);
        return b
    };
    P.prototype.clone = function() {
        return new P(this)
    };

    function Zg(a, b, c) {
        a.u = c ? bh(b, !0) : b;
        a.u && (a.u = a.u.replace(/:$/, ""))
    }

    function $g(a, b) {
        if (b) {
            b = Number(b);
            if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
            a.D = b
        } else a.D = null
    }

    function ah(a, b, c) {
        b instanceof ch ? (a.i = b, ih(a.i, a.B)) : (c || (b = dh(b, jh)), a.i = new ch(b, a.B))
    }

    function bh(a, b) {
        return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : ""
    }

    function dh(a, b, c) {
        return typeof a === "string" ? (a = encodeURI(a).replace(b, kh), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null
    }

    function kh(a) {
        a = a.charCodeAt(0);
        return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
    }
    var eh = /[#\/\?@]/g,
        gh = /[#\?:]/g,
        fh = /[#\?]/g,
        jh = /[#\?@]/g,
        hh = /#/g;

    function ch(a, b) {
        this.o = this.i = null;
        this.l = a || null;
        this.u = !!b
    }

    function lh(a) {
        a.i || (a.i = new Map, a.o = 0, a.l && bg(a.l, function(b, c) {
            a.add(decodeURIComponent(b.replace(/\+/g, " ")), c)
        }))
    }
    q = ch.prototype;
    q.add = function(a, b) {
        lh(this);
        this.l = null;
        a = mh(this, a);
        var c = this.i.get(a);
        c || this.i.set(a, c = []);
        c.push(b);
        this.o += 1;
        return this
    };
    q.remove = function(a) {
        lh(this);
        a = mh(this, a);
        return this.i.has(a) ? (this.l = null, this.o -= this.i.get(a).length, this.i.delete(a)) : !1
    };
    q.clear = function() {
        this.i = this.l = null;
        this.o = 0
    };
    q.isEmpty = function() {
        lh(this);
        return this.o == 0
    };

    function nh(a, b) {
        lh(a);
        b = mh(a, b);
        return a.i.has(b)
    }
    q.forEach = function(a, b) {
        lh(this);
        this.i.forEach(function(c, d) {
            c.forEach(function(e) {
                a.call(b, e, d, this)
            }, this)
        }, this)
    };

    function oh(a, b) {
        lh(a);
        var c = [];
        if (typeof b === "string") nh(a, b) && (c = c.concat(a.i.get(mh(a, b))));
        else
            for (a = Array.from(a.i.values()), b = 0; b < a.length; b++) c = c.concat(a[b]);
        return c
    }
    q.set = function(a, b) {
        lh(this);
        this.l = null;
        a = mh(this, a);
        nh(this, a) && (this.o -= this.i.get(a).length);
        this.i.set(a, [b]);
        this.o += 1;
        return this
    };
    q.get = function(a, b) {
        if (!a) return b;
        a = oh(this, a);
        return a.length > 0 ? String(a[0]) : b
    };
    q.toString = function() {
        if (this.l) return this.l;
        if (!this.i) return "";
        var a = [],
            b = Array.from(this.i.keys());
        for (let d = 0; d < b.length; d++) {
            var c = b[d];
            let e = encodeURIComponent(String(c));
            c = oh(this, c);
            for (let f = 0; f < c.length; f++) {
                let g = e;
                c[f] !== "" && (g += "=" + encodeURIComponent(String(c[f])));
                a.push(g)
            }
        }
        return this.l = a.join("&")
    };
    q.clone = function() {
        var a = new ch;
        a.l = this.l;
        this.i && (a.i = new Map(this.i), a.o = this.o);
        return a
    };

    function mh(a, b) {
        b = String(b);
        a.u && (b = b.toLowerCase());
        return b
    }

    function ih(a, b) {
        b && !a.u && (lh(a), a.l = null, a.i.forEach(function(c, d) {
            var e = d.toLowerCase();
            d != e && (this.remove(d), this.remove(e), c.length > 0 && (this.l = null, this.i.set(mh(this, e), Fa(c)), this.o += c.length))
        }, a));
        a.u = b
    };
    var ph, qh, rh;

    function sh() {
        return r.navigator ? r.navigator.userAgent : ""
    }
    var th = sh().indexOf("(iPad") != -1 || sh().indexOf("(Macintosh") != -1 || sh().indexOf("(iPod") != -1 || sh().indexOf("(iPhone") != -1;

    function uh() {
        qh === void 0 && (qh = sh().indexOf("afma-sdk-a") != -1);
        return !!qh
    }

    function vh() {
        if (rh === void 0) {
            a: {
                if (ph === void 0) {
                    if (th) {
                        var a = sh().indexOf("Safari") != -1;
                        var b = new P(window.location.href);
                        b = oh(b.i, "js");
                        b: {
                            if ((b = b.length ? b[0] : "") && b.lastIndexOf("afma-", 0) == 0) {
                                let c = b.lastIndexOf("v");
                                if (c > -1 && (b = b.substr(c + 1).match(/^(\d+\.\d+\.\d+|^\d+\.\d+|^\d+)(-.*)?$/))) {
                                    b = b[1];
                                    break b
                                }
                            }
                            b = "0.0.0"
                        }
                        if (!a || b !== "0.0.0") {
                            a = ph = !0;
                            break a
                        }
                    }
                    ph = !1
                }
                a = ph
            }
            rh = a || uh()
        }
        return rh
    };
    class wh {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.reject = b
            })
        }
    };

    function xh(a) {
        if (!a.countdownHandler) {
            let {
                promise: b,
                resolve: c
            } = new wh;
            a.countdownHandler = {
                promise: b,
                resolve: c
            }
        }
        return a.countdownHandler
    }

    function yh() {
        var a = [xh(r).promise];
        try {
            a.push(xh(r.parent).promise)
        } catch (b) {}
        return Promise.race(a)
    };

    function zh() {
        var a = Aa();
        return za(a, "AppleTV") || za(a, "Apple TV") || za(a, "CFNetwork") || za(a, "tvOS")
    };

    function Ah(a, b, c) {
        c < 0 ? c += 1 : c > 1 && --c;
        return 6 * c < 1 ? a + (b - a) * 6 * c : 2 * c < 1 ? b : 3 * c < 2 ? a + (b - a) * (2 / 3 - c) * 6 : a
    };

    function Bh(a) {
        return a.toString(16).padStart(2, "0")
    }

    function Ch(a) {
        var b = (a[0] + a[1] + a[2]) / 3;
        return Math.abs(b - a[0]) <= 5 && Math.abs(b - a[1]) <= 5 && Math.abs(b - a[2]) <= 5
    }
    var Dh = class extends Array {
        get r() {
            return this[0]
        }
        set r(a) {
            this[0] = Zd(a, 1)
        }
        get g() {
            return this[1]
        }
        set g(a) {
            this[1] = Zd(a, 1)
        }
        get b() {
            return this[2]
        }
        set b(a) {
            this[2] = Zd(a, 1)
        }
        get a() {
            var a;
            return (a = this[3]) != null ? a : 1
        }
        set a(a) {
            this[3] = Zd(a, 1)
        }
        blend(a) {
            var b = this.a,
                c = a.a * (1 - b),
                d = b + c;
            this[0] = (this[0] * b + a[0] * c) / d;
            this[1] = (this[1] * b + a[1] * c) / d;
            this[2] = (this[2] * b + a[2] * c) / d;
            this[3] = d;
            return this
        }
        clone() {
            return new Dh(...this)
        }
        equals(a) {
            return !(this.r !== a.r || this.g !== a.g || this.b !== a.b || this.a !== a.a)
        }
        toHex() {
            var a =
                Zd(Math.round(this.r), 255),
                b = Zd(Math.round(this.g), 255),
                c = Zd(Math.round(this.b), 255),
                d = Zd(Math.round(this.a * 255), 255),
                e = a % 17 || b % 17 || c % 17 || d % 17;
            a = e ? Bh(a) : (a / 17).toString(16);
            b = e ? Bh(b) : (b / 17).toString(16);
            c = e ? Bh(c) : (c / 17).toString(16);
            var f = "";
            d !== 255 && (f = e ? Bh(d) : (d / 17).toString(16));
            return `#${a}${b}${c}${f}`
        }
    };

    function Eh(a) {
        var b = a[0] / 255;
        var c = a[1] / 255,
            d = a[2] / 255,
            e = Math.max(b, c, d),
            f = Math.min(b, c, d),
            g = 0,
            h = 0,
            k = .5 * (e + f);
        e != f && (e == b ? g = 60 * (c - d) / (e - f) : e == c ? g = 60 * (d - b) / (e - f) + 120 : e == d && (g = 60 * (b - c) / (e - f) + 240), h = 0 < k && k <= .5 ? (e - f) / (2 * k) : (e - f) / (2 - 2 * k));
        b = [Math.round(g + 360) % 360, h, k];
        b[3] = a[3];
        return new Fh(...b)
    }
    var Fh = class extends Array {
        get h() {
            return this[0]
        }
        set h(a) {
            a %= 360;
            this[0] = a >= 0 ? a : 360 + a
        }
        get o() {
            return this[1]
        }
        set o(a) {
            this[1] = Zd(a, 1)
        }
        get i() {
            return this[2]
        }
        set i(a) {
            this[2] = Zd(a, 1)
        }
        get a() {
            var a;
            return (a = this[3]) != null ? a : 1
        }
        set a(a) {
            this[3] = Zd(a, 1)
        }
        clone() {
            return new Fh(...this)
        }
        equals(a) {
            return !(this.h !== a.h || this.o !== a.o || this.i !== a.i || this.a !== a.a)
        }
        toHex() {
            var a = this[1],
                b = this[2];
            var c = this[0] / 360;
            if (a == 0) b = a = c = b * 255;
            else {
                let d, e;
                e = b < .5 ? b * (1 + a) : b + a - a * b;
                d = 2 * b - e;
                b = 255 * Ah(d, e, c + 1 / 3);
                a = 255 * Ah(d, e,
                    c);
                c = 255 * Ah(d, e, c - 1 / 3)
            }
            c = [Math.round(b), Math.round(a), Math.round(c)];
            c[3] = this[3];
            return (new Dh(...c)).toHex()
        }
    };
    var Gh = class {
        constructor(a) {
            this.body = a
        }
        dispatchEvent(a, b) {
            this.body.dispatchEvent(new CustomEvent(a, {
                detail: b
            }))
        }
    };
    var Hh = class extends L {};
    class Ih {
        constructor(a) {
            this.i = C(a, Ef, 2);
            this.o = C(a, kf, 3);
            this.l = C(a, Ff, 25)
        }
    };
    var Jh;
    var Kh = class {
        enabledChannel() {}
        setSlice() {}
        setData() {}
        send() {}
        setDataAndSend() {}
        tick() {}
        populateServerPingbackOutput() {}
        flush() {
            return []
        }
    };
    var Lh = class {
        constructor(a, b) {
            this.body = b;
            this.pingback = Jh || new Kh;
            this.runtime = {};
            this.context = new Gh(b);
            this.uid = (a = b.id === "mys-meta" ? b : b.querySelector("#mys-meta")) ? a.getAttribute("data-1") || "" : "";
            this.pingback.enabledChannel(1)
        }
        getConfig() {
            return new Hh
        }
        o() {}
        onReady() {}
    };
    var Mh = class {
        constructor() {
            this.i = typeof mys !== "undefined" ? mys.pingback : void 0;
            this.o = 0
        }
        enabledChannel(a) {
            this.o = a;
            var b;
            (b = this.i) == null || b.tick(43, this.o)
        }
        setSlice(a, b) {
            var c;
            (c = this.i) == null || c.setAttribute(a, b)
        }
        setData(a, b) {
            var c;
            (c = this.i) == null || c.setData(a, b, this.o)
        }
        send(a) {
            var b;
            (b = this.i) == null || b.send(a)
        }
        setDataAndSend(a, b) {
            if (this.i) {
                for (let c in a) a.hasOwnProperty(c) && this.i.setData(c, a[c], this.o);
                this.i.send(b)
            }
        }
        tick(a, b) {
            var c;
            (c = this.i) == null || c.tick(a, this.o, b)
        }
        populateServerPingbackOutput() {}
        flush() {
            return []
        }
    };
    class Nh {
        constructor(a, b, c) {
            this.body = c;
            this.i = new a(b, c);
            var d;
            if (a = (d = this.body.querySelector('meta[name="runtime_data"]')) == null ? void 0 : d.content) try {
                let e = JSON.parse(a);
                e && typeof e === "object" && Object.assign(this.i.runtime, e)
            } catch (e) {}
        }
        get uid() {
            return this.i.uid
        }
        b0() {}
        b1() {
            this.i.o()
        }
        b2() {
            this.i.onReady()
        }
        b3() {}
        b4() {}
        b5() {}
    };

    function Oh(a) {
        var b;
        switch (a == null ? void 0 : (b = D(a, xf, 1)) == null ? void 0 : G(b, 31)) {
            case 47:
                return "acp";
            case 11:
                return "aci";
            case 28:
                return "ace";
            default:
                return "unknown"
        }
    };

    function Ph(a, b) {
        a.i.push(b);
        return a
    }
    var Qh = class {
        constructor(a, b, c) {
            this.input = a;
            this.config = b;
            this.uid = c;
            this.i = []
        }
        build() {
            var a = D(this.config, ef, 14);
            if (a) {
                a = Nc(a, 1, cf);
                var b = Yc(this.input, Df, 1);
                for (let [f, g] of b.entries()) {
                    b = f;
                    let h = g;
                    for (var c of this.i) c(h, b, a)
                }
                c = C(this.input, Ef, 2);
                if (c = H(c, 8))
                    for (var d of a.values()) Yb(Ec(d, 2)) != null && Yb(Ec(d, 11)) == null && J(d, 11, c);
                d = this.uid;
                if (d = fd(this.config, 18) === 2 ? `${d}-` : "") {
                    c = [];
                    for (var e of a.keys()) e.startsWith(d) || c.push(e);
                    for (let f of c) e = a.get(f), a.delete(f), a.set(`${d}${f}`, e)
                }
            }
        }
    };

    function Rh(a, b, c = "") {
        Ph(new Qh(a, b, c), (d, e, f) => {
            var g = `ad${e}`,
                h = Oh(d),
                k = h !== "unknown",
                m = 0,
                n = void 0;
            if (k) {
                m = h === "ace" ? 3 : 4;
                h = Sh(a, d);
                Th(h, d);
                Uh(h, d, m);
                n = Cf(d);
                n = C(n, mf, 14);
                var l;
                (l = H(n, 6)) || (E(n, 14) ? (n = C(d, rf, 5), n = H(n, 13)) : n = void 0, l = n);
                n = l;
                Vh(h, n);
                A(h, 16, Lb(1));
                f.set(g, h)
            } else {
                h = Sh(a, d);
                l = Cf(d);
                var p = wf(l);
                l = D(l, mf, 14);
                var x = l == null ? void 0 : H(l, 5),
                    y = l == null ? void 0 : H(l, 12);
                p && (x = Wh(a, h, p, x, !0));
                l && x && y === "spitzer" && (p = Xe(We(Ve(new Ye, 1), x), H(l, 6)), p = J(p, 4, y), E(l, 18) && gd(p, 7, !0), cd(h, 7, Ye, p), A(h, 16,
                    Lb(2)));
                f.set(g, h)
            }
            if (Yc(d, of , 14).length > 0) {
                h = Cf(d);
                h = df(new cf, H(h, 7));
                f.set(`conversion${e}`, h);
                for (let [ja, da] of Yc(d, of , 14).entries()) {
                    e = ja;
                    x = void 0;
                    l = a;
                    y = D(d, xf, 1);
                    p = H(da, 10);
                    h = df(bf(p), H(y, 7));
                    if (y && ((x = D(y, af, 49)) == null ? 0 : Yb(Ec(x, 1)) != null)) {
                        x = Uc(h, af, 26);
                        var F = C(y, af, 49);
                        F = H(F, 1);
                        J(x, 1, F);
                        A(h, 20, e == null ? e : Nb(e))
                    }(y = D(y, Ue, 23)) && Zc(h, 18, y);
                    y = D(da, mf, 14);
                    x = y == null ? void 0 : H(y, 5);
                    p && (x = Wh(l, h, p, x, !k));
                    y && x && (l = h, p = Xe(We(Ve(new Ye, 2), x), H(y, 6)), l = cd(l, 7, Ye, p), A(l, 16, Lb(2)));
                    h = A(h, 9);
                    k && (Th(h, d),
                        Uh(h, d, m), Vh(h, n), A(h, 16, Lb(1)));
                    f.set(`${g}Product${e}`, h)
                }
            }
        }).build()
    }

    function Xh(a, b) {
        if (!b) return !1;
        try {
            let c = b.match($f)[1] || null;
            if (c !== "https" && c !== "http" && c !== "intent") return !1;
            let d, e = (d = kg(a, "adurl")) != null ? d : "",
                f = ag(e.match($f)[3] || null);
            return f ? f !== ag(b.match($f)[3] || null) && !f.endsWith("doubleclick.net") && !f.endsWith("dartsearch.net") : !1
        } catch (c) {
            return !1
        }
    }

    function Yh(a, b, c) {
        var d;
        (d = !b) || (a = C(a, Ef, 2), d = E(a, 87));
        if (d) return null;
        try {
            if (c) {
                let e = kg(b, "adurl");
                return e ? kg(e, "gclid") : null
            }
            return b ? kg(b, "gclid") : null
        } catch (e) {
            return null
        }
    }

    function Sh(a, b) {
        b = Cf(b);
        var c = wf(b),
            d = Yh(a, c, !0);
        a = df(bf(c), H(b, 7));
        if (c = Hc(b, 49)) c = C(b, af, 49), c = Yb(Ec(c, 1)) != null;
        if (c) {
            c = Uc(a, af, 26);
            var e = C(b, af, 49);
            J(c, 1, H(e, 1))
        }
        if (c = Hc(b, 49)) c = C(b, af, 49), c = Yb(Ec(c, 2)) != null;
        c && (c = Uc(a, af, 26), e = C(b, af, 49), J(c, 2, H(e, 2)));
        (c = D(b, Ue, 23)) && Zc(a, 18, c);
        Hc(b, 39) && (c = D(b, Te, 39), Zc(a, 24, c));
        d && J(a, 17, d);
        b = Ic(b, 28, Yb);
        for (d = 0; d < b.length; ++d) ad(a, 6, Wb, b[d], Yb);
        return a
    }

    function Wh(a, b, c, d, e) {
        if (a = Yh(a, c, !e)) b = J(b, 17, a), c = Xh(c, d), gd(b, 23, c);
        return d
    }

    function Th(a, b) {
        var c = Cf(b);
        if (!E(c, 55)) {
            a = Uc(a, $e, 8);
            (b = D(b, rf, 5)) && J(a, 4, H(b, 13));
            c = D(c, mf, 14);
            b = (c == null ? void 0 : H(c, 3)) || "";
            var d = J(a, 2, b);
            J(d, 3, (c == null ? void 0 : H(c, 4)) || "");
            kg(b, "inline") === "true" && kg(b, "enifd") && gd(a, 7, !0);
            if (c == null ? 0 : H(c, 15)) {
                a: {
                    try {
                        var e = JSON.parse(H(c, 15))
                    } catch (f) {
                        e = "";
                        break a
                    }
                    c = e.id;typeof c === "number" && (e.id = String(c));c = e.Signatures;delete e.Signatures;
                    if (Array.isArray(c))
                        for (let f of c)
                            if (1 === f.fidelityType) {
                                Object.assign(e, f);
                                break
                            }
                    e = JSON.stringify(e)
                }
                J(a, 6, e)
            }
        }
    }

    function Uh(a, b, c) {
        b = D(b, xf, 1);
        b = D(b, mf, 14);
        var d = b == null ? void 0 : H(b, 5);
        b && d && (c = Xe(We(Ve(new Ye, c), d), H(b, 6)), a = cd(a, 7, Ye, c), A(a, 16, Lb(1)))
    }

    function Vh(a, b) {
        if (b) {
            var c = new Ze;
            b = J(c, 1, b);
            Zc(a, 12, b)
        }
    };

    function Zh(a) {
        var b = document;
        if (a) {
            var c = new Image;
            c.crossOrigin = "anonymous";
            c.onload = () => {
                var d = b.createElement("canvas");
                d.width = d.height = 16;
                if (d = d.getContext("2d")) {
                    try {
                        d.drawImage(c, 0, 0, 16, 16);
                        var e = d.getImageData(0, 0, 16, 16).data
                    } catch (k) {
                        return
                    }
                    d = "";
                    var f = 0;
                    for (let k = 0; k < e.length; k += 4) {
                        var g = e[k];
                        let m = e[k + 1],
                            n = e[k + 2];
                        if (e[k + 3] < 128 || Math.min(g, m, n) > 235 || Math.max(g, m, n) < 20) continue;
                        let l = new Dh(g, m, n);
                        g = Math.max(g, m, n) - Math.min(g, m, n);
                        !Ch(l) && g > f && (f = g, d = l.toHex())
                    }
                    if (d) {
                        var h = Eh(d.length > 6 ?
                            new Dh(parseInt(d.slice(1, 3), 16), parseInt(d.slice(3, 5), 16), parseInt(d.slice(5, 7), 16), parseInt(d.slice(7, 9) || "ff", 16) / 255) : new Dh(parseInt(d.charAt(1), 16) * 17, parseInt(d.charAt(2), 16) * 17, parseInt(d.charAt(3), 16) * 17, parseInt(d.charAt(4) || "f", 16) * 17 / 255));
                        e = (k, m) => {
                            h.i = m;
                            m = h.toHex();
                            for (let n of b.querySelectorAll(k)) n.style.transition = "background-color 180ms ease", n.style.setProperty("background-color", m, "important")
                        };
                        e(".x-layout", .2);
                        e(".text-button", .1);
                        e(".logo", .95)
                    }
                }
            };
            c.onerror = () => {};
            c.src = a
        }
    };
    var $h = {
            [18]: 496,
            [22]: 2128,
            [43]: 488,
            [44]: 848,
            [45]: 2128,
            [59]: 848,
            [133]: 242,
            [134]: 400,
            [135]: 1E3,
            [136]: 2E3,
            [137]: 3750,
            [139]: 48,
            [140]: 128,
            [141]: 256,
            [160]: 108,
            [242]: 150,
            [243]: 276,
            [244]: 512,
            [245]: 1E3,
            [247]: 1E3,
            [248]: 1800,
            [249]: 48,
            [250]: 64,
            [251]: 128,
            [278]: 95,
            [342]: 464,
            [343]: 1064,
            [344]: 2128,
            [345]: 496,
            [346]: 816,
            [347]: 2096,
            [396]: 210,
            [397]: 389,
            [398]: 778,
            [399]: 1370
        },
        ai = {
            [18]: -1,
            [22]: -1,
            [43]: 350,
            [44]: 350,
            [45]: 350,
            [59]: -1,
            [133]: 350,
            [134]: 350,
            [135]: 350,
            [136]: 350,
            [137]: 350,
            [139]: 50,
            [140]: 50,
            [141]: 50,
            [160]: 350,
            [242]: 150,
            [243]: 150,
            [244]: 150,
            [245]: 150,
            [247]: 150,
            [248]: 150,
            [249]: 50,
            [250]: 50,
            [251]: 50,
            [278]: 150,
            [342]: -1,
            [343]: -1,
            [344]: -1,
            [345]: -1,
            [346]: -1,
            [347]: -1,
            [396]: 150,
            [397]: 150,
            [398]: 150,
            [399]: 150
        },
        bi = {
            [18]: !1,
            [22]: !1,
            [43]: !0,
            [44]: !0,
            [45]: !0,
            [59]: !1,
            [133]: !0,
            [134]: !0,
            [135]: !0,
            [136]: !0,
            [137]: !0,
            [139]: !0,
            [140]: !0,
            [141]: !0,
            [160]: !0,
            [242]: !0,
            [243]: !0,
            [244]: !0,
            [245]: !0,
            [247]: !0,
            [248]: !0,
            [249]: !0,
            [250]: !0,
            [251]: !0,
            [278]: !0,
            [342]: !1,
            [343]: !1,
            [344]: !1,
            [345]: !1,
            [346]: !1,
            [347]: !1,
            [396]: !0,
            [397]: !0,
            [398]: !0,
            [399]: !0
        },
        ci = {
            [18]: "video/mp4",
            [22]: "video/mp4",
            [43]: "video/webm",
            [44]: "video/webm",
            [45]: "video/webm",
            [59]: "video/mp4",
            [133]: "video/mp4",
            [134]: "video/mp4",
            [135]: "video/mp4",
            [136]: "video/mp4",
            [137]: "video/mp4",
            [139]: "audio/mp4",
            [140]: "audio/mp4",
            [141]: "audio/mp4",
            [160]: "video/mp4",
            [242]: "video/webm",
            [243]: "video/webm",
            [244]: "video/webm",
            [245]: "video/webm",
            [247]: "video/webm",
            [248]: "video/webm",
            [249]: "audio/webm",
            [250]: "audio/webm",
            [251]: "audio/webm",
            [278]: "video/webm",
            [342]: "video/mp4",
            [343]: "video/mp4",
            [344]: "video/mp4",
            [345]: "video/mp4",
            [346]: "video/mp4",
            [347]: "video/mp4",
            [396]: "video/mp4",
            [397]: "video/mp4",
            [398]: "video/mp4",
            [399]: "video/mp4"
        },
        di = {
            [18]: "avc1.42001E, mp4a.40.2",
            [22]: "avc1.64001F, mp4a.40.2",
            [43]: "vp8, vorbis",
            [44]: "vp8, vorbis",
            [45]: "vp8, vorbis",
            [59]: "avc1.4D001F, mp4a.40.2",
            [133]: "avc1.4D401C",
            [134]: "avc1.4D401E",
            [135]: "avc1.4D401E",
            [136]: "avc1.4D401F",
            [137]: "avc1.640028",
            [139]: "mp4a.40.2",
            [140]: "mp4a.40.2",
            [141]: "mp4a.40.2",
            [160]: "avc1.4D401E",
            [242]: "vp9",
            [243]: "vp9",
            [244]: "vp9",
            [245]: "vp9",
            [247]: "vp9",
            [248]: "vp9",
            [249]: "opus",
            [250]: "opus",
            [251]: "opus",
            [278]: "vp9",
            [342]: "avc1.42E01E, mp4a.40.2",
            [343]: "avc1.42E01E, mp4a.40.2",
            [344]: "avc1.42E01E, mp4a.40.2",
            [345]: "avc1.42E01E, mp4a.40.2",
            [346]: "avc1.42E01E, mp4a.40.2",
            [347]: "avc1.4D001F, mp4a.40.2",
            [396]: "av01.0.01M.08",
            [397]: "av01.0.04M.08",
            [398]: "av01.0.08M.08",
            [399]: "av01.0.09M.08"
        };

    function Q(a, ...b) {
        return new a(...b)
    };
    var ei = typeof AsyncContext !== "undefined" && typeof AsyncContext.Snapshot === "function" ? a => a && AsyncContext.Snapshot.wrap(a) : a => a;

    function fi(a) {
        return /^\s*$/.test(a) ? !1 : /^[\],:{}\s\u2028\u2029]*$/.test(a.replace(/\\["\\\/bfnrtu]/g, "@").replace(/(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g, "]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, ""))
    }

    function gi(a) {
        try {
            return r.JSON.parse(a)
        } catch (b) {}
        a = String(a);
        if (fi(a)) try {
            return eval("(" + a + ")")
        } catch (b) {}
        throw Error("Invalid JSON string: " + a);
    };

    function hi() {
        N.call(this);
        this.headers = new Map;
        this.l = !1;
        this.i = null;
        this.K = "";
        this.B = 0;
        this.u = this.J = this.D = this.G = !1;
        this.L = 0;
        this.A = null;
        this.V = "";
        this.P = !1
    }
    t(hi, N);
    var ii = /^https?$/i,
        ji = ["POST", "PUT"];
    q = hi.prototype;
    q.send = function(a, b, c, d) {
        if (this.i) throw Error("[goog.net.XhrIo] Object is active with another request=" + this.K + "; newUri=" + a);
        if (typeof b === "string") var e = b;
        else b && (e = b.method, c != null || (c = b.body), d != null || (d = b.headers));
        e = e ? e.toUpperCase() : "GET";
        this.K = a;
        this.B = 0;
        this.G = !1;
        this.l = !0;
        this.i = new XMLHttpRequest;
        this.i.onreadystatechange = ei(() => this.R());
        try {
            this.J = !0, this.i.open(e, String(a), !0), this.J = !1
        } catch (g) {
            ki(this);
            return
        }
        a = c || "";
        b = new Map(this.headers);
        if (d)
            if (Object.getPrototypeOf(d) === Object.prototype)
                for (var f in d) b.set(f,
                    d[f]);
            else if (typeof d.keys === "function" && typeof d.get === "function")
            for (let g of d.keys()) b.set(g, d.get(g));
        else throw Error("Unknown input type for opt_headers: " + String(d));
        d = Array.from(b.keys()).find(g => "content-type" == g.toLowerCase());
        f = r.FormData && a instanceof r.FormData;
        !(Array.prototype.indexOf.call(ji, e, void 0) >= 0) || d || f || b.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
        for (let [g, h] of b) this.i.setRequestHeader(g, h);
        this.V && (this.i.responseType = this.V);
        "withCredentials" in
        this.i && this.i.withCredentials !== this.P && (this.i.withCredentials = this.P);
        try {
            this.A && (clearTimeout(this.A), this.A = null), this.L > 0 && (this.A = setTimeout(this.Z.bind(this), this.L)), this.D = !0, this.i.send(a), this.D = !1
        } catch (g) {
            ki(this)
        }
    };
    q.Z = function() {
        typeof fa != "undefined" && this.i && (this.B = 8, this.dispatchEvent("timeout"), this.abort(8))
    };

    function ki(a) {
        a.l = !1;
        a.i && (a.u = !0, a.i.abort(), a.u = !1);
        a.B = 5;
        li(a);
        mi(a)
    }

    function li(a) {
        a.G || (a.G = !0, a.dispatchEvent("complete"), a.dispatchEvent("error"))
    }
    q.abort = function(a) {
        this.i && this.l && (this.l = !1, this.u = !0, this.i.abort(), this.u = !1, this.B = a || 7, this.dispatchEvent("complete"), this.dispatchEvent("abort"), mi(this))
    };
    q.o = function() {
        this.i && (this.l && (this.l = !1, this.u = !0, this.i.abort(), this.u = !1), mi(this, !0));
        hi.ma.o.call(this)
    };
    q.R = function() {
        this.N || (this.J || this.D || this.u ? ni(this) : this.Y())
    };
    q.Y = function() {
        ni(this)
    };

    function ni(a) {
        if (a.l && typeof fa != "undefined")
            if (a.D && (a.i ? a.i.readyState : 0) == 4) setTimeout(a.R.bind(a), 0);
            else if (a.dispatchEvent("readystatechange"), (a.i ? a.i.readyState : 0) == 4) {
            a.l = !1;
            try {
                try {
                    var b = (a.i ? a.i.readyState : 0) > 2 ? a.i.status : -1
                } catch (f) {
                    b = -1
                }
                a: switch (b) {
                    case 200:
                    case 201:
                    case 202:
                    case 204:
                    case 206:
                    case 304:
                    case 1223:
                        var c = !0;
                        break a;
                    default:
                        c = !1
                }
                var d;
                if (!(d = c)) {
                    var e;
                    if (e = b === 0) {
                        let f = String(a.K).match($f)[1] || null;
                        !f && r.self && r.self.location && (f = r.self.location.protocol.slice(0, -1));
                        e = !ii.test(f ? f.toLowerCase() : "")
                    }
                    d = e
                }
                d ? (a.dispatchEvent("complete"), a.dispatchEvent("success")) : (a.B = 6, li(a))
            } finally {
                mi(a)
            }
        }
    }

    function mi(a, b) {
        if (a.i) {
            a.A && (clearTimeout(a.A), a.A = null);
            let c = a.i;
            a.i = null;
            b || a.dispatchEvent("ready");
            try {
                c.onreadystatechange = null
            } catch (d) {}
        }
    }
    q.isActive = function() {
        return !!this.i
    };

    function oi(a) {
        if (a.i) {
            a = a.i.responseText;
            a: {
                if (r.JSON) try {
                    var b = r.JSON.parse(a);
                    break a
                } catch (c) {}
                b = gi(a)
            }
            return b
        }
    };
    var pi = RegExp("/itag/(\\d+)/");

    function qi(a) {
        var b = Number(kg(a, "itag"));
        return b ? b : (a = a.match(pi)) && a.length === 2 ? Number(a[1]) : null
    }

    function ri(a) {
        var b = ci[a];
        a = di[a];
        b ? (b = (b == null ? "" : String(b)).toLowerCase(), b = a ? `${b}; codecs="${a==null?"":String(a)}"` : b) : b = "";
        return b
    }

    function si(a, b = 400) {
        return a * b * 1E3 / 8
    }

    function R(a, b) {
        if (typeof CustomEvent === "function") return new CustomEvent(a, {
            detail: b
        });
        var c = document.createEvent("CustomEvent");
        c.initCustomEvent(a, !1, !0, b);
        return c
    };

    function ti() {
        return window.ManagedMediaSource || window.MediaSource
    }

    function ui(a) {
        return a !== null && !!window.ManagedMediaSource && a instanceof window.ManagedMediaSource
    }

    function vi(a) {
        return [43, 44, 45].includes(a) && La ? !1 : bi[a] ? (a = ri(a), !!a && ti() !== void 0 && ti().isTypeSupported(a)) : !1
    };

    function wi(a, b) {
        return hd(a, 1, b)
    }

    function xi(a, b) {
        K(a, 2, b)
    }
    var yi = class extends L {};

    function zi(a) {
        I(a, 7, !1)
    }

    function Ai(a, b) {
        return K(a, 8, b)
    }

    function Bi(a, b) {
        return hd(a, 29, b)
    }

    function Ci(a, b) {
        return K(a, 24, b)
    }

    function Di(a, b) {
        hd(a, 30, b)
    }

    function Ei(a, b) {
        return I(a, 16, b)
    }

    function Fi(a, b) {
        return K(a, 20, b)
    }

    function Gi(a, b) {
        K(a, 21, b)
    }

    function Hi(a, b) {
        gd(a, 23, b)
    }

    function Ii(a, b) {
        I(a, 26, b)
    }
    var Ji = class extends L {
            getVideoUrl() {
                return H(this, 1)
            }
        },
        Ki = kd(Ji);
    var Li = class {
        constructor() {
            this.u = this.i = this.Z = "";
            this.Oa = this.Y = 0;
            this.l = "";
            this.B = null;
            this.R = this.J = "";
            this.Yb = "cover";
            this.I = !!r.customElements;
            this.aa = this.va = "";
            this.N = 0;
            this.ba = "";
            this.G = 0;
            this.ga = this.pa = this.D = this.V = !1;
            this.ea = this.L = "";
            this.fa = this.ta = this.Ub = !1;
            this.X = this.K = "";
            this.Tb = this.o = this.P = this.A = this.Na = !1
        }
    };
    var Mi = [243],
        Ni = [250];

    function Oi(a, b) {
        var c = new Map;
        for (var d of Wc(a, yi, 33)) vi(G(d, 1)) && c.set(G(d, 1), H(d, 2));
        for (let f of Mi)
            if (d = c.get(f)) {
                b.i = d;
                break
            }
        if (!b.i)
            for (let f of Wc(a, yi, 33))
                if (vi(G(f, 1))) {
                    b.i = H(f, 2);
                    break
                }
        c = new Map;
        for (var e of Wc(a, yi, 34)) vi(G(e, 1)) && c.set(G(e, 1), H(e, 2));
        for (let f of Ni)
            if (e = c.get(f)) {
                b.u = e;
                break
            }
        if (!b.u)
            for (let f of Wc(a, yi, 34))
                if (vi(G(f, 1))) {
                    b.u = H(f, 2);
                    break
                }
    }

    function Pi(a) {
        var b = Yc(a, Df, 1)[0],
            c = C(b, vf, 7),
            d = new Ji,
            e = C(a, Ef, 2),
            f = C(e, lf, 11);
        I(d, 14, E(e, 17));
        var g = c.getVideoUrl();
        g && K(d, 1, g);
        g = Cf(b);
        var h = H(g, 7);
        h && K(d, 6, h);
        if ((h = C(b, Af, 10)) && (h = jd(h, 22)) && h.size > 0) {
            let ka = jd(d, 31);
            h.forEach((Ub, Oc) => {
                ka.set(Oc, Ub)
            })
        }
        h = [83, 84, 87];
        var k = h.concat([99]).includes(G(g, 15));
        if (k) {
            var m = H(g, 11);
            m && K(d, 10, m);
            m = D(b, yf, 27);
            var n, l;
            Gi(Fi(d, (n = m == null ? void 0 : H(m, 6)) != null ? n : ""), (l = m == null ? void 0 : H(m, 7)) != null ? l : "")
        }
        n = G(c, 11);
        hd(d, 4, n || 0);
        E(c, 8) ? Pc(d, 5, Lb(1), 0) : Pc(d, 5,
            Lb(0), 0);
        n = D(c, nf, 14);
        var p, x, y, F;
        l = ((p = D(b, qf, 3)) == null ? void 0 : (x = Yc(p, nf, 1)[0]) == null ? void 0 : H(x, 3)) || ((y = D(b, zf, 8)) == null ? void 0 : (F = D(y, nf, 1)) == null ? void 0 : H(F, 3));
        n ? K(d, 9, H(n, 3)) : l ? K(d, 9, l) : (b = H(e, 14)) && b.toLowerCase() !== "cn" && (b = ed(c), K(d, 9, `https://i1.ytimg.com/vi/${H(c,7)}/${b>0&&b<1.4?"hqdefault":"mqdefault"}.jpg`));
        a = C(a, kf, 3);
        b = jd(a, 10);
        p = H(e, 4);
        (p.match(/video_mra\/.*/) || p.match(/video_location\/.*/) || p.match(/leadgen\/.*/)) && b.get("videoSmallblockPdiffEnv") !== "true" && zi(Ai(I(d, 15, !0),
            H(c, 24)));
        var ja, da;
        (((ja = D(a, ff, 5)) == null ? 0 : (da = Ic(ja, 8, Ob)) == null ? 0 : da.includes(52)) || k) && I(d, 17, !0);
        b.get("video_theme") === "clickable" && I(d, 18, !0);
        Di(Ci(Bi(K(d, 11, H(c, 16)), Hc(c, 34) ? sf(D(c, uf, 34)) : 0), H(c, 31)), Hc(c, 34) ? tf(D(c, uf, 34)) : 0);
        for (let ka of Wc(c, pf, 21)) xi(wi(bd(d, 33, yi), G(ka, 1)), H(ka, 2));
        for (let ka of Wc(c, pf, 22)) xi(wi(bd(d, 34, yi), G(ka, 1)), H(ka, 2));
        Hi(I(d, 19, E(c, 29) || !1), E(e, 75));
        Ii(Ei(d, h.includes(G(g, 15))), G(g, 15) === 84);
        E(f, 11) && I(d, 27, !0);
        I(d, 32, E(e, 101));
        return d
    }

    function Qi(a) {
        var b = new Li;
        b.pa = E(a, 14);
        b.Z = a.getVideoUrl();
        b.l = H(a, 6);
        b.va = H(a, 10);
        b.K = H(a, 20);
        b.Y = G(a, 4);
        b.Oa = fd(a, 5);
        b.R = H(a, 9);
        b.Ub = E(a, 17);
        b.ta = E(a, 18);
        b.aa = H(a, 11);
        b.N = G(a, 29);
        b.ba = H(a, 24);
        b.G = G(a, 30);
        b.fa = E(a, 19);
        b.X = H(a, 21);
        b.A = E(a, 16);
        b.P = E(a, 26);
        b.o = E(a, 27);
        b.Tb = E(a, 32);
        var c = jd(a, 31);
        c && c.size > 0 && (b.B = new Map, c.forEach((d, e) => {
            b.B.set(e, d)
        }));
        b.I && (E(a, 15) && (b.ga = !0, E(a, 7) && (b.J = H(a, 8))), Oi(a, b), b.V = E(a, 12), b.D = !!b.i);
        b.V ? (b.L = b.i, b.ea = b.u) : b.L = b.D ? b.i : b.Z;
        b.Na = E(a, 23);
        return b
    }
    async function Ri() {
        var a = document.createElement("video");
        a.muted = !0;
        a.setAttribute("playsinline", "true");
        a.setAttribute("webkit-playsinline", "");
        a.src = "data:video/mp4;base64,AAAAIGZ0eXBtcDQyAAAAAG1wNDJtcDQxaXNvbWF2YzEAAATKbW9vdgAAAGxtdmhkAAAAANLEP5XSxD+VAAB1MAAAdU4AAQAAAQAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAgAAACFpb2RzAAAAABCAgIAQAE////9//w6AgIAEAAAAAQAABDV0cmFrAAAAXHRraGQAAAAH0sQ/ldLEP5UAAAABAAAAAAAAdU4AAAAAAAAAAAAAAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAABAAAAAAAAAAAAAAAAAABAAAAAAoAAAAFoAAAAAAAkZWR0cwAAABxlbHN0AAAAAAAAAAEAAHVOAAAH0gABAAAAAAOtbWRpYQAAACBtZGhkAAAAANLEP5XSxD+VAAB1MAAAdU5VxAAAAAAANmhkbHIAAAAAAAAAAHZpZGUAAAAAAAAAAAAAAABMLVNNQVNIIFZpZGVvIEhhbmRsZXIAAAADT21pbmYAAAAUdm1oZAAAAAEAAAAAAAAAAAAAACRkaW5mAAAAHGRyZWYAAAAAAAAAAQAAAAx1cmwgAAAAAQAAAw9zdGJsAAAAwXN0c2QAAAAAAAAAAQAAALFhdmMxAAAAAAAAAAEAAAAAAAAAAAAAAAAAAAAAAoABaABIAAAASAAAAAAAAAABCkFWQyBDb2RpbmcAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP//AAAAOGF2Y0MBZAAf/+EAHGdkAB+s2UCgL/lwFqCgoKgAAB9IAAdTAHjBjLABAAVo6+yyLP34+AAAAAATY29scm5jbHgABQAFAAUAAAAAEHBhc3AAAAABAAAAAQAAABhzdHRzAAAAAAAAAAEAAAAeAAAD6QAAAQBjdHRzAAAAAAAAAB4AAAABAAAH0gAAAAEAABONAAAAAQAAB9IAAAABAAAAAAAAAAEAAAPpAAAAAQAAE40AAAABAAAH0gAAAAEAAAAAAAAAAQAAA+kAAAABAAATjQAAAAEAAAfSAAAAAQAAAAAAAAABAAAD6QAAAAEAABONAAAAAQAAB9IAAAABAAAAAAAAAAEAAAPpAAAAAQAAE40AAAABAAAH0gAAAAEAAAAAAAAAAQAAA+kAAAABAAATjQAAAAEAAAfSAAAAAQAAAAAAAAABAAAD6QAAAAEAABONAAAAAQAAB9IAAAABAAAAAAAAAAEAAAPpAAAAAQAAB9IAAAAUc3RzcwAAAAAAAAABAAAAAQAAACpzZHRwAAAAAKaWlpqalpaampaWmpqWlpqalpaampaWmpqWlpqalgAAABxzdHNjAAAAAAAAAAEAAAABAAAAHgAAAAEAAACMc3RzegAAAAAAAAAAAAAAHgAAA5YAAAAVAAAAEwAAABMAAAATAAAAGwAAABUAAAATAAAAEwAAABsAAAAVAAAAEwAAABMAAAAbAAAAFQAAABMAAAATAAAAGwAAABUAAAATAAAAEwAAABsAAAAVAAAAEwAAABMAAAAbAAAAFQAAABMAAAATAAAAGwAAABRzdGNvAAAAAAAAAAEAAAT6AAAAGHNncGQBAAAAcm9sbAAAAAIAAAAAAAAAHHNiZ3AAAAAAcm9sbAAAAAEAAAAeAAAAAAAAAAhmcmVlAAAGC21kYXQAAAMfBgX///8b3EXpvebZSLeWLNgg2SPu73gyNjQgLSBjb3JlIDE0OCByMTEgNzU5OTIxMCAtIEguMjY0L01QRUctNCBBVkMgY29kZWMgLSBDb3B5bGVmdCAyMDAzLTIwMTUgLSBodHRwOi8vd3d3LnZpZGVvbGFuLm9yZy94MjY0Lmh0bWwgLSBvcHRpb25zOiBjYWJhYz0xIHJlZj0zIGRlYmxvY2s9MTowOjAgYW5hbHlzZT0weDM6MHgxMTMgbWU9aGV4IHN1Ym1lPTcgcHN5PTEgcHN5X3JkPTEuMDA6MC4wMCBtaXhlZF9yZWY9MSBtZV9yYW5nZT0xNiBjaHJvbWFfbWU9MSB0cmVsbGlzPTEgOHg4ZGN0PTEgY3FtPTAgZGVhZHpvbmU9MjEsMTEgZmFzdF9wc2tpcD0xIGNocm9tYV9xcF9vZmZzZXQ9LTIgdGhyZWFkcz0xMSBsb29rYWhlYWRfdGhyZWFkcz0xIHNsaWNlZF90aHJlYWRzPTAgbnI9MCBkZWNpbWF0ZT0xIGludGVybGFjZWQ9MCBibHVyYXlfY29tcGF0PTAgc3RpdGNoYWJsZT0xIGNvbnN0cmFpbmVkX2ludHJhPTAgYmZyYW1lcz0zIGJfcHlyYW1pZD0yIGJfYWRhcHQ9MSBiX2JpYXM9MCBkaXJlY3Q9MSB3ZWlnaHRiPTEgb3Blbl9nb3A9MCB3ZWlnaHRwPTIga2V5aW50PWluZmluaXRlIGtleWludF9taW49Mjkgc2NlbmVjdXQ9NDAgaW50cmFfcmVmcmVzaD0wIHJjX2xvb2thaGVhZD00MCByYz0ycGFzcyBtYnRyZWU9MSBiaXRyYXRlPTExMiByYXRldG9sPTEuMCBxY29tcD0wLjYwIHFwbWluPTUgcXBtYXg9NjkgcXBzdGVwPTQgY3BseGJsdXI9MjAuMCBxYmx1cj0wLjUgdmJ2X21heHJhdGU9ODI1IHZidl9idWZzaXplPTkwMCBuYWxfaHJkPW5vbmUgZmlsbGVyPTAgaXBfcmF0aW89MS40MCBhcT0xOjEuMDAAgAAAAG9liIQAFf/+963fgU3DKzVrulc4tMurlDQ9UfaUpni2SAAAAwAAAwAAD/DNvp9RFdeXpgAAAwB+ABHAWYLWHUFwGoHeKCOoUwgBAAADAAADAAADAAADAAAHgvugkks0lyOD2SZ76WaUEkznLgAAFFEAAAARQZokbEFf/rUqgAAAAwAAHVAAAAAPQZ5CeIK/AAADAAADAA6ZAAAADwGeYXRBXwAAAwAAAwAOmAAAAA8BnmNqQV8AAAMAAAMADpkAAAAXQZpoSahBaJlMCCv//rUqgAAAAwAAHVEAAAARQZ6GRREsFf8AAAMAAAMADpkAAAAPAZ6ldEFfAAADAAADAA6ZAAAADwGep2pBXwAAAwAAAwAOmAAAABdBmqxJqEFsmUwIK//+tSqAAAADAAAdUAAAABFBnspFFSwV/wAAAwAAAwAOmQAAAA8Bnul0QV8AAAMAAAMADpgAAAAPAZ7rakFfAAADAAADAA6YAAAAF0Ga8EmoQWyZTAgr//61KoAAAAMAAB1RAAAAEUGfDkUVLBX/AAADAAADAA6ZAAAADwGfLXRBXwAAAwAAAwAOmQAAAA8Bny9qQV8AAAMAAAMADpgAAAAXQZs0SahBbJlMCCv//rUqgAAAAwAAHVAAAAARQZ9SRRUsFf8AAAMAAAMADpkAAAAPAZ9xdEFfAAADAAADAA6YAAAADwGfc2pBXwAAAwAAAwAOmAAAABdBm3hJqEFsmUwIK//+tSqAAAADAAAdUQAAABFBn5ZFFSwV/wAAAwAAAwAOmAAAAA8Bn7V0QV8AAAMAAAMADpkAAAAPAZ+3akFfAAADAAADAA6ZAAAAF0GbvEmoQWyZTAgr//61KoAAAAMAAB1QAAAAEUGf2kUVLBX/AAADAAADAA6ZAAAADwGf+XRBXwAAAwAAAwAOmAAAAA8Bn/tqQV8AAAMAAAMADpkAAAAXQZv9SahBbJlMCCv//rUqgAAAAwAAHVE=";
        if (a = a.play()) try {
            return await a, !0
        } catch (b) {}
        return !1
    };
    var Si = class extends Lh {
        getConfig(a) {
            var b = C(a, kf, 3);
            if (jd(b, 10).get("auwvsc") === "true") {
                b = this.runtime;
                var c = Pi(a);
                c = JSON.stringify(rc(c));
                b.videoConfig = c;
                var d, e;
                this.runtime.redirectUrl = (e = (d = Yc(a, Df, 1)[0]) == null ? void 0 : wf(Cf(d))) != null ? e : ""
            } else this.runtime.renderingInput = JSON.stringify(rc(a));
            d = new Ih(a);
            e = new Hh;
            b = fd(d.i, 19);
            b === 2 && (E(d.l, 2) || (b = 1));
            Pc(e, 2, Lb(b), 0);
            b = Zc(e, 1, d.i);
            b = I(b, 4, E(d.i, 21));
            c = D(d.o, jf, 9);
            b = Zc(b, 12, c);
            c = fd(d.i, 94);
            b = Pc(b, 18, Lb(c), 0);
            b = I(b, 19, E(d.i, 92));
            c = fd(d.i, 100);
            Pc(b, 20, Lb(c), 0);
            if (b = D(d.o, hf, 11)) Hc(b, 1) && (c = D(b, gf, 1), Zc(e, 10, c)), (b = D(b, ef, 2)) && Zc(e, 14, b);
            I(e, 16, E(d.l, 13) || !1);
            Rh(a, e, this.uid);
            return e
        }
    };
    var Ti = class {
        constructor() {
            this.u = !1
        }
        disable() {}
        Da() {}
        F() {}
        nb() {}
        Cb() {}
        ra() {}
        Y() {
            return !1
        }
        gb() {}
        lb() {}
    };

    function Ui() {
        var a = Vg(window);
        if (a) {
            if (a) {
                var b = a.pageViewId;
                a = a.clientId;
                Ta(a) && (b += a.replace(/\D/g, "").substring(0, 6))
            } else b = null;
            return +b
        }
        for (a = b = window; b && b !== b.parent;) b = b.parent, Jf(b) && (a = b);
        b = a;
        a = b.google_global_correlator;
        a || (b.google_global_correlator = a = 1 + Math.floor(Math.random() * 8796093022208));
        return a
    }

    function Vi(a, b) {
        var c = Wi[7] || "google_ps_7";
        a = a.S;
        var d = a[c];
        return d === void 0 ? (a[c] = b(), a[c]) : d
    }

    function Xi(a) {
        var b = Ui();
        return Vi(a, () => b)
    }
    var Yi = class {
            constructor() {
                this.S = {}
            }
        },
        Zi = null,
        Wi = {
            [8]: "google_prev_ad_formats_by_region",
            [9]: "google_prev_ad_slotnames_by_region"
        };
    var $i = class {
        constructor() {
            this.o = te `https://pagead2.googlesyndication.com/pagead/js/err_rep.js`
        }
        i(a) {
            if (!(Math.random() > .01 || (a.error && a.meta && a.id || (a = new Qf(a)), r.google_js_errors = r.google_js_errors || [], r.google_js_errors.push(a), r.error_rep_loaded))) {
                var b = this.o,
                    c = r.document;
                a = Kf("SCRIPT", c);
                if (b instanceof ee) b = b.i;
                else throw Error("");
                a.src = b;
                (b = pe(a.ownerDocument)) && a.setAttribute("nonce", b);
                (c = c.getElementsByTagName("script")[0]) && c.parentNode && c.parentNode.insertBefore(a, c);
                r.error_rep_loaded = !0
            }
        }
    };

    function aj(a) {
        a = a._google_rum_ns_ = a._google_rum_ns_ || {};
        return a.pq = a.pq || []
    };

    function bj(a, b, c) {
        If(b, (d, e) => {
            var f = c && c[e];
            !d && d !== 0 || f || (a += `&${encodeURIComponent(e)}=${encodeURIComponent(String(d))}`, c && (c[e] = !0))
        });
        return a
    }

    function cj(a, b, c, d = !0) {
        var e = a.l();
        if (!d) {
            let f = e.findIndex(g => g.getName() === b);
            if (f !== -1) {
                yg(e[f], c);
                c = e.filter((g, h) => h <= f || g.getName() !== b);
                a.u(c);
                return
            }
        }
        a.o(yg(xg(new zg, b), c))
    }

    function dj(a, b, c, d = !0) {
        if (b !== "ec") switch (b) {
            case "c":
                a.setCorrelator(c);
                break;
            case "e":
                c.split(",").map(Number).filter(f => !isNaN(f)).forEach(f => {
                    ad(a, 7, Nb, f, Ob)
                });
                break;
            default:
                var e = b.lastIndexOf(".");
                if (e !== -1) {
                    let f = b.substring(0, e);
                    e = b.substring(e + 1);
                    if (e !== "") {
                        let g = Number(e);
                        if (!isNaN(g)) {
                            b = Eg(a).find(h => h.getSlotId() === g);
                            b || (b = Ag(new Bg, g), Fg(a, b));
                            f === "qqid" ? J(b, 63, c) : cj(b, f, c, d);
                            break
                        }
                    }
                }
                cj(a, b, c, d)
        }
    }

    function ej(a) {
        return a.namespace !== "pagead"
    }

    function fj(a, b) {
        var c = `met.${b.type}`,
            d = Sa(b.value) ? Math.round(b.value).toString(36) : b.value,
            e = Math.round(b.duration);
        gj(a, c, `${b.label}` + (b.slotId != null ? `_${b.slotId}` : "") + `.${d}` + (e > 0 ? `_${e.toString(36)}` : "") + (b.taskId != null ? `__${Math.round(b.taskId).toString(36)}` : ""), !0, "~")
    }

    function hj(a) {
        return a.namespace === "pagead"
    }

    function ij(a, b) {
        var c = tg(sg(new ug, b.type), Math.round(Number(b.value)));
        a.namespace && J(c, 3, a.namespace);
        isFinite(b.duration) && id(c, 6, Math.round(b.duration));
        b.taskId != null && id(c, 13, b.taskId);
        var d = Number(b.label),
            e = isFinite(d);
        switch (b.type) {
            case 1:
                d === 24 && vg(Dg(jj(a)), Math.round(Number(b.value)));
                return;
            case 3:
            case 13:
                e ? Qc(c, 9, d == null ? d : Nb(d)) : Qc(c, 1, Xb(String(b.label)));
                break;
            case 2:
                e ? Qc(c, 8, d == null ? d : Nb(d)) : Qc(c, 1, Xb(String(b.label)));
                break;
            case 9:
                e ? Qc(c, 11, d == null ? d : Nb(d)) : Qc(c, 1, Xb(String(b.label)));
                break;
            default:
                Qc(c, 1, Xb(String(b.label)))
        }
        b.slotId != null ? (d = Eg(jj(a)).find(f => f.getSlotId() === b.slotId), d || (d = Ag(new Bg, b.slotId), Fg(jj(a), d)), cd(d, 2, ug, c)) : Cg(jj(a), c)
    }

    function kj(a) {
        a.ra("puid", `${(a.N+1).toString(36)}~${Date.now().toString(36)}`)
    }

    function lj(a) {
        a.i.document.readyState === "complete" ? a.i.setTimeout(() => {
            a.l()
        }, 0) : Ge(a.i, "load", a.L);
        var b = Je(a.i.document);
        typeof b !== "undefined" && Ge(a.i, b, a.ba);
        Ge(a.i, "pagehide", a.R)
    }

    function mj(a, b, c, d, e = "") {
        return a.report[b] == null ? b.length + c.length + 2 : d ? c.length + e.length : c.length - a.report[b].length
    }

    function nj(a, b, c, d, e = "") {
        a.report[b] = d && a.report[b] != null ? a.report[b] + `${e}${c}` : c
    }

    function jj(a) {
        a.D || (a.D = new Gg);
        return a.D
    }

    function oj(a) {
        a.A + a.o >= 6E3 && a.l()
    }

    function gj(a, b, c, d, e = "") {
        var f = mj(a, b, c, d, e);
        a.A + a.o + f > 8E3 && (a.l(), f = b.length + c.length + 2);
        nj(a, b, c, d, e);
        a.o += f;
        oj(a)
    }

    function pj(a) {
        var b = a.i,
            c = b.google_timing_params;
        if (!a.D) {
            let e = c && Object.keys(c).some(g => {
                    var h = c[g];
                    return g !== "ec" && (h || h === 0)
                }),
                f = a.I.some(([g, h]) => g !== "ec" && !!h);
            if (!e && !f) return
        }
        ej(a) || a.N++;
        var d = jj(a);
        If(a.B, (e, f) => {
            e && dj(d, f, e)
        });
        c && (If(c, (e, f) => {
            (e || e === 0) && dj(d, f, String(e))
        }), ej(a) || (b.google_timing_params = void 0));
        a.I.forEach(([e, f]) => {
            f && dj(d, e, f)
        });
        ej(a) || (a.I.length = 0);
        Ig(qj(a), d);
        ej(a) || kj(a);
        a.D = void 0
    }

    function rj(a, b) {
        var c = `${a.protocol}//${a.domain}${a.path}ima`,
            d = {};
        c = bj(c, a.B, d);
        c = bj(c, b, d);
        b = a.i;
        b.google_timing_params && (c = bj(c, b.google_timing_params, d), b.google_timing_params = void 0);
        Ca(a.I, e => {
            var [f, g] = e;
            c = bj(c, {
                [f]: g
            })
        });
        a.I.length = 0;
        return c
    }

    function qj(a) {
        if (!a.G) {
            let b = a.i;
            b.google_rum_rcs_pinger || (b.google_rum_rcs_pinger = new Pg(void 0, void 0, void 0, () => a.domain === "connect.csi.gstatic.com"));
            a.G = b.google_rum_rcs_pinger
        }
        return a.G
    }
    var sj = class extends Zf {
        constructor() {
            super();
            this.protocol = "https:";
            this.domain = "pagead2.googlesyndication.com";
            this.path = "/pagead/gen_204?id=";
            this.N = 0;
            this.B = {};
            this.K = {};
            this.P = [];
            this.report = {};
            this.o = 0;
            this.I = [];
            var a = (this.path + "ima").match(/[?&]s=([^&]*)/);
            this.namespace = a ? a[1] : "";
            a = this.i.navigator;
            this.Z = !(this.domain !== "csi.gstatic.com" && this.domain !== "connect.csi.gstatic.com" || !a || !a.sendBeacon);
            this.i.performance && this.i.performance.now || this.ra("dat", 1);
            a && a.deviceMemory && this.ra("dmc",
                a.deviceMemory);
            this.i === this.i.top && this.ra("top", 1);
            this.V = !1;
            this.L = () => {
                this.i.setTimeout(() => {
                    this.l()
                }, 1100)
            };
            this.R = () => {
                for (var c of this.P) try {
                    c()
                } catch (f) {}
                c = this.i;
                var d = {};
                if (typeof window.CustomEvent === "function") var e = new CustomEvent("rum_blp", d);
                else e = document.createEvent("CustomEvent"), e.initCustomEvent("rum_blp", !!d.bubbles, !!d.cancelable, d.detail);
                c.dispatchEvent(e);
                this.l();
                this.G instanceof Og && Ng(this.G)
            };
            this.aa = Yd(() => {
                this.l()
            });
            this.ba = () => {
                var c = this.i.document;
                (c.hidden !=
                    null ? c.hidden : c.mozHidden != null ? c.mozHidden : c.webkitHidden != null && c.webkitHidden) && this.aa()
            };
            this.X = this.i.setTimeout(() => {
                this.l()
            }, 5E3);
            this.A = 60;
            Ca(this.events, c => {
                ej(this) && fj(this, c);
                hj(this) && ij(this, c)
            });
            a = aj(this.i);
            var b = (...c) => {
                var d = c[0];
                c = d[0];
                d = d[1];
                var e = c.length + d.length + 2;
                ej(this) && this.A + this.o + e > 8E3 && this.l();
                this.I.push([c, d]);
                ej(this) && (this.o += e, oj(this));
                return 0
            };
            Ca(a, c => b(c));
            a.length = 0;
            a.push = b;
            kj(this);
            lj(this)
        }
        lb(a) {
            this.P.push(a)
        }
        ra(a, b) {
            b = String(b);
            this.A = this.B[a] !=
                null ? this.A + (b.length - this.B[a].length) : this.A + (a.length + b.length + 2);
            this.B[a] = b
        }
        Cb(a) {
            return this.B[a]
        }
        nb(a) {
            var b = 0;
            if (ej(this)) {
                let c = !1;
                for (let d of Object.keys(a)) this.report[d] != null && (c = !0), b += mj(this, d, a[d], !1);
                (this.A + this.o + b > 8E3 || c) && this.l()
            }
            for (let c of Object.keys(a)) ej(this) && nj(this, c, a[c], !1), hj(this) && c !== "ec" && dj(jj(this), c, a[c], !1);
            ej(this) && (this.o += b, oj(this))
        }
        F(a, b) {
            var c = `${a}=${b}`;
            this.K[c] || (hj(this) && a !== "ec" && dj(jj(this), a, b, !1), ej(this) && gj(this, a, b, !1), c.length < 1E3 &&
                (this.K[c] = !0))
        }
        Y() {
            return this.u && this.V
        }
        l() {
            if (this.Y()) {
                var a = new $i;
                if (hj(this)) try {
                    pj(this)
                } catch (b) {
                    a.i(b)
                }
                if (ej(this)) {
                    try {
                        this.o && this.sendBeacon(this.report)
                    } catch (b) {
                        a.i(b)
                    }
                    this.report = {};
                    this.o = 0
                }
                this.N === Infinity && this.disable();
                this.events.length = 0;
                this.i.clearTimeout(this.X);
                this.X = 0
            }
        }
        sendBeacon(a) {
            this.N++;
            a = rj(this, a);
            var b = !1;
            try {
                b = !!(this.Z && this.i.navigator && this.i.navigator.sendBeacon(a, null))
            } catch (c) {
                this.Z = !1
            }
            b || Lf(this.i, a);
            kj(this)
        }
        J(a) {
            this.u && this.N < Infinity && (super.J(a),
                ej(this) && fj(this, a), hj(this) && ij(this, a))
        }
        Da() {
            this.V = !0;
            this.l()
        }
        disable() {
            super.disable();
            this.i.clearTimeout(this.X);
            this.o = this.X = 0;
            this.report = {};
            this.D = void 0;
            xd(this.K);
            xd(this.B);
            He(this.i, "load", this.L);
            He(this.i, "pagehide", this.R)
        }
    };

    function S(a, b) {
        a.i.gb(b, 4, Sf())
    }

    function T() {
        var a = tj;
        var b = "cb";
        a.cb && a.hasOwnProperty(b) ? a = a.cb : (b = new a, a = a.cb = b);
        return a
    }
    var tj = class {
        constructor() {
            this.i = typeof window !== "undefined" && typeof window.document !== "undefined" ? new sj : new Ti;
            if (Zi) var a = Zi;
            else {
                a = ((a = Vg()) ? Jf(a.master) ? a.master : null : null) || window;
                var b = a.google_persistent_state_async;
                a = b != null && typeof b == "object" && b.S != null && typeof b.S == "object" ? Zi = b : a.google_persistent_state_async = Zi = new Yi
            }
            a = Xi(a);
            a != null && this.i.ra("c", a);
            a = Math.floor(Number(this.i.Cb("c")) / 2);
            a != null && this.i.ra("slotId", a)
        }
        Da() {
            this.i.Da()
        }
        l() {
            this.Da()
        }
        F(a, b) {
            b != null && this.i.F(a, b)
        }
        recordClick(a,
            b, c, d) {
            for (var e = !1, f = "notag"; d != null && d !== document.documentElement;) {
                let g, h;
                if (((g = d) == null ? 0 : g.getAttribute("data-ck-navigates")) || ((h = d) == null ? 0 : h.getAttribute("data-ck-tag"))) {
                    let m, n;
                    e = (n = (m = d) == null ? void 0 : m.getAttribute("data-ck-navigates")) != null ? n : !1;
                    let l, p;
                    f = (p = (l = d) == null ? void 0 : l.getAttribute("data-ck-tag")) != null ? p : "notag";
                    break
                }
                let k;
                d = (k = d.parentElement) != null ? k : void 0
            }
            this.i.gb(`${a}_${b}x${c}|${e}|${f}`, 4, Sf())
        }
    };
    var uj = class {
        constructor() {
            this.i = !0
        }
        async ya(a, b = !1) {
            T().F("faa", "1");
            var c = {
                keepalive: !0,
                method: "get",
                redirect: "follow",
                credentials: "include",
                mode: "no-cors"
            };
            b && (c.referrerPolicy = "no-referrer");
            try {
                var d = await fetch(a, c)
            } catch (f) {
                throw T().F("faf", "1"), f;
            }
            T().F("fas", "1");
            if (this.i && a.includes("/pagead/adview") && typeof window !== "undefined" && (a = window, b = {}, d = d.headers.get("X-Ad-Event-Value"))) try {
                let f = JSON.parse(d);
                b.revenueCurrency = f.currency;
                b.revenueMicros = f.value;
                var e = a.parent;
                b.googMsgType =
                    "aevi";
                e.postMessage(JSON.stringify(b), "*")
            } catch (f) {}
        }
    };
    var vj = "ad.doubleclick.net bid.g.doubleclick.net ggpht.com google.co.uk google.com googleads.g.doubleclick.net googleads4.g.doubleclick.net googleadservices.com googlesyndication.com googleusercontent.com gstatic.com gvt1.com prod.google.com pubads.g.doubleclick.net s0.2mdn.net static.doubleclick.net surveys.g.doubleclick.net youtube.com ytimg.com".split(" "),
        wj = ["c.googlesyndication.com"];

    function xj(a) {
        var b = typeof window !== "undefined" ? window : void 0;
        b = !zh() && (b == null ? 0 : b.location) ? b.location.protocol : "https";
        var c = !1;
        a == null || !a.startsWith("http") || (a == null ? 0 : a.startsWith("https")) ? c = !1 : yj(a, wj) ? c = !1 : b.includes("https") && yj(a, vj) && (c = !0);
        return c ? (a = new P(a), T().F("htp", "1"), Zg(a, "https"), a.toString()) : a
    }

    function zj(a) {
        if (!a) return !1;
        try {
            return (typeof a === "string" ? new P(a) : a).u === "gcache"
        } catch (b) {
            return !1
        }
    }

    function Aj(a) {
        var b;
        if (b = zj(a)) b = !!(new P(a)).i.get("url");
        return b
    }

    function Bj(a) {
        try {
            let b = typeof a === "string" ? new P(a) : a;
            if (zj(b)) {
                let c, d;
                return (d = (c = b.i.get("url")) != null ? c : b.i.get("tag.check_url")) != null ? d : null
            }
        } catch (b) {}
        return null
    }

    function yj(a, b) {
        return (new RegExp("^https?://([a-z0-9-]{1,63}\\.)*(" + b.join("|").replace(/\./g, "\\.") + ")(:[0-9]+)?([/?#]|$)", "i")).test(a)
    };
    var Cj = class {
        constructor() {
            this.o = window.document;
            this.i = new Map;
            this.l = 0
        }
        ya(a, b = !1) {
            var c = new wh,
                d = Kf("IMG", this.o),
                e = (this.l++).toString();
            this.i.set(e, d);
            d.addEventListener("load", () => {
                this.i.delete(e);
                c.resolve()
            });
            d.addEventListener("error", f => {
                this.i.delete(e);
                c.reject(f)
            });
            b && (d.referrerPolicy = "no-referrer");
            d.src = a;
            return c.promise
        }
    };
    var Dj = "://secure-...imrworldwide.com/ ://cdn.imrworldwide.com/ ://aksecure.imrworldwide.com/ ://[^.]*.moatads.com ://youtube[0-9]+.moatpixel.com ://pm.adsafeprotected.com/youtube ://pm.test-adsafeprotected.com/youtube ://e[0-9]+.yt.srs.doubleverify.com www.google.com/pagead/xsul www.youtube.com/pagead/slav".split(" "),
        Ej = /\bocr\b/;

    function Fj(a) {
        if (/^[\s\xa0]*$/.test(a == null ? "" : String(a)) || Ha && a.length > 2048) return !1;
        try {
            if ((new P(a)).A.match(Ej)) return !0
        } catch (b) {}
        return Dj.find(b => a.match(b) != null) != null
    };
    var Gj = class {
        constructor() {
            this.timeoutMs = 5E3;
            this.startTime = Date.now()
        }
        reset() {
            this.startTime = Date.now()
        }
    };
    var Hj = class extends Error {
        constructor(a) {
            super(String(a));
            this.errorCode = a
        }
    };

    function Ij(a) {
        M.call(this);
        this.l = a;
        this.i = {}
    }
    t(Ij, M);
    var Jj = [];
    q = Ij.prototype;
    q.listen = function(a, b, c, d) {
        Array.isArray(b) || (b && (Jj[0] = b.toString()), b = Jj);
        for (let e = 0; e < b.length; e++) {
            let f = Gd(a, b[e], c || this.handleEvent, d || !1, this.l || this);
            if (!f) break;
            this.i[f.key] = f
        }
        return this
    };
    q.wa = function(a, b, c, d) {
        return Kj(this, a, b, c, d)
    };

    function Kj(a, b, c, d, e, f) {
        if (Array.isArray(c))
            for (let g = 0; g < c.length; g++) Kj(a, b, c[g], d, e, f);
        else {
            b = Hd(b, c, d || a.handleEvent, e, f || a.l || a);
            if (!b) return a;
            a.i[b.key] = b
        }
        return a
    }
    q.na = function(a, b, c, d, e) {
        if (Array.isArray(b))
            for (let f = 0; f < b.length; f++) this.na(a, b[f], c, d, e);
        else c = c || this.handleEvent, d = ma(d) ? !!d.capture : !!d, e = e || this.l || this, c = Id(c), d = !!d, b = rd(a) ? a.Ka(b, c, d, e) : a ? (a = Kd(a)) ? a.Ka(b, c, d, e) : null : null, b && (Pd(b), delete this.i[b.key])
    };

    function Lj(a) {
        vd(a.i, function(b, c) {
            this.i.hasOwnProperty(c) && Pd(b)
        }, a);
        a.i = {}
    }
    q.o = function() {
        Ij.ma.o.call(this);
        Lj(this)
    };
    q.handleEvent = function() {
        throw Error("EventHandler.handleEvent not implemented");
    };
    async function Mj({
        url: a,
        timeout: b,
        withCredentials: c,
        method: d,
        content: e,
        headers: f = {}
    }) {
        try {
            return await Nj({
                url: a,
                timeout: b,
                withCredentials: c,
                method: d,
                content: e,
                headers: f
            })
        } catch (g) {
            if (!(g instanceof Error && g.message === "6" || g instanceof Hj && g.errorCode === 6) || !c) throw g instanceof Error ? g : Error(String(g));
        }
        return await Nj({
            url: a,
            timeout: b,
            withCredentials: !c,
            method: d,
            content: e,
            headers: f
        })
    }
    async function Nj({
        url: a,
        timeout: b,
        withCredentials: c,
        method: d,
        content: e,
        headers: f = {}
    }) {
        var g = new hi;
        g.P = c;
        b = b.startTime + b.timeoutMs - Date.now();
        g.L = Math.max(0, b > 0 ? b : 0);
        for (let [h, k] of Object.entries(f)) g.headers.set(h, k);
        try {
            return await Oj(g, xj(a), d, e)
        } finally {
            g.dispose()
        }
    }
    var Pj = class {
        get({
            url: a,
            timeout: b,
            withCredentials: c = !0,
            headers: d = {}
        }) {
            return Mj({
                url: a,
                timeout: b,
                withCredentials: c,
                method: "GET",
                headers: d
            })
        }
    };

    function Oj(a, b, c, d) {
        var e = Qj,
            f = new Ij;
        return (new Promise((g, h) => {
            f.wa(a, "success", () => {
                try {
                    g(e(a))
                } catch (k) {
                    h(k)
                }
            });
            f.wa(a, ["error", "timeout"], () => void h(new Hj(a.B)));
            a.send(b, c, d)
        })).finally(() => {
            f.dispose()
        })
    }

    function Qj(a) {
        a: {
            if (zh()) try {
                oi(a);
                var b = "application/json";
                break a
            } catch (e) {
                b = "application/xml";
                break a
            }
            a.i && (a.i ? a.i.readyState : 0) == 4 ? (b = a.i.getResponseHeader("Content-Type"), b = b === null ? void 0 : b) : b = void 0;b = b || ""
        }
        if (b.indexOf("application/json") !== -1) try {
            return oi(a) || {}
        } catch (e) {
            throw new Hj(5);
        }
        try {
            var c = a.i ? a.i.responseXML : null
        } catch (e) {
            c = null
        }
        if (c == null) {
            try {
                var d = a.i ? a.i.responseText : ""
            } catch (e) {
                d = ""
            }
            if (typeof DOMParser != "undefined") a = new DOMParser, d = ne(d === null ? "null" : d === void 0 ? "undefined" :
                d), c = a.parseFromString(oe(d), "application/xml");
            else throw Error("Your browser does not support loading xml documents");
        }
        a = c;
        if (!Ra(a)) throw Error(String(a));
        return c
    }
    for (var Rj = "google javascript ads imalib common UrlLoader".split(" "), Sj = r, Tj; Rj.length && (Tj = Rj.shift());) Rj.length || Pj === void 0 ? Sj[Tj] && Sj[Tj] !== Object.prototype[Tj] ? Sj = Sj[Tj] : Sj = Sj[Tj] = {} : Sj[Tj] = Pj;
    var Uj = class {
        constructor() {
            this.i = new Pj
        }
        async ya(a) {
            await this.i.get({
                url: a,
                timeout: new Gj
            })
        }
    };
    var Vj = class {
        constructor() {
            this.l = typeof window !== "undefined" && window.fetch != null
        }
        async ya(a, b = !1) {
            try {
                a = xj(a);
                b = b || Fj(a);
                if (this.l) {
                    this.i != null || (this.i = new uj);
                    try {
                        await this.i.ya(a, b);
                        return
                    } catch (c) {
                        this.l = !1
                    }
                }
                zh() ? (this.u != null || (this.u = new Uj), await this.u.ya(a, b)) : (this.o != null || (this.o = new Cj), await this.o.ya(a, b))
            } catch (c) {}
        }
    };

    function Wj() {
        if (typeof Gf === "function") var a = Gf;
        else if (typeof Gf === "object") a = Gf.constructor;
        else throw Error(void 0);
        return Qa(b => b instanceof a)
    };
    var Xj = {},
        Yj = {};

    function Zj() {
        throw Error("Do not instantiate directly");
    }
    Zj.prototype.sb = null;
    Zj.prototype.Ja = function() {
        return this.content
    };
    Zj.prototype.toString = function() {
        return this.content
    };
    Zj.prototype.Jb = function() {
        if (this.Ta !== Xj) throw Error("Sanitized content was not of kind HTML.");
        return ne(this.toString())
    };

    function ak() {
        Zj.call(this)
    }
    t(ak, Zj);
    ak.prototype.Ta = Xj;

    function bk(a) {
        if (a != null) switch (a.sb) {
            case 1:
                return 1;
            case -1:
                return -1;
            case 0:
                return 0
        }
        return null
    }

    function ck(a) {
        return a != null && a.Ta === Xj ? a : a instanceof me ? dk(oe(a).toString()) : dk(String(String(a)).replace(ek, fk), bk(a))
    }
    var dk = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = new b(String(c));
            d !== void 0 && (c.sb = d);
            return c
        }
    }(ak);

    function gk(a) {
        return hk(String(a), () => "").replace(ik, "&lt;")
    }
    var jk = RegExp.prototype.hasOwnProperty("sticky"),
        kk = new RegExp((jk ? "" : "^") + "(?:!|/?([a-zA-Z][a-zA-Z0-9:-]*))", jk ? "gy" : "g");

    function hk(a, b) {
        for (var c = [], d = a.length, e = 0, f = [], g, h, k = 0; k < d;) {
            switch (e) {
                case 0:
                    var m = a.indexOf("<", k);
                    if (m < 0) {
                        if (c.length === 0) return a;
                        c.push(a.substring(k));
                        k = d
                    } else c.push(a.substring(k, m)), h = m, k = m + 1, jk ? (kk.lastIndex = k, m = kk.exec(a)) : (kk.lastIndex = 0, m = kk.exec(a.substring(k))), m ? (f = ["<", m[0]], g = m[1], e = 1, k += m[0].length) : c.push("<");
                    break;
                case 1:
                    m = a.charAt(k++);
                    switch (m) {
                        case "'":
                        case '"':
                            let n = a.indexOf(m, k);
                            n < 0 ? k = d : (f.push(m, a.substring(k, n + 1)), k = n + 1);
                            break;
                        case ">":
                            f.push(m);
                            c.push(b(f.join(""),
                                g));
                            e = 0;
                            f = [];
                            h = g = null;
                            break;
                        default:
                            f.push(m)
                    }
                    break;
                default:
                    throw Error();
            }
            e === 1 && k >= d && (k = h + 1, c.push("<"), e = 0, f = [], h = g = null)
        }
        return c.join("")
    }

    function lk(a, b) {
        a = a.replace(/<\//g, "<\\/").replace(/\]\]>/g, "]]\\>");
        return b ? a.replace(/{/g, " \\{").replace(/}/g, " \\}").replace(/\/\*/g, "/ *").replace(/\\$/, "\\ ") : a
    }

    function mk(a) {
        a != null && a.Ta === Xj ? (a = gk(a.Ja()), a = String(a).replace(nk, fk)) : a = String(a).replace(ek, fk);
        return a
    }

    function ok(a) {
        return a != null && a.Ta === Yj ? lk(a.Ja(), !1) : a == null ? "" : lk(String(a), !0)
    }

    function pk(a, b) {
        a.i !== void 0 ? a.i.push(b) : a.content += b;
        return a
    }

    function qk(a, b) {
        a.i !== void 0 ? a.i.push(b) : b instanceof rk ? b.content !== void 0 ? a.content += b.Ja() : (a.i = [a.content, b], a.content = void 0) : a.content += b;
        return a
    }
    class rk extends ak {
        Ja() {
            if (this.content !== void 0) return this.content;
            var a = "";
            for (let b of this.i) a += b;
            return a
        }
        toString() {
            return this.Ja()
        }
    }
    var sk = (() => {
            function a() {
                this.content = ""
            }
            a.prototype = rk.prototype;
            return function() {
                return new a
            }
        })(),
        tk = {
            "\x00": "&#0;",
            "\t": "&#9;",
            "\n": "&#10;",
            "\v": "&#11;",
            "\f": "&#12;",
            "\r": "&#13;",
            " ": "&#32;",
            '"': "&quot;",
            "&": "&amp;",
            "'": "&#39;",
            "-": "&#45;",
            "/": "&#47;",
            "<": "&lt;",
            "=": "&#61;",
            ">": "&gt;",
            "`": "&#96;",
            "\u0085": "&#133;",
            "\u00a0": "&#160;",
            "\u2028": "&#8232;",
            "\u2029": "&#8233;"
        };

    function fk(a) {
        return tk[a]
    }
    var ek = /[\x00\x22\x26\x27\x3c\x3e]/g,
        nk = /[\x00\x22\x27\x3c\x3e]/g,
        uk = /^[a-zA-Z0-9+\/_-]+={0,2}$/;

    function vk(a) {
        a = String(a);
        return uk.test(a) ? a : "zSoyz"
    }
    var ik = /</g;
    /*
     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    function wk(a, b) {
        a: {
            var c = a(b || xk, void 0);a = ta || (ta = new Ae);b = c && c.hc ? c.hc() : null;
            if (!b) {
                b: if (ma(c)) {
                    if (c.Jb) {
                        var d = c.Jb();
                        if (d instanceof me) break b
                    }
                    d = se("zSoyz")
                } else d = se(String(c));b = a.createElement("DIV");b.innerHTML = oe(d);d = b.childNodes
            }
            if (d.length == 1 && (c = d[0], c.nodeType == 1)) {
                a = c;
                break a
            }
            b || (b = a.createElement("DIV"), b.append(...d));a = b
        }
        return a
    }
    var xk = {};

    function yk() {
        return dk('<div class="video-box" style="overflow: hidden; position: absolute;"><div class="video-container" style=" background-color: rgba(0,0,0,1); height: 100%; overflow: hidden; position: absolute; width: 100%; z-index: 1;"><div class="blurred-video-background" style=" height: 100%; width: 100%; position: absolute; top: 0; left: 0; z-index: -1; filter: blur(8px) brightness(0.8); background-size: contain; display: none;"></div></div></div>')
    };

    function zk(a, b) {
        var c = b != null ? b : {};
        b = a.zIndex;
        var d = a.ac;
        a = a.ta;
        c = c && c.tb;
        return dk('<div class="mute-button-container"><svg class="mute-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#fff"><path d="M16.5 12c0-1.77-1.02-3.29-2.5-4.03v2.21l2.45 2.45c.03-.2.05-.41.05-.63zm2.5 0c0 .94-.2 1.82-.54 2.64l1.51 1.51C20.63 14.91 21 13.5 21 12c0-4.28-2.99-7.86-7-8.77v2.06c2.89.86 5 3.54 5 6.71zM4.27 3L3 4.27 7.73 9H3v6h4l5 5v-6.73l4.25 4.25c-.67.52-1.42.93-2.25 1.18v2.06c1.38-.31 2.63-.95 3.69-1.81L19.73 21 21 19.73l-9-9L4.27 3zM12 4L9.91 6.09 12 8.18V4z"/><path d="M0 0h24v24H0z" fill="none"/></svg><svg class="unmute-icon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="#fff"><path d="M3 9v6h4l5 5V4L7 9H3zm13.5 3c0-1.77-1.02-3.29-2.5-4.03v8.05c1.48-.73 2.5-2.25 2.5-4.02zM14 3.23v2.06c2.89.86 5 3.54 5 6.71s-2.11 5.85-5 6.71v2.06c4.01-.91 7-4.49 7-8.77s-2.99-7.86-7-8.77z"/><path d="M0 0h24v24H0z" fill="none"/></svg><style' +
            (c ? ' nonce="' + mk(vk(c)) + '"' : "") + ">.mute-button-container {filter: drop-shadow(rgba(0, 0, 0, 0.2) 0px 1px 5px); height: 20px; margin: 0; overflow: hidden; padding: 8px; position: absolute; width: 20px; z-index: " + ok(b) + "; pointer-events: auto;" + (d ? " bottom " : " top ") + ": 0;" + (a ? " right " : " left ") + ": 0; background: " + (a ? " rgba(0,0,0,.2) " : " transparent ") + ";}[dir=rtl] .mute-button-container {" + (a ? " left " : " right ") + ": 0;}\x3c/style></div>")
    };

    function Ak(a, b) {
        b ? (a.l.style.display = "", a.u.style.display = "none") : (a.l.style.display = "none", a.u.style.display = "")
    }
    var Bk = class {
        constructor(a, b, c = b) {
            this.B = a;
            this.I = b;
            this.A = c;
            this.i = wk(zk, {
                zIndex: this.B,
                ac: this.I,
                ta: this.A
            });
            this.l = ue("mute-icon", this.i);
            this.u = ue("unmute-icon", this.i)
        }
        show() {
            this.i.style.visibility = ""
        }
        ca() {
            this.i.style.visibility = "hidden"
        }
        o() {
            return this.i
        }
    };
    var Ck = class {
        constructor(a) {
            this.url = a
        }
    };

    function Dk(a) {
        return a.url instanceof Ck ? a.url : new Ck(a.url)
    }
    var Ek = class {
        constructor(a, b, c = null) {
            this.eventType = a;
            this.url = b;
            this.i = c;
            this.id = null
        }
        getId() {
            return this.id
        }
    };
    class Fk {
        constructor(a, b) {
            this.l = a;
            this.u = b;
            this.o = 0;
            this.i = null
        }
        get() {
            if (this.o > 0) {
                this.o--;
                var a = this.i;
                this.i = a.next;
                a.next = null
            } else a = this.l();
            return a
        }
        put(a) {
            this.u(a);
            this.o < 100 && (this.o++, a.next = this.i, this.i = a)
        }
    };
    class Gk {
        constructor() {
            this.o = this.i = null
        }
        add(a, b) {
            var c = Hk.get();
            c.set(a, b);
            this.o ? this.o.next = c : this.i = c;
            this.o = c
        }
        remove() {
            var a = null;
            this.i && (a = this.i, this.i = this.i.next, this.i || (this.o = null), a.next = null);
            return a
        }
    }
    var Hk = new Fk(() => new Ik, a => a.reset());
    class Ik {
        constructor() {
            this.next = this.i = this.o = null
        }
        set(a, b) {
            this.o = a;
            this.i = b;
            this.next = null
        }
        reset() {
            this.next = this.i = this.o = null
        }
    };
    var Jk, Kk = !1,
        Lk = new Gk,
        Nk = (a, b) => {
            Jk || Mk();
            Kk || (Jk(), Kk = !0);
            Lk.add(a, b)
        },
        Mk = () => {
            var a = Promise.resolve(void 0);
            Jk = () => {
                a.then(Ok)
            }
        };

    function Ok() {
        for (var a; a = Lk.remove();) {
            try {
                a.o.call(a.i)
            } catch (b) {
                va(b)
            }
            Hk.put(a)
        }
        Kk = !1
    };

    function Pk(a) {
        if (!a) return !1;
        try {
            return !!a.$goog_Thenable
        } catch (b) {
            return !1
        }
    };

    function Qk(a) {
        this.i = 0;
        this.I = void 0;
        this.u = this.o = this.l = null;
        this.A = this.B = !1;
        if (a != Xd) try {
            let b = this;
            a.call(void 0, function(c) {
                Rk(b, 2, c)
            }, function(c) {
                Rk(b, 3, c)
            })
        } catch (b) {
            Rk(this, 3, b)
        }
    }

    function Sk() {
        this.next = this.context = this.o = this.l = this.i = null;
        this.u = !1
    }
    Sk.prototype.reset = function() {
        this.context = this.o = this.l = this.i = null;
        this.u = !1
    };
    var Tk = new Fk(function() {
        return new Sk
    }, function(a) {
        a.reset()
    });

    function Uk(a, b, c) {
        var d = Tk.get();
        d.l = a;
        d.o = b;
        d.context = c;
        return d
    }
    Qk.prototype.then = function(a, b, c) {
        return Vk(this, ei(typeof a === "function" ? a : null), ei(typeof b === "function" ? b : null), c)
    };
    Qk.prototype.$goog_Thenable = !0;
    Qk.prototype.cancel = function(a) {
        if (this.i == 0) {
            let b = new Wk(a);
            Nk(function() {
                Xk(this, b)
            }, this)
        }
    };

    function Xk(a, b) {
        if (a.i == 0)
            if (a.l) {
                var c = a.l;
                if (c.o) {
                    var d = 0,
                        e = null,
                        f = null;
                    for (let g = c.o; g && (g.u || (d++, g.i == a && (e = g), !(e && d > 1))); g = g.next) e || (f = g);
                    e && (c.i == 0 && d == 1 ? Xk(c, b) : (f ? (d = f, d.next == c.u && (c.u = d), d.next = d.next.next) : Yk(c), Zk(c, e, 3, b)))
                }
                a.l = null
            } else Rk(a, 3, b)
    }

    function $k(a, b) {
        a.o || a.i != 2 && a.i != 3 || al(a);
        a.u ? a.u.next = b : a.o = b;
        a.u = b
    }

    function Vk(a, b, c, d) {
        var e = Uk(null, null, null);
        e.i = new Qk(function(f, g) {
            e.l = b ? function(h) {
                try {
                    let k = b.call(d, h);
                    f(k)
                } catch (k) {
                    g(k)
                }
            } : f;
            e.o = c ? function(h) {
                try {
                    let k = c.call(d, h);
                    k === void 0 && h instanceof Wk ? g(h) : f(k)
                } catch (k) {
                    g(k)
                }
            } : g
        });
        e.i.l = a;
        $k(a, e);
        return e.i
    }
    Qk.prototype.N = function(a) {
        this.i = 0;
        Rk(this, 2, a)
    };
    Qk.prototype.G = function(a) {
        this.i = 0;
        Rk(this, 3, a)
    };

    function Rk(a, b, c) {
        if (a.i == 0) {
            a === c && (b = 3, c = new TypeError("Promise cannot resolve to itself"));
            a.i = 1;
            a: {
                var d = c,
                    e = a.N,
                    f = a.G;
                if (d instanceof Qk) {
                    $k(d, Uk(e || Xd, f || null, a));
                    var g = !0
                } else if (Pk(d)) d.then(e, f, a),
                g = !0;
                else {
                    if (ma(d)) try {
                        let h = d.then;
                        if (typeof h === "function") {
                            bl(d, h, e, f, a);
                            g = !0;
                            break a
                        }
                    } catch (h) {
                        f.call(a, h);
                        g = !0;
                        break a
                    }
                    g = !1
                }
            }
            g || (a.I = c, a.i = b, a.l = null, al(a), b != 3 || c instanceof Wk || cl(a, c))
        }
    }

    function bl(a, b, c, d, e) {
        function f(k) {
            h || (h = !0, d.call(e, k))
        }

        function g(k) {
            h || (h = !0, c.call(e, k))
        }
        var h = !1;
        try {
            b.call(a, g, f)
        } catch (k) {
            f(k)
        }
    }

    function al(a) {
        a.B || (a.B = !0, Nk(a.D, a))
    }

    function Yk(a) {
        var b = null;
        a.o && (b = a.o, a.o = b.next, b.next = null);
        a.o || (a.u = null);
        return b
    }
    Qk.prototype.D = function() {
        for (var a; a = Yk(this);) Zk(this, a, this.i, this.I);
        this.B = !1
    };

    function Zk(a, b, c, d) {
        if (c == 3 && b.o && !b.u)
            for (; a && a.A; a = a.l) a.A = !1;
        if (b.i) b.i.l = null, dl(b, c, d);
        else try {
            b.u ? b.l.call(b.context) : dl(b, c, d)
        } catch (e) {
            el.call(null, e)
        }
        Tk.put(b)
    }

    function dl(a, b, c) {
        b == 2 ? a.l.call(a.context, c) : a.o && a.o.call(a.context, c)
    }

    function cl(a, b) {
        a.A = !0;
        Nk(function() {
            a.A && el.call(null, b)
        })
    }
    var el = va;

    function Wk(a) {
        sa.call(this, a)
    }
    t(Wk, sa);
    Wk.prototype.name = "cancel";

    function fl(a, b) {
        N.call(this);
        this.u = a || 1;
        this.l = b || r;
        this.A = () => {
            if (this.enabled) {
                let c = Date.now() - this.B;
                c > 0 && c < this.u * .8 ? this.i = this.l.setTimeout(this.A, this.u - c) : (this.i && (this.l.clearTimeout(this.i), this.i = null), this.dispatchEvent("tick"), this.enabled && (this.stop(), this.start()))
            }
        };
        this.B = Date.now()
    }
    t(fl, N);
    q = fl.prototype;
    q.enabled = !1;
    q.i = null;
    q.setInterval = function(a) {
        this.u = a;
        this.i && this.enabled ? (this.stop(), this.start()) : this.i && this.stop()
    };
    q.start = function() {
        this.enabled = !0;
        this.i || (this.i = this.l.setTimeout(this.A, this.u), this.B = Date.now())
    };
    q.stop = function() {
        this.enabled = !1;
        this.i && (this.l.clearTimeout(this.i), this.i = null)
    };
    q.o = function() {
        fl.ma.o.call(this);
        this.stop();
        delete this.l
    };

    function gl(a) {
        if (typeof a !== "function")
            if (a && typeof a.handleEvent == "function") a = a.handleEvent.bind(a);
            else throw Error("Invalid listener argument");
        return Number(8E3) > 2147483647 ? -1 : r.setTimeout(a, 8E3)
    };

    function hl(a) {
        a.l && (r.clearTimeout(a.l), a.l = null)
    }

    function il(a) {
        a.l || (a.l = gl(() => {
            a.Ba || a.dispatchEvent("mediaPlaybackTimeout")
        }))
    }
    var jl = class extends N {
        constructor(a) {
            super();
            this.M = a;
            this.loaded = this.Ba = this.u = !1;
            this.l = null;
            this.i = new Ij(this);
            md(this, this.i);
            this.D = []
        }
        dispatchEvent(a) {
            return this.u ? (this.D.push(a), !0) : super.dispatchEvent(a)
        }
        releaseEvents() {
            this.u && (this.u = !1, this.D.forEach(a => {
                this.dispatchEvent(a)
            }))
        }
        sa() {
            this.Ha();
            this.i.listen(this.M, "ended", this.G);
            this.i.listen(this.M, "pause", this.J);
            this.i.listen(this.M, "playing", this.Z);
            this.i.listen(this.M, "timeupdate", this.K);
            this.i.listen(this.M, "volumechange",
                this.ga);
            this.i.listen(this.M, "error", this.onError);
            this.i.listen(this.M, "canplay", this.P);
            this.i.listen(this.M, "canplaythrough", this.R);
            this.i.listen(this.M, "loadstart", this.Y);
            this.i.listen(this.M, "durationchange", this.V);
            this.i.listen(this.M, "waiting", this.L);
            this.i.listen(this.M, "seeked", this.ba);
            this.i.listen(this.M, "seeking", this.ea);
            this.i.listen(this.M, "stalled", this.fa);
            this.i.listen(this.M, "progress", this.aa);
            this.i.listen(this.M, "loadeddata", this.A)
        }
        Ha() {
            Lj(this.i)
        }
        getCurrentTime() {
            return this.M.currentTime
        }
        getDuration() {
            return isNaN(this.M.duration) ?
                -1 : this.M.duration
        }
        getVolume() {
            return this.isMuted() ? 0 : this.M.volume
        }
        B() {
            return this.M.paused
        }
        isMuted() {
            return this.M.muted
        }
        G() {
            this.dispatchEvent("end");
            hl(this)
        }
        J() {
            this.M.ended || this.dispatchEvent("pause");
            hl(this)
        }
        Z() {
            this.dispatchEvent("play")
        }
        K() {
            var a = this.getCurrentTime();
            if (!this.Ba) {
                if (a <= 0) return;
                if (Ma && this.M.ended && this.getDuration() === 1) {
                    this.onError();
                    return
                }
                this.Ba || (this.Ba = !0, hl(this), this.dispatchEvent("start"))
            }
            this.dispatchEvent("timeUpdate")
        }
        L() {
            this.dispatchEvent("waiting")
        }
        ga() {
            this.dispatchEvent("volumeChange")
        }
        V() {
            this.dispatchEvent("durationChange")
        }
        onError() {
            hl(this);
            this.dispatchEvent("error")
        }
        P() {
            this.dispatchEvent("canPlay");
            this.A()
        }
        R() {
            this.dispatchEvent("canPlayThrough")
        }
        Y() {
            this.dispatchEvent("loadStart");
            this.dispatchEvent("mediaLoadAttempt")
        }
        ba() {
            this.dispatchEvent("seeked")
        }
        ea() {
            this.dispatchEvent("seeking")
        }
        fa() {
            this.dispatchEvent("stalled")
        }
        aa() {
            this.M.buffered && this.M.buffered.length && this.M.buffered.end(this.M.buffered.length - 1) === this.getDuration() && (S(T(), "vfl"), this.dispatchEvent("fullyLoaded"))
        }
        A() {
            this.loaded || (S(T(), "vil"), this.loaded = !0, this.dispatchEvent("loaded"))
        }
        play() {
            this.Ba ||
                il(this);
            return this.M.play()
        }
        pause() {
            this.M.pause()
        }
        setVolume(a) {
            this.M.volume = a
        }
        canPlayType(a) {
            if (typeof this.M.canPlayType !== "function") return T().F("vmcpy", "1"), !0;
            a = this.M.canPlayType(a);
            return a !== "" && a != null
        }
        getVideoUrl() {
            return this.M.currentSrc
        }
        getSize() {
            var a = this.M;
            b: {
                var b = a.nodeType == 9 ? a : a.ownerDocument || a.document;
                if (b.defaultView && b.defaultView.getComputedStyle && (b = b.defaultView.getComputedStyle(a, null))) {
                    b = b.display || b.getPropertyValue("display") || "";
                    break b
                }
                b = ""
            }
            if ((b || (a.currentStyle ?
                    a.currentStyle.display : null) || a.style && a.style.display) != "none") a = Fe(a);
            else {
                b = a.style;
                var c = b.display,
                    d = b.visibility,
                    e = b.position;
                b.visibility = "hidden";
                b.position = "absolute";
                b.display = "inline";
                a = Fe(a);
                b.display = c;
                b.position = e;
                b.visibility = d
            }
            return a
        }
    };
    var kl = class {
            constructor(a, b, c) {
                this.id = a;
                this.C = b;
                this.Bb = c;
                this.selected = !1
            }
        },
        ll = class {
            constructor() {
                this.i = []
            }
        };

    function U(a) {
        var b = ml;
        if (b.o || b.i.has(a.id) || a.C == null && a.control == null || a.Rc === !1) return b.A;
        var c = b.u;
        if (a.control != null)
            for (var d of b.l) {
                if (d.i.includes(a.control)) {
                    c = d;
                    break
                }
            } else a.ia != null && (c = a.ia);
        d = 0;
        a.control != null ? d = a.control.C : a.C != null && (d = a.C);
        a = new kl(a.id, d, !!a.Bb);
        c.i.push(a);
        b.l.includes(c) || b.l.push(c);
        b.i.set(a.id, a);
        return a
    }
    var ml = new class {
        constructor() {
            this.o = !1;
            this.i = new Map;
            this.u = new ll;
            this.A = new kl(0, 0, !1);
            this.l = [this.u]
        }
        reset() {
            for (let [, a] of this.i) a.selected = !1;
            this.o = !1
        }
    };
    var nl = class {
        constructor(a) {
            this.i = a
        }
        hb(a, b) {
            for (let c of this.i)
                if (a = b.get(c)) a.selected = !0
        }
    };
    var ql = class extends nl {
        constructor() {
            var a = ol(),
                b = pl;
            super(a);
            this.o = b
        }
        hb(a, b) {
            super.hb(a, b);
            var c = [];
            a = [];
            for (let d of this.i) b.get(d) ? c.push(d) : a.push(d);
            b = c.map(String).join(",") || "0";
            a = a.map(String).join(",") || "0";
            T().F("sei", b);
            T().F("nsei", a);
            T().F("bi", this.o)
        }
    };

    function rl() {
        var a = sl,
            b = tl(a);
        if (b !== null)
            if (fi(b)) {
                var c = JSON.parse(b);
                b = c.experimentIds;
                var d = c.binaryIdentifier;
                c = c.adEventId;
                var e = typeof d === "string";
                if (typeof c === "string") {
                    var f = T();
                    c != null && f.i.ra("qqid", c)
                }
                e && (a.i = d);
                if (typeof b !== "string") a.onError("missing-flags", a.i);
                else {
                    if (!e) a.onError("missing-binary-id", a.i);
                    a.l = b
                }
            } else a.onError("invalid-json", a.i)
    }

    function tl(a) {
        var b = null;
        try {
            b = a.u.getElementsByClassName("lima-exp-data")
        } catch (c) {
            return a.onError("missing-element", a.i), null
        }
        if (b.length > 1) return a.onError("multiple-elements", a.i), null;
        b = b[0];
        return b ? b.innerHTML : (a.onError("missing-element", a.i), null)
    }
    var ul = class {
        constructor(a) {
            this.u = a;
            this.l = null;
            this.i = "missing-id";
            this.o = !1
        }
        reset() {
            this.l = null;
            this.i = "missing-id";
            this.o = !1
        }
    };
    var vl = class extends ul {
            onError(a, b) {
                var c = T();
                c.F("eee", a);
                c.F("bi", b)
            }
        },
        wl;

    function ol() {
        return xl.split(",").map(a => {
            a = a.trim();
            a = Number((a.charCodeAt(0) - 43 & -3 ? "0" : "") + a + ".");
            a = Number.isInteger(a) ? a : void 0;
            return a
        }).filter(a => a != null && !isNaN(a))
    };
    var yl = new ll,
        zl = new ll,
        Al = new ll;
    U({
        id: 95342637,
        C: 0
    });
    U({
        id: 318475490,
        C: 0
    });
    U({
        id: 324123032,
        C: 0
    });
    U({
        id: 95342168,
        C: 10
    });
    U({
        id: 95342169,
        C: 10
    });
    U({
        id: 21062100,
        C: 0
    });
    U({
        id: 420706142,
        C: 0
    });
    U({
        id: 44745813,
        C: 0
    });
    U({
        id: 95355265,
        C: 0
    });
    U({
        id: 95382105,
        C: 0
    });
    U({
        id: 95389385,
        C: 0
    });
    U({
        id: 95391052,
        C: 0
    });
    U({
        id: 95390991,
        C: 0
    });
    U({
        id: 95405086,
        C: 0
    });
    U({
        id: 44746068,
        C: 0
    });
    U({
        id: 418572006,
        C: 10
    });
    U({
        id: 95338773,
        C: 10,
        ia: zl
    });
    U({
        id: 95338774,
        C: 10,
        ia: zl
    });
    U({
        id: 95334214,
        C: 10
    });
    U({
        id: 95334215,
        C: 10
    });
    U({
        id: 44714743,
        C: 0
    });
    U({
        id: 44715336,
        C: 10
    });
    U({
        id: 44724516,
        C: 0
    });
    U({
        id: 44726389,
        C: 10
    });
    U({
        id: 44733246,
        C: 10
    });
    U({
        id: 44751889,
        C: 10
    });
    U({
        id: 44751890,
        C: 10
    });
    U({
        id: 44752995,
        C: 10
    });
    U({
        id: 44752996,
        C: 10
    });
    U({
        id: 44762627,
        C: 0
    });
    U({
        id: 44762628,
        C: 0
    });
    U({
        id: 44801479,
        C: 10,
        ia: yl
    });
    U({
        id: 44801480,
        C: 10,
        ia: yl
    });
    U({
        id: 44754608,
        C: 10
    });
    U({
        id: 44754609,
        C: 10
    });
    U({
        id: 44776384,
        C: 0
    });
    U({
        id: 44789282,
        C: 0
    });
    U({
        id: 95355192,
        C: 0
    });
    U({
        id: 95403989,
        C: 0
    });
    U({
        id: 95334260,
        C: 0
    });
    U({
        id: 75259416,
        C: 0
    });
    U({
        id: 75259420,
        C: 0
    });
    U({
        id: 318524579,
        C: 0
    });
    U({
        id: 75259421,
        C: 0
    });
    U({
        id: 95399021,
        C: 0
    });
    U({
        id: 45401791,
        C: 0
    });
    U({
        id: 44809192,
        C: 0,
        ia: Al
    });
    U({
        id: 44809193,
        C: 0,
        ia: Al
    });
    U({
        id: 95320804,
        C: 0,
        ia: Al
    });
    U({
        id: 95320805,
        C: 0,
        ia: Al
    });
    U({
        id: 46130031,
        C: 0
    });
    U({
        id: 95377441,
        C: 0
    });
    U({
        id: 95327848,
        C: 0
    });
    U({
        id: 31065644,
        C: 1
    });
    U({
        id: 31065645,
        C: 1
    });
    var Bl = new ll;
    U({
        id: 95331588,
        C: 0,
        ia: Bl
    });
    U({
        id: 95331589,
        C: 1E3,
        ia: Bl
    });
    var Cl = U({
        id: 95378017,
        C: 0
    });
    U({
        id: 95332182,
        C: 0
    });
    U({
        id: 95362047,
        C: 0
    });
    U({
        id: 95370886,
        C: 0
    });
    U({
        id: 318523523,
        C: 0
    });
    U({
        id: 95379050,
        C: 10
    });
    U({
        id: 95379051,
        C: 10
    });
    U({
        id: 95391729,
        C: 0
    });
    U({
        id: 95392006,
        C: 0
    });
    U({
        id: 95392007,
        C: 0
    });
    U({
        id: 95378020,
        C: 0
    });
    U({
        id: 95380703,
        C: 0
    });
    U({
        id: 95380704,
        C: 0
    });
    U({
        id: 95380705,
        C: 0
    });
    U({
        id: 95380706,
        C: 0
    });
    U({
        id: 95387020,
        C: 0
    });
    U({
        id: 95392225,
        C: 0
    });
    U({
        id: 95386938,
        C: 1
    });
    U({
        id: 95386939,
        C: 1
    });
    U({
        id: 95389256,
        C: 0
    });
    U({
        id: 95389401,
        C: 0
    });
    U({
        id: 95391764,
        C: 0
    });
    U({
        id: 95396213,
        C: 0
    });
    U({
        id: 95406154,
        C: 0
    });
    U({
        id: 95406098,
        C: 0
    });
    U({
        id: 95406099,
        C: 0
    });
    U({
        id: 95406100,
        C: 0
    });
    U({
        id: 95403657,
        C: 0
    });
    U({
        id: 95410373,
        C: 0
    });
    U({
        id: 95410512,
        C: 0
    });
    if (typeof window !== "undefined" && typeof window.document !== "undefined" && typeof window.initializeVirtualDom === "undefined") {
        var sl, Dl = window.document;
        wl || (wl = new vl(Dl));
        sl = wl;
        var xl;
        sl.o || (rl(), sl.o = !0);
        xl = sl.l;
        var pl;
        sl.o || (rl(), sl.o = !0);
        pl = sl.i;
        if (xl != null) {
            var El = new ql,
                Fl = ml;
            Fl.o || (El.hb(Fl.l, Fl.i), Fl.o = !0)
        }
    };

    function Gl(a, b) {
        for (var c; !(c = a.next()).done;) b(c.value)
    };

    function Hl(a, b) {
        var c = new Set(a);
        Gl(b[Symbol.iterator](), d => c.add(d));
        return c
    };
    var Il = {
            attributes: !0,
            attributeFilter: ["style", "class"]
        },
        Jl = new Map;

    function Kl(a, b, c, d) {
        return typeof DOMRect !== "undefined" ? new DOMRect(a, b, c, d) : {
            x: a,
            y: b,
            width: c,
            height: d,
            top: b,
            bottom: b + d,
            left: a,
            right: a + c,
            toJSON() {
                return this
            }
        }
    }

    function Ll(a, b) {
        return [a.top - b.top, a.left - b.left, a.width - b.width, a.height - b.height].every(c => Math.abs(c) <= 1)
    }
    class Ml {
        constructor() {
            this.l = this.i = this.o = null
        }
    }

    function Nl(a, b, c, d) {
        var e = a.getBoundingClientRect();
        Ll(b, e) ? (e = setTimeout(() => void Nl(a, b, c, d), 200), d.l = e) : (Ol(d), c(e))
    }

    function Pl(a) {
        var b = new Ml,
            c = new Promise(f => {
                var g = a.getBoundingClientRect();
                if ("ResizeObserver" in window) {
                    var h = new ResizeObserver(k => {
                        window.requestAnimationFrame(() => {
                            for (let l of k) {
                                var m = void 0,
                                    n = void 0;
                                l.contentBoxSize ? (n = Array.isArray(l.contentBoxSize) ? l.contentBoxSize[0] : l.contentBoxSize, m = Math.round(n.inlineSize), n = Math.round(n.blockSize)) : (m = Math.round(l.contentRect.width), n = Math.round(l.contentRect.height));
                                let p, x, y = ((p = l) == null ? void 0 : (x = p.contentRect) == null ? void 0 : x.left) || g.left,
                                    F,
                                    ja, da = ((F = l) == null ? void 0 : (ja = F.contentRect) == null ? void 0 : ja.top) || g.top;
                                m = Kl(y, da, m, n);
                                if (!Ll(g, m)) {
                                    Ol(b);
                                    f(m);
                                    break
                                }
                            }
                        })
                    });
                    b.o = h;
                    h.observe(a);
                    h = new MutationObserver(() => {
                        window.requestAnimationFrame(() => {
                            var k = a.getBoundingClientRect();
                            Ll(g, k) || (Ol(b), f(k))
                        })
                    });
                    b.i = h;
                    h.observe(a, Il)
                } else Nl(a, g, f, b)
            }),
            d, e = (d = Jl.get(c)) != null ? d : new Set;
        e.add(b);
        Jl.set(c, e);
        return c
    }

    function Ql(a) {
        var b = Kl(0, 0, 1, 1),
            c = g => {
                var h = Pl(a),
                    k, m = (k = Jl.get(g)) != null ? k : new Set,
                    n;
                k = (n = Jl.get(h)) != null ? n : new Set;
                Jl.set(g, Hl(m, k));
                return h
            },
            d = (g, h) => {
                c(g).then(k => {
                    b.width <= k.width && b.height <= k.height ? (Rl(g), h(k)) : d(g, h)
                })
            },
            e = new wh,
            f = e.promise;
        d(f, e.resolve);
        return f
    }

    function Rl(a) {
        a = Jl.get(a);
        for (let b of a) Ol(b)
    }

    function Ol(a) {
        a.l && window.clearTimeout(a.l);
        a.o && (a.o.disconnect(), a.o = null);
        a.i && (a.i.disconnect(), a.i = null)
    };
    var Sl = class extends N {
        constructor(a) {
            super();
            this.l = a;
            this.A = this.B = !1;
            this.D = this.G = 0;
            this.i = new fl(1E3);
            md(this, this.i);
            Gd(this.i, "tick", this.J, !1, this);
            Gd(this.l, "pause", this.u, !1, this);
            Gd(this.l, "playing", this.u, !1, this);
            Gd(this.l, "ended", this.u, !1, this);
            Gd(this.l, "timeupdate", this.u, !1, this)
        }
        getCurrentTime() {
            var a = this.l;
            return typeof a.currentTime === "number" ? a.currentTime : typeof a.getCurrentTime === "function" ? a.getCurrentTime() : 0
        }
        u(a) {
            switch (a.type) {
                case "playing":
                    this.sa();
                    break;
                case "pause":
                case "ended":
                    this.Ha();
                    break;
                case "timeupdate":
                    !this.B && this.getCurrentTime() > 0 && (this.B = !0, this.sa())
            }
        }
        sa() {
            !this.i.enabled && this.B && (this.G = this.getCurrentTime() * 1E3, this.D = Date.now(), this.A = !1, this.i.start())
        }
        Ha() {
            this.i.enabled && this.i.stop()
        }
        J() {
            var a = Date.now(),
                b = a - this.D,
                c = this.getCurrentTime() * 1E3;
            c - this.G < b * .5 ? this.A || (this.A = !0, this.dispatchEvent("playbackStalled")) : this.A = !1;
            this.G = c;
            this.D = a
        }
    };
    var Tl = class extends N {
        constructor(a = null) {
            super();
            this.A = a
        }
        aa() {
            return !1
        }
        G() {
            return !1
        }
        P() {
            return !1
        }
        Y() {
            return -1
        }
        Z() {
            return -1
        }
        ba() {}
        pa() {}
        fa() {}
        reset() {}
    };

    function Ul(a) {
        return new Map(a.l.split("/").reduce((b, c, d, e) => {
            d % 2 && b.set(e[d - 1], c);
            return b
        }, new Map))
    }

    function Vl(a) {
        var b, c;
        return (b = a.uri) == null ? void 0 : (c = b.l) == null ? void 0 : c.startsWith("/videoplayback")
    }

    function Wl(a, b) {
        var c = a.uri.i.get(b);
        return c ? c : (a = a.o.get(b)) ? a : null
    }

    function Xl(a) {
        a = a.uri.i.get("range");
        if (!a) return null;
        a = a.split("-")[0];
        return !a || isNaN(Number(a)) ? null : Number(a)
    }
    var Yl = class {
        constructor(a, b = !1) {
            this.uri = a;
            this.i = b;
            this.o = Ul(a)
        }
        getId() {
            return Wl(this, "id")
        }
    };
    var Zl = ["doubleclick.net"];

    function $l(a) {
        return Ba() || u("iPad") || u("iPod") ? !!(vh() && (a == null ? 0 : a.Vc)) : u("Android") ? vh() ? !0 : u("iPad") || u("Android") && !u("Mobile") || u("Silk") ? !1 : am() : !1
    }

    function am() {
        var a = !1,
            b = (new P(window.location.href)).o;
        Zl.forEach(c => {
            b.includes(c) && (a = !0)
        });
        return a
    };

    function bm(a, b, c) {
        if (typeof a === "number") var d = {
            name: cm(a)
        };
        else a && a.name ? (d = a, a = dm(a.name)) : (d = {
            name: "UnknownError"
        }, a = em);
        this.code = a;
        this.i = d;
        b = "Error " + b + ": " + this.getName();
        c && (b += ", " + c);
        sa.call(this, b)
    }
    t(bm, sa);
    bm.prototype.getName = function() {
        return this.i && this.i.name || ""
    };
    var fm = {
            Rb: 1,
            Hc: 2,
            NOT_FOUND_ERR: 3,
            Mb: 4,
            Nb: 5,
            Ic: 6,
            Qb: 7,
            ABORT_ERR: 8,
            Pb: 9,
            Jc: 10,
            TIMEOUT_ERR: 11,
            Ob: 12,
            INVALID_ACCESS_ERR: 13,
            INVALID_STATE_ERR: 14
        },
        em = (r.oa || r.ua || fm).Rb,
        gm = (r.oa || r.ua || fm).NOT_FOUND_ERR,
        hm = (r.oa || r.ua || fm).Mb,
        im = (r.oa || r.ua || fm).Nb,
        jm = (r.oa || r.ua || fm).Qb,
        km = (r.oa || r.ua || fm).ABORT_ERR,
        lm = (r.oa || r.ua || fm).Pb,
        mm = (r.oa || r.ua || fm).TIMEOUT_ERR,
        nm = (r.oa || r.ua || fm).Ob,
        om = (r.DOMException || fm).INVALID_ACCESS_ERR,
        pm = (r.DOMException || fm).INVALID_STATE_ERR;

    function dm(a) {
        switch (a) {
            case "UnknownError":
                return em;
            case "NotFoundError":
                return gm;
            case "ConstraintError":
                return hm;
            case "DataError":
                return im;
            case "TransactionInactiveError":
                return jm;
            case "AbortError":
                return km;
            case "ReadOnlyError":
                return lm;
            case "TimeoutError":
                return mm;
            case "QuotaExceededError":
                return nm;
            case "InvalidAccessError":
                return om;
            case "InvalidStateError":
                return pm;
            default:
                return em
        }
    }

    function cm(a) {
        switch (a) {
            case em:
                return "UnknownError";
            case gm:
                return "NotFoundError";
            case hm:
                return "ConstraintError";
            case im:
                return "DataError";
            case jm:
                return "TransactionInactiveError";
            case km:
                return "AbortError";
            case lm:
                return "ReadOnlyError";
            case mm:
                return "TimeoutError";
            case nm:
                return "QuotaExceededError";
            case om:
                return "InvalidAccessError";
            case pm:
                return "InvalidStateError";
            default:
                return "UnknownError"
        }
    }

    function qm(a, b) {
        return "error" in a ? new bm(a.error, b) : new bm({
            name: "UnknownError"
        }, b)
    }

    function V(a, b) {
        return "name" in a ? new bm(a, b + ": " + a.message) : new bm({
            name: "UnknownError"
        }, b)
    };

    function rm(a) {
        this.i = a
    }
    var sm = r.IDBKeyRange || r.webkitIDBKeyRange;
    rm.prototype.range = function() {
        return this.i
    };
    /*

     Copyright 2005, 2007 Bob Ippolito. All Rights Reserved.
     Copyright The Closure Library Authors.
     SPDX-License-Identifier: MIT
    */
    function W() {
        this.B = [];
        this.A = this.u = !1;
        this.l = void 0;
        this.G = this.X = this.D = !1;
        this.I = 0;
        this.o = null;
        this.N = 0
    }
    W.prototype.cancel = function(a) {
        if (this.u) this.l instanceof W && this.l.cancel();
        else {
            if (this.o) {
                let b = this.o;
                delete this.o;
                a ? b.cancel(a) : (b.N--, b.N <= 0 && b.cancel())
            }
            this.G = !0;
            this.u || X(this, new tm(this))
        }
    };
    W.prototype.J = function(a, b) {
        this.D = !1;
        um(this, a, b)
    };

    function um(a, b, c) {
        a.u = !0;
        a.l = c;
        a.A = !b;
        vm(a)
    }

    function wm(a) {
        if (a.u) {
            if (!a.G) throw new xm(a);
            a.G = !1
        }
    }
    W.prototype.i = function(a) {
        wm(this);
        um(this, !0, a)
    };

    function X(a, b) {
        wm(a);
        um(a, !1, b)
    }

    function ym(a, b) {
        return zm(a, b, null)
    }

    function zm(a, b, c, d) {
        var e = a.u;
        e || (b === c ? b = c = ei(b) : (b = ei(b), c = ei(c)));
        a.B.push([b, c, d]);
        e && vm(a);
        return a
    }
    W.prototype.then = function(a, b, c) {
        var d, e, f = new Qk(function(g, h) {
            e = g;
            d = h
        });
        zm(this, e, function(g) {
            g instanceof tm ? f.cancel() : d(g);
            return Am
        }, this);
        return f.then(a, b, c)
    };
    W.prototype.$goog_Thenable = !0;

    function Bm(a) {
        return Da(a.B, function(b) {
            return typeof b[1] === "function"
        })
    }
    var Am = {};

    function vm(a) {
        if (a.I && a.u && Bm(a)) {
            var b = a.I,
                c = Cm[b];
            c && (r.clearTimeout(c.i), delete Cm[b]);
            a.I = 0
        }
        a.o && (a.o.N--, delete a.o);
        b = a.l;
        for (var d = c = !1; a.B.length && !a.D;) {
            var e = a.B.shift(),
                f = e[0];
            let h = e[1];
            e = e[2];
            if (f = a.A ? h : f) try {
                var g = f.call(e || null, b);
                g === Am && (g = void 0);
                g !== void 0 && (a.A = a.A && (g == b || g instanceof Error), a.l = b = g);
                if (Pk(b) || typeof r.Promise === "function" && b instanceof r.Promise) d = !0, a.D = !0
            } catch (k) {
                b = k, a.A = !0, Bm(a) || (c = !0)
            }
        }
        a.l = b;
        d && (g = a.J.bind(a, !0), d = a.J.bind(a, !1), b instanceof W ? (zm(b, g,
            d), b.X = !0) : b.then(g, d));
        c && (b = new Dm(b), Cm[b.i] = b, a.I = b.i)
    }

    function xm() {
        sa.call(this)
    }
    t(xm, sa);
    xm.prototype.message = "Deferred has already fired";
    xm.prototype.name = "AlreadyCalledError";

    function tm() {
        sa.call(this)
    }
    t(tm, sa);
    tm.prototype.message = "Deferred was canceled";
    tm.prototype.name = "CanceledError";

    function Dm(a) {
        this.i = r.setTimeout(() => {
            delete Cm[this.i];
            throw this.o;
        }, 0);
        this.o = a
    }
    var Cm = {};

    function Em() {
        N.call(this)
    }
    t(Em, N);
    Em.prototype.i = null;
    Em.prototype.next = function(a) {
        if (a) this.i["continue"](a);
        else this.i["continue"]()
    };
    Em.prototype.remove = function() {
        var a = new W;
        try {
            var b = this.i["delete"]()
        } catch (c) {
            return X(a, V(c, "deleting via cursor")), a
        }
        b.onsuccess = function() {
            a.i()
        };
        b.onerror = function(c) {
            X(a, qm(c.target, "deleting via cursor"))
        };
        return a
    };
    Em.prototype.getValue = function() {
        return this.i.value
    };

    function Fm(a, b) {
        var c = new Em;
        try {
            let e = b ? b.range() : null;
            var d = a.openCursor(e)
        } catch (e) {
            throw c.dispose(), V(e, a.name);
        }
        d.onsuccess = function(e) {
            c.i = e.target.result || null;
            c.i ? c.dispatchEvent("n") : c.dispatchEvent("c")
        };
        d.onerror = function() {
            c.dispatchEvent("e")
        };
        return c
    };

    function Gm(a) {
        this.i = a
    }
    Gm.prototype.getName = function() {
        return this.i.name
    };

    function Hm(a, b, c) {
        var d = new W;
        try {
            var e = a.i.get(c)
        } catch (f) {
            return b += " with key " + O(c), X(d, V(f, b)), d
        }
        e.onsuccess = function(f) {
            d.i(f.target.result)
        };
        e.onerror = function(f) {
            b += " with key " + O(c);
            X(d, qm(f.target, b))
        };
        return d
    }
    Gm.prototype.get = function(a) {
        return Hm(this, "getting from index " + this.getName(), a)
    };
    Gm.prototype.getAll = function(a, b) {
        return Im(this, "getting all from index " + this.getName(), a, b)
    };

    function Im(a, b, c, d) {
        var e;
        c === void 0 ? e = void 0 : e = c instanceof rm ? c.range() : (new rm(sm.only(c))).range();
        var f = new W;
        try {
            var g = a.i.getAll(e, d)
        } catch (h) {
            return b += " for range " + (e ? O(e) : "<all>"), X(f, V(h, b)), f
        }
        g.onsuccess = function() {
            f.i(g.result)
        };
        g.onerror = function(h) {
            b += " for range " + (e ? O(e) : "<all>");
            X(f, qm(h.target, b))
        };
        return f
    }

    function Jm(a, b) {
        return Fm(a.i, b)
    };

    function Km(a, b, c, d, e) {
        var f = new W;
        try {
            var g = e ? a.i[b](d, e) : a.i[b](d)
        } catch (h) {
            return c += O(d), e && (c += ", with key " + O(e)), X(f, V(h, c)), f
        }
        g.onsuccess = function(h) {
            f.i(h.target.result)
        };
        g.onerror = function(h) {
            c += O(d);
            e && (c += ", with key " + O(e));
            X(f, qm(h.target, c))
        };
        return f
    }

    function Lm(a, b, c, d) {
        var e;
        c === void 0 ? e = void 0 : e = c instanceof rm ? c.range() : (new rm(sm.only(c))).range();
        var f = new W;
        try {
            var g = a.i.getAll(e, d)
        } catch (h) {
            return b += " for range " + (e ? O(e) : "<all>"), X(f, V(h, b)), f
        }
        g.onsuccess = function() {
            f.i(g.result)
        };
        g.onerror = function(h) {
            b += " for range " + (e ? O(e) : "<all>");
            X(f, qm(h.target, b))
        };
        return f
    }

    function Mm(a) {
        try {
            return new Gm(a.i.index("timestamp"))
        } catch (b) {
            throw V(b, "getting index timestamp");
        }
    }
    class Nm {
        constructor(a) {
            this.i = a
        }
        getName() {
            return this.i.name
        }
        put(a, b) {
            return Km(this, "put", "putting into " + this.getName() + " with value", a, b)
        }
        add(a, b) {
            return Km(this, "add", "adding into " + this.getName() + " with value ", a, b)
        }
        remove(a) {
            var b = new W;
            try {
                var c = this.i["delete"](a instanceof rm ? a.range() : a)
            } catch (e) {
                return c = "removing from " + this.getName() + " with key " + O(a), X(b, V(e, c)), b
            }
            c.onsuccess = function() {
                b.i()
            };
            var d = this;
            c.onerror = function(e) {
                var f = "removing from " + d.getName() + " with key " + O(a);
                X(b,
                    qm(e.target, f))
            };
            return b
        }
        get(a) {
            var b = new W;
            try {
                var c = this.i.get(a)
            } catch (e) {
                return c = "getting from " + this.getName() + " with key " + O(a), X(b, V(e, c)), b
            }
            c.onsuccess = function(e) {
                b.i(e.target.result)
            };
            var d = this;
            c.onerror = function(e) {
                var f = "getting from " + d.getName() + " with key " + O(a);
                X(b, qm(e.target, f))
            };
            return b
        }
        getAll(a, b) {
            return Lm(this, "getting all from index " + this.getName(), a, b)
        }
        clear() {
            var a = "clearing store " + this.getName(),
                b = new W;
            try {
                var c = this.i.clear()
            } catch (d) {
                return X(b, V(d, a)), b
            }
            c.onsuccess =
                function() {
                    b.i()
                };
            c.onerror = function(d) {
                X(b, qm(d.target, a))
            };
            return b
        }
        count(a) {
            var b = new W;
            try {
                let c = a ? a.range() : null,
                    d = this.i.count(c);
                d.onsuccess = function(f) {
                    b.i(f.target.result)
                };
                let e = this;
                d.onerror = function(f) {
                    X(b, qm(f.target, e.getName()))
                }
            } catch (c) {
                X(b, V(c, this.getName()))
            }
            return b
        }
    };
    class Om extends N {
        constructor(a, b) {
            super();
            this.i = a;
            this.u = b;
            this.l = new Ij(this);
            this.l.listen(this.i, "complete", this.dispatchEvent.bind(this, "complete"));
            this.l.listen(this.i, "abort", this.dispatchEvent.bind(this, "abort"));
            this.l.listen(this.i, "error", this.A)
        }
        A(a) {
            a.target instanceof bm ? this.dispatchEvent({
                type: "error",
                target: a.target
            }) : this.dispatchEvent({
                type: "error",
                target: qm(a.target, "in transaction")
            })
        }
        objectStore(a) {
            try {
                return new Nm(this.i.objectStore(a))
            } catch (b) {
                throw V(b, "getting object store " +
                    a);
            }
        }
        commit(a) {
            if (this.i.commit || !a) try {
                this.i.commit()
            } catch (b) {
                throw V(b, "cannot commit the transaction");
            }
        }
        wait() {
            var a = new W;
            Hd(this, "complete", a.i.bind(a));
            var b = Hd(this, "abort", function() {
                Pd(c);
                X(a, new bm(km, "waiting for transaction to complete"))
            });
            var c = Hd(this, "error", function(e) {
                Pd(b);
                X(a, e.target)
            });
            var d = this.u;
            return ym(a, function() {
                return d
            })
        }
        abort() {
            this.i.abort()
        }
        o() {
            super.o();
            this.l.dispose()
        }
    }
    var Pm = {
        READ_ONLY: "readonly",
        READ_WRITE: "readwrite",
        Kc: "versionchange"
    };

    function Qm(a) {
        N.call(this);
        this.i = a;
        this.l = new Ij(this);
        this.l.listen(this.i, "abort", this.dispatchEvent.bind(this, "abort"));
        this.l.listen(this.i, "error", this.A);
        this.l.listen(this.i, "versionchange", this.B);
        this.l.listen(this.i, "close", this.dispatchEvent.bind(this, "close"))
    }
    t(Qm, N);
    q = Qm.prototype;
    q.u = !0;
    q.A = function(a) {
        a = (a = a.target) && a.error;
        this.dispatchEvent({
            type: "error",
            errorCode: a && a.severity
        })
    };
    q.B = function(a) {
        this.dispatchEvent(new Rm(a.oldVersion, a.newVersion))
    };
    q.close = function() {
        this.u && (this.i.close(), this.u = !1)
    };
    q.la = function() {
        return this.u
    };
    q.getName = function() {
        return this.i.name
    };
    q.getVersion = function() {
        return Number(this.i.version)
    };

    function Sm(a, b) {
        var c = ["MediaSourceVideoChunk"];
        try {
            let d = b ? a.i.transaction(c, b) : a.i.transaction(c);
            return new Om(d, a)
        } catch (d) {
            throw V(d, "creating transaction");
        }
    }
    q.o = function() {
        Qm.ma.o.call(this);
        this.l.dispose()
    };

    function Rm(a, b) {
        od.call(this, "versionchange");
        this.oldVersion = a;
        this.newVersion = b
    }
    t(Rm, od);
    var Tm = void 0;

    function Um(a) {
        var b = new W;
        Tm == void 0 && (Tm = r.indexedDB || r.mozIndexedDB || r.webkitIndexedDB || r.moz_indexedDB);
        var c = Tm.open("IndexedDbVideoChunkPersistentStorage", 7);
        c.onsuccess = function(d) {
            d = new Qm(d.target.result);
            b.i(d)
        };
        c.onerror = function(d) {
            X(b, qm(d.target, "opening database IndexedDbVideoChunkPersistentStorage"))
        };
        c.onupgradeneeded = function(d) {
            if (a) {
                var e = new Qm(d.target.result);
                a(new Rm(d.oldVersion, d.newVersion), e, new Om(d.target.transaction, e))
            }
        };
        c.onblocked = function() {};
        return b
    };

    function Vm(a, b) {
        var c = new Date(Date.now());
        c.setDate(c.getDate() - 30);
        c = new rm(sm.upperBound(c, void 0));
        var d = Jm(Mm(Sm(a.i, Pm.READ_WRITE).objectStore("MediaSourceVideoChunk")), c),
            e = d.listen("n", () => {
                d.remove();
                d.next()
            });
        Hd(d, "c", () => {
            Pd(e);
            b()
        })
    }

    function Wm() {
        var a;
        return ((a = navigator.storage) == null ? 0 : a.estimate) ? navigator.storage.estimate().then(b => {
            T().F("csue", String(b.usage))
        }) : Promise.resolve(void 0)
    }

    function Xm(a, b, c) {
        var d, e = new Yl(b, (d = a.l) == null ? void 0 : d.xb);
        d = e.getId();
        a = Wl(e, "itag");
        b = Wl(e, "source");
        var f = Wl(e, "lmt");
        e = Xl(e);
        var g = [];
        d ? a ? b ? f ? e === null && g.push("startIndex") : g.push("lmt") : g.push("source") : g.push("itag") : g.push("videoId");
        return g.length > 0 ? (T().F("civp", g.join("-")), null) : {
            videoId: d,
            itag: a,
            source: b,
            lmt: f,
            startIndex: e + c
        }
    }

    function Ym(a, b, c) {
        var d = Sm(a.i, Pm.READ_WRITE).objectStore("MediaSourceVideoChunk");
        return Promise.resolve(d.get(b)).then(e => {
            if (!e) return T().F("cenf", "1"), null;
            if (e.lmt !== c) return T().F("cdl", "1"), d.remove(b).then(null, f => {
                T().F("crdlvf", f.message)
            }), null;
            T().F("cefml", "1");
            return {
                itag: e.itag,
                endIndex: e.endIndex,
                isLastVideoChunk: e.isLastVideoChunk,
                video: e.video
            }
        }, e => {
            T().F("cgvf", e.message);
            return null
        })
    }

    function Zm(a) {
        var b = [a.videoId, a.source, a.startIndex].join(),
            c = 0;
        for (let d = 0; d < b.length; d++) c = Math.imul(31, c) + b.charCodeAt(d) | 0;
        return `${c.toString()},${a.itag}`
    }

    function $m(a, b) {
        a = Sm(a.i, Pm.READ_WRITE).objectStore("MediaSourceVideoChunk");
        Promise.resolve(a.put(b)).then(() => {
            T().F("cavs", "1")
        }, c => {
            T().F("cavf", c.message)
        })
    }

    function an(a) {
        var b = new Set,
            c = new rm(sm.bound(new Date(Date.now() - 2592E6), new Date(Date.now()), void 0, void 0));
        return new Promise(d => {
            var e = Jm(Mm(Sm(a.i, Pm.READ_ONLY).objectStore("MediaSourceVideoChunk")), c),
                f = e.listen("n", () => {
                    var g = e.getValue();
                    g && g.videoId && b.add(g.videoId);
                    e.next()
                });
            Hd(e, "c", () => {
                Pd(f);
                d(Array.from(b))
            })
        })
    }
    var bn = class extends N {
        constructor(a) {
            super();
            this.l = a;
            this.i = null
        }
        initialize() {
            return Promise.resolve(Um(this.u)).then(a => {
                this.i = a
            }, a => {
                T().F("codf", a.message)
            })
        }
        la() {
            return this.i !== null && this.i.la()
        }
        close() {
            return (new Promise(a => {
                Vm(this, a)
            })).then(() => Wm()).then(() => {
                this.i.close()
            })
        }
        Ua(a) {
            return (a = Xm(this, a, 0)) ? Ym(this, Zm(a), a.lmt) : Promise.resolve(null)
        }
        Qa(a, b, c, d) {
            (b = Xm(this, b, c)) ? (c = b.startIndex, $m(this, {
                cacheId: Zm(b),
                startIndex: c,
                endIndex: c + a.byteLength - 1,
                lmt: b.lmt,
                timestamp: new Date(Date.now()),
                isLastVideoChunk: d,
                itag: b.itag,
                video: a
            })) : Promise.resolve(void 0)
        }
        u(a, b) {
            if (a.oldVersion !== 6) {
                if (b.i.objectStoreNames.contains("MediaSourceVideoChunk")) try {
                    b.i.deleteObjectStore("MediaSourceVideoChunk")
                } catch (d) {
                    throw V(d, "deleting object store MediaSourceVideoChunk");
                }
                a = {
                    keyPath: "cacheId"
                };
                try {
                    var c = new Nm(b.i.createObjectStore("MediaSourceVideoChunk", a))
                } catch (d) {
                    throw V(d, "creating object store MediaSourceVideoChunk");
                }
                b = {
                    unique: !1
                };
                try {
                    c.i.createIndex("timestamp", "timestamp", b)
                } catch (d) {
                    throw V(d,
                        "creating new index timestamp with key path timestamp");
                }
            }
        }
    };
    class cn extends Error {
        constructor() {
            super("");
            this.name = "XhrAbortedError"
        }
    }
    async function dn(a) {
        var b = 0;
        do {
            let c, d;
            if ((d = a.i) == null ? 0 : d.eb) c = Math.min(1E3, 2 ** b - 1), await new Promise(m => {
                setTimeout(m, c)
            });
            a.state === 2 && (a.state = 1);
            let e = Date.now(),
                f = a.l,
                g = await en(a),
                h = Date.now(),
                k;
            (k = a.A) == null || k.dispatchEvent(R("chunk_loaded_finished", Object.assign({}, g, {
                Mc: b,
                mimeType: a.ea.mimeType,
                Zc: e,
                Yc: h,
                ed: a.l - f,
                od: c
            })));
            b++
        } while (fn(a));
        a.state !== 3 && (a.state = 0)
    }

    function gn(a) {
        a.K && (a.K.abort(), a.K = null, a.state = 0)
    }

    function fn(a) {
        var b;
        if (((b = a.i) == null ? 0 : b.Ga) && !a.R) return !1;
        b = a.V > 3;
        var c = a.A && a.A.readyState >= HTMLMediaElement.HAVE_FUTURE_DATA,
            d = a.l >= a.u || a.state === 3,
            e;
        if (((e = a.i) == null ? 0 : e.eb) && c) return !d;
        b && a.D !== null && (e = R("media_source_error", {
            code: a.l > 0 ? MediaError.MEDIA_ERR_NETWORK : MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED,
            message: `Response code "${a.D}" with ${a.u} bytes requested and ${a.l} bytes loaded`
        }), a.dispatchEvent(e));
        return !d && !b
    }
    async function en(a) {
        a.uri.i.set("range", `${a.l}-${a.u-1}`);
        var b = {
            rangeStart: a.l,
            requestedRangeSize: a.u - a.l
        };
        if (a.J && !a.ga) {
            let c, d;
            if (((d = (c = a.i) == null ? void 0 : c.qc) != null ? d : 0) > 0) {
                let e = !1;
                await Promise.race([a.L, new Promise(g => {
                    var h;
                    setTimeout(() => {
                        e = !0;
                        g(void 0)
                    }, (h = a.i) == null ? void 0 : h.qc)
                })]);
                let f;
                if ((f = a.B) == null ? 0 : f.la()) return hn(a, b);
                e && (b.cacheOpenTimedOut = !0);
                a.ga = !0
            } else return await a.L, hn(a, b)
        }
        try {
            b.loadSource = "ls_network", await jn(a, b)
        } catch (c) {
            kn(a, c, b)
        } finally {
            a.K = null
        }
        return b
    }
    async function hn(a, b = {}) {
        var c = a.B,
            d, e, f;
        if (((f = (d = a.i) == null ? void 0 : d.oc) != null ? f : 0) > 0 && ((e = a.i) == null ? 0 : e.Pc)) {
            let g = !1;
            c = await Promise.race([c.Ua(a.uri).then(h => {
                g = !0;
                h || (b.cacheGetVideoFailedReason = "miss");
                return h
            }).catch(h => {
                g = !0;
                b.cacheGetVideoFailedReason = "Error: " + h.message;
                return null
            }), new Promise(h => {
                var k;
                setTimeout(() => {
                    g || (b.cacheGetVideoFailedReason = "timeout");
                    h(null)
                }, (k = a.i) == null ? void 0 : k.oc)
            })])
        } else c = await c.Ua(a.uri);
        if (c) c.isLastVideoChunk && (a.state = 3), b.loadSource = "ls_cache_hit",
            ln(a, c.video, 0);
        else try {
            b.loadSource = "ls_cache_miss_fallback", await jn(a, b)
        } catch (g) {
            kn(a, g, b)
        } finally {
            a.K = null
        }
        return b
    }

    function jn(a, b = {}) {
        var c = mn(a);
        return new Promise((d, e) => {
            var f = new XMLHttpRequest;
            a.K = f;
            var g;
            ((g = a.i) == null ? 0 : g.Ga) && f.addEventListener("abort", () => {
                e(new cn)
            });
            var h = 0,
                k = [],
                m = a.u - a.l,
                n = () => {
                    if (f.status >= 400) a.D = f.status;
                    else {
                        var l = h;
                        if (c) {
                            var p = f.responseText;
                            l = new ArrayBuffer(p.length - h);
                            let x = new Uint8Array(l);
                            for (let y = 0; y < l.byteLength; y++) x[y] = p.charCodeAt(h + y) & 255;
                            p = l;
                            l = 0;
                            a.J && k.push(p)
                        } else p = f.response;
                        p = ln(a, p, l);
                        h += p
                    }
                };
            f.addEventListener("load", () => {
                S(T(), "lvlcl");
                if (f.status >= 400) T().F("lvlxes",
                    f.status.toString()), a.D = f.status, e();
                else {
                    var l = c ? f.responseText.length : f.response.byteLength;
                    l < m && (a.state = 3);
                    n();
                    if (a.J && l > 0)
                        if (l = l < m, c) {
                            var p = k.reduce((y, F) => y + F.byteLength, 0);
                            p = new Uint8Array(p);
                            let x = 0;
                            for (let y of k) p.set(new Uint8Array(y), x), x += y.byteLength;
                            a.B.Qa(p.buffer, a.uri, 0, l)
                        } else a.B.Qa(f.response, a.uri, 0, l);
                    d()
                }
            });
            f.addEventListener("timeout", () => {
                S(T(), "lvlct");
                a.D = f.status;
                b.loadErrorStatusCode = f.status;
                b.loadFailedReason = "timeout";
                e()
            });
            f.addEventListener("error", () => {
                S(T(), "lvlce");
                a.D = f.status;
                e()
            });
            f.addEventListener("readystatechange", () => {
                if (f.readyState === f.HEADERS_RECEIVED) {
                    var l = f.getResponseHeader("X-Afma-Gcache-IsGcacheHit");
                    l !== null && (b.gcacheHit = l === "true");
                    l = f.getResponseHeader("X-Afma-Gcache-IsDownloaded");
                    l !== null && (b.gcacheDownloaded = l === "true");
                    l = f.getResponseHeader("X-Afma-Gcache-CachedBytes");
                    l !== null && (b.gcacheBytes = Number(l) || 0)
                }
            });
            c ? f.onprogress = n : f.addEventListener("progress", n);
            f.open("get", a.uri.toString());
            c ? f.overrideMimeType && f.overrideMimeType("text/plain; charset=x-user-defined") :
                f.responseType = "arraybuffer";
            f.send(null)
        })
    }

    function kn(a, b, c = {}) {
        if (b instanceof cn) c.loadFailedReason = "aborted";
        else {
            var d;
            c.loadFailedReason = (d = c.loadFailedReason) != null ? d : "error";
            a.D !== null && (c.loadErrorStatusCode = a.D);
            var e;
            b = new Yl(a.uri, (e = a.i) == null ? void 0 : e.xb);
            var f;
            if (((f = a.i) == null ? 0 : f.ab) && Vl(b)) {
                a: if (Vl(b)) {
                    d = (e = Wl(b, "mn")) ? e.split(",") : null;
                    f = Wl(b, "fvip");
                    e = b.uri.clone();
                    if (d && f && !b.i) {
                        var g = (Number(Wl(b, "fallback_count")) || 0) + 1;
                        if (d = d[g]) {
                            e.o = `r${f}---${d}.googlevideo.com`;
                            e.i.set("fallback_count", g);
                            var h = e;
                            break a
                        }
                    }
                    var k;
                    f = Number(((k = (h = e.i.get("cmo")) == null ? void 0 : h.split("=")) != null ? k : [])[1]) || 0;
                    b.uri.o.match(/^r{1,2}(\d+)---(.+)\.googlevideo.com$/) && (e.o = "redirector.googlevideo.com");
                    e.i.set("cmo", `pf=${f+1}`);
                    h = e
                } else h = b.uri;a.uri = h;c.bandaidFallback = !0;a.dispatchEvent(R("bandaid_fallback_count"))
            }
            else((g = a.i) == null ? 0 : g.wd) && Aj(a.uri) && (a.uri = new P(Bj(a.uri)));
            a.V++
        }
    }

    function ln(a, b, c) {
        if (b === null) return 0;
        b = b.slice(c);
        a.l += b.byteLength;
        a.dispatchEvent({
            type: "progress",
            Za: b
        });
        return b.byteLength
    }

    function mn(a) {
        var b, c, d;
        return ((b = a.i) == null ? void 0 : b.Ad) === !0 || ((c = a.i) == null ? void 0 : c.zb) === !0 || ((d = a.i) == null ? void 0 : d.yb) === !0
    }
    var nn = class extends Tl {
        constructor(a, b = null, c) {
            super(b);
            this.i = c;
            this.K = null;
            this.R = !1;
            this.V = this.l = this.u = 0;
            this.ga = !1;
            this.D = this.L = null;
            this.ea = a;
            this.uri = new P(a.url);
            this.state = 0;
            this.B = (this.J = $l(this.i) && !Aj(this.uri)) ? Q(bn) : null;
            nd(this, () => {
                ld(this.B)
            });
            this.L = this.J ? this.B.initialize() : null;
            var d;
            (d = this.L) == null || d.then(async () => {
                var e;
                if ((e = this.B) == null ? 0 : e.la()) {
                    let g;
                    (g = this.A) == null || g.dispatchEvent(R("cache_init_success", {
                        mimeType: this.ea.mimeType
                    }))
                }
                var f;
                if ((f = this.i) == null ? 0 :
                    f.pd)
                    if (e = await an(this.B), e.length > 0) {
                        let g;
                        (g = this.A) == null || g.dispatchEvent(R("indexed_db_mrid", {
                            Bd: e.join(",")
                        }))
                    }
            })
        }
        Y() {
            return this.u
        }
        Z() {
            return this.l
        }
        G() {
            return this.state === 3
        }
        aa() {
            return this.state === 0
        }
        P() {
            return this.u <= this.l
        }
        pa() {
            var a;
            (a = this.i) != null && a.Ga && (this.R = !0, this.state === 3 || this.P() || (this.state = 1, dn(this)))
        }
        fa() {
            var a;
            (a = this.i) != null && a.Ga && (this.R = !1, gn(this))
        }
        reset() {
            gn(this);
            this.V = this.state = this.l = this.u = 0
        }
        ba(a) {
            if (this.state === 1) this.u += a, this.state = 2;
            else if (this.state ===
                0) {
                this.u += a;
                let b;
                if ((b = this.i) == null || !b.Ga || this.R) this.state = 1, dn(this)
            }
        }
        o() {
            this.J && this.B.la() && this.B.close();
            super.o()
        }
    };
    var on = {
        nd: 2E5,
        ld: 7E4,
        pb: 3E5,
        fd: 5E3,
        Cd: 5E3,
        md: 6E3
    };
    async function pn(a) {
        var b = 0;
        do {
            let d;
            ((d = a.K) == null ? 0 : d.eb) && await new Promise(g => {
                setTimeout(g, Math.min(1E3, 2 ** b - 1))
            });
            a.state === 2 && (a.state = 1);
            await qn(a);
            b++;
            let e = a.uri.i.get("range"),
                f;
            (f = a.A) == null || f.dispatchEvent(R("chunk_load_attempted", {
                kc: b,
                range: e,
                mimeType: a.J.mimeType
            }))
        } while (rn(a));
        var c;
        (c = a.A) == null || c.dispatchEvent(R("chunk_loaded", {
            kc: b,
            mimeType: a.J.mimeType
        }));
        a.state !== 3 && (a.state = 0)
    }

    function rn(a) {
        var b = a.D > 3,
            c = a.A && a.A.readyState >= HTMLMediaElement.HAVE_FUTURE_DATA,
            d = a.l >= a.i || a.state === 3,
            e;
        if (((e = a.K) == null ? 0 : e.eb) && c) return !d;
        b && (a.B === null && (a.B = 400), c = R("media_source_error", {
            code: a.l > 0 ? MediaError.MEDIA_ERR_NETWORK : MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED,
            message: `Response code "${a.B}" with ${a.i} bytes requested and ${a.l} bytes loaded`
        }), a.dispatchEvent(c));
        return !d && !b
    }
    async function qn(a) {
        a.uri.i.set("range", `${a.l}-${a.i-1}`);
        if (a.u) return await a.L, sn(a);
        try {
            await tn(a)
        } catch (b) {
            a.D++
        }
    }
    async function sn(a) {
        if (!a.u) return Promise.reject();
        var b = await a.u.Ua(a.uri),
            c;
        (c = a.A) == null || c.dispatchEvent(R("chunk_cache_query", {
            Oc: b !== null,
            mimeType: a.J.mimeType
        }));
        if (b) b.isLastVideoChunk && (a.state = 3), un(a, b.video);
        else try {
            await tn(a)
        } catch (d) {
            a.D++
        }
    }
    async function tn(a) {
        var b = 0,
            c = a.i - a.l,
            d = await fetch(a.uri.toString());
        if (d.status >= 400) return T().F("lvlfes", d.status.toString()), a.B = d.status, Promise.reject();
        var e, f = (e = d.body) == null ? void 0 : e.getReader();
        if (!f) return S(T(), "lvlmr"), a.B = d.status, Promise.reject();
        var g = [],
            h = async () => {
                var k = await f.read(),
                    m = k.value;
                k.done ? vn(a, g, b < c) : (g.push(m), b += m == null ? void 0 : m.length, un(a, m == null ? void 0 : m.buffer), await h())
            };
        await h()
    }

    function un(a, b) {
        b !== null && (b = b.slice(0), a.l += b.byteLength, a.dispatchEvent({
            type: "progress",
            Za: b
        }))
    }

    function vn(a, b, c) {
        c && (a.state = 3, un(a, new ArrayBuffer(0)));
        var d = new Uint8Array(b.reduce((f, g) => f + g.length, 0)),
            e = 0;
        for (let f of b) d.set(f, e), e += f.length;
        a.u && d.buffer.byteLength > 0 && a.u.Qa(d.buffer, a.uri, 0, c)
    }
    var wn = class extends Tl {
        constructor(a, b, c = null, d) {
            super(c);
            this.u = b;
            this.K = d;
            this.D = this.l = this.i = 0;
            this.B = null;
            this.J = a;
            this.uri = new P(a.url);
            this.state = 0;
            var e;
            this.L = (e = this.u) == null ? void 0 : e.initialize();
            nd(this, () => {
                ld(this.u)
            })
        }
        Y() {
            return this.i
        }
        Z() {
            return this.l
        }
        G() {
            return this.state === 3
        }
        aa() {
            return this.state === 0
        }
        ba(a) {
            this.state === 1 ? (this.i += a, this.state = 2) : this.state === 0 && (this.i += a, this.state = 1, pn(this))
        }
        reset() {
            this.D = this.state = this.l = this.i = 0
        }
        o() {
            var a;
            ((a = this.u) == null ? 0 : a.la()) && this.u.close();
            super.o()
        }
    };
    var xn = class {
        constructor(a) {
            this.i = a;
            var b;
            this.o = ((b = this.i) == null ? 0 : b.xd) ? 9E4 : 5E3
        }
        fc(a, b, c, d) {
            var e;
            return ((e = this.i) == null ? 0 : e.Wc) && c - d >= 3E5 ? 0 : c === 0 ? 1E6 : b - a < this.o ? 3E5 : 0
        }
    };

    function yn(a) {
        if (!a.ha.updating && a.l) {
            if (a.u && a.G !== null) {
                var b = a.u.ha;
                b = b.buffered.length > 0 ? b.buffered.end(b.buffered.length - 1) : 0;
                let c = a.ha.buffered.length > 0 ? a.ha.buffered.end(a.ha.buffered.length - 1) : 0;
                if (!a.G() && c > b - a.J) return
            }
            a.i.length > 0 ? (b = a.i.shift(), a.ha.appendBuffer(b)) : (a.l = !1, a.dispatchEvent(new Event("updateend")))
        }
    }
    var zn = class extends N {
        constructor(a, b, c = 0, d = null, e = null, f = 0) {
            super();
            this.ha = a;
            this.i = [];
            this.l = !1;
            this.A = () => {
                yn(this)
            };
            this.J = c;
            this.G = d;
            this.u = e;
            this.B = f;
            this.u && this.u.listen("updateend", this.A);
            this.ha || S(T(), `msms_sbf${b}`);
            this.D = () => {
                S(T(), `msms_sbe${b}`)
            };
            this.ha.addEventListener("updateend", this.A);
            this.ha.addEventListener("error", this.D)
        }
        get updating() {
            return this.l
        }
        o() {
            this.i.length = 0;
            this.l = !1;
            var a;
            (a = this.u) == null || a.na("updateend", this.A);
            var b;
            (b = this.ha) == null || b.removeEventListener("updateend",
                this.A);
            var c;
            (c = this.ha) == null || c.removeEventListener("error", this.D);
            super.o()
        }
    };

    function An(a, b) {
        var c;
        a.i = new Yl(b, (c = a.o) == null ? void 0 : c.xb);
        b = a.i.getId();
        c = Wl(a.i, "itag");
        var d = Wl(a.i, "source"),
            e = Wl(a.i, "lmt");
        a = Wl(a.i, "range");
        if (b && c && d && a) return new Request(`http://url/videoplayback?id=${b}&itag=${c}&source=${d}&lmt=${e}&range=${a}`);
        T().F("civp", "1");
        return null
    }
    var Bn = class {
        constructor(a) {
            this.o = a;
            this.i = this.cache = null
        }
        initialize() {
            return window.caches.open("CACHE_VIDEO_CHUNK_PERSISTENT_STORAGE").then(a => {
                this.cache = a
            }, a => {
                T().F("codf", a.message)
            })
        }
        la() {
            return this.cache !== null
        }
        close() {
            return Promise.resolve()
        }
        Ua(a) {
            a = An(this, a);
            return this.la() && a ? this.cache.match(a).then(b => {
                if (!b) return T().F("cenf", "1"), Promise.resolve(null);
                T().F("cef", "1");
                return b.arrayBuffer().then(c => {
                    var d = Xl(this.i),
                        e;
                    (e = this.i.uri.i.get("range")) ? (e = e.split("-")[1], e = !e || isNaN(Number(e)) ?
                        null : Number(e)) : e = null;
                    d = d + c.byteLength - 1;
                    e = e > d;
                    return {
                        itag: Wl(this.i, "itag"),
                        endIndex: d,
                        isLastVideoChunk: e,
                        video: c
                    }
                })
            }, b => {
                T().F("cgvf", b.message);
                return Promise.resolve(null)
            }) : (T().F("cgvf", "1"), Promise.resolve(null))
        }
        Qa(a, b) {
            b = An(this, b);
            a = new Response(a);
            this.la() && b ? this.cache.put(b, a).then(() => {
                T().F("cavs", "1")
            }, c => {
                T().F("cavf", c.message)
            }) : (T().F("cavf", "1"), Promise.resolve())
        }
    };
    var Cn = class {
        constructor(a, b) {
            this.currentTimeSeconds = a;
            this.removedRanges = b
        }
    };

    function Dn(a) {
        S(T(), "msms_oso");
        a.i.dispatchEvent(new CustomEvent("media_source_open"));
        if (a.Z) En(a) && Fn(a);
        else {
            for (let b = 0; b < a.B.length; ++b) {
                let c = a.B[b];
                T().F(`msms_mime${b}`, c.mimeType);
                T().F(`msms_cs${b}`, c.pb.toString());
                let d, e, f;
                if (((d = a.l) == null ? 0 : d.Kb) || ((e = a.l) == null ? 0 : e.zb) || ((f = a.l) == null ? 0 : f.yb) && uh()) {
                    let g, h;
                    if ((h = a.l) == null ? 0 : h.vd)
                        if (b > 0) {
                            let m = a.u[0],
                                n = a.K[0];
                            g = Q(zn, a.T.addSourceBuffer(c.mimeType), b, a.Na, () => m.G(), n, a.aa)
                        } else g = Q(zn, a.T.addSourceBuffer(c.mimeType), b, 0, null, null,
                            a.aa);
                    else g = Q(zn, a.T.addSourceBuffer(c.mimeType), b);
                    let k = a.u[b];
                    a.J[b] = m => {
                        m = m.Za;
                        if (m.byteLength !== 0) {
                            var n = g;
                            n.l = !0;
                            if (n.B > 0)
                                for (let l = 0; l < m.byteLength; l += n.B) n.i.push(m.slice(l, l + n.B));
                            else n.i.push(m);
                            yn(n)
                        }
                        k.G() && (a.P++, En(a) && Fn(a))
                    };
                    k.listen("progress", a.J[b]);
                    a.G[b] = m => {
                        a.dispatchEvent(m)
                    };
                    k.listen("media_source_error", a.G[b]);
                    a.A.push(g.ha);
                    a.K.push(g);
                    g.listen("updateend", () => {
                        a.u[b].P() && Gn(a)
                    })
                } else {
                    let g = a.T.addSourceBuffer(c.mimeType);
                    if (!g) {
                        S(T(), `msms_sbf${b}`);
                        continue
                    }
                    let h = a.u[b],
                        k;
                    if ((k = a.l) == null ? 0 : k.kb) a.D.push([]), g.addEventListener("updateend", () => {
                        Hn(a, g, b)
                    });
                    g.addEventListener("error", () => {
                        S(T(), `msms_sbe${b}`)
                    });
                    a.J[b] = m => {
                        var n = b;
                        m = m.Za;
                        if (m.byteLength !== 0) {
                            let l;
                            ((l = a.l) == null ? 0 : l.kb) ? (a.D[n].push(m), Hn(a, g, n)) : g.appendBuffer(m)
                        }
                        h.G() && (a.P++, En(a) && Fn(a))
                    };
                    h.listen("progress", a.J[b]);
                    a.G[b] = m => {
                        a.dispatchEvent(m)
                    };
                    h.listen("media_source_error", a.G[b]);
                    a.A.push(g)
                }
                ui(a.T) && (a.A[b].onbufferedchange = g => {
                    g.removedRanges.length > 0 && a.i.dispatchEvent(new CustomEvent("bufferremoved", {
                        detail: new Cn(a.i.currentTime, g.removedRanges)
                    }))
                })
            }
            T().F("msms_ns", a.A.length.toString());
            a.Z = !0;
            Gn(a)
        }
    }

    function In(a) {
        var b = [];
        for (let c = 0; c < a.B.length; ++c) b.push(new xn(a.l));
        return b
    }

    function Jn(a) {
        if (En(a) && (a.i.ended || Math.abs(a.i.currentTime - a.i.duration) < .25)) Kn(a);
        else {
            var b, c;
            if (!(c = a.i.readyState === HTMLMediaElement.HAVE_ENOUGH_DATA) && (c = ((b = a.l) == null ? 0 : b.Uc) && a.i.readyState === HTMLMediaElement.HAVE_FUTURE_DATA)) a: {
                b = a.i.currentTime;c = a.i.buffered;
                for (let e = 0; e < c.length; e++)
                    if (b >= c.start(e) && b < c.end(e)) {
                        c = c.end(e) - b >= 1;
                        break a
                    }
                c = !1
            }
            if (c) Ln(a);
            else if (En(a)) {
                a.P = 0;
                for (var d of a.u) d.reset();
                Gn(a)
            } else if (Mn(a) && Nn(a)) {
                a.P = 0;
                for (d = 0; d < a.B.length; d++) a.u[d].reset(), a.A[d].abort();
                Gn(a)
            }
        }
    }

    function En(a) {
        return a.P === a.B.length
    }

    function Fn(a) {
        var b, c, d;
        ((b = a.l) == null ? 0 : b.Kb) || ((c = a.l) == null ? 0 : c.zb) || ((d = a.l) == null ? 0 : d.yb) && uh() ? Promise.all(a.K.map(e => new Promise(f => {
            e.updating ? e.wa("updateend", () => {
                f()
            }) : f()
        }))).then(() => {
            a.T.endOfStream()
        }) : Promise.all(a.A.map((e, f) => new Promise(g => {
            if (e.updating) {
                var h = () => {
                    var k;
                    ((k = a.l) == null ? 0 : k.kb) && (e.updating || a.D[f].length > 0) || (e.removeEventListener("updateend", h), g())
                };
                e.addEventListener("updateend", h)
            } else g()
        }))).then(() => {
            a.T.endOfStream()
        })
    }

    function Gn(a) {
        if (a.Z && !En(a) && a.T.readyState !== "closed")
            for (let c = 0; c < a.B.length; ++c) {
                let d = a.u[c];
                var b = a.A[c];
                b = b.buffered.length === 0 ? 0 : b.buffered.end(0) * 1E3;
                b = a.ba[c].fc(a.ea, b, d.Y(), d.Z());
                b !== 0 && d.ba(b)
            }
    }

    function Hn(a, b, c) {
        a.D[c].length === 0 && a.u[c].P() ? Gn(a) : b.updating || a.D[c].length === 0 || (a = a.D[c].shift(), b.appendBuffer(a))
    }

    function Kn(a) {
        a.T.readyState === "open" && Fn(a);
        a.i.currentTime = a.i.duration + .01
    }

    function On(a) {
        var b = a.T;
        var c = window;
        if (typeof MediaSource !== "undefined" && b instanceof MediaSource || typeof c.ManagedMediaSource !== "undefined" && b instanceof c.ManagedMediaSource) b = he(URL.createObjectURL(b));
        else {
            c = b.type;
            c.toLowerCase() === "application/octet-stream" ? c = !0 : (c = c.match(/^([^;]+)(?:;\w+=(?:\w+|"[\w;,= ]+"))*$/i), c = (c == null ? void 0 : c.length) === 2 && (/^image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp|x-icon|heic|heif|avif|x-ms-bmp)$/i.test(c[1]) || /^video\/(?:3gpp|avi|mpeg|mpg|mp4|ogg|webm|x-flv|matroska|x-matroska|quicktime|x-ms-wmv)$/i.test(c[1]) ||
                /^audio\/(?:3gpp2|3gpp|aac|amr|L16|midi|mp3|mp4|mpeg|oga|ogg|opus|x-m4a|matroska|x-matroska|x-wav|wav|webm)$/i.test(c[1]) || /^font\/[\w-]+$/i.test(c[1])));
            if (!c) throw Error("");
            b = he(URL.createObjectURL(b))
        }
        a.L = b.toString();
        return a.L
    }

    function Ln(a) {
        a.i.playbackRate += .01;
        a.i.playbackRate -= .01
    }

    function Mn(a) {
        return a.u.every(b => b.aa() || b.G())
    }

    function Nn(a) {
        var b;
        return (((b = a.l) == null ? 0 : b.Kb) ? a.K : a.A).every(c => !c.updating)
    }

    function Pn(a) {
        a.L && window.URL.revokeObjectURL(a.L);
        a.T.removeEventListener("sourceopen", a.V);
        a.T.removeEventListener("startstreaming", a.Y);
        a.T.removeEventListener("endstreaming", a.R);
        for (var b of a.K) b.dispose();
        a.Z = !1;
        a.A.length = 0;
        a.K.length = 0;
        a.D.length = 0;
        a.P = 0;
        for (b = 0; b < a.u.length; ++b) {
            let c = a.u[b];
            a.J[b] && c.na("progress", a.J[b]);
            a.G[b] && c.na("media_source_error", a.G[b]);
            c.reset()
        }
        a.J.length = 0;
        a.G.length = 0;
        a.T = Q(ti());
        a.T.addEventListener("sourceopen", a.V);
        ui(a.T) && (a.T.addEventListener("startstreaming",
            a.Y), a.T.addEventListener("endstreaming", a.R));
        return On(a)
    }
    var Rn = class extends N {
            constructor(a, b, c, d = 1, e = 1E3) {
                super();
                this.B = a;
                this.i = b;
                this.l = c;
                this.A = [];
                this.K = [];
                this.L = null;
                this.P = 0;
                this.Z = !1;
                this.ea = 0;
                this.D = [];
                this.J = [];
                this.G = [];
                this.pa = !1;
                this.Na = d;
                this.aa = e;
                this.ga = () => {
                    this.pa = !0
                };
                this.i.addEventListener("ended", this.ga, {
                    once: !0
                });
                var f;
                if ((f = this.l) == null ? 0 : f.kb) {
                    let g = null;
                    if ($l(this.l)) {
                        let h;
                        g = ((h = this.l) == null ? 0 : h.yd) ? Q(Bn) : Q(bn)
                    }
                    this.u = this.B.map(h => Q(wn, h, Aj(h.url) ? null : g, this.i, this.l))
                } else this.u = this.B.map(g => Q(nn, g, this.i, this.l));
                (c == null ? 0 : c.ab) && this.u.forEach(g => {
                    g.listen("bandaid_fallback_count", h => {
                        this.dispatchEvent(h)
                    })
                });
                this.T = Q(ti());
                this.V = () => {
                    Dn(this)
                };
                this.Y = () => {
                    var g;
                    if ((g = this.l) == null ? 0 : g.Ga) {
                        for (let h of this.u) h.pa();
                        Gn(this)
                    }
                    this.i.dispatchEvent(new CustomEvent("mms_start_streaming"))
                };
                this.R = () => {
                    var g;
                    if ((g = this.l) == null ? 0 : g.Ga)
                        for (let h of this.u) h.fa();
                    this.i.dispatchEvent(new CustomEvent("mms_end_streaming"))
                };
                this.T.addEventListener("sourceopen", this.V);
                ui(this.T) && (this.T.addEventListener("startstreaming",
                    this.Y), this.T.addEventListener("endstreaming", this.R));
                this.ba = In(this);
                this.fa = () => {
                    Jn(this)
                };
                this.i.addEventListener("playbackStalled", this.fa)
            }
            updateVideoTime(a) {
                this.ea = a;
                Gn(this);
                var b;
                if ((b = this.l) == null ? 0 : b.Ab)
                    if (a = this.i.currentTime, !(this.pa || this.i.paused || this.B.length <= 1 || !En(this) || Math.abs(a - this.i.duration) >= .25))
                        for (let c of this.A)
                            if (b = c.buffered.end(c.buffered.length - 1), a > b - Qn) {
                                Kn(this);
                                break
                            }
            }
            o() {
                this.L && window.URL.revokeObjectURL(this.L);
                for (let a of this.K) a.dispose();
                for (let a of this.u) a.dispose();
                this.T.removeEventListener("sourceopen", this.V);
                this.T.removeEventListener("startstreaming", this.Y);
                this.T.removeEventListener("endstreaming", this.R);
                this.i.removeEventListener("ended", this.ga);
                this.i.removeEventListener("playbackStalled", this.fa);
                super.o()
            }
            Xa(a) {
                this.ba.filter(() => !1).map(b => b).forEach(b => {
                    b.i = Object.assign({}, on, b.i, a)
                })
            }
        },
        Qn = 1 / 30;
    var Sn = RegExp("/pagead/conversion|/pagead/adview|/pagead/gen_204|/activeview?|csi.gstatic.com/csi|google.com/pagead/xsul|google.com/ads/measurement/l|googleads.g.doubleclick.net/pagead/ide_cookie|googleads.g.doubleclick.net/xbbe/pixel"),
        Tn = RegExp("outstream.min.js"),
        Un = RegExp("outstream.min.css"),
        Vn = RegExp("fonts.gstatic.com"),
        Wn = RegExp("googlevideo.com/videoplayback|c.2mdn.net/videoplayback|gcdn.2mdn.net/videoplayback"),
        Xn = RegExp("custom.elements.min.js");

    function Yn(a, b) {
        var c = 0,
            d = 0,
            e = 0,
            f = 0,
            g = 0,
            h = 0,
            k = 0,
            m = !1,
            n = !1;
        if (typeof ha("performance.getEntriesByType", r) === "function" && "transferSize" in r.PerformanceResourceTiming.prototype) {
            var l = r.performance.getEntriesByType("resource");
            for (var p of l) Sn.test(p.name) || (f += 1, p.transferSize ? (c += p.transferSize, p.encodedBodySize && p.transferSize < p.encodedBodySize && (h += 1, e += p.encodedBodySize, Tn.test(p.name) && (m = !0), Un.test(p.name) && (n = !0)), Wn.test(p.name) && (d += p.transferSize)) : p.transferSize === 0 && p.encodedBodySize ===
                0 ? Xn.test(p.name) ? c += 6686 : Vn.test(p.name) || (k += 1) : (g += 1, e += p.encodedBodySize, Tn.test(p.name) && (m = !0), Un.test(p.name) && (n = !0)));
            p = 0;
            if (a.duration) {
                for (l = 0; l < a.buffered.length; l++) p += a.buffered.end(l) - a.buffered.start(l);
                p = Math.min(p, a.duration)
            }
            l = T();
            a = {
                event_name: b,
                asset_bytes: c,
                video_bytes: d,
                cached_data_bytes: e,
                js_cached: m,
                css_cached: n,
                num_assets: f,
                num_assets_cached: g,
                num_assets_cache_validated: h,
                num_assets_unmeasurable: k,
                video_played_seconds: a.currentTime.toFixed(2),
                video_muted: a.muted,
                video_seconds_loaded: p.toFixed(2)
            };
            for (let x in a) a[x] = typeof a[x] === "object" ? encodeURIComponent(JSON.stringify(a[x])) : encodeURIComponent(String(a[x]));
            l.i.nb(a)
        } else T().F("error", "reporting_timing_not_supported")
    };
    var Zn = class {
        constructor(a, b, c) {
            this.url = a;
            this.mimeType = b;
            this.pb = c
        }
    };

    function $n(a) {
        var b = T(),
            c = a.getVideoPlaybackQuality && a.getVideoPlaybackQuality();
        c ? (a = a.currentTime, b.F("vqdf", String(c.droppedVideoFrames)), b.F("vqtf", String(c.totalVideoFrames)), b.F("vqfr", String(Math.round(c.totalVideoFrames / a)))) : b.F("vqu", "1")
    };

    function ao(a) {
        this.i = a
    }
    ao.prototype.toString = function() {
        return this.i
    };
    var bo = new ao("video_mute"),
        co = new ao("video_caption_visibility");

    function eo(a, b, c) {
        var d = a.i;
        d && (d.subscribe(co, b, c), nd(a, () => {
            d.unsubscribe(co, b, c)
        }))
    }
    var fo = class extends M {
        constructor(a = null) {
            super();
            this.l = new Ij(this);
            md(this, this.l);
            this.i = a
        }
        unsubscribe(a, b, c) {
            return this.i ? this.i.unsubscribe(a, b, c) : !1
        }
    };

    function go(a) {
        M.call(this);
        this.I = 1;
        this.u = [];
        this.A = 0;
        this.i = [];
        this.l = {};
        this.G = !!a
    }
    t(go, M);
    q = go.prototype;
    q.subscribe = function(a, b, c) {
        var d = this.l[a];
        d || (d = this.l[a] = []);
        var e = this.I;
        this.i[e] = a;
        this.i[e + 1] = b;
        this.i[e + 2] = c;
        this.I = e + 3;
        d.push(e);
        return e
    };
    q.unsubscribe = function(a, b, c) {
        if (a = this.l[a]) {
            let d = this.i;
            if (a = a.find(function(e) {
                    return d[e + 1] == b && d[e + 2] == c
                })) return this.B(a)
        }
        return !1
    };
    q.B = function(a) {
        var b = this.i[a];
        if (b) {
            let c = this.l[b];
            this.A != 0 ? (this.u.push(a), this.i[a + 1] = () => {}) : (c && Ea(c, a), delete this.i[a], delete this.i[a + 1], delete this.i[a + 2])
        }
        return !!b
    };
    q.D = function(a, b) {
        var c = this.l[a];
        if (c) {
            let e = Array(arguments.length - 1);
            var d = arguments.length;
            let f;
            for (f = 1; f < d; f++) e[f - 1] = arguments[f];
            if (this.G)
                for (f = 0; f < c.length; f++) d = c[f], ho(this.i[d + 1], this.i[d + 2], e);
            else {
                this.A++;
                try {
                    for (f = 0, d = c.length; f < d && !this.N; f++) {
                        let g = c[f];
                        this.i[g + 1].apply(this.i[g + 2], e)
                    }
                } finally {
                    if (this.A--, this.u.length > 0 && this.A == 0)
                        for (; c = this.u.pop();) this.B(c)
                }
            }
        }
    };

    function ho(a, b, c) {
        Nk(function() {
            a.apply(b, c)
        })
    }
    q.clear = function(a) {
        if (a) {
            let b = this.l[a];
            b && (b.forEach(this.B, this), delete this.l[a])
        } else this.i.length = 0, this.l = {}
    };
    q.o = function() {
        go.ma.o.call(this);
        this.clear();
        this.u.length = 0
    };

    function io(a) {
        M.call(this);
        this.i = new go(a);
        md(this, this.i)
    }
    t(io, M);
    io.prototype.subscribe = function(a, b, c) {
        return this.i.subscribe(a.toString(), b, c)
    };
    io.prototype.unsubscribe = function(a, b, c) {
        return this.i.unsubscribe(a.toString(), b, c)
    };
    io.prototype.clear = function(a) {
        this.i.clear(a !== void 0 ? a.toString() : void 0)
    };
    var jo = class extends fo {
        constructor(a, b) {
            super(b);
            eo(this, c => {
                c ? a.show() : a.ca()
            }, this)
        }
    };
    var ko = class extends N {
        constructor() {
            super();
            this.element = null;
            this.l = new Ij(this);
            md(this, this.l)
        }
    };

    function lo(a) {
        var b = a.i;
        b.addEventListener("cuechange", () => {
            var c = b.cues;
            for (let d = 0; d < c.length; d++) {
                let e = c[d];
                e.align = "center";
                e.position = "auto"
            }
        }, {
            once: !0
        })
    }
    var mo = class extends ko {
        constructor(a, b, c = !0) {
            super();
            a.setAttribute("crossorigin", "anonymous");
            var d = xe("TRACK");
            d.setAttribute("kind", "captions");
            d.setAttribute("src", b);
            d.setAttribute("default", "");
            a.appendChild(d);
            this.i = a.textTracks[0];
            lo(this);
            c ? this.show() : this.ca()
        }
        show() {
            this.i.mode = "showing"
        }
        ca() {
            this.i.mode = "hidden"
        }
    };

    function no(a, b) {
        if (typeof ReportingObserver !== "undefined") {
            var c = e => {
                    for (let f of e) a(f) && b(f)
                },
                d = new ReportingObserver(c, {
                    buffered: !0
                });
            r.addEventListener("pagehide", () => {
                c(d.takeRecords(), d);
                d.disconnect()
            });
            d.observe()
        }
    }

    function oo(a = null) {
        no(b => {
            var c;
            return ((c = b.body) == null ? void 0 : c.id) === "HeavyAdIntervention"
        }, b => {
            var c = b.body.message,
                d = T();
            d.F("ham", c);
            c.includes("CPU") ? d.F("hacpu", "true") : c.includes("network") && d.F("habytes", "true");
            a && a(b)
        })
    };
    var po = "autoplay controls crossorigin demuxedaudiosrc demuxedvideosrc loop muted playsinline poster preload src webkit-playsinline x-webkit-airplay".split(" "),
        qo = "autoplay buffered controls crossOrigin currentSrc currentTime defaultMuted defaultPlaybackRate disablePictureInPicture disableRemotePlayback duration ended loop muted networkState onerror onwaitingforkey paused played playsinline poster preload preservesPitch mozPreservesPitch webkitPreservesPitch readyState seekable videoWidth videoHeight volume textTracks canPlayType captureStream getVideoPlaybackQuality load pause play requestPictureInPicture setSinkId oncanplay oncanplaythrough onload onplay onpause onended onfullscreenchange onfullscreenerror addEventListener dispatchEvent removeEventListener requestFullscreen".split(" "),
        ro = {
            childList: !0
        },
        so = !RegExp("^\\s*class\\s*\\{\\s*\\}\\s*$").test(class {}.toString()),
        to = HTMLElement;
    if (so) {
        class a {
            constructor() {
                var b = Object.getPrototypeOf(this).constructor;
                return r.Reflect.construct(HTMLElement, [], b)
            }
        }
        to = a;
        Object.setPrototypeOf(to, HTMLElement);
        Object.setPrototypeOf(to.prototype, HTMLElement.prototype)
    }
    var uo = a => {
        if (a !== null)
            for (let b of a)
                if (b.nodeName === "TRACK".toString()) return b;
        return null
    };
    class vo {
        constructor(a, b = "") {
            this.code = a;
            this.message = b
        }
    }
    class wo extends vo {
        constructor(a = "") {
            super(MediaError.MEDIA_ERR_SRC_NOT_SUPPORTED, a)
        }
    }

    function xo(a) {
        yo(a);
        zo(a);
        var b;
        ((b = a.da) == null ? 0 : b.bb) && a.H.addEventListener("ended", () => {
            a.za = !1
        });
        a.H.addEventListener("loadedmetadata", () => {
            a.Ya = Ql(a);
            a.Ya.then(d => {
                var e = a.H; {
                    var f = new $d(d.width, d.height);
                    d = a.H.videoWidth;
                    var g = a.H.videoHeight;
                    let h = f.width,
                        k = f.height;
                    d > 0 && g > 0 && h > 0 && k > 0 ? (f = f.width / f.height, d /= g, d = Math.min(d, f) / Math.max(d, f) >= .97 ? "cover" : "contain") : d = null
                }
                if (d !== null)
                    if (d = {
                            "object-fit": d
                        }, typeof d === "string") Ce(e, void 0, d);
                    else
                        for (let h in d) Ce(e, d[h], h)
            })
        });
        a.H.addEventListener("playing",
            () => {
                a.Hb || (Yn(a.H, "first_play"), a.Hb = !0)
            });
        a.H.addEventListener("pause", () => {
            a.Wa || (Yn(a.H, "first_pause"), $n(a.H), a.Wa = !0)
        });
        Gd(r, "pagehide", () => {
            a.Wa || (Yn(a.H, "first_pause"), $n(a.H), a.Wa = !0)
        });
        a.H.addEventListener("stalled", () => {
            T().F("ves", "1")
        });
        Q(Sl, a.H).listen("playbackStalled", () => {
            T().F("pbs", "1");
            var d;
            if ((d = a.da) == null ? 0 : d.Ab) {
                let e;
                (e = a.W) == null || Jn(e)
            }
        });
        a.H.addEventListener("media_source_error", d => {
            Ao(a);
            d = d.detail;
            Bo(a, new vo(d.code, d.message))
        });
        var c;
        ((c = a.da) == null ? 0 : c.bb) && a.H.addEventListener("error",
            d => {
                Co(a);
                var e = a.H.error,
                    f;
                !e || e.code !== MediaError.MEDIA_ERR_DECODE && ((f = e.message) == null || !f.includes("Media failed to decode")) || !a.W || a.wb >= 10 ? (a.Ea = !1, a.xa = null, a.za = !1) : (d.stopImmediatePropagation(), a.wb++, a.xa === null && (a.xa = a.H.currentTime), a.Ea = !0, setTimeout(() => {
                    a.Ea && a.za && Do(a)
                }, 0))
            });
        Eo(a)
    }

    function Fo(a) {
        a.H.addEventListener("volumechange", () => {
            a.jb.i.D(bo.toString(), a.H.muted);
            a.lc || a.jb.i.D(co.toString(), a.H.muted)
        })
    }

    function Go(a) {
        var b = uo(a.childNodes);
        b && Ho(a, b);
        a.Sa === null && Io(a)
    }

    function Jo(a) {
        a.H.load();
        var b;
        ((b = a.da) == null ? 0 : b.Tc) && a.H.dispatchEvent(new Event("canplaythrough"))
    }

    function Ko(a, b) {
        if (b !== a.Gb) {
            a.Gb = b;
            a.mc && b && zj(b) && (b = Bj(b));
            var c = b && zj(b) ? Bj(b) : b;
            c = c ? qi(c) : null;
            let d = !!c && vi(c);
            T().F("umsem", d ? "1" : "0");
            if (d) {
                c = Q(Zn, b, ri(c), ai[c] * 1E3, null);
                a.W = Q(Rn, [c], a.H, a.da);
                a.Ia && a.W.Xa(a.Ia);
                a.W.listen("media_source_error", f => {
                    f = R("media_source_error", f.detail);
                    a.H.dispatchEvent(f)
                });
                let e;
                ((e = a.da) == null ? 0 : e.ab) && a.W.listen("bandaid_fallback_count", () => {
                    a.dispatchEvent(R("bandaid_fallback_count"))
                });
                a.La = () => a.W.updateVideoTime(a.H.currentTime * 1E3);
                a.H.addEventListener("timeupdate",
                    a.La);
                ui(a.W.T) && (Lo(a, "disableRemotePlayback", "true"), Mo());
                Lo(a, "src", On(a.W))
            } else Ao(a), Lo(a, "src", b);
            a.Ib || Jo(a);
            b && a.H.dispatchEvent(new Event("loadstart"))
        }
    }

    function No(a) {
        a.src && Bo(a, new vo(MediaError.MEDIA_ERR_ABORTED, "Setting demuxed src after src is already set."));
        if (!a.qa && !a.ka && a.W) Ao(a), Lo(a, "src", null), Jo(a);
        else if (a.qa && a.ka) {
            a.H.dispatchEvent(new Event("loadstart"));
            var b = qi(zj(a.ka) ? Bj(a.ka) : a.ka),
                c = qi(zj(a.qa) ? Bj(a.qa) : a.qa);
            if (b && vi(b))
                if (c && vi(c)) {
                    var d = !!b && vi(b) && !!c && vi(c);
                    T().F("umsed", d ? "1" : "0");
                    b = Q(Zn, a.ka, ri(b), -1, null);
                    c = Q(Zn, a.qa, ri(c), -1, null);
                    var e;
                    d = ((e = a.da) == null ? 0 : e.zd) ? [b] : [b, c];
                    a.W = Q(Rn, d, a.H, a.da);
                    a.Ia && a.W.Xa(a.Ia);
                    a.W.listen("media_source_error", k => {
                        k = R("media_source_error", k.detail);
                        a.H.dispatchEvent(k)
                    });
                    var f;
                    ((f = a.da) == null ? 0 : f.ab) && a.W.listen("bandaid_fallback_count", () => {
                        a.dispatchEvent(R("bandaid_fallback_count"))
                    });
                    a.La = () => a.W.updateVideoTime(a.H.currentTime * 1E3);
                    a.H.addEventListener("timeupdate", a.La);
                    var g, h;
                    (g = a.da) == null || !g.Ab || (h = a.da) != null && h.Sc || (a.fb = () => {
                        Ln(a.W)
                    }, a.H.addEventListener("playing", a.fb));
                    ui(a.W.T) && (Lo(a, "disableRemotePlayback", "true"), Mo());
                    Lo(a, "src", On(a.W));
                    a.Ib || Jo(a)
                } else Bo(a,
                    new wo(`Audio itag "${c}" not supported.`));
            else Bo(a, new wo(`Video itag "${b}" not supported.`))
        }
    }

    function Lo(a, b, c) {
        c !== a.H.getAttribute(b) && (c === null ? a.H.removeAttribute(b) : a.H.setAttribute(b, c))
    }

    function Mo() {
        navigator.audioSession && navigator.audioSession.type !== "ambient" && (navigator.audioSession.type = "ambient")
    }

    function Co(a) {
        a.Fa && (a.H.removeEventListener("loadedmetadata", a.Fa), a.Fa = null)
    }

    function Ao(a) {
        Co(a);
        a.xa = null;
        a.Ea = !1;
        a.za = !1;
        a.W && (a.H.removeEventListener("timeupdate", a.La), a.H.removeEventListener("playing", a.fb), a.W.dispose(), a.W = null)
    }

    function Do(a) {
        if (a.W) {
            a.H.dispatchEvent(R("media_source_reconstruct"));
            a.Ea = !1;
            a.Fa = () => {
                Co(a);
                a.xa !== null && (a.H.currentTime = a.xa, a.xa = null);
                a.za && a.H.play()
            };
            a.H.addEventListener("loadedmetadata", a.Fa, {
                once: !0
            });
            var b = Pn(a.W);
            Lo(a, "src", b)
        }
    }

    function Bo(a, b) {
        a.ob = b;
        a.H.dispatchEvent(new Event("error"))
    }

    function yo(a) {
        for (let b of qo)
            if (b in a.H)
                if (b === "play") {
                    let c = () => {
                        var d;
                        if ((d = a.da) == null ? 0 : d.bb) {
                            a.za = !0;
                            if (a.Ea) return Do(a), Promise.resolve();
                            if (a.Fa) return Promise.resolve()
                        }
                        return a.bc ? Promise.resolve() : a.H.play()
                    };
                    Object.defineProperty(a, "play", {
                        set: d => {
                            a.H.play = d
                        },
                        get: () => c
                    })
                } else if (b === "pause") {
            let c = () => {
                var d;
                if ((d = a.da) == null ? 0 : d.bb) a.za = !1;
                a.H.pause()
            };
            Object.defineProperty(a, "pause", {
                set: d => {
                    a.H.pause = d
                },
                get: () => c
            })
        } else if (typeof a.H[b] === "function") {
            let c = a.H[b].bind(a.H);
            Object.defineProperty(a,
                b, {
                    set: d => {
                        a.H[b] = d
                    },
                    get: () => c
                })
        } else Object.defineProperty(a, b, {
            set: c => {
                a.H[b] = c
            },
            get: () => a.H[b]
        })
    }

    function zo(a) {
        Object.defineProperty(a, "error", {
            set: () => {},
            get: () => a.H.error ? a.H.error : a.ob
        })
    }

    function Eo(a) {
        a.H.style.width = Ee();
        a.H.style.height = Ee()
    }

    function Ho(a, b) {
        if (a.Sa === null && b.hasAttribute("src")) {
            let c = b.getAttribute("src");
            a.Sa = new mo(a.H, c, b.hasAttribute("default"));
            new jo(a.Sa, a.jb);
            c.includes("kind=asr") && T().F("act", "1")
        }
    }

    function Io(a) {
        if (r.MutationObserver) {
            let b = new MutationObserver(c => {
                for (let d of c)
                    if (d.type === "childList" && (c = uo(d.addedNodes))) {
                        Ho(a, c);
                        b.disconnect();
                        break
                    }
            });
            b.observe(a, ro)
        }
    }
    var Oo = class extends to {
        constructor(a, b = !1, c = null) {
            super();
            this.da = c;
            T().F("ulv", "1");
            this.lc = b;
            this.ob = this.Gb = this.W = null;
            this.H = xe("VIDEO");
            xo(this);
            this.jb = a || new io;
            Fo(this);
            this.Sa = null;
            Go(this);
            this.attachShadow({
                mode: "open"
            });
            this.shadowRoot.appendChild(this.H);
            oo(() => {
                T().F("has", this.src || this.ka);
                T().F("hat", String(this.H.currentTime))
            });
            this.Ea = this.Hb = this.Wa = !1;
            this.wb = 0;
            this.xa = this.Fa = null;
            this.za = !1;
            this.La = null;
            this.fb = () => {};
            this.Ya = null;
            this.bc = this.Ib = this.mc = !1;
            this.Ia = null
        }
        set qa(a) {
            this.setAttribute("demuxedaudiosrc",
                a)
        }
        get qa() {
            return this.getAttribute("demuxedaudiosrc")
        }
        set ka(a) {
            this.setAttribute("demuxedvideosrc", a)
        }
        get ka() {
            return this.getAttribute("demuxedvideosrc")
        }
        set src(a) {
            this.setAttribute("src", a)
        }
        get src() {
            return this.getAttribute("src")
        }
        static get observedAttributes() {
            return po
        }
        attributeChangedCallback(a, b, c) {
            switch (a) {
                case "src":
                    Ko(this, c);
                    break;
                case "demuxedaudiosrc":
                case "demuxedvideosrc":
                    No(this);
                    break;
                case "muted":
                    this.H[a] = c === "" ? !0 : !!c;
                    Lo(this, a, c);
                    break;
                default:
                    Lo(this, a, c)
            }
        }
        Xa(a) {
            this.Ia =
                a;
            var b;
            (b = this.W) == null || b.Xa(a)
        }
        disconnectedCallback() {
            this.Ya && Rl(this.Ya);
            super.disconnectedCallback && super.disconnectedCallback()
        }
    };
    r.customElements && (r.customElements.get("lima-video") || r.customElements.define("lima-video", Oo));

    function Po() {
        if (window.MutationObserver) {
            var a = [];
            (new MutationObserver(() => {
                for (let b of a) b();
                a = []
            })).observe(document.createTextNode(""), {
                characterData: !0
            })
        }
    }
    typeof Promise === "function" && String(Promise).indexOf("[native code]") > -1 || Po();
    var Qo = class {
        constructor(a, b) {
            this.name = a;
            this.i = b
        }
        getName() {
            return this.name
        }
    };

    function Ro() {
        try {
            var a = window.top.location.href
        } catch (b) {
            return 2
        }
        return a == null ? 2 : a === window.document.location.href ? 0 : 1
    };

    function So(a = {}) {
        var b = new Map;
        Y(b, "AD_TOS", () => To(a.Lc));
        Y(b, "ADCOUNT", () => Uo(a.Pa));
        Y(b, "AD_MT", () => Vo(a.U));
        Y(b, "ADPLAYHEAD", () => Wo(a.U));
        Y(b, "ADSERVINGID", () => Xo(a.ad));
        Y(b, "ASSETURI", () => Yo(a.U));
        Z(b, "CLICKPOS", "-1");
        Y(b, "CSET", () => Date.now().toString());
        Y(b, "PODSEQUENCE", () => Zo(a.ad));
        var c = a.rd,
            d = a.td;
        Z(b, "UNIVERSALADID", c && d ? `${c} ${d}` : "-1");
        return $o(a, b)
    }

    function $o(a = {}, b = new Map) {
        Y(b, "ADTYPE", () => ap(a.ad));
        Z(b, "APPBUNDLE", a.appName || "-1");
        Y(b, "BREAKMAXADS", () => bp(a.Pa));
        Z(b, "BREAKMAXADLENGTH", "-1");
        Y(b, "BREAKMAXDURATION", () => cp(a.Pa));
        Z(b, "BREAKMINADLENGTH", "-1");
        Z(b, "BREAKMINDURATION", "-1");
        Y(b, "BREAKPOSITION", () => dp(a.Pa));
        Y(b, "CACHEBUSTING", ep);
        Z(b, "CLICKTYPE", a.Qc || "-1");
        Z(b, "CLIENTUA", fp({
            qb: a.qb,
            rb: a.rb,
            Eb: a.Eb,
            Fb: a.Fb
        }));
        Z(b, "CONTENTID", "-1");
        Z(b, "CONTENTURI", "-1");
        Z(b, "DEVICEIP", "-1");
        Z(b, "DEVICEUA", "-1");
        Z(b, "DOMAIN", a.domain || gp());
        Z(b,
            "GDPRCONSENT", a.Zb ? a.Zb : "-1");
        Z(b, "IFA", "-2");
        Z(b, "IFATYPE", "-2");
        Z(b, "INVENTORYSTATE", "-1");
        Z(b, "LATLONG", "-1");
        Y(b, "LIMITADTRACKING", () => hp(a.Sb));
        Y(b, "MEDIAPLAYHEAD", () => ip(a.Pa));
        Y(b, "OMIDPARTNER", () => jp(a.gd, a.hd));
        Z(b, "PAGEURL", a.jd || kp());
        Z(b, "PLACEMENTTYPE", a.kd || "-1");
        Z(b, "PLAYERSIZE", "-1");
        Z(b, "PLAYERSTATE", "-1");
        Z(b, "REGULATIONS", "-1");
        Z(b, "SERVERSIDE", "0");
        Z(b, "SERVERUA", "-1");
        Y(b, "TIMESTAMP", lp);
        Y(b, "TRANSACTIONID", () => mp(a.Sb));
        Z(b, "US_PRIVACY", a.ud || "-1");
        a.nc && Z(b, "UACH", a.nc);
        return b
    }

    function Z(a, b, c) {
        a.set(b, new Qo(b, {
            toString: () => c
        }))
    }

    function Y(a, b, c) {
        a.set(b, new Qo(b, {
            toString: () => c()
        }))
    }

    function np(a, b = new Map) {
        b.set("ERRORCODE", new Qo("ERRORCODE", a))
    }

    function fp({
        qb: a = null,
        rb: b = null,
        Eb: c = null,
        Fb: d = null
    }) {
        if (!a && !c) return "-1";
        var e = "unknown";
        a && (e = a + (b ? "/" + b : ""));
        a = "";
        c && (a = " " + c + (d ? "/" + d : ""));
        return e + a
    }

    function To(a = null) {
        if (a == null) return "-1";
        var b = Date.now();
        return a > b ? "-1" : Math.round(b - a).toString()
    }

    function Uo(a = null) {
        return a ? a.i().toString() : "-1"
    }

    function cp(a = null) {
        return a ? a.o().toString() : "-1"
    }

    function bp(a = null) {
        return a ? a.A().toString() : "-1"
    }

    function Vo(a = null) {
        return a == null ? "-1" : Math.round(Math.max(0, a.getCurrentTime() * 1E3)).toString()
    }

    function Wo(a = null) {
        if (a == null) a = "-1";
        else {
            a = a.getCurrentTime();
            a = a < 0 ? 0 : a;
            var b = Math.floor(a / 3600);
            if (Number.isFinite(b)) {
                b = String(b);
                var c = b.indexOf(".");
                c === -1 && (c = b.length);
                var d = b[0] === "-" ? "-" : "";
                d && (b = b.substring(1));
                b = d + "0".repeat(Math.max(0, 2 - c)) + b
            } else b = String(b);
            a = `${b+":"}${Math.floor(a/60)%60<10?"0":""}${Math.floor(a/60)%60}:${Math.floor(a%60)<10?"0":""}${Math.floor(a%60)}${(a%1).toFixed(3).slice(1)}`
        }
        return a
    }

    function Xo(a = null) {
        return (a = a && a.i()) ? a : "-1"
    }

    function ap(a = null) {
        return a ? a.o() : "-1"
    }

    function Yo(a = null) {
        return a == null ? "-1" : a.getVideoUrl()
    }

    function dp(a = null) {
        if (a == null) return "-1";
        a = a.l();
        return a === 0 ? "1" : a === -1 ? "3" : "2"
    }

    function ep() {
        return Math.round(Math.random() * 1E8 + 1E8).toString().slice(1)
    }

    function gp() {
        var a = Ro() === 2 ? null : window.top.location.hostname;
        return a ? a : "-1"
    }

    function hp(a = null) {
        return a == null || a.i == null ? "-1" : a.i ? "1" : "0"
    }

    function ip(a = null) {
        return a ? a.u().toString() : "-1"
    }

    function jp(a = null, b = null) {
        return a == null || b == null ? "-1" : `${a}/${b}`
    }

    function kp() {
        var a = Ro() === 2 ? null : window.top.location.href;
        return a ? a : "-1"
    }

    function Zo(a = null) {
        return (a = a == null ? void 0 : a.l()) ? a.toString() : "-1"
    }

    function lp() {
        return (new Date).toISOString()
    }

    function mp(a = null) {
        return a && a.transactionId ? a.transactionId.toString() : "-1"
    };
    var op = /(?:\[|%5B)([a-zA-Z0-9_]+)(?:\]|%5D)/g;

    function pp(a, b) {
        return a.replace(op, (c, d) => {
            d = b.get(d);
            if (d == null) return c;
            b: {
                try {
                    var e = d.i.toString();
                    break b
                } catch (f) {}
                e = null
            }
            e = e == null || e !== "" && /^[\s\xa0]*$/.test(e == null ? "" : String(e)) ? null : encodeURIComponent(e).replace(/%2C/g, ",");
            return e != null ? e : c
        })
    };

    function qp(a, b) {
        return a.map(c => {
            c = typeof c === "string" ? new Ck(c) : c;
            return new Ck(pp(c.url, b))
        })
    }

    function rp(a, b, c = null, d = !1) {
        b = b.map(e => typeof e === "string" ? new Ck(e) : e);
        c = c ? qp(b, c) : b;
        for (let e of c) a.D.ya(e.url, d)
    }
    var sp = class {
        constructor(a) {
            this.D = a
        }
    };

    function tp(a) {
        T().F("rec", Array.from(a.i, ([b, c]) => `${b}-${c}`).join("|"))
    }

    function up(a, b) {
        return (a.B.get(b) || []).map(c => Dk(c))
    }
    async function vp(a, b, c) {
        c = c.map(d => typeof d === "string" ? new Ck(d) : d);
        a.A.length > 0 && (c = await Promise.all(c.map(async d => {
            for (let e of a.A) d = await e(b, d);
            return d
        })));
        a.N.forEach(d => {
            try {
                d(b)
            } catch (e) {}
        });
        wp(a, b, c)
    }

    function wp(a, b, c) {
        xp(a, b) ? yp(a, b, c) : zp(a, b) && (b === "skip" && navigator && navigator.userActivation && (T().F("uas_hba", navigator.userActivation.hasBeenActive ? "1" : "0"), T().F("uas_ia", navigator.userActivation.isActive ? "1" : "0")), c.filter(d => d.url.match(/\/aclk.*label=video_engaged_view/)).length && (b === "complete" && S(T(), "evoace"), b === "progress" && S(T(), "evoape"), b === "engagedView" && S(T(), "evoaeve")), Ap(a, b, c))
    }

    function xp(a, b) {
        if (a.i.has(b)) return !1;
        switch (b) {
            case "measurable_impression":
                return !a.i.has("impression");
            case "viewable_impression":
                return !a.i.has("impression") || !a.i.has("measurable_impression");
            default:
                return !1
        }
    }

    function yp(a, b, c) {
        var d = c;
        a.l != null && (d = qp(c, a.l));
        a.o.has(b) ? d.forEach(e => void a.o.get(b).push(e)) : a.o.set(b, d)
    }

    function zp(a, b) {
        switch (b) {
            case "abandon":
                return !a.i.has(b) && !a.i.has("skip") && !a.i.has("instreamAdComplete") && a.i.has("impression");
            case "instreamAdComplete":
            case "complete":
                return !a.i.has(b) && !a.i.has("skip");
            case "mute":
            case "unmute":
            case "pause":
            case "resume":
            case "fullscreen":
            case "exitFullscreen":
            case "progress":
            case "vastProgress":
            case "error":
            case "click":
            case "expand":
            case "collapse":
            case "videoIconClicked":
            case "vastIconRendered":
                return !0;
            default:
                return !a.i.has(b)
        }
    }

    function Ap(a, b, c) {
        a.i.has(b) ? a.i.set(b, a.i.get(b) + 1) : a.i.set(b, 1);
        c.length && rp(a, c, a.l, a.G.includes(b));
        c = null;
        b === "impression" ? c = "measurable_impression" : b === "measurable_impression" && (c = "viewable_impression");
        c != null && a.o.has(c) && (b = a.o.get(c) || [], a.o.delete(c), Ap(a, c, b))
    }

    function Bp(a, b) {
        var c = a.B.get("progress");
        if (c && !(c.length <= 0)) {
            var d = [],
                e = a.u,
                f = a.I;
            c.forEach(g => {
                var h = g.i;
                h && h <= b && h > a.u && (e = h > e ? h : e, d.push(Dk(g)))
            });
            a.u = e;
            a.I = f;
            d.length > 0 && a.report("progress", d)
        }
    }

    function Cp(a, b) {
        b.forEach(c => {
            a.l.set(c.getName(), c)
        })
    }

    function Dp(a, b) {
        a.A.push(b)
    }
    var Ep = class extends sp {
        constructor(a, b) {
            super(b);
            this.N = [];
            this.A = [];
            this.I = this.u = -1;
            this.B = a;
            this.G = [];
            this.i = new Map;
            this.o = new Map;
            this.l = new Map;
            T().F("ua_e", navigator && navigator.userActivation ? "1" : "0");
            T().i.lb(() => {
                tp(this)
            })
        }
        report(a, b = up(this, a)) {
            vp(this, a, b || [])
        }
        reportError(a) {
            S(T(), "err");
            T().F("aec", String(a));
            np(a, this.l);
            this.report("error")
        }
    };

    function Fp(a, b, c = 30) {
        a.R = b;
        a.L = c
    }

    function Gp(a) {
        switch (a) {
            case "error":
                return !1;
            case "loaded":
                return !1;
            case "media_load_attempt":
                return !1;
            default:
                return !0
        }
    }

    function Hp(a, b) {
        if (Gp(b) && !a.G) T().F("trackPrestart", `${b}`), T().l();
        else {
            a: switch (b) {
                case "error":
                    var c = !0;
                    break a;
                default:
                    c = !1
            }
            if (c || !a.J.has(b)) a.report(b),
            a.J.add(b),
            a.dispatchEvent(b)
        }
    }

    function Ip(a) {
        a.R && !a.P && (a.U.getCurrentTime() > a.L || a.U.M.ended) && a.U.Ba && (a.P = !0, Hp(a, "engagedView"), S(T(), "sdps"))
    }
    var Jp = class extends N {
        constructor(a, b, c) {
            super();
            this.A = a;
            this.U = b;
            this.u = c;
            this.G = !1;
            this.i = null;
            this.R = !1;
            this.L = 0;
            this.P = !1;
            this.J = new Set;
            this.l = new Map
        }
        sa() {
            this.Ha();
            this.U.sa();
            this.i = new Ij(this);
            md(this, this.i);
            Cp(this.A, So({
                U: this.U
            }));
            this.i.listen(this.U, "timeUpdate", this.D);
            this.i.listen(this.U, "mediaLoadAttempt", this.ea)
        }
        Ha() {
            this.U.Ha();
            this.i != null && this.i.dispose();
            this.J.clear()
        }
        report(a) {
            this.A.report(a)
        }
        D() {
            if (!(this.u < 0)) {
                let a = this.U.getCurrentTime();
                a >= 5 && !this.l.get("5s") &&
                    (S(T(), "5s"), this.l.set("5s", !0));
                a >= 10 && !this.l.get("10s") && (S(T(), "10s"), this.l.set("10s", !0));
                a >= 30 && !this.l.get("30s") && (S(T(), "30s"), this.l.set("30s", !0));
                this.u - a * 1E3 <= 2E3 && !this.l.get("2sbc") && (S(T(), "2sbc"), this.l.set("2sbc", !0));
                Ip(this)
            }
        }
        ea() {
            Hp(this, "media_load_attempt")
        }
        fa() {
            this.dispatchEvent("error");
            this.A.reportError(402)
        }
    };
    var Kp = class extends Jp {
        constructor(a, b, c) {
            super(a, b, c);
            this.K = this.B = !1
        }
        sa() {
            super.sa();
            var a;
            (a = this.i) == null || a.listen(this.U, "start", this.aa);
            var b;
            (b = this.i) == null || b.listen(this.U, "loaded", this.Y);
            var c;
            (c = this.i) == null || c.listen(this.U, "play", this.ga);
            var d;
            (d = this.i) == null || d.listen(this.U, "pause", this.Z);
            var e;
            (e = this.i) == null || e.listen(this.U, "waiting", this.ba);
            var f;
            (f = this.i) == null || f.listen(this.U, "end", this.V);
            var g;
            (g = this.i) == null || g.listen(this.U, "error", this.onError);
            var h;
            (h = this.i) ==
            null || h.listen(this.U, "mediaPlaybackTimeout", this.fa);
            var k;
            (k = this.i) == null || k.listen(this.U, "volumeChange", this.onVolumeChange)
        }
        D() {
            if (!(this.u < 0)) {
                let a = this.U.getCurrentTime();
                a * 1E3 > this.u * .25 && Hp(this, "firstQuartile");
                a * 1E3 > this.u * .5 && Hp(this, "midpoint");
                a * 1E3 > this.u * .75 && Hp(this, "thirdQuartile");
                super.D();
                Bp(this.A, this.U.getCurrentTime())
            }
        }
        aa() {
            this.G = !0;
            Hp(this, "start");
            Hp(this, "impression");
            Hp(this, "creativeView");
            T().F("dm", String(this.u));
            S(T(), "ff")
        }
        Y() {
            this.dispatchEvent("loaded")
        }
        ga() {
            this.B &&
                (this.dispatchEvent("resume"), this.B = !1);
            this.K && (this.dispatchEvent("bufferFinish"), this.K = !1)
        }
        Z() {
            this.dispatchEvent("pause");
            this.B = !0
        }
        ba() {
            this.G && (this.dispatchEvent("bufferStart"), this.K = !0)
        }
        V() {
            Ip(this);
            Hp(this, "complete");
            var a = this.u - this.U.getCurrentTime() * 1E3;
            T().F("endedMediaDiff", `${a}`);
            T().l()
        }
        onError() {
            this.dispatchEvent("error");
            this.A.reportError(400)
        }
        onVolumeChange() {
            this.dispatchEvent("volumeChange")
        }
    };
    var Lp = {},
        Mp = (a, b = .01) => {
            var c = {};
            Object.assign(c, a, Lp);
            Math.random() <= b && (a = "https://pagead2.googlesyndication.com/pagead/gen_204", b = window.location.href, (b.startsWith("https://googleads.g.doubleclick-cn.net") || b.startsWith("https://imasdk.googleapis-cn.com")) && (a = "https://pagead2.googlesyndication-cn.com/pagead/gen_204"), b = Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ Date.now()).toString(36), b = b != null ? "=" + encodeURIComponent(String(b)) : "", a = eg(a,
                "zx" + b), Yg(a, c))
        },
        Np = a => {
            var b = {};
            b[a] = "1";
            Mp(b, .01)
        };
    var Op = class {
        constructor(a) {
            this.i = a;
            this.o = xj(this.i.Z);
            this.l = new Promise(b => {
                this.u = b
            });
            this.u(this.o)
        }
        async apply(a) {
            if (this.i.V && a instanceof Oo) {
                a.ka = this.i.i;
                a.qa = this.i.u;
                var b = "demuxed"
            } else this.i.D ? (a.src = this.i.i, b = "only") : (b = await this.l, this.i.I ? (a.src = b, b = "lima") : (a.src = this.o, b = "original", a.load()));
            Mp({
                st: b
            })
        }
    };
    var Pp = {
        error: "videoplayfailed[ERRORCODE]",
        media_load_attempt: "media_load_attempt",
        start: "part2viewed",
        firstQuartile: "videoplaytime25",
        midpoint: "videoplaytime50",
        thirdQuartile: "videoplaytime75",
        complete: "videoplaytime100",
        pause: "adpause",
        resume: "adresume",
        mute: "admute",
        unmute: "adunmute"
    };

    function Qp(a, b) {
        a.has(b.eventType) ? a.get(b.eventType).push(b) : a.set(b.eventType, [b])
    }

    function Rp(a, b) {
        var c;
        (c = !a.i.I) || (c = (Cl.selected || Cl.Bb) && Ka);
        c = c ? document.createElement("video") : new Oo;
        c.setAttribute("playsinline", !0);
        c.setAttribute("webkit-playsinline", !0);
        c.setAttribute("x-webkit-airplay", "allow");
        c.setAttribute("preload", "auto");
        a.i.Na && (c.crossOrigin = "anonymous", c.poster = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAYAAAAfFcSJAAAADUlEQVR42mM4z8DwHwAFJgHgFR/eXgAAAABJRU5ErkJggg==");
        c.muted = !a.i.A;
        c.style.width = "100%";
        c.style.height = "100%";
        c.style.display = "block";
        b.appendChild(c);
        a.i.I && a.i.J && (b = document.createElement("track"), b.setAttribute("kind", "captions"), b.setAttribute("src", a.i.J), b.setAttribute("default", ""), c.appendChild(b));
        return c
    }

    function Sp(a) {
        var b = new Map,
            c = a.i.B,
            d = !1;
        if (a.i.l) {
            for (let [f, g] of Object.entries(Pp)) {
                var e = a.i.l;
                e = f === "unmute" && a.i.K ? a.i.K : ig(e, "label", g);
                Qp(b, new Ek(f, e))
            }
            e = new Ek("progress", ig(a.i.l, "label", "videoplaytime10s"), 10);
            Qp(b, e);
            a.i.P && (e = new Ek("skip", ig(a.i.l, "label", "videoskipped")), Qp(b, e));
            a.i.o && (d = new Ek("reward_granted", ig(a.i.l, "label", "admob_reward_granted")), Qp(b, d), d = c && c.size > 0)
        }
        a.i.va && Qp(b, new Ek("impression", a.i.va));
        c = !1;
        a.i.ba && (Qp(b, new Ek("engagedView", a.i.ba, a.B)), c = !0);
        a.i.X &&
            Qp(b, new Ek("impression", a.i.X));
        a.A = new Ep(b, a.K);
        d && Dp(a.A, (f, g) => Tp(a, f, g));
        b = new Kp(a.A, a.u, a.i.Y || 0);
        Fp(b, c, a.B);
        b.sa()
    }

    function Up(a) {
        a.u.listen("mediaPlaybackTimeout", () => {});
        a.o.addEventListener("ended", () => {
            a.l = 3;
            Vp(a)
        });
        a.o.addEventListener("error", () => {
            a.l = 4;
            a.i.o && yh().then(b => {
                b.resumeTimer()
            });
            if (a.o.src) {
                let b = {
                    ve: "1",
                    msei: String(qi(a.o.src))
                };
                Mp(b)
            }
        });
        a.o.addEventListener("playing", () => {
            a.l = 1
        });
        a.o.addEventListener("pause", () => {
            a.l = 2
        });
        a.o.addEventListener("timeupdate", () => {
            a.getDuration() <= 0 || a.getCurrentTime() >= a.X && Vp(a)
        })
    }
    async function Wp(a) {
        await a.J.apply(a.o);
        a.L()
    }
    async function Tp(a, b, c) {
        if (b !== "reward_granted") return c;
        b = a.i.B;
        c = c.url;
        if (b)
            for (let [d, e] of b) b = e, e === "@gw_tmstmp@" ? b = String(Date.now()) : e === "@gw_rwd_userid@" ? b = a.N : e === "@gw_rwd_custom_data@" && (b = a.D), c = ig(c, d, b);
        return new Ck(c)
    }

    function Xp(a, b) {
        a.A && a.A.report(b)
    }
    async function Yp(a) {
        a.l != 3 && Xp(a, "skip");
        a.l = 3
    }

    function Vp(a) {
        !a.G && a.i.aa && (a.G = !0, Yg(a.i.aa))
    }
    var Zp = class {
        constructor(a, b) {
            this.i = b;
            this.o = Rp(this, a);
            this.G = !1;
            this.u = new jl(this.o);
            this.X = this.i.N === 0 ? 10 : this.i.N / 1E3;
            this.B = this.i.G === 0 ? 30 : this.i.G / 1E3;
            this.K = new Vj;
            this.A = null;
            Sp(this);
            this.l = 0;
            this.i.o && yh().then(c => {
                c.pauseTimer()
            });
            this.I = new Promise(c => {
                this.L = c
            });
            this.D = this.N = "";
            Up(this);
            this.J = new Op(b);
            Wp(this)
        }
        async play(a = !0) {
            await this.I;
            if (this.l != 1)
                if (a && Xp(this, "resume"), a = this.o.play(), this.l == 0 && il(this.u), a) try {
                    await a, this.l = 1, this.i.o && yh().then(b => {
                        b.resumeTimer()
                    })
                } catch (b) {
                    throw Np("pf"),
                        b;
                } else Np("pnr")
        }
        async pause(a = !0) {
            await this.I;
            this.l != 1 ? hl(this.u) : (a && Xp(this, "pause"), this.i.o && yh().then(b => {
                b.pauseTimer()
            }), this.o.pause(), this.l = 2)
        }
        getDuration() {
            return this.u.getDuration()
        }
        getCurrentTime() {
            return this.u.getCurrentTime()
        }
    };

    function $p(a) {
        var b = a.o.o;
        b.addEventListener("play", () => a.i.show());
        b.addEventListener("error", () => a.i.ca());
        b.addEventListener("ended", () => a.i.ca());
        b.addEventListener("volumechange", () => {
            Ak(a.i, a.o.o.muted)
        })
    }
    var aq = class {
        constructor(a, b) {
            this.o = a;
            this.i = b;
            this.l = b.o();
            Ak(this.i, !0);
            this.l.addEventListener("click", c => {
                var d = !this.o.o.muted,
                    e = this.o;
                (e.o.muted = d) ? Xp(e, "mute"): Xp(e, "unmute");
                if (!d) {
                    var f = e.J;
                    var g = e.o;
                    if (f.i.D && g.src === f.i.i) {
                        let h = g.currentTime;
                        g.src = f.o;
                        f = h
                    } else f = -1;
                    f >= 0 && e.l == 1 && (e.l = 0, e.o.currentTime = f, e.play())
                }
                Ak(this.i, d);
                c.stopPropagation();
                c.preventDefault()
            });
            $p(this)
        }
    };

    function bq(a) {
        var b = cq(a, a.o);
        a = a.i ? cq(a, a.i) : null;
        return !!b && !!window.MediaSource && vi(b) && (!a || vi(a))
    }

    function dq(a, b, c = -1) {
        var d = c > 0 ? Math.min(c / a.u, 1) : 1,
            e = a.B[b];
        return e != void 0 ? Promise.resolve(e * d) : Promise.resolve(eq(a, b, c))
    }

    function fq(a) {
        return bq(a) ? Promise.resolve(!0) : dq(a, a.o).then(b => b <= (a.I - 300) * 1E3)
    }

    function gq(a) {
        if (a.A < 0) return Promise.resolve(!0);
        var b = dq(a, a.o, 31E3),
            c = a.i ? dq(a, a.i, 31E3) : Promise.resolve(0);
        return Promise.all([b, c]).then(d => d[0] + d[1] <= (a.A - 300) * 1E3)
    }

    function cq(a, b) {
        a.l[b] || (a.l[b] = qi(b) || -1);
        return a.l[b]
    }

    function eq(a, b, c = -1) {
        b = cq(a, b);
        var d = $h[b] || 400,
            e = si(a.u / 1E3, d);
        return bq(a) && c > 0 && c < a.u ? Math.min(si(c / 1E3, d) + ai[b] * 1E3, e) : e
    }
    var hq = class {
        constructor(a, b, c, d = "") {
            this.u = b;
            this.o = c;
            this.i = d;
            a: switch (a) {
                case 0:
                case 1:
                    b = 2500;
                    break a;
                default:
                    b = -1
            }
            this.I = b;
            a: switch (a) {
                case 1:
                    a = 2500;
                    break a;
                default:
                    a = -1
            }
            this.A = a;
            this.l = {};
            this.B = {}
        }
    };

    function iq(a, b) {
        b ? a.setAttribute("preload", "auto") : a.setAttribute("preload", "metadata");
        jq(a)
    }

    function jq(a) {
        a.setAttribute("playsinline", "true");
        a.setAttribute("webkit-playsinline", "")
    }

    function kq() {
        var a = document.createElement("video");
        a.setAttribute("muted", "true");
        a.muted = !0;
        jq(a);
        a.play();
        return !a.paused
    };

    function lq(a) {
        a.l && (a.pauseVideo(), a.l = !1)
    }

    function mq(a, b) {
        T().F("ape", b ? "1" : "0");
        b ? (a.B = !0, a.K || a.u.listen(a.A, "timeupdate", a.L), a.u.listen(a.A, "ended", a.R), a.i && !a.i.l || a.l || nq(a)) : a.dispatchEvent("video_exceeds_byte_limit")
    }

    function oq(a) {
        a.B ? Promise.resolve() : a.K || a.V ? (a.i && !a.i.l && a.l && lq(a), !a.G || a.K ? (mq(a, !0), Promise.resolve()) : gq(a.G).then(b => mq(a, b))) : (a.dispatchEvent("autoplay_not_supported"), Promise.reject())
    }

    function nq(a) {
        if (!a.l) {
            let b = a.playVideo();
            b ? (b.then(() => pq(a), c => {
                a.l = !1;
                a.J = !1;
                qq(a);
                a.P && a.P(c)
            }), a.J = !0) : pq(a);
            a.l = !0
        }
    }

    function qq(a) {
        a.B = !1;
        a.u.na(a.A, "timeupdate", a.L);
        a.u.na(a.A, "ended", a.R)
    }

    function rq(a) {
        a.K = !0;
        a.u.na(a.A, "timeupdate", a.L)
    }

    function pq(a) {
        a.J = !1;
        a.l && a.i && !a.i.l && lq(a)
    }
    var sq = class extends N {
        constructor(a, b, c, d) {
            super();
            this.A = a;
            this.i = b || null;
            this.P = c || null;
            this.G = d || null;
            this.K = this.J = this.l = this.B = !1;
            this.u = new Ij(this);
            md(this, this.u);
            this.L = () => {
                this.l && this.A.currentTime >= 31 && (this.dispatchEvent("stopped_exceeded_time_limit"), lq(this), qq(this))
            };
            this.R = () => {
                qq(this)
            };
            this.i && (this.u.listen(this.i, "became-visible", () => {
                this.B && nq(this)
            }), this.u.listen(this.i, "became-invisible", () => {
                !this.J && this.B && lq(this)
            }), Ud(this.i));
            this.V = kq();
            this.G ? fq(this.G).then(e => {
                T().F("ple", e ? "1" : "0");
                iq(this.A, e)
            }) : (T().F("ple", "1"), iq(this.A, !0))
        }
    };
    var tq = class extends sq {
        constructor(a, b, c, d) {
            super(a.o, b, c, d);
            this.D = a
        }
        playVideo() {
            this.D.i.A && (this.D.o.muted = !1, this.D.o.volume = 1);
            return this.D.play(!1)
        }
        pauseVideo() {
            this.D.pause(!1)
        }
    };

    function uq(a, b) {
        var c = b != null ? b : {};
        b = a.zIndex;
        var d = a.ta;
        a = c && c.tb;
        c = pk(sk(), '<div class="playback-container ' + mk(d ? "clickable" : "default") + '"><div class="play-pause-icon">');
        d = d ? 28 : 48;
        var e = dk('<svg class="play-icon" xmlns="http://www.w3.org/2000/svg" width="' + mk(d) + '" height="' + mk(d) + '" viewBox="0 0 48 48" fill="#fff"><path d="M16 10v28l22-14z"/></svg>');
        e = qk(c, e);
        var f = dk('<svg class="pause-icon" xmlns="http://www.w3.org/2000/svg" width="' + mk(d) + '" height="' + mk(d) + '" viewBox="0 0 48 48" fill="#fff"><path d="M12 38h8V10h-8v28zm16-28v28h8V10h-8z"/></svg>');
        pk(qk(e, f), "</div><style" + (a ? ' nonce="' + mk(vk(a)) + '"' : "") + ">.playback-container {align-items: center; display: flex; justify-content: center; height: 100%; position: absolute; width: 100%; z-index: " + ok(b) + ";}.play-pause-icon {height: " + ok(d) + "px; position: absolute; width: " + ok(d) + "px;}.hide-controls>.play-pause-icon {visibility: hidden;}.playback-container:not(.hide-controls) {background-color: rgba(0,0,0,.3);}.play-icon,.pause-icon {position: absolute;}.playback-container.clickable {height: 36px; width: 36px; left: 0; bottom: 0; pointer-events: auto;}.playback-container.clickable:not(.hide-controls) {background-color: rgba(0,0,0,.2);}\x3c/style></div>");
        return c
    };

    function vq(a) {
        a.i.classList.remove("hide-controls");
        a.A.style.visibility = "";
        a.u.style.visibility = "hidden"
    }
    var wq = class {
        constructor(a) {
            this.l = a;
            this.i = wk(uq, {
                zIndex: 4,
                ta: this.l
            });
            this.i.classList.add("hide-controls");
            this.A = ue("play-icon", this.i);
            this.u = ue("pause-icon", this.i)
        }
        ca() {
            this.i.style.visibility = "hidden"
        }
        hideControls() {
            this.l ? (this.i.classList.remove("hide-controls"), this.A.style.visibility = "hidden", this.u.style.visibility = "") : this.i.classList.add("hide-controls")
        }
        o() {
            return this.i
        }
    };

    function xq(a) {
        var b = a.o.o;
        b.addEventListener("pause", () => vq(a.A));
        b.addEventListener("play", () => a.A.hideControls());
        b.addEventListener("error", () => {
            a.A.ca();
            a.i && qq(a.i)
        });
        b.addEventListener("ended", () => {
            a.A.ca();
            a.i && qq(a.i)
        })
    }

    function yq(a) {
        vq(a.A);
        zq(a);
        a.D.addEventListener("click", () => {
            switch (a.o.l) {
                case 0:
                case 2:
                    a.o.play();
                    oq(a.i);
                    rq(a.i);
                    Lp.ctr = String(Date.now());
                    break;
                case 1:
                    a.o.pause(), qq(a.i), Lp.ctp = String(Date.now())
            }
            Mp({})
        })
    }

    function zq(a) {
        var b = new Se(a.o.o);
        b.wa("monitoring-failed", () => {
            Mp({
                lm: "unknown"
            })
        });
        b.wa("monitoring-started", () => {
            Mp({
                lm: "intersection-observer"
            })
        });
        if (a.l.ga) {
            let c = new hq(a.l.pa ? 1 : 0, a.l.Y || 3E4, a.l.L, a.l.ea);
            a.u = 0;
            a.i = new tq(a.o, b, a.B, c);
            a.i.listen("video_exceeds_byte_limit", () => {
                a.u = 1
            })
        } else a.i = new tq(a.o, b, a.B);
        a.u !== 1 && oq(a.i)
    }
    var Aq = class {
        constructor(a, b, c, d, e) {
            this.o = a;
            this.A = b;
            this.D = b.o();
            this.u = c.Oa;
            this.l = c;
            this.B = e;
            this.I = d;
            xq(this)
        }
        async start() {
            if (this.u == 1) return this.l.ta && this.I && this.I.addEventListener("click", () => {
                this.o.play();
                oq(this.i);
                rq(this.i);
                Lp.ctr = String(Date.now())
            }), yq(this), Promise.resolve();
            var a = {};
            await Ri() ? a.sap = "t" : (this.u = 1, a.sap = "f");
            a.cf = "playback_controller";
            Mp(a);
            yq(this)
        }
    };

    function Bq(a) {
        window.parent.postMessage(JSON.stringify({
            type: "rewarded",
            message: a
        }), "*")
    }
    var Cq = (a, b) => {
            window.addEventListener("message", c => {
                try {
                    let d = ma(c.data) ? c.data : JSON.parse(c.data);
                    if (d.type == "rewarded") switch (d.message) {
                        case "visible":
                            a(d);
                            break;
                        case "back_button":
                            b()
                    }
                } catch (d) {}
            }, !1)
        },
        Dq = (a, b, c, d, e) => {
            window.addEventListener("message", f => {
                try {
                    let g = ma(f.data) ? f.data : JSON.parse(f.data);
                    if (g.type == "rewarded") switch (g.message) {
                        case "closed":
                            a();
                            break;
                        case "granted":
                            b();
                            break;
                        case "reward_confirmation_shown":
                            c();
                            break;
                        case "reward_confirmation_resume_clicked":
                            d();
                            break;
                        case "query_prefetched":
                            e &&
                                e()
                    }
                } catch (g) {}
            }, !1)
        };

    function Eq(a) {
        if (a.o.R) {
            a.i = document.createElement("img");
            a.i.src = a.o.R;
            a.i.alt = "";
            a.i.style.width = "100%";
            a.i.style.height = "100%";
            a.i.style.display = "block";
            a.i.style.position = "absolute";
            a.i.style.objectFit = a.o.Yb;
            a.i.style.zIndex = 3;
            a.l.appendChild(a.i);
            let b = a.u.o;
            b.addEventListener("playing", () => {
                a.i.style.visibility = "hidden"
            });
            b.addEventListener("error", () => {
                a.i.style.visibility = "hidden"
            });
            b.addEventListener("timeupdate", () => {
                b.currentTime == 0 && (a.i.style.visibility = "visible")
            })
        }
    }

    function Fq(a) {
        var b = new Bk(5, a.o.ta);
        a.l.appendChild(b.o());
        return new aq(a.u, b)
    }

    function Gq(a) {
        var b = new wq(a.o.ta);
        a.l.appendChild(b.o());
        return new Aq(a.u, b, a.o, a.i, () => {
            a.J()
        })
    }

    function Hq(a, b, c) {
        c = c.getBoundingClientRect();
        b = b.getBoundingClientRect();
        a.l.style.left = `${c.left-b.left}px`;
        a.l.style.top = `${c.top-b.top}px`;
        a.l.style.width = `${c.width}px`;
        a.l.style.height = `${c.height}px`;
        a.l.style.position = "absolute"
    }
    var Iq = class {
        constructor(a) {
            this.l = wk(yk);
            this.L = ue("video-container", this.l);
            this.o = a;
            this.u = new Zp(this.L, this.o);
            this.X = this.i = null;
            this.N = this.o.o;
            T().Da()
        }
        J() {}
        D() {}
        start() {
            Eq(this);
            this.o.fa || (this.X = Fq(this), Ak(this.X.i, !this.o.A));
            Gq(this).start();
            if (this.o.o) {
                let a = () => {};
                this.o.P && (a = () => {
                    Yp(this.u)
                });
                Dq(a, () => {
                    Xp(this.u, "reward_granted")
                }, () => {
                    this.u.pause()
                }, () => {
                    this.D();
                    this.u.play()
                }, () => {
                    this.N && Bq("prefetched")
                })
            }
            this.N && (Cq(a => {
                a = a && a.ssvOptions;
                var b = this.u,
                    c = a && typeof a.customData ===
                    "string" ? a.customData : "";
                b.N = a && typeof a.userId === "string" ? a.userId : "";
                b.D = c
            }, () => {}), Bq("prefetched"))
        }
    };

    function Jq(a) {
        a = a.i.o;
        a.muted = !1;
        a.volume = 1
    }
    var Kq = class {
        constructor(a, b) {
            this.i = a;
            this.o = b;
            b.container.querySelector("#cancel-video-button").addEventListener("click", () => {
                Yp(this.i);
                this.i.pause(!1);
                this.o.ca();
                Bq("canceled");
                Bq("closed");
                T().F("sop_ca", "1")
            });
            b.container.querySelector("#continue-video-button").addEventListener("click", () => {
                this.o.ca();
                Jq(this);
                this.i.play(!1);
                T().F("sop_co", "1")
            });
            T().Da()
        }
        show() {
            this.i.pause(!1);
            this.o.show();
            T().F("sop_s", "1")
        }
    };

    function Lq(a, b) {
        var c = b != null ? b : {};
        b = a.message;
        var d = a.Wb,
            e = a.Xb,
            f = a.zIndex;
        c = c && c.tb;
        return dk('<div id="dialog-wrapper"><div id="sound-on-confirmation-dialog"><div id="confirmation-title">' + ck(a.title) + '</div><div id="confirmation-message">' + ck(b) + '</div><div id="confirmation-buttons"><div role="button" tabindex="0" id="cancel-video-button">' + ck(d) + '</div><div role="button" tabindex="0" id="continue-video-button">' + ck(e) + "</div></div></div><style" + (c ? ' nonce="' + mk(vk(c)) + '"' : "") + ">#dialog-wrapper {background: rgba(0, 0, 0, .4); font-family: Roboto, Arial, sans-serif; font-size: 20px; height: 100%; left: 0; opacity: 0; pointer-events: none; position: absolute; top: 0; transition: opacity .15s ease-out; width: 100%; z-index: " +
            ok(f) + ";}#dialog-wrapper.visible {opacity: 1; pointer-events: auto;}#sound-on-confirmation-dialog {background: #fff; left: 8%; padding: 5%; position: absolute; right: 8%; top: 50%; transform: translateY(-50%) scale(.85); transition: transform .15s ease-out;}.visible > #sound-on-confirmation-dialog {transform: translateY(-50%);}#confirmation-title {color: #3e82f7; line-height: 1.3em; margin-bottom: 5%; margin-top: 2%;}#confirmation-message {color: rgba(0, 0, 0, .54); font-size: .8em; line-height: 1.3em; margin-bottom: 8%;}#confirmation-buttons {text-align: right;}#cancel-video-button, #continue-video-button {color: #fff; display: inline-block; font-size: .65em; line-height: 2.5em; font-weight: 500; margin-top: 2%; padding-left: 1em; padding-right: 1em; text-align: center;}#cancel-video-button {color: #3e82f7;}#continue-video-button {background: #3e82f7; border-radius: 2px; box-shadow: 0 2px 2px 0 rgba(0, 0, 0, .24);}\x3c/style></div>")
    };
    var Mq = class {
        constructor(a, b, c, d) {
            this.container = wk(Lq, {
                title: a,
                message: b,
                Wb: c,
                Xb: d,
                zIndex: 6
            });
            this.ca()
        }
        o() {
            return this.container
        }
        ca() {
            this.container.classList.remove("visible")
        }
        show() {
            this.container.classList.add("visible")
        }
    };

    function Nq(a) {
        var b = a.u,
            c = b.o;
        a.B && (yh().then(d => {
            var e;
            (e = d.waitForVideoCompletion) == null || e.call(d)
        }), c.addEventListener("waiting", () => {
            yh().then(d => {
                d.pauseTimer()
            })
        }), c.addEventListener("timeupdate", () => {
            b.getCurrentTime() > 30 && yh().then(d => {
                var e;
                (e = d.onVideoCompleted) == null || e.call(d)
            })
        }));
        c.addEventListener("error", () => {
            a.B && yh().then(d => {
                var e;
                (e = d.onVideoCompleted) == null || e.call(d)
            });
            Oq(a)
        });
        c.addEventListener("ended", () => {
            a.B && yh().then(d => {
                var e;
                (e = d.onVideoCompleted) == null || e.call(d)
            });
            Oq(a)
        });
        c.addEventListener("playing", () => {
            a.B && yh().then(d => {
                d.resumeTimer()
            });
            a.context.body.classList.add("video-playing")
        })
    }

    function Oq(a) {
        var b = a.l;
        a.context.body.classList.remove("video-playing");
        a.context.body.classList.add("end-card-shown");
        b.style.display = "none";
        if ((b = document.querySelector('a[data-asoch-targets$="ochImage"]')) && (a.G ? !b.hasAttribute("href") : b.hasAttribute("href"))) {
            let e = document.querySelector('a[data-asoch-targets$="ochButton"]');
            var c, d = (c = e.getAttribute("href")) != null ? c : a.K;
            a: if (d instanceof ge) a = d;
                else {
                    for (a = 0; a < ke.length; ++a)
                        if (c = ke[a], c instanceof ie && c.dc(d)) {
                            a = he(d);
                            break a
                        }
                    a = void 0
                }
            if (!a) throw Error("URL not recognized as safe: " +
                d);
            d = a;
            if (d instanceof ge)
                if (d instanceof ge) d = d.i;
                else throw Error("");
            else d = le.test(d) ? d : void 0;
            d !== void 0 && (b.href = d);
            e.getAttribute("target") && b.setAttribute("target", e.getAttribute("target"))
        }
    }
    class Pq extends Iq {
        constructor(a, b, c, d, e, f, g) {
            if (Wj()(b)) {
                var h = Pi(b);
                h = Qi(h)
            } else h = Qi(b);
            super(h);
            this.body = c;
            Wj()(b) ? (c = Yc(b, Df, 1)[0], this.A = C(c, Af, 10), d = [2, 4], e = d.includes, f = C(b, Ef, 2), f = G(f, 32, 3), d = e.call(d, f), b = C(b, kf, 3), this.G = d && jd(b, 10).get("jbaquero_raspberry_fix_end_card_href") === "true", this.B = d && jd(b, 10).get("jbaquero_raspberry_sync_video_countdown") === "true", this.K = wf(Cf(c))) : (this.A = e || new Af, this.G = f != null ? f : !1, this.B = g != null ? g : !1, this.K = d != null ? d : "");
            this.context = a;
            Nq(this)
        }
        J() {
            if (this.u.i.A) {
                let a =
                    this.u,
                    b = new Mq(H(this.A, 18), H(this.A, 19), H(this.A, 21), H(this.A, 20));
                this.I = new Kq(a, b);
                this.body.appendChild(b.o());
                this.I.show()
            }
        }
        D() {
            if (this.I) {
                var a = this.I;
                a.o.ca();
                Jq(a);
                T().F("sop_di", "1")
            }
        }
    }

    function Qq(a) {
        if (a.runtime.videoConfig) {
            var b = Ki(a.runtime.videoConfig);
            let c = a.runtime.rewardedFields ? Bf(a.runtime.rewardedFields) : new Af;
            return new Pq(a.context, b, a.body, a.runtime.redirectUrl, c, a.runtime.fixEndCardHref === "true", a.runtime.syncVideoCountdown === "true")
        }
        b = Hf(a.runtime.renderingInput);
        return new Pq(a.context, b, a.body)
    }
    var Rq = class extends Si {
        constructor() {
            super(...arguments);
            this.i = null
        }
        getConfig(a) {
            var b = super.getConfig(a),
                c = C(a, kf, 3);
            if (jd(c, 10).get("auwvsc") === "true") {
                var d, e;
                let f = (e = (d = Yc(a, Df, 1)[0]) == null ? void 0 : C(d, Af, 10)) != null ? e : new Af;
                this.runtime.rewardedFields = JSON.stringify(rc(f));
                d = [2, 4];
                e = d.includes;
                a = C(a, Ef, 2);
                a = G(a, 32, 3);
                (a = e.call(d, a)) && jd(c, 10).get("jbaquero_raspberry_fix_end_card_href") === "true" && (this.runtime.fixEndCardHref = "true");
                a && jd(c, 10).get("jbaquero_raspberry_sync_video_countdown") ===
                    "true" && (this.runtime.syncVideoCountdown = "true")
            }
            return b
        }
        o() {
            Lp.tid = "3484";
            Lp.dn = "web_interstitial_raspberry";
            this.runtime.earlyVideoInit !== "true" || this.i || (this.i = Qq(this), this.body.appendChild(this.i.l))
        }
        onReady() {
            super.onReady();
            var a = this.context.body,
                b = this.runtime.earlyVideoInit === "true";
            if (this.runtime.isPiroExp === "true" && (a.classList.add("piro-exp"), !b)) {
                var c;
                a = (c = this.runtime.piroLogoUrl) != null ? c : "";
                Zh(a)
            }
            a: {
                a = this.runtime.earlyVideoInit === "true";this.i || (this.i = Qq(this), this.body.appendChild(this.i.l));
                c = document.querySelector(".product-video");
                if (a) {
                    c && Hq(this.i, this.body, c);
                    this.i.start();
                    if (this.runtime.isPiroExp === "true") {
                        var d;
                        a = (d = this.runtime.piroLogoUrl) != null ? d : "";
                        Zh(a)
                    }
                    if (!c) break a
                } else {
                    this.i.start();
                    if (!c) break a;
                    Hq(this.i, this.body, c)
                }(d = document.querySelector(".blurred-video-background")) && this.runtime.enable_blurred_background === "true" && (d.style.backgroundImage = this.runtime.end_frame_url, d.style.display = "block");document.querySelector(".video-container") && (d.style.backgroundColor =
                    "#00000080")
            }
        }
    };
    (function(a, b) {
        Jh = new Mh;
        var c, d, e, f, g = (f = (e = (d = (c = window).mys) != null ? d : c.mys = {}).designs) != null ? f : e.designs = new Map;
        class h extends Nh {
            constructor(k, m) {
                super(b, k, m)
            }
        }
        g.set(a, h)
    })("video_mra/web_interstitial_raspberry_ms", class extends Rq {});
}).call(this);
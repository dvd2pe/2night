(function() {
    /*

     Copyright The Closure Library Authors.
     SPDX-License-Identifier: Apache-2.0
    */
    var n = this || self;

    function aa(a, b) {
        a: {
            var c = ["CLOSURE_FLAGS"];
            for (var d = n, e = 0; e < c.length; e++)
                if (d = d[c[e]], d == null) {
                    c = null;
                    break a
                }
            c = d
        }
        a = c && c[a];
        return a != null ? a : b
    }

    function ba(a) {
        var b = typeof a;
        return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
    }

    function ca(a) {
        var b = ba(a);
        return b == "array" || b == "object" && typeof a.length == "number"
    }

    function da(a) {
        var b = typeof a;
        return b == "object" && a != null || b == "function"
    };

    function ea(a, ...b) {
        b = b.filter(Boolean).join("&");
        if (!b) return a;
        var c = a.match(/[?&]adurl=/);
        return c ? a.slice(0, c.index + 1) + b + "&" + a.slice(c.index + 1) : a + (a.indexOf("?") < 0 ? "?" : "&") + b
    }

    function fa(a, b) {
        return a === 0 ? "ri=1" : a === 1 ? b ? "ri=24" : "ri=27" : a === 2 ? b ? "ri=25" : "ri=26" : ""
    }

    function ha(a, b) {
        return b ? "&" + a + "=" + encodeURIComponent(b) : ""
    }

    function ia(a) {
        a = a.m;
        if (!a) return "";
        var b = ha("uap", a.platform) + ha("uapv", a.platformVersion) + ha("uafv", a.uaFullVersion) + ha("uaa", a.architecture) + ha("uam", a.model) + ha("uab", a.bitness);
        a.fullVersionList && (b += "&uafvl=" + encodeURIComponent(a.fullVersionList.map(c => encodeURIComponent(c.brand) + ";" + encodeURIComponent(c.version)).join("|")));
        a.wow64 != null && (b += "&uaw=" + Number(a.wow64));
        return b.slice(1)
    }

    function ka(a, b) {
        if (a.h.dsh === "1") return null;
        var c = a.h.ae;
        if (c === "1") {
            let d = a.h.adurl;
            if (d) try {
                return {
                    version: 3,
                    B: decodeURIComponent(d),
                    A: ea(a.i, "act=1", fa(b, !0), ia(a))
                }
            } catch (e) {}
        }
        return c === "2" ? {
            version: 4,
            B: ea(a.i, "dct=1", "suid=" + a.j, fa(b, !1)),
            A: ea(a.i, "act=1", fa(b, !0), "suid=" + a.j)
        } : null
    }

    function la(a, b) {
        return b === 2 ? ea(a.i, "ri=2") : b === 0 ? ea(a.i, "ri=16") : a.i
    }
    var ma = class {
        constructor({
            url: a,
            ra: b
        }) {
            this.i = a;
            this.m = b;
            this.j = (new Date).getTime() - 17040672E5;
            this.h = {};
            for (var c = /[?&]([^&=]+)=([^&]*)/g; b = c.exec(a);) this.h[b[1]] = b[2]
        }
    };
    /*

     Copyright Google LLC
     SPDX-License-Identifier: Apache-2.0
    */
    var na = class {
            constructor(a) {
                this.h = a
            }
            toString() {
                return this.h
            }
        },
        oa = new na("about:invalid#zClosurez");
    class qa {
        constructor(a) {
            this.qa = a
        }
    }

    function t(a) {
        return new qa(b => b.substr(0, a.length + 1).toLowerCase() === a + ":")
    }
    var ra = new qa(a => /^[^:]*([/?#]|$)/.test(a)),
        sa = t("http"),
        ta = t("https"),
        ua = t("ftp"),
        va = t("mailto"),
        wa = t("intent"),
        xa = t("market"),
        ya = t("itms"),
        za = t("itms-appss"),
        Aa = [t("data"), sa, ta, va, ua, ra];

    function Ba(a, b = Aa) {
        if (a instanceof na) return a;
        for (let c = 0; c < b.length; ++c) {
            let d = b[c];
            if (d instanceof qa && d.qa(a)) return new na(a)
        }
    }

    function Ca(a, b = Aa) {
        return Ba(a, b) || oa
    }
    var Da = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;

    function Ea(a, b) {
        if (b instanceof na)
            if (b instanceof na) b = b.h;
            else throw Error("");
        else b = Da.test(b) ? b : void 0;
        b !== void 0 && (a.href = b)
    };

    function Fa(a, b = `unexpected value ${a}!`) {
        throw Error(b);
    };

    function Ga(a, b) {
        Array.prototype.forEach.call(a, b, void 0)
    }

    function Ha(a, b) {
        a: {
            let c = a.length,
                d = typeof a === "string" ? a.split("") : a;
            for (let e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) {
                    b = e;
                    break a
                }
            b = -1
        }
        return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b]
    }

    function Ia(a) {
        var b = a.length;
        if (b > 0) {
            let c = Array(b);
            for (let d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };

    function Ja(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };

    function Ka(a) {
        fetch(a, {
            keepalive: !0,
            mode: "no-cors",
            credentials: "include"
        })
    };

    function La(a) {
        n.setTimeout(() => {
            throw a;
        }, 0)
    };
    var Ma = aa(899588437, !1),
        Na = aa(748402147, !0);

    function Oa(a) {
        var b;
        a: {
            if (b = n.navigator)
                if (b = b.userAgent) break a;b = ""
        }
        return b.indexOf(a) != -1
    };

    function Pa() {
        return Oa("iPhone") && !Oa("iPod") && !Oa("iPad")
    };

    function Qa(a) {
        Qa[" "](a);
        return a
    }
    Qa[" "] = function() {};
    var Ra = Pa(),
        Sa = Oa("iPad");
    var Ta = Pa() || Oa("iPod"),
        Ua = Oa("iPad");
    var Va = {},
        Wa = null;
    var Xa = void 0;

    function Ya(a) {
        a = Error(a);
        Ja(a, "warning");
        return a
    };

    function Za() {
        return typeof BigInt === "function"
    };

    function $a(a, b = !1) {
        return b && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol()
    }
    var ab = $a(),
        cb = $a(),
        db = $a("m_m", !0);
    var u = $a("jas", !0),
        eb, fb = [];
    fb[u] = 7;
    eb = Object.freeze(fb);

    function gb(a) {
        a[u] |= 34;
        return a
    }

    function ib(a) {
        a[u] |= 8192;
        return a
    }

    function jb(a) {
        a[u] |= 32;
        return a
    }

    function kb(a, b) {
        2 & b && (a |= 2);
        return a | 1
    };
    var lb = {};

    function v(a, b) {
        return b === void 0 ? a.h !== nb && !!(2 & (a.l[u] | 0)) : !!(2 & b) && a.h !== nb
    }
    var nb = {};
    class ob {
        constructor(a, b, c) {
            this.h = a;
            this.i = b;
            this.j = c
        }
        next() {
            var a = this.h.next();
            a.done || (a.value = this.i.call(this.j, a.value));
            return a
        }[Symbol.iterator]() {
            return this
        }
    }
    Object.freeze({});

    function pb(a) {
        a.Ha = !0;
        return a
    };
    var qb = pb(a => typeof a === "number"),
        rb = pb(a => typeof a === "string"),
        sb = pb(a => typeof a === "boolean"),
        tb = pb(a => typeof a === "function");
    var ub = typeof n.BigInt === "function" && typeof n.BigInt(0) === "bigint";

    function vb(a) {
        var b = a;
        if (rb(b)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error(String(b));
        } else if (qb(b) && !Number.isSafeInteger(b)) throw Error(String(b));
        return ub ? BigInt(a) : a = sb(a) ? a ? "1" : "0" : rb(a) ? a.trim() || "0" : String(a)
    }
    var Bb = pb(a => ub ? a >= wb && a <= xb : a[0] === "-" ? yb(a, zb) : yb(a, Ab)),
        zb = Number.MIN_SAFE_INTEGER.toString(),
        wb = ub ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
        Ab = Number.MAX_SAFE_INTEGER.toString(),
        xb = ub ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;

    function yb(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (let c = 0; c < a.length; c++) {
            let d = a[c],
                e = b[c];
            if (d > e) return !1;
            if (d < e) return !0
        }
    };
    var x = 0,
        y = 0;

    function Cb(a) {
        var b = a >>> 0;
        x = b;
        y = (a - b) / 4294967296 >>> 0
    }

    function Db(a) {
        if (a < 0) {
            Cb(-a);
            let [b, c] = Eb(x, y);
            x = b >>> 0;
            y = c >>> 0
        } else Cb(a)
    }

    function Fb(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (b <= 2097151) var c = "" + (4294967296 * b + a);
        else Za() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + c * 6777216 + b * 6710656, c += b * 8147497, b *= 2, a >= 1E7 && (c += a / 1E7 >>> 0, a %= 1E7), c >= 1E7 && (b += c / 1E7 >>> 0, c %= 1E7), c = b + Gb(c) + Gb(a));
        return c
    }

    function Gb(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    }

    function Hb() {
        var a = x,
            b = y;
        if (b & 2147483648)
            if (Za()) a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0));
            else {
                let [c, d] = Eb(a, b);
                a = "-" + Fb(c, d)
            }
        else a = Fb(a, b);
        return a
    }

    function Eb(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };
    var Ib = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        Jb = Number.isSafeInteger,
        A = Number.isFinite,
        Kb = Math.trunc,
        Lb = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Mb(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return A(a);
            case "string":
                return Lb.test(a);
            default:
                return !1
        }
    }

    function Nb(a) {
        if (!A(a)) throw Ya("enum");
        return a | 0
    }

    function Ob(a) {
        return a == null ? a : A(a) ? a | 0 : void 0
    }

    function Pb(a) {
        if (typeof a !== "number") throw Ya("int32");
        if (!A(a)) throw Ya("int32");
        return a | 0
    }

    function Qb(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return A(a) ? a | 0 : void 0
    }

    function Rb(a) {
        if (typeof a !== "number") throw Ya("uint32");
        if (!A(a)) throw Ya("uint32");
        return a >>> 0
    }

    function Sb(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return A(a) ? a >>> 0 : void 0
    }

    function Tb(a) {
        var b = void 0;
        b != null || (b = 1024);
        if (!Mb(a)) throw Ya("int64");
        var c = typeof a;
        switch (b) {
            case 512:
                switch (c) {
                    case "string":
                        return Ub(a);
                    case "bigint":
                        return String(Ib(64, a));
                    default:
                        return Vb(a)
                }
            case 1024:
                switch (c) {
                    case "string":
                        return b = Kb(Number(a)), Jb(b) ? a = vb(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), a = Za() ? vb(Ib(64, BigInt(a))) : vb(Wb(a))), a;
                    case "bigint":
                        return vb(Ib(64, a));
                    default:
                        return vb(Jb(a) ? a : Vb(a))
                }
            case 0:
                switch (c) {
                    case "string":
                        return Ub(a);
                    case "bigint":
                        return vb(Ib(64,
                            a));
                    default:
                        a = Kb(a);
                        if (!Jb(a)) {
                            Db(a);
                            b = x;
                            c = y;
                            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
                            let d = c * 4294967296 + (b >>> 0);
                            b = Number.isSafeInteger(d) ? d : Fb(b, c);
                            a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
                        }
                        return a
                }
            default:
                return Fa(b, "Unknown format requested type for int64")
        }
    }

    function Wb(a) {
        var b = a.length;
        if (a[0] === "-" ? b < 20 || b === 20 && a <= "-9223372036854775808" : b < 19 || b === 19 && a <= "9223372036854775807") return a;
        if (a.length < 16) Db(Number(a));
        else if (Za()) a = BigInt(a), x = Number(a & BigInt(4294967295)) >>> 0, y = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            b = +(a[0] === "-");
            y = x = 0;
            let c = a.length;
            for (let d = b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) {
                let f = Number(a.slice(d, e));
                y *= 1E6;
                x = x * 1E6 + f;
                x >= 4294967296 && (y += Math.trunc(x / 4294967296), y >>>= 0, x >>>= 0)
            }
            if (b) {
                let [d, e] = Eb(x, y);
                x = d;
                y = e
            }
        }
        return Hb()
    }

    function Vb(a) {
        a = Kb(a);
        Jb(a) ? a = String(a) : (Db(a), a = Hb());
        return a
    }

    function Ub(a) {
        var b = Kb(Number(a));
        if (Jb(b)) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return Wb(a)
    }

    function B(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function Xb(a, b, c, d) {
        if (a != null && a[db] === lb) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? ((a = b[ab]) || (a = new b, gb(a.l), a = b[ab] = a), b = a) : b = new b : b = void 0, b;
        c = a[u] | 0;
        d = c | d & 32 | d & 2;
        d !== c && (a[u] = d);
        return new b(a)
    }

    function Yb(a, b, c) {
        a = b ? Pb(a) : Qb(a);
        return a == null ? c ? 0 : void 0 : a | 0
    }

    function C(a, b, c) {
        if (b) {
            if (typeof a !== "string") throw Error();
            return a
        }
        var d;
        return (d = B(a)) != null ? d : c ? "" : void 0
    };

    function Zb(a) {
        return a
    };
    var $b = {},
        ac = (() => class extends Map {
            constructor() {
                super()
            }
        })();

    function bc(a) {
        return a
    }

    function cc(a) {
        if (a.u & 2) throw Error("Cannot mutate an immutable Map");
    }
    var E = class extends ac {
        constructor(a, b, c = bc, d = bc) {
            super();
            this.u = a[u] | 0;
            this.o = b;
            this.D = c;
            this.ga = this.o ? dc : d;
            for (let e = 0; e < a.length; e++) {
                let f = a[e],
                    g = c(f[0], !1, !0),
                    k = f[1];
                b ? k === void 0 && (k = null) : k = d(f[1], !1, !0, void 0, void 0, this.u);
                super.set(g, k)
            }
        }
        M(a) {
            return ib(Array.from(super.entries(), a))
        }
        clear() {
            cc(this);
            super.clear()
        }
        delete(a) {
            cc(this);
            return super.delete(this.D(a, !0, !1))
        }
        entries() {
            if (this.o) {
                var a = super.keys();
                a = new ob(a, ec, this)
            } else a = super.entries();
            return a
        }
        values() {
            if (this.o) {
                var a = super.keys();
                a = new ob(a, E.prototype.get, this)
            } else a = super.values();
            return a
        }
        forEach(a, b) {
            this.o ? super.forEach((c, d, e) => {
                a.call(b, e.get(d), d, e)
            }) : super.forEach(a, b)
        }
        set(a, b) {
            cc(this);
            a = this.D(a, !0, !1);
            return a == null ? this : b == null ? (super.delete(a), this) : super.set(a, this.ga(b, !0, !0, this.o, !1, this.u))
        }
        has(a) {
            return super.has(this.D(a, !1, !1))
        }
        get(a) {
            a = this.D(a, !1, !1);
            var b = super.get(a);
            if (b !== void 0) {
                var c = this.o;
                return c ? (c = this.ga(b, !1, !0, c, this.pa, this.u), c !== b && super.set(a, c), c) : b
            }
        }[Symbol.iterator]() {
            return this.entries()
        }
    };
    E.prototype.toJSON = void 0;

    function dc(a, b, c, d, e, f) {
        a = Xb(a, d, c, f);
        e && (a = fc(a));
        return a
    }

    function ec(a) {
        return [a, this.get(a)]
    }
    var hc;

    function ic() {
        return hc || (hc = new E(gb([]), void 0, void 0, void 0, $b))
    };

    function jc(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        var f = [],
            g = a.length,
            k = 4294967295,
            h = !1,
            l = !!(b & 64),
            m = l ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1)) {
            var p = g && a[g - 1];
            p != null && typeof p === "object" && p.constructor === Object ? (g--, k = g) : p = void 0;
            if (l && !(b & 128) && !e) {
                h = !0;
                var q;
                k = ((q = kc) != null ? q : Zb)(k - m, m, a, p, void 0) + m
            }
        }
        b = void 0;
        for (e = 0; e < g; e++)
            if (q = a[e], q != null && (q = c(q, d)) != null)
                if (l && e >= k) {
                    let r = e - m,
                        w;
                    ((w = b) != null ? w : b = {})[r] = q
                } else f[e] = q;
        if (p)
            for (let r in p) {
                a = p[r];
                if (a == null || (a = c(a, d)) == null) continue;
                g = +r;
                let w;
                if (l && !Number.isNaN(g) &&
                    (w = g + m) < k) f[w] = a;
                else {
                    let z;
                    ((z = b) != null ? z : b = {})[r] = a
                }
            }
        b && (h ? f.push(b) : f[k] = b);
        return f
    }

    function lc(a) {
        a[0] = mc(a[0]);
        a[1] = mc(a[1]);
        return a
    }

    function mc(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return Bb(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    let b = a[u] | 0;
                    return a.length === 0 && b & 1 ? void 0 : jc(a, b, mc)
                }
                if (a != null && a[db] === lb) return nc(a);
                if (a instanceof E) return a = a.size !== 0 ? a.M(lc) : void 0, a;
                return
        }
        return a
    }
    var kc;

    function nc(a) {
        a = a.l;
        return jc(a, a[u] | 0, mc)
    };

    function oc(a, b, c, d = 0) {
        if (a == null) {
            var e = 32;
            c ? (a = [c], e |= 128) : a = [];
            b && (e = e & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[u] | 0;
            if (Na && 1 & e) throw Error("rfarr");
            2048 & e && !(2 & e) && pc();
            if (e & 256) throw Error("farr");
            if (e & 64) return (e | d) !== e && (a[u] = e | d), a;
            if (c && (e |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;e |= 64;
                var f = c.length;
                if (f) {
                    var g = f - 1;
                    let h = c[g];
                    if (h != null && typeof h === "object" && h.constructor === Object) {
                        b = e & 128 ? 0 : -1;
                        g -= b;
                        if (g >= 1024) throw Error("pvtlmt");
                        for (var k in h)
                            if (f = +k,
                                f < g) c[f + b] = h[k], delete h[k];
                            else break;
                        e = e & -16760833 | (g & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    k = Math.max(b, f - (e & 128 ? 0 : -1));
                    if (k > 1024) throw Error("spvt");
                    e = e & -16760833 | (k & 1023) << 14
                }
            }
        }
        a[u] = e | 64 | d;
        return a
    }

    function pc() {
        if (Na) throw Error("carr");
        if (cb != null) {
            var a;
            var b = (a = Xa) != null ? a : Xa = {};
            a = b[cb] || 0;
            a >= 5 || (b[cb] = a + 1, b = Error(), Ja(b, "incident"), La(b))
        }
    };

    function qc(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[u] | 0;
            return a.length === 0 && c & 1 ? void 0 : rc(a, c, b)
        }
        if (a != null && a[db] === lb) return sc(a);
        if (a instanceof E) {
            c = a.u;
            if (c & 2) return a;
            if (a.size) {
                b = gb(a.M());
                if (a.o)
                    for (a = 0; a < b.length; a++) {
                        let d = b[a],
                            e = d[1];
                        e == null || typeof e !== "object" ? e = void 0 : e != null && e[db] === lb ? e = sc(e) : Array.isArray(e) ? e = rc(e, e[u] | 0, !!(c & 32)) : e = void 0;
                        d[1] = e
                    }
                return b
            }
        }
    }

    function rc(a, b, c) {
        if (b & 2) return a;
        !c || 4096 & b || 16 & b ? a = tc(a, b, !1, c && !(b & 16)) : (a[u] |= 34, b & 4 && Object.freeze(a));
        return a
    }

    function uc(a, b, c) {
        a = new a.constructor(b);
        c && (a.h = nb);
        a.i = nb;
        return a
    }

    function sc(a) {
        var b = a.l,
            c = b[u] | 0;
        return v(a, c) ? a : vc(a, b, c) ? uc(a, b) : tc(b, c)
    }

    function wc(a) {
        var b = a.l,
            c = b[u] | 0;
        return vc(a, b, c) ? uc(a, b, !0) : new a.constructor(tc(b, c, !1))
    }

    function tc(a, b, c, d) {
        d != null || (d = !!(34 & b));
        a = jc(a, b, qc, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        a[u] = b;
        return a
    }

    function fc(a) {
        var b = a.l,
            c = b[u] | 0;
        return v(a, c) ? vc(a, b, c) ? uc(a, b, !0) : new a.constructor(tc(b, c, !1)) : a
    }

    function xc(a) {
        if (a.h !== nb) return !1;
        var b = a.l;
        b = tc(b, b[u] | 0);
        b[u] |= 2048;
        a.l = b;
        a.h = void 0;
        a.i = void 0;
        return !0
    }

    function yc(a) {
        if (!xc(a) && v(a, a.l[u] | 0)) throw Error();
    }

    function zc(a, b) {
        b === void 0 && (b = a[u] | 0);
        b & 32 && !(b & 4096) && (a[u] = b | 4096)
    }

    function vc(a, b, c) {
        return c & 2 ? !0 : c & 32 && !(c & 4096) ? (b[u] = c | 2, a.h = nb, !0) : !1
    };

    function F(a, b) {
        a = Ac(a.l, b);
        if (a !== null) return a
    }

    function Bc(a, b, c) {
        return Ac(a, b, void 0, c)
    }

    function Ac(a, b, c, d) {
        if (b === -1) return null;
        var e = b + (c ? 0 : -1),
            f = a.length - 1;
        if (!(f < 1 + (c ? 0 : -1))) {
            if (e >= f) {
                var g = a[f];
                if (g != null && typeof g === "object" && g.constructor === Object) {
                    c = g[b];
                    var k = !0
                } else if (e === f) c = g;
                else return
            } else c = a[e];
            if (d && c != null) {
                d = d(c);
                if (d == null) return d;
                if (!Object.is(d, c)) return k ? g[b] = d : a[e] = d, d
            }
            return c
        }
    }

    function G(a, b, c) {
        yc(a);
        var d = a.l;
        H(d, d[u] | 0, b, c);
        return a
    }

    function H(a, b, c, d) {
        var e = c + -1,
            f = a.length - 1;
        if (f >= 0 && e >= f) {
            let g = a[f];
            if (g != null && typeof g === "object" && g.constructor === Object) return g[c] = d, b
        }
        if (e <= f) return a[e] = d, b;
        if (d !== void 0) {
            let g;
            f = ((g = b) != null ? g : b = a[u] | 0) >> 14 & 1023 || 536870912;
            c >= f ? d != null && (a[f + -1] = {
                [c]: d
            }) : a[e] = d
        }
        return b
    }

    function J(a, b) {
        a = Ac(a.l, b);
        return a != null && a[db] === lb || Array.isArray(a)
    }

    function Cc(a, b, c, d, e) {
        var f = a.l,
            g = f[u] | 0;
        d = d && d !== 4 ? d !== 1 && (a ? v(a, g) : 2 & g) ? 1 : d : 4;
        e = !!e || d === 3;
        d === 2 && xc(a) && (f = a.l, g = f[u] | 0);
        a = Dc(f, b);
        var k = a === eb ? 7 : a[u] | 0,
            h = kb(k, g);
        var l = !(4 & h);
        if (l) {
            let m = 0,
                p = 0;
            for (; m < a.length; m++) {
                let q = c(a[m]);
                q != null && (a[p++] = q)
            }
            p < m && (a.length = p);
            c = (h | 4) & -513;
            h = c &= -1025;
            h &= -4097
        }
        h !== k && (a[u] = h, 2 & h && Object.freeze(a));
        return a = Ec(a, h, f, g, b, d, l, e)
    }

    function Ec(a, b, c, d, e, f, g, k) {
        var h = b,
            l = Fc(b);
        l && f === 2 && (a = [...a], h = 0, b = Gc(b, d), d = H(c, d, e, a), l = !1);
        l || (f === 1 || (f !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? (b |= !a.length || g && !(4096 & b) || 32 & d && !(4096 & b || 16 & b) ? 2 : 256, b !== h && (a[u] = b), Object.freeze(a)) : (k || (b |= 16), b !== h && (a[u] = b)));
        2 & b || !(4096 & b || 16 & b) || zc(c, d);
        return a
    }

    function Dc(a, b) {
        a = Ac(a, b);
        return Array.isArray(a) ? a : eb
    }

    function Fc(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function K(a, b, c, d, e) {
        var f = a.l,
            g = f[u] | 0;
        var k = v(a, g);
        a: {!k && xc(a) && (f = a.l, g = f[u] | 0);
            var h = Ac(f, b);a = !1;
            if (h == null) {
                if (k) {
                    b = ic();
                    break a
                }
                h = []
            } else if (h.constructor === E)
                if (h.u & 2 && !k) h = h.M();
                else {
                    b = h;
                    break a
                }
            else Array.isArray(h) ? a = !!((h[u] | 0) & 2) : h = [];
            if (k) {
                if (!h.length) {
                    b = ic();
                    break a
                }
                a || (a = !0, gb(h))
            } else if (a) {
                a = !1;
                ib(h);
                h = [...h];
                for (let l = 0; l < h.length; l++) {
                    let m = h[l] = [...h[l]];
                    Array.isArray(m[1]) && (m[1] = gb(m[1]))
                }
                h = ib(h)
            }!a && g & 32 && jb(h);d = new E(h, c, d, e);g = H(f, g, b, d);a || zc(f, g);b = d
        }!k && c && (b.pa = !0);
        return b
    }

    function Hc(a, b, c, d) {
        var e = !1;
        d = Bc(a, d, f => {
            var g = Xb(f, c, !1, b);
            e = g !== f && g != null;
            return g
        });
        if (d != null) return e && !v(d) && zc(a, b), d
    }

    function L(a, b, c) {
        var d = a.l,
            e = d[u] | 0;
        b = Hc(d, e, b, c);
        if (b == null) return b;
        e = d[u] | 0;
        if (!v(a, e)) {
            let f = fc(b);
            f !== b && (xc(a) && (d = a.l, e = d[u] | 0), b = f, e = H(d, e, c, b), zc(d, e))
        }
        return b
    }

    function Gc(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function O(a, b) {
        a = F(a, b);
        a = a == null || typeof a === "boolean" ? a : typeof a === "number" ? !!a : void 0;
        return a != null ? a : !1
    }

    function Ic(a, b) {
        var c;
        return (c = Qb(F(a, b))) != null ? c : 0
    }

    function Jc(a, b) {
        var c;
        return (c = Sb(F(a, b))) != null ? c : 0
    }

    function P(a, b) {
        var c;
        return (c = B(F(a, b))) != null ? c : ""
    }

    function Q(a, b, c = 0) {
        var d;
        return (d = Ob(F(a, b))) != null ? d : c
    }

    function R(a, b, c) {
        if (c != null && typeof c !== "boolean") throw Error(`Expected boolean but got ${ba(c)}: ${c}`);
        return G(a, b, c)
    }

    function T(a, b, c) {
        G(a, b, c == null ? c : Pb(c))
    }

    function U(a, b, c) {
        if (c != null && typeof c !== "string") throw Error();
        return G(a, b, c)
    }

    function Kc(a, b, c) {
        G(a, b, c == null ? c : Nb(c))
    };

    function Lc(a) {
        return JSON.stringify(nc(a))
    }
    var V = class {
        constructor(a) {
            this.l = oc(a, void 0, void 0, 2048)
        }
        toJSON() {
            return nc(this)
        }
    };
    V.prototype[db] = lb;
    V.prototype.toString = function() {
        return this.l.toString()
    };
    var Mc = class extends V {};
    var Nc = class extends V {};
    var Oc = class extends V {};
    var Pc = class extends V {};
    var Qc = class extends V {};
    var Rc = class extends V {
        C() {
            return P(this, 3)
        }
        fa(a) {
            R(this, 5, a)
        }
    };
    var Sc = class extends V {};
    var Tc = class extends V {
        C() {
            return P(this, 1)
        }
        fa(a) {
            R(this, 2, a)
        }
    };
    var Uc = class extends V {};
    var Vc = class extends V {};

    function Wc(a) {
        var b = a.l,
            c = b;
        b = b[u] | 0;
        var d = !(a ? v(a, b) : 2 & b);
        d && a && xc(a) && (c = a.l, b = c[u] | 0);
        a = Dc(c, 7);
        var e = a === eb ? 7 : a[u] | 0,
            f = kb(e, b),
            g = !(4 & f);
        if (g) {
            var k = a,
                h = b;
            let l = !!(2 & f);
            l && (h |= 2);
            let m = !l,
                p = !0,
                q = 0,
                r = 0;
            for (; q < k.length; q++) {
                let w = Xb(k[q], Rc, !1, h);
                if (w instanceof Rc) {
                    if (!l) {
                        let z = v(w);
                        m && (m = !z);
                        p && (p = z)
                    }
                    k[r++] = w
                }
            }
            r < q && (k.length = r);
            f |= 4;
            f = p ? f & -4097 : f | 4096;
            f = m ? f | 8 : f & -9
        }
        f !== e && (a[u] = f, 2 & f && Object.freeze(a));
        if (d && !(8 & f || !a.length && (2 & f || !(16 & f) && 32 & b))) {
            Fc(f) && (a = [...a], f = Gc(f, b), b = H(c, b, 7, a));
            d = a;
            e = f;
            for (k = 0; k < d.length; k++) f = d[k], h = fc(f), f !== h && (d[k] = h);
            e |= 8;
            f = e = d.length ? e | 4096 : e & -4097;
            a[u] = f
        }
        return a = Ec(a, f, c, b, 7, 4, g, !1)
    }

    function Xc(a, b) {
        G(a, 28, b == null ? b : Rb(b))
    }
    var Yc = class extends V {};
    var Zc = class extends V {};
    var $c = function(a) {
        return b => {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b = new a(jb(b))
            }
            return b
        }
    }(class extends V {});
    var ad = class extends V {};

    function bd(a, b) {
        if (a)
            for (let c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function cd(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };

    function dd(a = document) {
        return a.createElement("img")
    };
    var ed = [];

    function id() {
        var a = ed;
        ed = [];
        for (let b of a) try {
            b()
        } catch (c) {}
    }

    function jd(a) {
        ed.push(a);
        ed.length === 1 && (window.Promise ? Promise.resolve().then(id) : (a = window.setImmediate, tb(a) ? a(id) : setTimeout(id, 0)))
    };

    function kd(a, b) {
        for (let c in a) b.call(void 0, a[c], c, a)
    }

    function ld(a) {
        var b = [],
            c = 0;
        for (let d in a) b[c++] = a[d];
        return b
    };

    function md(a, b) {
        kd(b, function(c, d) {
            d == "style" ? a.style.cssText = c : d == "class" ? a.className = c : d == "for" ? a.htmlFor = c : nd.hasOwnProperty(d) ? a.setAttribute(nd[d], c) : d.lastIndexOf("aria-", 0) == 0 || d.lastIndexOf("data-", 0) == 0 ? a.setAttribute(d, c) : a[d] = c
        })
    }
    var nd = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    };

    function od(a, b, c) {
        var d = arguments,
            e = document,
            f = d[1];
        var g = String(d[0]);
        g = String(g);
        e.contentType === "application/xhtml+xml" && (g = g.toLowerCase());
        g = e.createElement(g);
        f && (typeof f === "string" ? g.className = f : Array.isArray(f) ? g.className = f.join(" ") : md(g, f));
        d.length > 2 && pd(e, g, d);
        return g
    }

    function pd(a, b, c) {
        function d(e) {
            e && b.appendChild(typeof e === "string" ? a.createTextNode(e) : e)
        }
        for (let e = 2; e < c.length; e++) {
            let f = c[e];
            !ca(f) || da(f) && f.nodeType > 0 ? d(f) : Ga(f && typeof f.length == "number" && typeof f.item == "function" ? Ia(f) : f, d)
        }
    };
    var qd = {
            capture: !0
        },
        rd = {
            passive: !0
        },
        sd = cd(() => {
            var a = !1;
            try {
                let b = Object.defineProperty({}, "passive", {
                    get() {
                        a = !0
                    }
                });
                n.addEventListener("test", null, b)
            } catch (b) {}
            return a
        });

    function td(a) {
        return a ? a.passive && sd() ? a : a.capture || !1 : !1
    }

    function W(a, b, c, d) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, td(d))
    }

    function ud(a) {
        var b = X;
        b.readyState === "complete" || b.readyState === "interactive" ? jd(a) : b.addEventListener("DOMContentLoaded", a)
    }

    function vd(a) {
        var b = window;
        b.document.readyState === "complete" ? jd(a) : b.addEventListener("load", a)
    };

    function wd(a, b, c = null, d = !1) {
        xd(a, b, c, d)
    }

    function xd(a, b, c, d) {
        a.google_image_requests || (a.google_image_requests = []);
        var e = dd(a.document);
        if (c || d) {
            let f = g => {
                c && c(g);
                if (d) {
                    g = a.google_image_requests;
                    let k = Array.prototype.indexOf.call(g, e, void 0);
                    k >= 0 && Array.prototype.splice.call(g, k, 1)
                }
                typeof e.removeEventListener === "function" && e.removeEventListener("load", f, td());
                typeof e.removeEventListener === "function" && e.removeEventListener("error", f, td())
            };
            W(e, "load", f);
            W(e, "error", f)
        }
        e.src = b;
        a.google_image_requests.push(e)
    }

    function yd(a) {
        var b = window,
            c;
        if (c = b.navigator) c = b.navigator.userAgent, c = !(!/Chrome/.test(c) || /Edge/.test(c));
        c && typeof b.navigator.sendBeacon === "function" ? b.navigator.sendBeacon(a) : wd(b, a, void 0, !1)
    };
    var zd = 0;

    function Ad() {
        var a = Bd(zd, document.currentScript);
        a && (a.dataset.initialized = "true")
    }

    function Cd(a) {
        return (a = Bd(a, document.currentScript)) && a.getAttribute("data-jc-version") || "unknown"
    }

    function Bd(a, b = null) {
        return b && b.getAttribute("data-jc") === String(a) ? b : document.querySelector(`[data-jc="${a}"]`)
    }

    function Dd(a) {
        if (!(Math.random() > .01)) {
            let b = Bd(a, document.currentScript);
            a = `https://${b&&b.getAttribute("data-jc-rcd")==="true"?"pagead2.googlesyndication-cn.com":"pagead2.googlesyndication.com"}/pagead/gen_204?id=jca&jc=${a}&version=${Cd(a)}&sample=0.01`;
            yd(a)
        }
    };
    var Ed = class {
        constructor(a, b) {
            this.error = a;
            this.meta = {};
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror"
        }
    };

    function Fd(a) {
        var b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        if (a.stack) a: {
            a = a.stack;
            var c = b;
            try {
                a.indexOf(c) == -1 && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n");
                break a
            } catch (d) {
                b = c;
                break a
            }
            b = void 0
        }
        return b
    };
    var Gd = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)"),
        Hd = class {
            constructor(a, b) {
                this.h = a;
                this.i = b
            }
        },
        Id = class {
            constructor(a, b) {
                this.url = a;
                this.h = !!b;
                this.depth = null
            }
        };
    var Jd = null;

    function Kd() {
        var a = n.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function Ld() {
        var a = n.performance;
        return a && a.now ? a.now() : null
    };
    var Md = class {
        constructor(a, b) {
            var c = Ld() || Kd();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    var Y = n.performance,
        Nd = !!(Y && Y.mark && Y.measure && Y.clearMarks),
        Od = cd(() => {
            var a;
            if (a = Nd) {
                var b;
                a = window;
                if (Jd === null) {
                    Jd = "";
                    try {
                        let c = "";
                        try {
                            c = a.top.location.hash
                        } catch (d) {
                            c = a.location.hash
                        }
                        c && (Jd = (b = c.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (c) {}
                }
                b = Jd;
                a = !!b.indexOf && b.indexOf("1337") >= 0
            }
            return a
        });

    function Pd(a) {
        a && Y && Od() && (Y.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), Y.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    };

    function Qd(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    }

    function Rd(a, b, c, d, e) {
        var f = [];
        bd(a, (g, k) => {
            (g = Sd(g, b, c, d, e)) && f.push(`${encodeURIComponent(k)}=${g}`)
        });
        return f.join(b)
    }

    function Sd(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        rb(c) && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                let f = [];
                for (let g = 0; g < a.length; g++) f.push(Sd(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(Rd(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function Td(a) {
        var b = 1;
        for (let c in a.i) c.length > b && (b = c.length);
        return 3997 - b - a.j.length - 1
    }

    function Ud(a, b) {
        var c = Td(a) - b.length;
        if (c < 0) return "";
        b = "";
        a.h.sort((f, g) => f - g);
        var d = null,
            e = "";
        for (let f = 0; f < a.h.length; f++) {
            let g = a.h[f],
                k = a.i[g];
            for (let h = 0; h < k.length; h++) {
                if (!c) {
                    d = d == null ? g : d;
                    break
                }
                let l = Rd(k[h], a.j, ",$");
                if (l) {
                    l = e + l;
                    if (c >= l.length) {
                        c -= l.length;
                        b += l;
                        e = a.j;
                        break
                    }
                    d = d == null ? g : d
                }
            }
        }
        a = "";
        d != null && (a = `${e}trn=${d}`);
        return b + a
    }

    function Vd(a, b, c, d) {
        return Td(a) - d.length < 0 ? "" : b + "//" + c + d + Ud(a, d)
    }
    var Wd = class {
        constructor() {
            this.j = "&";
            this.i = {};
            this.m = 0;
            this.h = []
        }
    };
    var Xd = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function Yd(a, b) {
        if (!b) return a;
        var c = a.indexOf("#");
        c < 0 && (c = a.length);
        var d = a.indexOf("?");
        if (d < 0 || d > c) {
            d = c;
            var e = ""
        } else e = a.substring(d + 1, c);
        a = [a.slice(0, d), e, a.slice(c)];
        c = a[1];
        a[1] = b ? c ? c + "&" + b : b : c;
        return a[0] + (a[1] ? "?" + a[1] : "") + a[2]
    }

    function Zd(a, b, c) {
        if (Array.isArray(b))
            for (let d = 0; d < b.length; d++) Zd(a, String(b[d]), c);
        else b != null && c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))))
    }

    function $d(a, b, c, d) {
        for (var e = c.length;
            (b = a.indexOf(c, b)) >= 0 && b < d;) {
            var f = a.charCodeAt(b - 1);
            if (f == 38 || f == 63)
                if (f = a.charCodeAt(b + e), !f || f == 61 || f == 38 || f == 35) return b;
            b += e + 1
        }
        return -1
    }
    var ae = /#|$/;

    function be(a, b) {
        var c = a.search(ae),
            d = $d(a, 0, b, c);
        if (d < 0) return null;
        var e = a.indexOf("&", d);
        if (e < 0 || e > c) e = c;
        d += b.length + 1;
        return decodeURIComponent(a.slice(d, e !== -1 ? e : 0).replace(/\+/g, " "))
    }
    var ce = /[?&]($|#)/;

    function de(a, b) {
        for (var c = a.search(ae), d = 0, e, f = [];
            (e = $d(a, d, b, c)) >= 0;) f.push(a.substring(d, e)), d = Math.min(a.indexOf("&", e) + 1 || c, c);
        f.push(a.slice(d));
        return f.join("").replace(ce, "$1")
    }

    function ee(a, b) {
        a = de(a, "label");
        b = b != null ? "=" + encodeURIComponent(String(b)) : "";
        return Yd(a, "label" + b)
    };

    function fe(a, b, c) {
        try {
            if (a.h && a.h.h) {
                var d = a.h.start(b.toString(), 3);
                var e = c();
                a.h.end(d)
            } else e = c()
        } catch (f) {
            c = !0;
            try {
                Pd(d), c = a.v(b, new Ed(f, {
                    message: Fd(f)
                }), void 0, void 0)
            } catch (g) {
                a.m(217, g)
            }
            if (c) {
                let g, k;
                (g = window.console) == null || (k = g.error) == null || k.call(g, f)
            } else throw f;
        }
        return e
    }

    function ge(a, b) {
        var c = he;
        return (...d) => fe(c, a, () => b.apply(void 0, d))
    }
    var ke = class {
        constructor(a = null) {
            this.pinger = ie;
            this.h = a;
            this.i = null;
            this.j = !1;
            this.v = this.m
        }
        m(a, b, c, d, e) {
            e = e || "jserror";
            var f = void 0;
            try {
                let S = new Wd;
                var g = S;
                g.h.push(1);
                g.i[1] = Qd("context", a);
                b.error && b.meta && b.id || (b = new Ed(b, {
                    message: Fd(b)
                }));
                g = b;
                if (g.msg) {
                    b = S;
                    var k = g.msg.substring(0, 512);
                    b.h.push(2);
                    b.i[2] = Qd("msg", k)
                }
                var h = g.meta || {};
                k = h;
                if (this.i) try {
                    this.i(k)
                } catch (M) {}
                if (d) try {
                    d(k)
                } catch (M) {}
                d = S;
                h = [h];
                d.h.push(3);
                d.i[3] = h;
                var l;
                if (!(l = r)) {
                    d = n;
                    h = [];
                    let M;
                    k = null;
                    do {
                        var m = d;
                        try {
                            var p;
                            if (p = !!m &&
                                m.location.href != null) b: {
                                try {
                                    Qa(m.foo);
                                    p = !0;
                                    break b
                                } catch (I) {}
                                p = !1
                            }
                            var q = p
                        } catch (I) {
                            q = !1
                        }
                        q ? (M = m.location.href, k = m.document && m.document.referrer || null) : (M = k, k = null);
                        h.push(new Id(M || ""));
                        try {
                            d = m.parent
                        } catch (I) {
                            d = null
                        }
                    } while (d && m !== d);
                    for (let I = 0, fd = h.length - 1; I <= fd; ++I) h[I].depth = fd - I;
                    m = n;
                    if (m.location && m.location.ancestorOrigins && m.location.ancestorOrigins.length === h.length - 1)
                        for (q = 1; q < h.length; ++q) {
                            let I = h[q];
                            I.url || (I.url = m.location.ancestorOrigins[q - 1] || "", I.h = !0)
                        }
                    l = h
                }
                var r = l;
                let Z = new Id(n.location.href, !1);
                l = null;
                let pa = r.length - 1;
                for (m = pa; m >= 0; --m) {
                    var w = r[m];
                    !l && Gd.test(w.url) && (l = w);
                    if (w.url && !w.h) {
                        Z = w;
                        break
                    }
                }
                w = null;
                let Oe = r.length && r[pa].url;
                Z.depth !== 0 && Oe && (w = r[pa]);
                f = new Hd(Z, w);
                if (f.i) {
                    r = S;
                    var z = f.i.url || "";
                    r.h.push(4);
                    r.i[4] = Qd("top", z)
                }
                var D = {
                    url: f.h.url || ""
                };
                if (f.h.url) {
                    let M = f.h.url.match(Xd);
                    var N = M[1],
                        bb = M[3],
                        gd = M[4];
                    z = "";
                    N && (z += N + ":");
                    bb && (z += "//", z += bb, gd && (z += ":" + gd));
                    var hd = z
                } else hd = "";
                N = S;
                D = [D, {
                    url: hd
                }];
                N.h.push(5);
                N.i[5] = D;
                je(this.pinger, e, S, this.j, c)
            } catch (S) {
                try {
                    let Z, pa;
                    je(this.pinger, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Fd(S),
                        url: (pa = (Z = f) == null ? void 0 : Z.h.url) != null ? pa : ""
                    }, this.j, c)
                } catch (Z) {}
            }
            return !0
        }
    };
    class le {};

    function je(a, b, c, d = !1, e) {
        if ((d ? a.h : Math.random()) < (e || .01)) try {
            let f;
            c instanceof Wd ? f = c : (f = new Wd, bd(c, (k, h) => {
                var l = f,
                    m = l.m++;
                k = Qd(h, k);
                l.h.push(m);
                l.i[m] = k
            }));
            let g = Vd(f, a.protocol, a.domain, a.path + b + "&");
            g && wd(n, g)
        } catch (f) {}
    }

    function me() {
        var a = ie,
            b = window.google_srt;
        b >= 0 && b <= 1 && (a.h = b)
    }
    var ne = class {
        constructor() {
            this.domain = "pagead2.googlesyndication.com";
            this.path = "/pagead/gen_204?id=";
            this.protocol = "https:";
            this.h = Math.random()
        }
    };
    var oe = [sa, ta, va, ua, ra, xa, ya, wa, za];

    function pe(a, b) {
        if (a instanceof na) return a;
        var c = Ca(a, oe);
        c === oa && b(a);
        return c
    }

    function qe(a) {
        return b => {
            b = {
                id: "unsafeurl",
                ctx: a,
                url: b
            };
            var c = [];
            for (d in b) Zd(d, b[d], c);
            var d = Yd("https://pagead2.googlesyndication.com/pagead/gen_204", c.join("&"));
            navigator.sendBeacon && navigator.sendBeacon(d, "")
        }
    };
    var ie, he, re = new class {
        constructor(a, b) {
            this.i = [];
            this.j = b || n;
            var c = null;
            b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.i = b.google_js_reporting_queue, c = b.google_measure_js_timing);
            this.h = Od() || (c != null ? c : Math.random() < a)
        }
        start(a, b) {
            if (!this.h) return null;
            a = new Md(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            Y && Od() && Y.mark(b);
            return a
        }
        end(a) {
            if (this.h && qb(a.value)) {
                a.duration = (Ld() || Kd()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                Y && Od() && Y.mark(b);
                !this.h || this.i.length >
                    2048 || this.i.push(a)
            }
        }
    }(1, window);

    function se() {
        window.google_measure_js_timing || (re.h = !1, re.i !== re.j.google_js_reporting_queue && (Od() && Ga(re.i, Pd), re.i.length = 0))
    }(function(a) {
        ie = a != null ? a : new ne;
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        me();
        he = new ke(re);
        he.i = b => {
            var c = zd;
            c !== 0 && (b.jc = String(c), b.shv = Cd(c))
        };
        he.j = !0;
        window.document.readyState === "complete" ? se() : re.h && W(window, "load", () => {
            se()
        })
    })();

    function te(a, b) {
        return ge(a, b)
    }

    function ue(a, b) {
        var c = le;
        var d = "ea";
        c.ea && c.hasOwnProperty(d) || (d = new c, c.ea = d);
        c = [];
        !b.eid && c.length && (b.eid = c.toString());
        je(ie, a, b, !0)
    };

    function ve(a = window) {
        return a
    };
    var X = document,
        we = window;
    var xe = a => {
        var b = X;
        try {
            return b.querySelectorAll("*[" + a + "]")
        } catch (c) {
            return []
        }
    };
    ld({
        Ca: 0,
        Ba: 1,
        ya: 2,
        ta: 3,
        za: 4,
        ua: 5,
        Aa: 6,
        wa: 7,
        xa: 8,
        sa: 9,
        va: 10,
        Da: 11
    }).map(a => Number(a));
    ld({
        Fa: 0,
        Ga: 1,
        Ea: 2
    }).map(a => Number(a));

    function ye(a) {
        var b = new ze;
        yc(b);
        b = Cc(b, 1, Ob, 2, !0);
        if (Array.isArray(a)) {
            var c = a.length;
            for (let d = 0; d < c; d++) b.push(Nb(a[d]))
        } else
            for (c of a) b.push(Nb(c))
    }
    var ze = class extends V {};
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    [2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2].reduce((a, b) => a + b);
    ye([1, 8, 9, 10, 11, 12, 2, 3, 4, 5, 15, 16, 19, 20, 21, 23, 25]);
    ye([1, 6, 7, 9, 10, 11, 12, 2, 22, 3, 4, 5, 13, 14, 18, 19, 20, 21, 23, 24]);
    ye([1, 6, 7, 9, 10, 11, 12, 22, 26, 27, 2, 3, 4, 5, 13, 14, 17, 18, 19, 20, 21, 23, 24]);
    new ze;
    var Ae = class extends V {};
    var Be = (a, b) => {
            a = wc(a);
            a = nc(a);
            b = nc(b);
            var c = Math.max(a.length, b.length);
            for (let d = 0; d < c; ++d) a[d] == null && (a[d] = b[d]);
            return new Yc(a)
        },
        Ce = (a, b) => {
            b = P(a, 2) || b;
            if (!b) return "";
            if (O(a, 13)) return b;
            var c = /[?&]adurl=([^&]+)/.exec(b);
            if (!c) return b;
            var d = [b.slice(0, c.index + 1)];
            K(a, 4, void 0, C, C).forEach((e, f) => {
                d.push(encodeURIComponent(f) + "=" + encodeURIComponent(e) + "&")
            });
            d.push(b.slice(c.index + 1));
            return O(a, 27) ? (b = d.join(""), (a = K(a, 4, void 0, C, C).get("label")) && (b = ee(b, a)), b) : d.join("")
        },
        De = (a, b, c) => {
            var d =
                K(b, 1, Yc, C);
            b = c.split(",");
            if (!b.every(e => d.has(e))) return ue("gdn-asoch", {
                type: 1,
                data: c
            }), null;
            c = a || d.get(b[0]);
            a = a ? b : b.slice(1);
            for (let e of a) a = d.get(e), c = Be(c, a), Xc(c, (Jc(c, 28) || 0) | (Jc(a, 28) || 0));
            return c
        },
        Ee = a => {
            var b = K(a, 4, void 0, C, C);
            Ob(F(a, 5)) != null && b.set("nb", Q(a, 5).toString());
            Jc(a, 28) && b.set("als", Jc(a, 28).toString())
        },
        Fe = (a, b = []) => {
            b = b.length > 0 ? b : xe("data-asoch-targets");
            var c = [];
            for (let e = 0; e < b.length; ++e) {
                var d = b[e].getAttribute("data-asoch-targets");
                if (d = De(null, a, d)) Ee(d), c.push({
                    element: b[e],
                    data: d
                })
            }
            return c
        },
        He = (a, b, c, d) => {
            c = Ce(b, c);
            if (c.length !== 0) {
                if (d === 609 && J(b, 24)) {
                    var e = L(b, Mc, 24);
                    a.setAttribute("attributionDestination", P(e, 2));
                    a.setAttribute("attributionSourceNonce", P(e, 1))
                }(e = (e = Bd(35)) && e.dataset.expanded ? e.dataset.expanded : null) && d === 557 && (c = Ge(c, "expanded", e));
                Ea(a, pe(c, qe(d)));
                a.target || (a.target = B(F(b, 11)) != null ? P(b, 11) : "_top")
            }
        },
        Ie = a => {
            for (let b of a)
                if (a = b.data, b.element.tagName == "A" && !O(a, 1)) {
                    let c = b.element;
                    He(c, a, c.href, 609)
                }
        },
        Ge = (a, b, c) => {
            b = encodeURIComponent(b);
            var d = encodeURIComponent(c);
            c = new RegExp("[?&]" + b + "=([^&]+)");
            var e = c.exec(a);
            b = b + "=" + d;
            return e ? a.replace(c, e[0].charAt(0) + b) : a.replace("?", "?" + b + "&")
        },
        Je = a => {
            var b = n.oneAfmaInstance;
            if (b)
                for (var c of a)
                    if ((a = c.data) && J(a, 8)) {
                        var d = L(a, Uc, 8);
                        if (d = P(d, 4)) {
                            c = b.fetchAppStoreOverlay;
                            a = L(a, Uc, 8);
                            c.call(b, d, void 0, P(a, 6));
                            break
                        }
                    }
        },
        Ke = (a, b = 500) => {
            var c = [],
                d = [];
            for (var e of a)(a = e.data) && J(a, 12) && (d.push(L(a, Tc, 12)), c.push(L(a, Tc, 12).C()));
            e = (f, g) => {
                if (g)
                    for (let k of d) g[k.C()] && k.fa(!0)
            };
            a = n.oneAfmaInstance;
            for (let f of c) a == null || a.canOpenAndroidApp(f, e, () => {}, b)
        },
        Ne = (a, b, c, d, e, f) => {
            if (!d || !J(d, 8)) return !1;
            var g = L(d, Uc, 8),
                k = P(g, 2);
            K(d, 10, void 0, C, C).forEach((D, N) => {
                k = Ge(k, N, D)
            });
            Le(d) && O(d, 15) && !/[?&]label=/.test(e) && (e = Me(e, "label", "deep_link_fallback"));
            if (b == null ? 0 : O(b, 1)) P(d, 9) ? ue("skspvc", {
                url: 1
            }) : ue("skspvc", {
                url: 0
            });
            var h = P(d, 9),
                l = void 0,
                m = void 0,
                p = -1;
            if ((b == null ? 0 : O(b, 7)) && h) {
                let D = ee(h, "skspvc_triggered"),
                    N = ee(h, "skspvc_registered"),
                    bb = ee(h, "skspvc_dismissed");
                l = () => {
                    yd(D);
                    p = setTimeout(() => {
                        yd(N)
                    }, 3E3)
                };
                m = () => {
                    yd(bb);
                    clearTimeout(p)
                }
            }
            var q = be(k, "inline") === "true" && !!be(k, "enifd");
            ue("deeplink", {
                is_alleyoop_eligible: q ? "1" : "0",
                app_id: be(k, "id")
            });
            var r = void 0;
            if (c && h && !a && q) {
                let D = ee(h, "alleyoop_triggered");
                r = () => {
                    yd(D)
                }
            }
            var w = D => f.openStoreOverlay(D, l, m, P(g, 6)),
                z = D => f.openIntentOrNativeApp(D, !0, {}, r);
            b = f.redirectForStoreU2({
                clickUrl: e,
                trackingUrl: P(g, 3),
                finalUrl: k,
                pingFunc: O(d, 13) ? f.httpTrack : f.click,
                openFunc: (b == null ? 0 : O(b, 1)) ? w : z,
                isExternalClickUrl: O(d, 13)
            });
            c && h && !a && !b && q && (a = ee(h,
                "alleyoop_failed"), yd(a));
            return b
        },
        Pe = (a, b, c, d, e = !1) => {
            c && c.startsWith("intent:") ? d.openIntentOrNativeApp(c) : e ? d.openWebApp(c, void 0, void 0, !0, !0) : (e = a == null ? void 0 : O(a, 1)) && (a == null ? 0 : Sb(F(a, 2)) != null) && !b ? d.openChromeCustomTab(c, {
                cct_init_h: String(a == null ? void 0 : Jc(a, 2)),
                cct_bp: "2"
            }) : e ? b ? d.openBrowser(c) : d.openChromeCustomTab(c) : d.openSystemBrowser(c, {
                useFirstPackage: !0,
                useRunningProcess: !0
            })
        },
        Re = (a, b, c, d, e, f, g, k = !1, h = !1) => {
            var l = O(e, 15);
            if (a && b && !l && (f = Qe(f, g.click), k && (e == null ? 0 : O(e, 21)))) return;
            Pe(c, d, f, g, h)
        },
        Qe = (a, b = null) => {
            if (b === null) {
                var c = new ma({
                    url: a,
                    ra: null
                });
                if (c.h.dsh === "1" || c.h.aspm !== "1") a = (b = ka(c, 0)) ? navigator.sendBeacon ? navigator.sendBeacon(b.A, "") ? b.B : la(c, 2) : la(c, 0) : a;
                else if (b = ka(c, 1)) Ka(b.A), a = b.B;
                return a
            }
            c = ka(new ma({
                url: a
            }), 0);
            if (!c) return a;
            b(c.A);
            return c.B
        },
        Se = (a, b = !0) => {
            b && we.fetch ? we.fetch(a, {
                method: "GET",
                keepalive: !0,
                mode: "no-cors"
            }).then(c => {
                c.ok || wd(we, a)
            }) : wd(we, a)
        },
        Me = (a, b, c) => {
            b = encodeURIComponent(String(b));
            c = encodeURIComponent(String(c));
            return a.replace("?",
                "?" + b + "=" + c + "&")
        },
        Le = a => {
            for (let b of Wc(a))
                if (Q(b, 1) === 3 && P(b, 2)) return !0;
            return !1
        };
    var Te = (a, b) => a && (a = a.match(b + "=([^&]+)")) && a.length == 2 ? a[1] : "";
    var Ue = class extends V {};

    function Ve(a, b) {
        return U(a, 2, b)
    }

    function We(a, b) {
        return U(a, 3, b)
    }

    function Xe(a, b) {
        return U(a, 4, b)
    }

    function Ye(a, b) {
        return U(a, 5, b)
    }

    function Ze(a, b) {
        return U(a, 9, b)
    }

    function $e(a, b) {
        yc(a);
        var c = a.l,
            d = c[u] | 0;
        if (b == null) H(c, d, 10);
        else {
            var e = b === eb ? 7 : b[u] | 0,
                f = e,
                g = Fc(e),
                k = g || Object.isFrozen(b),
                h = !0,
                l = !0;
            for (let p = 0; p < b.length; p++) {
                var m = b[p];
                g || (m = v(m), h && (h = !m), l && (l = m))
            }
            g || (e = h ? 13 : 5, e = l ? e & -4097 : e | 4096);
            k && e === f || (b = [...b], f = 0, e = Gc(e, d));
            e !== f && (b[u] = e);
            d = H(c, d, 10, b);
            2 & e || !(4096 & e || 16 & e) || zc(c, d)
        }
        return a
    }

    function af(a, b) {
        return R(a, 11, b)
    }

    function bf(a, b) {
        return U(a, 1, b)
    }

    function cf(a, b) {
        return R(a, 7, b)
    }
    var df = class extends V {};
    var ef = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function ff(a) {
        var b;
        return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
    }

    function gf(a) {
        var b, c;
        return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
    }

    function hf() {
        var a = window;
        if (!gf(a)) return null;
        var b = ff(a);
        if (b.uach_promise) return b.uach_promise;
        a = a.navigator.userAgentData.getHighEntropyValues(ef).then(c => {
            b.uach != null || (b.uach = c);
            return c
        });
        return b.uach_promise = a
    }

    function jf(a) {
        var b;
        return af($e(Ye(Ve(bf(Xe(cf(Ze(We(new df, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), ((b = a.fullVersionList) == null ? void 0 : b.map(c => {
            var d = new Ue;
            d = U(d, 1, c.brand);
            return U(d, 2, c.version)
        })) || []), a.wow64 || !1)
    }

    function kf() {
        var a, b;
        return (b = (a = hf()) == null ? void 0 : a.then(c => jf(c))) != null ? b : null
    };

    function lf(a) {
        for (let b of a)
            if (b.element.tagName == "A") {
                a = b.element;
                let c = b.data;
                B(F(c, 2)) == null && U(c, 2, a.href)
            }
    }

    function mf(a, b) {
        return Ha(a, c => c.element === b)
    }

    function nf(a) {
        ud(te(556, () => {
            new of (a || {})
        }))
    }

    function pf(a) {
        K(a.i, 1, Yc, C).forEach(b => {
            a.j != null || P(b, 2) === "" || P(b, 9) === "" || O(b, 13) || O(b, 1) || (a.j = b)
        });
        a.j && (Ea(a.N, pe(P(a.j, 2), qe(1714))), a.N.target = P(a.j, 11) || "_top")
    }

    function qf(a, b) {
        var c, d;
        if (!b.defaultPrevented || a.J === b) {
            var e = b.type === "click";
            if (a.I && e && !a.ma) b.preventDefault();
            else {
                for (c = b.target;
                    (!k || !d) && c;) {
                    d || c.tagName != "A" || (d = c);
                    var f = c.hasAttribute("data-asoch-targets"),
                        g = c.hasAttribute("data-asoch-fixed-value");
                    if (!k)
                        if (g) var k = new Yc(JSON.parse(c.getAttribute("data-asoch-fixed-value")) || []);
                        else if (c.tagName == "A" || f)
                        if (f = f && c.getAttribute("data-asoch-is-dynamic") === "true" ? Fe(a.i, [c]) : a.h, f = mf(f, c))
                            if (k = f.data, f = c.getAttribute("data-asoch-dyn-extra-targets")) a: {
                                f =
                                De(k, a.i, f);
                                if (!f) break a;k = wc(f);Ee(k)
                            }
                    c = c.parentElement
                }
                k = (c = k) && !O(c, 1);
                if (a.L && a.j && b.defaultPrevented) rf(a, b, d, k ? c : a.j);
                else {
                    if (k) {
                        if (!a.L && b.defaultPrevented) {
                            rf(a, b, d, c);
                            return
                        }
                        for (var h of Cc(c, 6, B)) Se(h)
                    }
                    a.O && k && O(c, 21) && (b.preventDefault ? b.preventDefault() : b.returnValue = !1);
                    h = d;
                    d = c;
                    !a.I || e || h || d || (h = a.N, d = a.j);
                    if (h && (c = d && !O(d, 1))) {
                        e = h;
                        h = c ? d : null;
                        (d = mf(a.h, e)) ? d = d.data: (d = new Yc, U(d, 2, e.href), U(d, 11, e.target || "_top"), a.h.push({
                            element: e,
                            data: d
                        }));
                        He(e, h || d, P(d, 2), 557);
                        sf(a, b, e, h);
                        for (var l of Cc(a.i,
                                17, B)) d = X.body, c = {}, typeof window.CustomEvent === "function" ? k = new CustomEvent(l, c) : (k = document.createEvent("CustomEvent"), k.initCustomEvent(l, !!c.bubbles, !!c.cancelable, c.detail)), d.dispatchEvent(k);
                        var m;
                        if (h == null ? 0 : (m = L(h, Vc, 26)) == null ? 0 : B(F(m, 1)) != null) {
                            m = new Nc;
                            Ob(F(h, 5)) != null ? (l = m, d = Q(h, 5), Kc(l, 1, d)) : (l = Te(e.href, "nb"), l != "" && Kc(m, 1, +l));
                            l = Te(e.href, "nx");
                            l != "" && T(m, 2, +l);
                            l = Te(e.href, "ny");
                            l != "" && T(m, 3, +l);
                            l = Te(e.href, "bg");
                            l != "" && U(m, 4, l);
                            l = Te(e.href, "nm");
                            l != "" && T(m, 5, +l);
                            l = Te(e.href, "mb");
                            l != "" && T(m, 6, +l);
                            l = de(e.href, "bg");
                            Ea(e, pe(l, qe(1211)));
                            l = L(h, Vc, 26);
                            k = P(l, 1);
                            l = L(h, Vc, 26);
                            l = P(l, 2);
                            d = Qb(F(h, 20)) != null ? Ic(h, 20) : null;
                            f = Lc(m);
                            m = a.G;
                            c = ve(n);
                            g = new ad;
                            k = U(g, 1, k);
                            k = U(k, 4, f);
                            k = U(k, 10, Date.now().toString());
                            d !== null && T(k, 2, d);
                            m !== null && U(k, 3, m);
                            Kc(k, 9, 7);
                            var p;
                            c == null || (p = c.fence) == null || p.setReportEventDataForAutomaticBeacons({
                                eventType: "reserved.top_navigation_start",
                                eventData: JSON.stringify(k),
                                destination: ["buyer"],
                                once: !0
                            });
                            var q;
                            c == null || (q = c.fence) == null || q.reportEvent({
                                eventType: "click",
                                eventData: l,
                                destination: ["component-seller"]
                            })
                        }
                        O(a.i, 16) || a.T ? tf(a, b, e, h) : (p = "", (q = n.oneAfmaInstance) && (p = a.ca ? q.appendClickSignals(e.href, !0) : q.appendClickSignals(e.href)), uf(a, b, e, h, p))
                    }
                }
            }
        }
    }

    function rf(a, b, c, d) {
        if (a.J === b && a.K) {
            var e = new Pc(a.K),
                f = P(d, 9),
                g = "";
            switch (Q(e, 4, 1)) {
                case 2:
                    if (Ic(e, 2)) g = "blocked_fast_click";
                    else if (P(e, 1) || P(e, 7)) g = "blocked_border_click";
                    break;
                case 3:
                    g = X;
                    g = g.getElementById ? g.getElementById("common_15click_anchor") : null;
                    var k = window;
                    if (typeof k.copfcChm === "function" && g) {
                        var h = wc(d);
                        Kc(h, 5, 12);
                        K(h, 4, void 0, C, C).set("nb", (12).toString());
                        let l = mf(a.h, g);
                        l ? l.data = h : a.h.push({
                            element: g,
                            data: h
                        });
                        !a.aa && c && (sf(a, b, c, h), U(h, 2, c.href));
                        k.copfcChm(b, Ce(h, g.href), null,
                            J(e, 10) ? Lc(L(e, Oc, 10)) : null);
                        a.aa && sf(a, b, g, h)
                    }
                    g = "onepointfiveclick_first_click"
            }
            if (f && g) {
                c = f + "&label=" + g;
                if (g === "onepointfiveclick_first_click" || g === "blocked_border_click") {
                    k = a.Y;
                    g = a.X;
                    f = a.ba;
                    e = new Ae;
                    d = Q(d, 5);
                    h = b.clientX;
                    G(e, 1, h == null ? h : Tb(h));
                    h = b.clientY;
                    G(e, 2, h == null ? h : Tb(h));
                    T(e, 3, d);
                    d = k ? k.changedTouches : [];
                    g = g ? g.changedTouches : [];
                    d && d.length > 0 && (T(e, 4, d[0].clientX), T(e, 5, d[0].clientY));
                    g && g.length > 0 && (T(e, 6, g[0].clientX), T(e, 7, g[0].clientY));
                    (b.isTrusted === !1 || navigator.userActivation && navigator.userActivation.hasBeenActive ===
                        !1 || navigator.userActivation && navigator.userActivation.isActive === !1) && R(e, 8, !0);
                    if (f != null) {
                        b = f instanceof Map ? f.entries() : Object.entries(f);
                        for (let [l, m] of b) b = Number(l), d = Date.now() - Number(m), K(e, 9, void 0, Yb, Yb).set(b, d)
                    }
                    c += "&cpspb=" + Lc(e)
                }
                Se(c, !1)
            }
            Dd(a.U)
        }
    }

    function sf(a, b, c, d) {
        if (!O(d, 13)) {
            var e = c.href;
            var f = /[?&]adurl=([^&]+)/.exec(e);
            e = f ? [e.slice(0, f.index), e.slice(f.index)] : [e, ""];
            for (Ea(c, pe(e[0], qe(557))); !c.id;)
                if (f = "asoch-id-" + (Math.floor(Math.random() * 2147483648).toString(36) + Math.abs(Math.floor(Math.random() * 2147483648) ^ Date.now()).toString(36)), !X.getElementById(f)) {
                    c.id = f;
                    break
                }
            f = c.id;
            typeof window.xy === "function" && window.xy(b, c, X.body);
            typeof window.mb === "function" && window.mb(c);
            typeof window.bgz === "function" && window.bgz(f);
            typeof window.ja ===
                "function" && window.ja(f, d ? Q(d, 5) : 0);
            typeof window.vti === "function" && window.vti(c);
            a.m && typeof window.ss === "function" && (a.Z ? window.ss(f, 1, a.m) : window.ss(a.m, 1));
            if (e.length > 0) {
                let g;
                b = a.G.length > 0 && (d == null || (g = L(d, Vc, 26)) == null || B(F(g, 1)) == null) ? c.href + "&uach=" + encodeURIComponent(a.G) + e[1] : c.href + e[1];
                Ea(c, pe(b, qe(557)))
            }
        }
    }
    async function tf(a, b, c, d) {
        var e = "",
            f = n.oneAfmaInstance;
        if (f && (b.preventDefault(), e = (a.ca ? await f.appendClickSignalsAsync(c.href, !0) : await f.appendClickSignalsAsync(c.href)) || "", a.T)) {
            if (a.la) return;
            if (f = await f.getNativeClickMeta()) {
                if (f.customClickGestureEligible) return;
                e = Me(e, "nas", f.encodedNas)
            }
        }
        uf(a, b, c, d, e)
    }

    function uf(a, b, c, d, e) {
        a.S++;
        a.H < 0 && (a.H = Date.now());
        var f = O(a.i, 2),
            g = a.P > 0 ? a.P : 300;
        g = f && Date.now() - a.V > g;
        var k = (d == null ? 0 : J(d, 29)) ? L(d, Sc, 29) : null;
        (a.na || a.da) && k === null && (k = new Sc, R(k, 1, !0), a.da && G(k, 2, Rb(200)));
        var h = n.oneAfmaInstance;
        if (h) {
            b.preventDefault ? b.preventDefault() : b.returnValue = !1;
            c = O(d, 13) ? e : h.logScionEventAndAddParam(e);
            b = c;
            if (!a.F && d && J(d, 12)) {
                e = L(d, Tc, 12).C();
                if (Wc(d).length > 0)
                    for (l of Wc(d));
                var l = L(d, Tc, 12);
                O(l, 2) ? (h.click(b), h.openAndroidApp(e), l = !0) : l = !1
            } else l = !1;
            l || Ne(a.F,
                a.v, a.ha, d, c, h) || Re(f, g, k, a.F, d, c, h, a.O, a.ia)
        } else {
            if (g && (d = c.href) && be(d, "cce")) {
                f = new ma({
                    url: d
                });
                a: {
                    d = f.h.cce;
                    if (d === "1") d = 0;
                    else if (d === "2") d = 1;
                    else {
                        d = null;
                        break a
                    }
                    f = ea(f.i, "cc=1");k = f.indexOf("?");d = k < 0 ? null : {
                        url: "https://www.googleadservices.com/pagead/aclk" + f.slice(k),
                        method: d
                    }
                }
                d && (d.method === 0 ? navigator.sendBeacon && navigator.sendBeacon(d.url, "") : d.method === 1 && Ka(d.url))
            }
            d = window;
            a.ka && d.pawsig && typeof d.pawsig.clk === "function" ? (ue("paw_sigs", {
                msg: "click",
                count: a.S.toString(),
                elapsed: (Date.now() -
                    a.H).toString()
            }), g && d.pawsig.clk(c)) : g && (d = Qe(c.href), d !== c.href && Ea(c, pe(d, qe(599))))
        }
        g && (a.V = Date.now());
        Dd(a.U)
    }
    var of = class {
        constructor(a) {
            this.F = Ta || Ra || Ua || Sa;
            var b = xe("data-asoch-meta");
            if (b.length !== 1) ue("gdn-asoch", {
                type: 2,
                data: b.length
            });
            else {
                this.U = 70;
                this.i = new Zc(JSON.parse(b[0].getAttribute("data-asoch-meta")) || []);
                this.R = a["extra-meta"] ? new Zc(JSON.parse(a["extra-meta"])) : null;
                this.T = a["is-fsn"] === "true";
                this.la = a["is-tap-disabled-for-fsn"] === "true";
                this.I = (b = a.nm ? $c(a.nm) : null) ? Q(b, 4) != 0 : !1;
                this.ma = b ? O(b, 5) : !1;
                this.v = a["ios-store-overlay-config"] ? new Qc(JSON.parse(a["ios-store-overlay-config"])) :
                    null;
                this.ha = a["enable-alleyoop-interactions"] === "true";
                this.na = a["use-cct-over-browser"] === "true";
                this.ia = a["enable-lock-screen-ad-custom-webview"] === "true";
                this.da = a["use-half-page-cct-over-browser"] === "true";
                this.aa = a["correct-redirect-url-for-och-15-click"] === "true";
                this.ca = a["use-click-signals-json"] === "true";
                this.L = a["default-msg-in-och"] === "true";
                this.ka = a["enable-paw"] === "true";
                this.O = a["allow-redirection-muted-in-och"] === "true";
                this.P = Number(a["custom-async-tracking-throttle-interval"]) ||
                    -1;
                this.G = "";
                b = kf();
                b != null && b.then(e => {
                    var f = Lc(e);
                    e = [];
                    var g = 0;
                    for (var k = 0; k < f.length; k++) {
                        var h = f.charCodeAt(k);
                        if (h > 255) {
                            var l = Error("go/unicode-to-byte-error");
                            Ma && La(l);
                            e[g++] = h & 255;
                            h >>= 8
                        }
                        e[g++] = h
                    }
                    f = 3;
                    f === void 0 && (f = 0);
                    if (!Wa)
                        for (Wa = {}, g = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), k = ["+/=", "+/", "-_=", "-_.", "-_"], h = 0; h < 5; h++) {
                            l = g.concat(k[h].split(""));
                            Va[h] = l;
                            for (var m = 0; m < l.length; m++) {
                                var p = l[m];
                                Wa[p] === void 0 && (Wa[p] = m)
                            }
                        }
                    f = Va[f];
                    g = Array(Math.floor(e.length /
                        3));
                    k = f[64] || "";
                    for (h = l = 0; l < e.length - 2; l += 3) {
                        var q = e[l],
                            r = e[l + 1];
                        p = e[l + 2];
                        m = f[q >> 2];
                        q = f[(q & 3) << 4 | r >> 4];
                        r = f[(r & 15) << 2 | p >> 6];
                        p = f[p & 63];
                        g[h++] = m + q + r + p
                    }
                    m = 0;
                    p = k;
                    switch (e.length - l) {
                        case 2:
                            m = e[l + 1], p = f[(m & 15) << 2] || k;
                        case 1:
                            e = e[l], g[h] = f[e >> 2] + f[(e & 3) << 4 | m >> 4] + p + k
                    }
                    this.G = g.join("")
                });
                this.h = Fe(this.i, []);
                this.j = null;
                this.N = od("A");
                this.L && pf(this);
                this.oa = Number(a["deeplink-and-android-app-validation-timeout"]) || 500;
                this.V = -Infinity;
                this.H = this.S = 0;
                this.m = P(this.i, 5) || "";
                this.Z = O(this.i, 11);
                this.R && (this.Z =
                    O(this.R, 11));
                this.K = this.ba = this.W = this.X = this.Y = this.J = null;
                O(this.i, 3) || (Ie(this.h), R(this.i, 3, !0));
                lf(this.h);
                a = n.oneAfmaInstance;
                !this.F && a && Ke(this.h, this.oa);
                var c;
                if (a && ((c = this.v) == null ? 0 : O(c, 2))) switch (c = () => {
                    var e = Ic(this.v, 4);
                    e > 0 ? n.setTimeout(() => {
                        Je(this.h)
                    }, e) : Je(this.h)
                }, Q(this.v, 3)) {
                    case 1:
                        a.runOnOnShowEvent(c);
                        break;
                    case 2:
                        vd(c);
                        break;
                    default:
                        Je(this.h)
                }
                if (a && this.I) {
                    pf(this);
                    if (!this.j) return;
                    W(X, "touchstart", f => {
                        this.W = f
                    }, qd);
                    var d;
                    let e;
                    (d = we.AFMA_Communicator) == null || (e = d.addEventListener) ==
                        null || e.call(d, "onCustomClickGesture", () => {
                            qf(this, this.W || new Event("touchstart"))
                        })
                }
                W(X, "click", te(557, e => {
                    qf(this, e)
                }), qd);
                W(X, "auxclick", te(557, e => {
                    e.button === 1 && qf(this, e)
                }), qd);
                this.m && typeof window.ss === "function" && W(X.body, "mouseover", te(626, () => {
                    window.ss(this.m, 0)
                }), rd);
                typeof window.ivti === "function" && window.ivti(X.body);
                d = window;
                d.googqscp && typeof d.googqscp.registerCallback === "function" && d.googqscp.registerCallback((e, f, g, k, h) => {
                    this.J = e;
                    this.K = f;
                    this.Y = g;
                    this.X = k;
                    this.ba = h
                });
                Ad()
            }
        }
    };
    var vf = te(555, a => nf(a));
    zd = 70;
    var wf = Bd(70, document.currentScript);
    if (wf == null) throw Error("JSC not found 70");
    var xf = {},
        yf = wf.attributes;
    for (let a = yf.length - 1; a >= 0; a--) {
        let b = yf[a].name;
        b.indexOf("data-jcp-") === 0 && (xf[b.substring(9)] = yf[a].value)
    }
    vf(xf);
}).call(this);
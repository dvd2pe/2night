(function() {
    var m, aa = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        n = function(a) {
            var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
            return b ? b.call(a) : {
                next: aa(a)
            }
        },
        ba = function(a) {
            for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
            return c
        },
        ca = "function" == typeof Object.create ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        da;
    if ("function" == typeof Object.setPrototypeOf) da = Object.setPrototypeOf;
    else {
        var ea;
        a: {
            var fa = {
                    Ga: !0
                },
                ia = {};
            try {
                ia.__proto__ = fa;
                ea = ia.Ga;
                break a
            } catch (a) {}
            ea = !1
        }
        da = ea ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var ja = da,
        ka = function(a, b) {
            a.prototype = ca(b.prototype);
            a.prototype.constructor = a;
            if (ja) ja(a, b);
            else
                for (var c in b)
                    if ("prototype" != c)
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.na = b.prototype
        },
        la = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a, b, c) {
            a != Array.prototype && a != Object.prototype && (a[b] = c.value)
        },
        p = "undefined" != typeof window && window === this ? this : "undefined" != typeof global && null != global ? global :
        this,
        ma = function(a, b) {
            if (b) {
                var c = p;
                a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    e in c || (c[e] = {});
                    c = c[e]
                }
                a = a[a.length - 1];
                d = c[a];
                b = b(d);
                b != d && null != b && la(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        },
        q = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        na = function() {
            na = function() {};
            p.Symbol || (p.Symbol = oa)
        },
        oa = function() {
            var a = 0;
            return function(b) {
                return "jscomp_symbol_" + (b || "") + a++
            }
        }(),
        qa = function() {
            na();
            var a = p.Symbol.iterator;
            a || (a = p.Symbol.iterator = p.Symbol("iterator"));
            "function" !=
            typeof Array.prototype[a] && la(Array.prototype, a, {
                configurable: !0,
                writable: !0,
                value: function() {
                    return pa(aa(this))
                }
            });
            qa = function() {}
        },
        pa = function(a) {
            qa();
            a = {
                next: a
            };
            a[p.Symbol.iterator] = function() {
                return this
            };
            return a
        };
    ma("WeakMap", function(a) {
        function b() {}

        function c(a) {
            q(a, e) || la(a, e, {
                value: new b
            })
        }

        function d(a) {
            var d = Object[a];
            d && (Object[a] = function(a) {
                if (a instanceof b) return a;
                c(a);
                return d(a)
            })
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var b = Object.seal({}),
                        c = Object.seal({}),
                        d = new a([
                            [b, 2],
                            [c, 3]
                        ]);
                    if (2 != d.get(b) || 3 != d.get(c)) return !1;
                    d["delete"](b);
                    d.set(c, 4);
                    return !d.has(b) && 4 == d.get(c)
                } catch (x) {
                    return !1
                }
            }()) return a;
        var e = "$jscomp_hidden_" + Math.random();
        d("freeze");
        d("preventExtensions");
        d("seal");
        var f = 0,
            g = function(a) {
                this.U = (f += Math.random() + 1).toString();
                if (a) {
                    a = n(a);
                    for (var b; !(b = a.next()).done;) b = b.value, this.set(b[0], b[1])
                }
            };
        g.prototype.set = function(a, b) {
            c(a);
            if (!q(a, e)) throw Error("WeakMap key fail: " + a);
            a[e][this.U] = b;
            return this
        };
        g.prototype.get = function(a) {
            return q(a, e) ? a[e][this.U] : void 0
        };
        g.prototype.has = function(a) {
            return q(a, e) && q(a[e], this.U)
        };
        g.prototype["delete"] = function(a) {
            return q(a, e) && q(a[e], this.U) ? delete a[e][this.U] : !1
        };
        return g
    });
    ma("Map", function(a) {
        if (function() {
                if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
                try {
                    var b = Object.seal({
                            x: 4
                        }),
                        c = new a(n([
                            [b, "s"]
                        ]));
                    if ("s" != c.get(b) || 1 != c.size || c.get({
                            x: 4
                        }) || c.set({
                            x: 4
                        }, "t") != c || 2 != c.size) return !1;
                    var d = c.entries(),
                        e = d.next();
                    if (e.done || e.value[0] != b || "s" != e.value[1]) return !1;
                    e = d.next();
                    return e.done || 4 != e.value[0].x || "t" != e.value[1] || !d.next().done ? !1 : !0
                } catch (t) {
                    return !1
                }
            }()) return a;
        qa();
        var b = new WeakMap,
            c = function(a) {
                this.S = {};
                this.g =
                    f();
                this.size = 0;
                if (a) {
                    a = n(a);
                    for (var b; !(b = a.next()).done;) b = b.value, this.set(b[0], b[1])
                }
            };
        c.prototype.set = function(a, b) {
            a = 0 === a ? 0 : a;
            var c = d(this, a);
            c.list || (c.list = this.S[c.id] = []);
            c.f ? c.f.value = b : (c.f = {
                next: this.g,
                w: this.g.w,
                head: this.g,
                key: a,
                value: b
            }, c.list.push(c.f), this.g.w.next = c.f, this.g.w = c.f, this.size++);
            return this
        };
        c.prototype["delete"] = function(a) {
            a = d(this, a);
            return a.f && a.list ? (a.list.splice(a.index, 1), a.list.length || delete this.S[a.id], a.f.w.next = a.f.next, a.f.next.w = a.f.w, a.f.head = null,
                this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this.S = {};
            this.g = this.g.w = f();
            this.size = 0
        };
        c.prototype.has = function(a) {
            return !!d(this, a).f
        };
        c.prototype.get = function(a) {
            return (a = d(this, a).f) && a.value
        };
        c.prototype.entries = function() {
            return e(this, function(a) {
                return [a.key, a.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(a) {
                return a.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(a) {
                return a.value
            })
        };
        c.prototype.forEach = function(a, b) {
            for (var c = this.entries(), d; !(d = c.next()).done;) d =
                d.value, a.call(b, d[1], d[0], this)
        };
        c.prototype[Symbol.iterator] = c.prototype.entries;
        var d = function(a, c) {
                var d = c && typeof c;
                "object" == d || "function" == d ? b.has(c) ? d = b.get(c) : (d = "" + ++g, b.set(c, d)) : d = "p_" + c;
                var e = a.S[d];
                if (e && q(a.S, d))
                    for (a = 0; a < e.length; a++) {
                        var f = e[a];
                        if (c !== c && f.key !== f.key || c === f.key) return {
                            id: d,
                            list: e,
                            index: a,
                            f: f
                        }
                    }
                return {
                    id: d,
                    list: e,
                    index: -1,
                    f: void 0
                }
            },
            e = function(a, b) {
                var c = a.g;
                return pa(function() {
                    if (c) {
                        for (; c.head != a.g;) c = c.w;
                        for (; c.next != c.head;) return c = c.next, {
                            done: !1,
                            value: b(c)
                        };
                        c = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var a = {};
                return a.w = a.next = a.head = a
            },
            g = 0;
        return c
    });
    ma("Number.isFinite", function(a) {
        return a ? a : function(a) {
            return "number" !== typeof a ? !1 : !isNaN(a) && Infinity !== a && -Infinity !== a
        }
    });
    ma("Number.isInteger", function(a) {
        return a ? a : function(a) {
            return Number.isFinite(a) ? a === Math.floor(a) : !1
        }
    });
    var r = this,
        u = function(a) {
            return "string" == typeof a
        },
        v = function(a) {
            return "number" == typeof a
        },
        w = function() {},
        y = function(a) {
            var b = typeof a;
            if ("object" == b)
                if (a) {
                    if (a instanceof Array) return "array";
                    if (a instanceof Object) return b;
                    var c = Object.prototype.toString.call(a);
                    if ("[object Window]" == c) return "object";
                    if ("[object Array]" == c || "number" == typeof a.length && "undefined" != typeof a.splice && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("splice")) return "array";
                    if ("[object Function]" == c ||
                        "undefined" != typeof a.call && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("call")) return "function"
                } else return "null";
            else if ("function" == b && "undefined" == typeof a.call) return "object";
            return b
        },
        z = function(a) {
            var b = y(a);
            return "array" == b || "object" == b && "number" == typeof a.length
        },
        A = function(a) {
            return "function" == y(a)
        },
        ra = function(a) {
            var b = typeof a;
            return "object" == b && null != a || "function" == b
        },
        sa = function(a, b, c) {
            return a.call.apply(a.bind, arguments)
        },
        ta = function(a, b, c) {
            if (!a) throw Error();
            if (2 < arguments.length) {
                var d = Array.prototype.slice.call(arguments, 2);
                return function() {
                    var c = Array.prototype.slice.call(arguments);
                    Array.prototype.unshift.apply(c, d);
                    return a.apply(b, c)
                }
            }
            return function() {
                return a.apply(b, arguments)
            }
        },
        ua = function(a, b, c) {
            ua = Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ? sa : ta;
            return ua.apply(null, arguments)
        },
        va = Date.now || function() {
            return +new Date
        },
        wa = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.na = b.prototype;
            a.prototype =
                new c;
            a.prototype.constructor = a;
            a.Za = function(a, c, f) {
                for (var d = Array(arguments.length - 2), e = 2; e < arguments.length; e++) d[e - 2] = arguments[e];
                return b.prototype[c].apply(a, d)
            }
        };
    var C = function(a) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, C);
        else {
            var b = Error().stack;
            b && (this.stack = b)
        }
        a && (this.message = String(a))
    };
    wa(C, Error);
    C.prototype.name = "CustomError";
    var ya = Array.prototype.indexOf ? function(a, b) {
            return Array.prototype.indexOf.call(a, b, void 0)
        } : function(a, b) {
            if (u(a)) return u(b) && 1 == b.length ? a.indexOf(b, 0) : -1;
            for (var c = 0; c < a.length; c++)
                if (c in a && a[c] === b) return c;
            return -1
        },
        za = Array.prototype.forEach ? function(a, b, c) {
            Array.prototype.forEach.call(a, b, c)
        } : function(a, b, c) {
            for (var d = a.length, e = u(a) ? a.split("") : a, f = 0; f < d; f++) f in e && b.call(c, e[f], f, a)
        },
        Ca = function(a) {
            var b = document;
            b = Aa(b.querySelectorAll && b.querySelector ? b.querySelectorAll(".GoogleActiveViewClass") :
                Ba());
            a: {
                for (var c = b.length, d = u(b) ? b.split("") : b, e = 0; e < c; e++)
                    if (e in d && a.call(void 0, d[e], e, b)) {
                        a = e;
                        break a
                    }
                a = -1
            }
            return 0 > a ? null : u(b) ? b.charAt(a) : b[a]
        },
        Da = function(a) {
            return Array.prototype.concat.apply([], arguments)
        },
        Aa = function(a) {
            var b = a.length;
            if (0 < b) {
                for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
                return c
            }
            return []
        };
    var Ea = String.prototype.trim ? function(a) {
            return a.trim()
        } : function(a) {
            return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
        },
        Fa = function(a, b) {
            return a < b ? -1 : a > b ? 1 : 0
        },
        Ga = function() {
            return "opacity".replace(/\-([a-z])/g, function(a, b) {
                return b.toUpperCase()
            })
        },
        Ha = function(a) {
            var b = u(void 0) ? "undefined".replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g, "\\$1").replace(/\x08/g, "\\x08") : "\\s";
            return a.replace(new RegExp("(^" + (b ? "|[" + b + "]+" : "") + ")([a-z])", "g"), function(a, b, e) {
                return b + e.toUpperCase()
            })
        };
    var D;
    a: {
        var Ia = r.navigator;
        if (Ia) {
            var Ja = Ia.userAgent;
            if (Ja) {
                D = Ja;
                break a
            }
        }
        D = ""
    }
    var E = function(a) {
        return -1 != D.indexOf(a)
    };
    var Ka = function(a, b) {
        for (var c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    };
    var La = function(a) {
        La[" "](a);
        return a
    };
    La[" "] = w;
    var Ma = function(a, b) {
        try {
            return La(a[b]), !0
        } catch (c) {}
        return !1
    };
    var Na = E("Opera"),
        F = E("Trident") || E("MSIE"),
        Oa = E("Edge"),
        Pa = E("Gecko") && !(-1 != D.toLowerCase().indexOf("webkit") && !E("Edge")) && !(E("Trident") || E("MSIE")) && !E("Edge"),
        Qa = -1 != D.toLowerCase().indexOf("webkit") && !E("Edge"),
        Ra = function() {
            var a = r.document;
            return a ? a.documentMode : void 0
        },
        Sa;
    a: {
        var Ta = "",
            Ua = function() {
                var a = D;
                if (Pa) return /rv:([^\);]+)(\)|;)/.exec(a);
                if (Oa) return /Edge\/([\d\.]+)/.exec(a);
                if (F) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
                if (Qa) return /WebKit\/(\S+)/.exec(a);
                if (Na) return /(?:Version)[ \/]?(\S+)/.exec(a)
            }();Ua && (Ta = Ua ? Ua[1] : "");
        if (F) {
            var Va = Ra();
            if (null != Va && Va > parseFloat(Ta)) {
                Sa = String(Va);
                break a
            }
        }
        Sa = Ta
    }
    var Wa = Sa,
        Xa = {},
        Ya;
    var Za = r.document;
    Ya = Za && F ? Ra() || ("CSS1Compat" == Za.compatMode ? parseInt(Wa, 10) : 5) : void 0;
    var $a = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
    var G = function(a, b) {
        this.Aa = a === ab && b || "";
        this.Ea = cb
    };
    G.prototype.toString = function() {
        return "Const{" + this.Aa + "}"
    };
    var cb = {},
        ab = {};
    var eb = function() {
            this.wa = "";
            this.Fa = db
        },
        db = {};
    var Ba = function() {
            var a, b;
            var c = document;
            if (c.querySelectorAll && c.querySelector) return c.querySelectorAll(".GoogleActiveViewClass");
            if (c.getElementsByClassName) {
                var d = c.getElementsByClassName("GoogleActiveViewClass");
                return d
            }
            d = c.getElementsByTagName("*");
            var e = {};
            for (a = b = 0; c = d[a]; a++) {
                var f = c.className,
                    g;
                if (g = "function" == typeof f.split) g = 0 <= ya(f.split(/\s+/), "GoogleActiveViewClass");
                g && (e[b++] = c)
            }
            e.length = b;
            return e
        },
        fb = function(a) {
            return 9 == a.nodeType ? a : a.ownerDocument || a.document
        };
    var gb = function(a, b) {
        this.Qa = 100;
        this.Ia = a;
        this.Ua = b;
        this.aa = 0;
        this.g = null
    };
    gb.prototype.get = function() {
        if (0 < this.aa) {
            this.aa--;
            var a = this.g;
            this.g = a.next;
            a.next = null
        } else a = this.Ia();
        return a
    };
    gb.prototype.put = function(a) {
        this.Ua(a);
        this.aa < this.Qa && (this.aa++, a.next = this.g, this.g = a)
    };
    var hb = function(a) {
            r.setTimeout(function() {
                throw a;
            }, 0)
        },
        ib, jb = function() {
            var a = r.MessageChannel;
            "undefined" === typeof a && "undefined" !== typeof window && window.postMessage && window.addEventListener && !E("Presto") && (a = function() {
                var a = document.createElement("IFRAME");
                a.style.display = "none";
                a.src = "";
                document.documentElement.appendChild(a);
                var b = a.contentWindow;
                a = b.document;
                a.open();
                a.write("");
                a.close();
                var c = "callImmediate" + Math.random(),
                    d = "file:" == b.location.protocol ? "*" : b.location.protocol + "//" + b.location.host;
                a = ua(function(a) {
                    if (("*" == d || a.origin == d) && a.data == c) this.port1.onmessage()
                }, this);
                b.addEventListener("message", a, !1);
                this.port1 = {};
                this.port2 = {
                    postMessage: function() {
                        b.postMessage(c, d)
                    }
                }
            });
            if ("undefined" !== typeof a && !E("Trident") && !E("MSIE")) {
                var b = new a,
                    c = {},
                    d = c;
                b.port1.onmessage = function() {
                    if (void 0 !== c.next) {
                        c = c.next;
                        var a = c.qa;
                        c.qa = null;
                        a()
                    }
                };
                return function(a) {
                    d.next = {
                        qa: a
                    };
                    d = d.next;
                    b.port2.postMessage(0)
                }
            }
            return "undefined" !== typeof document && "onreadystatechange" in document.createElement("SCRIPT") ?
                function(a) {
                    var b = document.createElement("SCRIPT");
                    b.onreadystatechange = function() {
                        b.onreadystatechange = null;
                        b.parentNode.removeChild(b);
                        b = null;
                        a();
                        a = null
                    };
                    document.documentElement.appendChild(b)
                } : function(a) {
                    r.setTimeout(a, 0)
                }
        };
    var kb = function() {
            this.fa = this.O = null
        },
        mb = new gb(function() {
            return new lb
        }, function(a) {
            a.reset()
        });
    kb.prototype.add = function(a, b) {
        var c = mb.get();
        c.set(a, b);
        this.fa ? this.fa.next = c : this.O = c;
        this.fa = c
    };
    kb.prototype.remove = function() {
        var a = null;
        this.O && (a = this.O, this.O = this.O.next, this.O || (this.fa = null), a.next = null);
        return a
    };
    var lb = function() {
        this.next = this.scope = this.ja = null
    };
    lb.prototype.set = function(a, b) {
        this.ja = a;
        this.scope = b;
        this.next = null
    };
    lb.prototype.reset = function() {
        this.next = this.scope = this.ja = null
    };
    var rb = function(a, b) {
            nb || ob();
            pb || (nb(), pb = !0);
            qb.add(a, b)
        },
        nb, ob = function() {
            if (r.Promise && r.Promise.resolve) {
                var a = r.Promise.resolve(void 0);
                nb = function() {
                    a.then(sb)
                }
            } else nb = function() {
                var a = sb;
                !A(r.setImmediate) || r.Window && r.Window.prototype && !E("Edge") && r.Window.prototype.setImmediate == r.setImmediate ? (ib || (ib = jb()), ib(a)) : r.setImmediate(a)
            }
        },
        pb = !1,
        qb = new kb,
        sb = function() {
            for (var a; a = qb.remove();) {
                try {
                    a.ja.call(a.scope)
                } catch (b) {
                    hb(b)
                }
                mb.put(a)
            }
            pb = !1
        };
    var I = function(a) {
            this.u = 0;
            this.xa = void 0;
            this.K = this.A = this.H = null;
            this.$ = this.ia = !1;
            if (a != w) try {
                var b = this;
                a.call(void 0, function(a) {
                    H(b, 2, a)
                }, function(a) {
                    H(b, 3, a)
                })
            } catch (c) {
                H(this, 3, c)
            }
        },
        tb = function() {
            this.next = this.context = this.M = this.V = this.D = null;
            this.Z = !1
        };
    tb.prototype.reset = function() {
        this.context = this.M = this.V = this.D = null;
        this.Z = !1
    };
    var ub = new gb(function() {
            return new tb
        }, function(a) {
            a.reset()
        }),
        vb = function(a, b, c) {
            var d = ub.get();
            d.V = a;
            d.M = b;
            d.context = c;
            return d
        };
    I.prototype.then = function(a, b, c) {
        return wb(this, A(a) ? a : null, A(b) ? b : null, c)
    };
    I.prototype.$goog_Thenable = !0;
    I.prototype.cancel = function(a) {
        0 == this.u && rb(function() {
            var b = new J(a);
            xb(this, b)
        }, this)
    };
    var xb = function(a, b) {
            if (0 == a.u)
                if (a.H) {
                    var c = a.H;
                    if (c.A) {
                        for (var d = 0, e = null, f = null, g = c.A; g && (g.Z || (d++, g.D == a && (e = g), !(e && 1 < d))); g = g.next) e || (f = g);
                        e && (0 == c.u && 1 == d ? xb(c, b) : (f ? (d = f, d.next == c.K && (c.K = d), d.next = d.next.next) : yb(c), zb(c, e, 3, b)))
                    }
                    a.H = null
                } else H(a, 3, b)
        },
        Bb = function(a, b) {
            a.A || 2 != a.u && 3 != a.u || Ab(a);
            a.K ? a.K.next = b : a.A = b;
            a.K = b
        },
        wb = function(a, b, c, d) {
            var e = vb(null, null, null);
            e.D = new I(function(a, g) {
                e.V = b ? function(c) {
                    try {
                        var e = b.call(d, c);
                        a(e)
                    } catch (k) {
                        g(k)
                    }
                } : a;
                e.M = c ? function(b) {
                    try {
                        var e = c.call(d,
                            b);
                        void 0 === e && b instanceof J ? g(b) : a(e)
                    } catch (k) {
                        g(k)
                    }
                } : g
            });
            e.D.H = a;
            Bb(a, e);
            return e.D
        };
    I.prototype.Xa = function(a) {
        this.u = 0;
        H(this, 2, a)
    };
    I.prototype.Ya = function(a) {
        this.u = 0;
        H(this, 3, a)
    };
    var H = function(a, b, c) {
            if (0 == a.u) {
                a === c && (b = 3, c = new TypeError("Promise cannot resolve to itself"));
                a.u = 1;
                a: {
                    var d = c,
                        e = a.Xa,
                        f = a.Ya;
                    if (d instanceof I) {
                        Bb(d, vb(e || w, f || null, a));
                        var g = !0
                    } else {
                        if (d) try {
                            var h = !!d.$goog_Thenable
                        } catch (k) {
                            h = !1
                        } else h = !1;
                        if (h) d.then(e, f, a), g = !0;
                        else {
                            if (ra(d)) try {
                                var l = d.then;
                                if (A(l)) {
                                    Cb(d, l, e, f, a);
                                    g = !0;
                                    break a
                                }
                            } catch (k) {
                                f.call(a, k);
                                g = !0;
                                break a
                            }
                            g = !1
                        }
                    }
                }
                g || (a.xa = c, a.u = b, a.H = null, Ab(a), 3 != b || c instanceof J || Db(a, c))
            }
        },
        Cb = function(a, b, c, d, e) {
            var f = !1,
                g = function(a) {
                    f || (f = !0, c.call(e,
                        a))
                },
                h = function(a) {
                    f || (f = !0, d.call(e, a))
                };
            try {
                b.call(a, g, h)
            } catch (l) {
                h(l)
            }
        },
        Ab = function(a) {
            a.ia || (a.ia = !0, rb(a.Ma, a))
        },
        yb = function(a) {
            var b = null;
            a.A && (b = a.A, a.A = b.next, b.next = null);
            a.A || (a.K = null);
            return b
        };
    I.prototype.Ma = function() {
        for (var a; a = yb(this);) zb(this, a, this.u, this.xa);
        this.ia = !1
    };
    var zb = function(a, b, c, d) {
            if (3 == c && b.M && !b.Z)
                for (; a && a.$; a = a.H) a.$ = !1;
            if (b.D) b.D.H = null, Eb(b, c, d);
            else try {
                b.Z ? b.V.call(b.context) : Eb(b, c, d)
            } catch (e) {
                Fb.call(null, e)
            }
            ub.put(b)
        },
        Eb = function(a, b, c) {
            2 == b ? a.V.call(a.context, c) : a.M && a.M.call(a.context, c)
        },
        Db = function(a, b) {
            a.$ = !0;
            rb(function() {
                a.$ && Fb.call(null, b)
            })
        },
        Fb = hb,
        J = function(a) {
            C.call(this, a)
        };
    wa(J, C);
    J.prototype.name = "cancel";
    var Gb = function(a, b, c) {
        this.Sa = a;
        this.resolve = b;
        this.reject = c
    };
    var K = "StopIteration" in r ? r.StopIteration : {
            message: "StopIteration",
            stack: ""
        },
        L = function() {};
    L.prototype.next = function() {
        throw K;
    };
    L.prototype.ga = function() {
        return this
    };
    var Hb = function(a) {
            if (a instanceof L) return a;
            if ("function" == typeof a.ga) return a.ga(!1);
            if (z(a)) {
                var b = 0,
                    c = new L;
                c.next = function() {
                    for (;;) {
                        if (b >= a.length) throw K;
                        if (b in a) return a[b++];
                        b++
                    }
                };
                return c
            }
            throw Error("Not implemented");
        },
        Ib = function(a, b) {
            if (z(a)) try {
                za(a, b, void 0)
            } catch (c) {
                if (c !== K) throw c;
            } else {
                a = Hb(a);
                try {
                    for (;;) b.call(void 0, a.next(), void 0, a)
                } catch (c) {
                    if (c !== K) throw c;
                }
            }
        },
        Jb = function(a, b) {
            var c = 1;
            Ib(a, function(a) {
                c = b.call(void 0, c, a)
            });
            return c
        },
        Kb = function(a, b) {
            var c = Hb(a);
            a = new L;
            a.next = function() {
                var a = c.next();
                if (b.call(void 0, a, void 0, c)) return a;
                throw K;
            };
            return a
        };
    var Lb = function(a, b) {
        this.s = {};
        this.c = [];
        this.Y = this.b = 0;
        var c = arguments.length;
        if (1 < c) {
            if (c % 2) throw Error("Uneven number of arguments");
            for (var d = 0; d < c; d += 2) this.set(arguments[d], arguments[d + 1])
        } else a && this.addAll(a)
    };
    m = Lb.prototype;
    m.v = function() {
        Mb(this);
        for (var a = [], b = 0; b < this.c.length; b++) a.push(this.s[this.c[b]]);
        return a
    };
    m.B = function() {
        Mb(this);
        return this.c.concat()
    };
    m.R = function(a) {
        return M(this.s, a)
    };
    m.clear = function() {
        this.s = {};
        this.Y = this.b = this.c.length = 0
    };
    m.remove = function(a) {
        return M(this.s, a) ? (delete this.s[a], this.b--, this.Y++, this.c.length > 2 * this.b && Mb(this), !0) : !1
    };
    var Mb = function(a) {
        if (a.b != a.c.length) {
            for (var b = 0, c = 0; b < a.c.length;) {
                var d = a.c[b];
                M(a.s, d) && (a.c[c++] = d);
                b++
            }
            a.c.length = c
        }
        if (a.b != a.c.length) {
            var e = {};
            for (c = b = 0; b < a.c.length;) d = a.c[b], M(e, d) || (a.c[c++] = d, e[d] = 1), b++;
            a.c.length = c
        }
    };
    m = Lb.prototype;
    m.get = function(a, b) {
        return M(this.s, a) ? this.s[a] : b
    };
    m.set = function(a, b) {
        M(this.s, a) || (this.b++, this.c.push(a), this.Y++);
        this.s[a] = b
    };
    m.addAll = function(a) {
        if (a instanceof Lb)
            for (var b = a.B(), c = 0; c < b.length; c++) this.set(b[c], a.get(b[c]));
        else
            for (b in a) this.set(b, a[b])
    };
    m.forEach = function(a, b) {
        for (var c = this.B(), d = 0; d < c.length; d++) {
            var e = c[d],
                f = this.get(e);
            a.call(b, f, e, this)
        }
    };
    m.clone = function() {
        return new Lb(this)
    };
    m.ga = function(a) {
        Mb(this);
        var b = 0,
            c = this.Y,
            d = this,
            e = new L;
        e.next = function() {
            if (c != d.Y) throw Error("The map has changed since the iterator was created");
            if (b >= d.c.length) throw K;
            var e = d.c[b++];
            return a ? e : d.s[e]
        };
        return e
    };
    var M = function(a, b) {
        return Object.prototype.hasOwnProperty.call(a, b)
    };
    var Nb = function(a) {
            if (a.v && "function" == typeof a.v) return a.v();
            if (u(a)) return a.split("");
            if (z(a)) {
                for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
                return b
            }
            b = [];
            c = 0;
            for (d in a) b[c++] = a[d];
            return b
        },
        Ob = function(a, b, c) {
            if (a.forEach && "function" == typeof a.forEach) a.forEach(b, c);
            else if (z(a) || u(a)) za(a, b, c);
            else {
                if (a.B && "function" == typeof a.B) var d = a.B();
                else if (a.v && "function" == typeof a.v) d = void 0;
                else if (z(a) || u(a)) {
                    d = [];
                    for (var e = a.length, f = 0; f < e; f++) d.push(f)
                } else
                    for (f in d = [], e = 0, a) d[e++] = f;
                e = Nb(a);
                f = e.length;
                for (var g = 0; g < f; g++) b.call(c, e[g], d && d[g], a)
            }
        };
    var Pb = /^(?:([^:/?#.]+):)?(?:\/\/(?:([^/?#]*)@)?([^/#?]*?)(?::([0-9]+))?(?=[/#?]|$))?([^?#]+)?(?:\?([^#]*))?(?:#([\s\S]*))?$/,
        Qb = function(a, b) {
            if (a) {
                a = a.split("&");
                for (var c = 0; c < a.length; c++) {
                    var d = a[c].indexOf("="),
                        e = null;
                    if (0 <= d) {
                        var f = a[c].substring(0, d);
                        e = a[c].substring(d + 1)
                    } else f = a[c];
                    b(f, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "")
                }
            }
        };
    var N = function(a) {
        this.m = this.I = this.C = "";
        this.N = null;
        this.G = this.j = "";
        this.i = this.Oa = !1;
        if (a instanceof N) {
            this.i = a.i;
            Rb(this, a.C);
            var b = a.I;
            O(this);
            this.I = b;
            b = a.m;
            O(this);
            this.m = b;
            Sb(this, a.N);
            b = a.j;
            O(this);
            this.j = b;
            Tb(this, a.l.clone());
            a = a.G;
            O(this);
            this.G = a
        } else a && (b = String(a).match(Pb)) ? (this.i = !1, Rb(this, b[1] || "", !0), a = b[2] || "", O(this), this.I = Ub(a), a = b[3] || "", O(this), this.m = Ub(a, !0), Sb(this, b[4]), a = b[5] || "", O(this), this.j = Ub(a, !0), Tb(this, b[6] || "", !0), a = b[7] || "", O(this), this.G = Ub(a)) : (this.i = !1, this.l = new P(null, this.i))
    };
    N.prototype.toString = function() {
        var a = [],
            b = this.C;
        b && a.push(Vb(b, Wb, !0), ":");
        var c = this.m;
        if (c || "file" == b) a.push("//"), (b = this.I) && a.push(Vb(b, Wb, !0), "@"), a.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.N, null != c && a.push(":", String(c));
        if (c = this.j) this.m && "/" != c.charAt(0) && a.push("/"), a.push(Vb(c, "/" == c.charAt(0) ? Xb : Yb, !0));
        (c = this.l.toString()) && a.push("?", c);
        (c = this.G) && a.push("#", Vb(c, Zb));
        return a.join("")
    };
    N.prototype.resolve = function(a) {
        var b = this.clone(),
            c = !!a.C;
        c ? Rb(b, a.C) : c = !!a.I;
        if (c) {
            var d = a.I;
            O(b);
            b.I = d
        } else c = !!a.m;
        c ? (d = a.m, O(b), b.m = d) : c = null != a.N;
        d = a.j;
        if (c) Sb(b, a.N);
        else if (c = !!a.j) {
            if ("/" != d.charAt(0))
                if (this.m && !this.j) d = "/" + d;
                else {
                    var e = b.j.lastIndexOf("/"); - 1 != e && (d = b.j.substr(0, e + 1) + d)
                }
            e = d;
            if (".." == e || "." == e) d = "";
            else if (-1 != e.indexOf("./") || -1 != e.indexOf("/.")) {
                d = 0 == e.lastIndexOf("/", 0);
                e = e.split("/");
                for (var f = [], g = 0; g < e.length;) {
                    var h = e[g++];
                    "." == h ? d && g == e.length && f.push("") : ".." ==
                        h ? ((1 < f.length || 1 == f.length && "" != f[0]) && f.pop(), d && g == e.length && f.push("")) : (f.push(h), d = !0)
                }
                d = f.join("/")
            } else d = e
        }
        c ? (O(b), b.j = d) : c = "" !== a.l.toString();
        c ? Tb(b, a.l.clone()) : c = !!a.G;
        c && (a = a.G, O(b), b.G = a);
        return b
    };
    N.prototype.clone = function() {
        return new N(this)
    };
    var Rb = function(a, b, c) {
            O(a);
            a.C = c ? Ub(b, !0) : b;
            a.C && (a.C = a.C.replace(/:$/, ""))
        },
        Sb = function(a, b) {
            O(a);
            if (b) {
                b = Number(b);
                if (isNaN(b) || 0 > b) throw Error("Bad port number " + b);
                a.N = b
            } else a.N = null
        },
        Tb = function(a, b, c) {
            O(a);
            b instanceof P ? (a.l = b, a.l.ma(a.i)) : (c || (b = Vb(b, $b)), a.l = new P(b, a.i))
        };
    N.prototype.getQuery = function() {
        return this.l.toString()
    };
    var Q = function(a, b, c) {
        O(a);
        a.l.set(b, c);
        return a
    };
    N.prototype.removeParameter = function(a) {
        O(this);
        this.l.remove(a);
        return this
    };
    var O = function(a) {
        if (a.Oa) throw Error("Tried to modify a read-only Uri");
    };
    N.prototype.ma = function(a) {
        this.i = a;
        this.l && this.l.ma(a)
    };
    var Ub = function(a, b) {
            return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : ""
        },
        Vb = function(a, b, c) {
            return u(a) ? (a = encodeURI(a).replace(b, ac), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null
        },
        ac = function(a) {
            a = a.charCodeAt(0);
            return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
        },
        Wb = /[#\/\?@]/g,
        Yb = /[#\?:]/g,
        Xb = /[#\?]/g,
        $b = /[#\?@]/g,
        Zb = /#/g,
        P = function(a, b) {
            this.b = this.a = null;
            this.h = a || null;
            this.i = !!b
        },
        R = function(a) {
            a.a || (a.a = new Lb, a.b = 0, a.h && Qb(a.h, function(b, c) {
                a.add(decodeURIComponent(b.replace(/\+/g,
                    " ")), c)
            }))
        };
    m = P.prototype;
    m.add = function(a, b) {
        R(this);
        this.h = null;
        a = S(this, a);
        var c = this.a.get(a);
        c || this.a.set(a, c = []);
        c.push(b);
        this.b += 1;
        return this
    };
    m.remove = function(a) {
        R(this);
        a = S(this, a);
        return this.a.R(a) ? (this.h = null, this.b -= this.a.get(a).length, this.a.remove(a)) : !1
    };
    m.clear = function() {
        this.a = this.h = null;
        this.b = 0
    };
    m.R = function(a) {
        R(this);
        a = S(this, a);
        return this.a.R(a)
    };
    m.forEach = function(a, b) {
        R(this);
        this.a.forEach(function(c, d) {
            za(c, function(c) {
                a.call(b, c, d, this)
            }, this)
        }, this)
    };
    m.B = function() {
        R(this);
        for (var a = this.a.v(), b = this.a.B(), c = [], d = 0; d < b.length; d++)
            for (var e = a[d], f = 0; f < e.length; f++) c.push(b[d]);
        return c
    };
    m.v = function(a) {
        R(this);
        var b = [];
        if (u(a)) this.R(a) && (b = Da(b, this.a.get(S(this, a))));
        else {
            a = this.a.v();
            for (var c = 0; c < a.length; c++) b = Da(b, a[c])
        }
        return b
    };
    m.set = function(a, b) {
        R(this);
        this.h = null;
        a = S(this, a);
        this.R(a) && (this.b -= this.a.get(a).length);
        this.a.set(a, [b]);
        this.b += 1;
        return this
    };
    m.get = function(a, b) {
        if (!a) return b;
        a = this.v(a);
        return 0 < a.length ? String(a[0]) : b
    };
    m.toString = function() {
        if (this.h) return this.h;
        if (!this.a) return "";
        for (var a = [], b = this.a.B(), c = 0; c < b.length; c++) {
            var d = b[c],
                e = encodeURIComponent(String(d));
            d = this.v(d);
            for (var f = 0; f < d.length; f++) {
                var g = e;
                "" !== d[f] && (g += "=" + encodeURIComponent(String(d[f])));
                a.push(g)
            }
        }
        return this.h = a.join("&")
    };
    m.clone = function() {
        var a = new P;
        a.h = this.h;
        this.a && (a.a = this.a.clone(), a.b = this.b);
        return a
    };
    var S = function(a, b) {
        b = String(b);
        a.i && (b = b.toLowerCase());
        return b
    };
    P.prototype.ma = function(a) {
        a && !this.i && (R(this), this.h = null, this.a.forEach(function(a, c) {
            var b = c.toLowerCase();
            c != b && (this.remove(c), this.remove(b), 0 < a.length && (this.h = null, this.a.set(S(this, b), Aa(a)), this.b += a.length))
        }, this));
        this.i = a
    };
    P.prototype.extend = function(a) {
        for (var b = 0; b < arguments.length; b++) Ob(arguments[b], function(a, b) {
            this.add(b, a)
        }, this)
    };
    var bc = $a(function() {
        var a = !1;
        try {
            var b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
            r.addEventListener("test", null, b)
        } catch (c) {}
        return a
    });

    function cc(a) {
        return a ? a.passive && bc() ? a : a.capture || !1 : !1
    }
    var dc = function(a, b, c) {
        a.addEventListener && a.addEventListener("load", b, cc(c))
    };
    var ec = function(a, b, c) {
        c = void 0 === c ? {} : c;
        this.error = a;
        this.context = b.context;
        this.line = b.line || -1;
        this.msg = b.message || "";
        this.file = b.file || "";
        this.id = b.id || "jserror";
        this.meta = c
    };
    var fc = function(a) {
            try {
                return !!a && null != a.location.href && Ma(a, "foo")
            } catch (b) {
                return !1
            }
        },
        gc = function(a, b) {
            if (a)
                for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b.call(void 0, a[c], c, a)
        };
    var hc = /^https?:\/\/(\w|-)+\.cdn\.ampproject\.(net|org)(\?|\/|$)/,
        ic = function(a, b) {
            this.Ba = a;
            this.Ca = b
        },
        jc = function(a, b) {
            this.url = a;
            this.ra = !!b;
            this.depth = v(void 0) ? void 0 : null
        };
    var kc = function(a, b) {
        a.google_image_requests || (a.google_image_requests = []);
        var c = a.document.createElement("img");
        c.src = b;
        a.google_image_requests.push(c)
    };
    var lc = function() {
            this.sa = 4E3;
            this.W = "&";
            this.Ha = ",$";
            this.da = "trn";
            this.Wa = null;
            this.pa = !1;
            this.P = {};
            this.Ra = 0;
            this.J = []
        },
        mc = function(a, b) {
            var c = {};
            c[a] = b;
            return [c]
        },
        oc = function(a, b, c, d, e) {
            var f = [];
            gc(a, function(a, h) {
                (a = nc(a, b, c, d, e)) && f.push(h + "=" + a)
            });
            return f.join(b)
        },
        nc = function(a, b, c, d, e) {
            if (null == a) return "";
            b = b || "&";
            c = c || ",$";
            "string" == typeof c && (c = c.split(""));
            if (a instanceof Array) {
                if (d = d || 0, d < c.length) {
                    for (var f = [], g = 0; g < a.length; g++) f.push(nc(a[g], b, c, d + 1, e));
                    return f.join(c[d])
                }
            } else if ("object" ==
                typeof a) return e = e || 0, 2 > e ? encodeURIComponent(oc(a, b, c, d, e + 1)) : "...";
            return encodeURIComponent(String(a))
        },
        T = function(a, b, c, d) {
            a.J.push(b);
            a.P[b] = mc(c, d)
        },
        qc = function(a, b, c, d) {
            b = b + "//" + c + d;
            var e = pc(a) - d.length;
            if (0 > e) return "";
            a.J.sort(function(a, b) {
                return a - b
            });
            d = null;
            c = "";
            for (var f = 0; f < a.J.length; f++)
                for (var g = a.J[f], h = a.P[g], l = 0; l < h.length; l++) {
                    if (!e) {
                        d = null == d ? g : d;
                        break
                    }
                    var k = oc(h[l], a.W, a.Ha);
                    if (k) {
                        k = c + k;
                        if (e >= k.length) {
                            e -= k.length;
                            b += k;
                            c = a.W;
                            break
                        } else a.pa && (c = e, k[c - 1] == a.W && --c, b += k.substr(0,
                            c), c = a.W, e = 0);
                        d = null == d ? g : d
                    }
                }
            f = "";
            a.da && null != d && (f = c + a.da + "=" + (a.Wa || d));
            return b + f + ""
        },
        pc = function(a) {
            if (!a.da) return a.sa;
            var b = 1,
                c;
            for (c in a.P) b = c.length > b ? c.length : b;
            return a.sa - a.da.length - b - a.W.length - 1
        };
    var rc = function(a, b, c, d, e) {
        if ((d ? a.Va : Math.random()) < (e || a.Ja)) try {
            if (c instanceof lc) var f = c;
            else f = new lc, gc(c, function(a, b) {
                var c = f,
                    d = c.Ra++;
                a = mc(b, a);
                c.J.push(d);
                c.P[d] = a
            });
            var g = qc(f, a.Ta, a.m, a.j + b + "&");
            g && kc(r, g)
        } catch (h) {}
    };
    var sc = null;
    var tc = function() {
            var a = r.performance;
            return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : va()
        },
        uc = function() {
            var a = void 0 === a ? r : a;
            return (a = a.performance) && a.now ? a.now() : null
        };
    var vc = function(a, b, c) {
        this.label = a;
        this.type = b;
        this.value = c;
        this.duration = 0;
        this.uniqueId = this.label + "_" + this.type + "_" + Math.random();
        this.slotId = void 0
    };
    var U = r.performance,
        wc = !!(U && U.mark && U.measure && U.clearMarks),
        xc = $a(function() {
            var a;
            if (a = wc) {
                var b;
                if (null === sc) {
                    sc = "";
                    try {
                        a = "";
                        try {
                            a = r.top.location.hash
                        } catch (c) {
                            a = r.location.hash
                        }
                        a && (sc = (b = a.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (c) {}
                }
                b = sc;
                a = !!b.indexOf && 0 <= b.indexOf("1337")
            }
            return a
        }),
        zc = function() {
            var a = yc;
            this.T = [];
            this.Na = a || r;
            var b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.T = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.L = xc() || (null != b ? b :
                1 > Math.random())
        };
    zc.prototype.disable = function() {
        this.L = !1;
        this.T != this.Na.google_js_reporting_queue && (xc() && za(this.T, Ac), this.T.length = 0)
    };
    var Ac = function(a) {
        a && U && xc() && (U.clearMarks("goog_" + a.uniqueId + "_start"), U.clearMarks("goog_" + a.uniqueId + "_end"))
    };
    zc.prototype.start = function(a, b) {
        if (!this.L) return null;
        var c = uc() || tc();
        a = new vc(a, b, c);
        b = "goog_" + a.uniqueId + "_start";
        U && xc() && U.mark(b);
        return a
    };
    zc.prototype.end = function(a) {
        if (this.L && v(a.value)) {
            var b = uc() || tc();
            a.duration = b - a.value;
            b = "goog_" + a.uniqueId + "_end";
            U && xc() && U.mark(b);
            this.L && this.T.push(a)
        }
    };
    var Dc = function() {
            var a = Bc;
            this.va = Cc;
            this.La = "jserror";
            this.za = !0;
            this.oa = null;
            this.Ka = this.ta;
            this.ca = void 0 === a ? null : a;
            this.Da = !1
        },
        Fc = function(a, b) {
            try {
                if (a.ca && a.ca.L) {
                    var c = a.ca.start((374).toString(), 3);
                    var d = b();
                    a.ca.end(c)
                } else d = b()
            } catch (f) {
                b = a.za;
                try {
                    Ac(c);
                    var e = Ec(f);
                    b = a.Ka.call(a, 374, e, void 0, void 0)
                } catch (g) {
                    a.ta(217, g)
                }
                if (!b) throw f;
            }
            return d
        },
        Hc = function(a) {
            var b = Gc;
            return function(c) {
                for (var d = [], e = 0; e < arguments.length; ++e) d[e - 0] = arguments[e];
                return Fc(b, function() {
                    return a.apply(void 0,
                        d)
                })
            }
        };
    Dc.prototype.ta = function(a, b, c, d, e) {
        e = e || this.La;
        try {
            var f = new lc;
            f.pa = !0;
            T(f, 1, "context", a);
            b.error && b.meta && b.id || (b = Ec(b));
            b.msg && T(f, 2, "msg", b.msg.substring(0, 512));
            b.file && T(f, 3, "file", b.file);
            0 < b.line && T(f, 4, "line", b.line);
            var g = b.meta || {};
            if (this.oa) try {
                this.oa(g)
            } catch (xa) {}
            if (d) try {
                d(g)
            } catch (xa) {}
            b = [g];
            f.J.push(5);
            f.P[5] = b;
            d = r;
            b = [];
            g = null;
            do {
                var h = d;
                if (fc(h)) {
                    var l = h.location.href;
                    g = h.document && h.document.referrer || null
                } else l = g, g = null;
                b.push(new jc(l || ""));
                try {
                    d = h.parent
                } catch (xa) {
                    d = null
                }
            } while (d &&
                h != d);
            l = 0;
            for (var k = b.length - 1; l <= k; ++l) b[l].depth = k - l;
            h = r;
            if (h.location && h.location.ancestorOrigins && h.location.ancestorOrigins.length == b.length - 1)
                for (k = 1; k < b.length; ++k) {
                    var x = b[k];
                    x.url || (x.url = h.location.ancestorOrigins[k - 1] || "", x.ra = !0)
                }
            var t = new jc(r.location.href, !1);
            h = null;
            var bb = b.length - 1;
            for (x = bb; 0 <= x; --x) {
                var B = b[x];
                !h && hc.test(B.url) && (h = B);
                if (B.url && !B.ra) {
                    t = B;
                    break
                }
            }
            B = null;
            var vd = b.length && b[bb].url;
            0 != t.depth && vd && (B = b[bb]);
            var ha = new ic(t, B);
            ha.Ca && T(f, 6, "top", ha.Ca.url || "");
            T(f,
                7, "url", ha.Ba.url || "");
            rc(this.va, e, f, this.Da, c)
        } catch (xa) {
            try {
                rc(this.va, e, {
                    context: "ecmserr",
                    rctx: a,
                    msg: Ic(xa),
                    url: ha && ha.Ba.url
                }, this.Da, c)
            } catch (Ud) {}
        }
        return this.za
    };
    var Ec = function(a) {
            return new Jc(Ic(a), a.fileName, a.lineNumber)
        },
        Ic = function(a) {
            var b = a.toString();
            a.name && -1 == b.indexOf(a.name) && (b += ": " + a.name);
            a.message && -1 == b.indexOf(a.message) && (b += ": " + a.message);
            if (a.stack) {
                a = a.stack;
                var c = b;
                try {
                    -1 == a.indexOf(c) && (a = c + "\n" + a);
                    for (var d; a != d;) d = a, a = a.replace(/((https?:\/..*\/)[^\/:]*:\d+(?:.|\n)*)\2/, "$1");
                    b = a.replace(/\n */g, "\n")
                } catch (e) {
                    b = c
                }
            }
            return b
        },
        Jc = function(a, b, c) {
            ec.call(this, Error(a), {
                message: a,
                file: void 0 === b ? "" : b,
                line: void 0 === c ? -1 : c
            })
        };
    ka(Jc, ec);

    function Kc(a) {
        return Q(Q(Q(new N("//pagead2.googlesyndication.com/pagead/gen_204"), "id", "sodar"), "v", 36), "t", a)
    }
    var V = function(a, b, c, d, e) {
            var f = Kc(1);
            Q(f, "e", a);
            c && Q(f, "li", c);
            d && Q(f, "cv", d);
            e && Q(f, "sid", e);
            b && Q(f, "bgai", b);
            kc(window, f.toString())
        },
        Lc = function(a, b, c, d, e, f) {
            c = void 0 === c ? null : c;
            d = void 0 === d ? null : d;
            e = void 0 === e ? null : e;
            f = void 0 === f ? null : f;
            "0.01" < Math.random() || (a = Q(Q(Q(Q(Q(new N("//pagead2.googlesyndication.com/pagead/gen_204"), "id", "sodarir"), "v", 36), "d", a ? 1 : 0), "s", b ? 1 : 0), "f", "0.01"), d && Q(a, "li", d), e && Q(a, "cv", e), f && Q(a, "sid", f), c && Q(a, "bgai", c), kc(window, a.toString()))
        },
        Oc = function() {
            void 0 ===
                Mc && (Mc = Nc())
        },
        Mc, Pc = function() {
            new Oc;
            return Mc || null
        },
        Nc = function() {
            var a = window.GoogleTyFxhY;
            if (!a) return V(13), null;
            if (0 == a.length) return V(1), null;
            a = a.shift();
            return (a._scs_ || a._cv_ || a._sid_) && a._bgu_ && a._bgp_ ? a : (V(2), null)
        },
        Rc = function(a, b) {
            return function() {
                try {
                    return a.apply(this, arguments)
                } catch (g) {
                    if (!(1 <= Qc.count)) {
                        var c = g,
                            d = Kc(3),
                            e = Pc()._scs_,
                            f = Pc()._sid_;
                        e && Q(d, "bgai", e);
                        f && Q(d, "sid", f);
                        Q(d, "c", b);
                        Q(d, "ex", Ic(c));
                        c = d.toString();
                        2E3 < c.length ? V(11, e) : kc(window, c);
                        Qc.count += 1
                    }
                }
            }
        },
        Qc = {
            count: 0
        },
        Sc = function(a, b) {
            b = Rc(b, "i:lh");
            dc(a, b, {
                capture: void 0
            });
            return b
        },
        Tc = function(a, b) {
            var c = b;
            var d = Sc(a, function() {
                if (c) {
                    var b = c;
                    c = null;
                    var f = {
                        capture: void 0
                    };
                    a.removeEventListener && a.removeEventListener("load", d, cc(f));
                    return b.apply(this, arguments)
                }
            })
        },
        Uc = function() {
            return Ca(function(a) {
                return "DIV" == a.tagName && 0 == a.id.lastIndexOf("DfaVisibilityIdentifier_", 0)
            })
        };

    function Vc(a) {
        switch (a) {
            case void 0:
                return 0;
            case !0:
                return 1;
            case !1:
                return 2;
            default:
                return -1
        }
    };
    var Wc = function(a) {
        return !E("Safari") || (E("Chrome") || E("CriOS")) && !E("Edge") || E("Coast") || E("Opera") || E("Edge") || E("Firefox") || E("FxiOS") || E("Silk") || E("Android") ? !0 : (a = (a = fb(a)) && (a ? a.parentWindow || a.defaultView : window), !!(a && a.location && a.location.ancestorOrigins && 0 < a.location.ancestorOrigins.length && a.location.origin == a.location.ancestorOrigins[0]))
    };
    var Xc = function(a, b) {
        this.Pa = b;
        this.ya = null == a;
        this.ua = a
    };
    ka(Xc, L);
    Xc.prototype.next = function() {
        if (this.ya) throw K;
        var a = this.ua || null;
        this.ya = null == a;
        var b;
        if (b = a) {
            b = this.Pa;
            if (Ma(a, "parentElement") && null != a.parentElement && a != a.parentElement) var c = a.parentElement;
            else if (b) {
                var d = void 0 === d ? Wc : d;
                if (d(a)) try {
                    var e = fb(a),
                        f = e && (e ? e.parentWindow || e.defaultView : window),
                        g = f && f.frameElement;
                    c = null == g ? null : g
                } catch (h) {
                    c = null
                } else c = null
            } else c = null;
            b = c
        }
        this.ua = b;
        return a
    };
    var Yc = {};
    var Zc = function(a) {
        var b = 1;
        a = Kb(new Xc(a, !0), function() {
            return 0 < b
        });
        return Jb(a, function(a, d) {
            var c = 1;
            if (Ma(d, "style") && d.style) {
                var f = parseFloat;
                a: {
                    var g = fb(d);
                    if (g.defaultView && g.defaultView.getComputedStyle && (g = g.defaultView.getComputedStyle(d, null))) {
                        g = g.opacity || g.getPropertyValue("opacity") || "";
                        break a
                    }
                    g = ""
                }
                if (!g) {
                    g = d.style[Ga()];
                    if ("undefined" !== typeof g) d = g;
                    else {
                        g = d.style;
                        var h = Yc.opacity;
                        if (!h) {
                            var l = Ga();
                            h = l;
                            void 0 === d.style[l] && (l = (Qa ? "Webkit" : Pa ? "Moz" : F ? "ms" : Na ? "O" : null) + Ha(l), void 0 !==
                                d.style[l] && (h = l));
                            Yc.opacity = h
                        }
                        d = g[h] || ""
                    }
                    g = d
                }
                f = f(g);
                v(f) && !isNaN(f) && (c = f)
            }
            return b = a * c
        })
    };
    var $c = !F || 9 <= Number(Ya),
        ad = !F || 9 <= Number(Ya),
        bd;
    if (bd = F) {
        var cd;
        if (Object.prototype.hasOwnProperty.call(Xa, "9")) cd = Xa["9"];
        else {
            for (var dd = 0, ed = Ea(String(Wa)).split("."), fd = Ea("9").split("."), gd = Math.max(ed.length, fd.length), hd = 0; 0 == dd && hd < gd; hd++) {
                var id = ed[hd] || "",
                    jd = fd[hd] || "";
                do {
                    var W = /(\d*)(\D*)(.*)/.exec(id) || ["", "", "", ""],
                        X = /(\d*)(\D*)(.*)/.exec(jd) || ["", "", "", ""];
                    if (0 == W[0].length && 0 == X[0].length) break;
                    dd = Fa(0 == W[1].length ? 0 : parseInt(W[1], 10), 0 == X[1].length ? 0 : parseInt(X[1], 10)) || Fa(0 == W[2].length, 0 == X[2].length) || Fa(W[2], X[2]);
                    id = W[3];
                    jd = X[3]
                } while (0 == dd)
            }
            cd = Xa["9"] = 0 <= dd
        }
        bd = !cd
    }
    var kd = bd,
        ld = function() {
            if (!r.addEventListener || !Object.defineProperty) return !1;
            var a = !1,
                b = Object.defineProperty({}, "passive", {
                    get: function() {
                        a = !0
                    }
                });
            try {
                r.addEventListener("test", w, b), r.removeEventListener("test", w, b)
            } catch (c) {}
            return a
        }();
    var md = function(a, b) {
        this.type = a;
        this.currentTarget = this.target = b;
        this.defaultPrevented = this.la = !1
    };
    md.prototype.stopPropagation = function() {
        this.la = !0
    };
    md.prototype.preventDefault = function() {
        this.defaultPrevented = !0
    };
    var Y = function(a, b) {
        md.call(this, a ? a.type : "");
        this.relatedTarget = this.currentTarget = this.target = null;
        this.button = this.screenY = this.screenX = this.clientY = this.clientX = this.offsetY = this.offsetX = 0;
        this.key = "";
        this.charCode = this.keyCode = 0;
        this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
        this.state = null;
        this.pointerId = 0;
        this.pointerType = "";
        this.F = null;
        if (a) {
            var c = this.type = a.type,
                d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
            this.target = a.target || a.srcElement;
            this.currentTarget =
                b;
            (b = a.relatedTarget) ? Pa && (Ma(b, "nodeName") || (b = null)): "mouseover" == c ? b = a.fromElement : "mouseout" == c && (b = a.toElement);
            this.relatedTarget = b;
            d ? (this.clientX = void 0 !== d.clientX ? d.clientX : d.pageX, this.clientY = void 0 !== d.clientY ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY = d.screenY || 0) : (this.offsetX = Qa || void 0 !== a.offsetX ? a.offsetX : a.layerX, this.offsetY = Qa || void 0 !== a.offsetY ? a.offsetY : a.layerY, this.clientX = void 0 !== a.clientX ? a.clientX : a.pageX, this.clientY = void 0 !== a.clientY ? a.clientY : a.pageY,
                this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
            this.button = a.button;
            this.keyCode = a.keyCode || 0;
            this.key = a.key || "";
            this.charCode = a.charCode || ("keypress" == c ? a.keyCode : 0);
            this.ctrlKey = a.ctrlKey;
            this.altKey = a.altKey;
            this.shiftKey = a.shiftKey;
            this.metaKey = a.metaKey;
            this.pointerId = a.pointerId || 0;
            this.pointerType = u(a.pointerType) ? a.pointerType : nd[a.pointerType] || "";
            this.state = a.state;
            this.F = a;
            a.defaultPrevented && this.preventDefault()
        }
    };
    wa(Y, md);
    var od = [1, 4, 2],
        nd = {
            2: "touch",
            3: "pen",
            4: "mouse"
        },
        pd = function(a, b) {
            return $c ? a.F.button == b : "click" == a.type ? 0 == b : !!(a.F.button & od[b])
        };
    Y.prototype.stopPropagation = function() {
        Y.na.stopPropagation.call(this);
        this.F.stopPropagation ? this.F.stopPropagation() : this.F.cancelBubble = !0
    };
    Y.prototype.preventDefault = function() {
        Y.na.preventDefault.call(this);
        var a = this.F;
        if (a.preventDefault) a.preventDefault();
        else if (a.returnValue = !1, kd) try {
            if (a.ctrlKey || 112 <= a.keyCode && 123 >= a.keyCode) a.keyCode = -1
        } catch (b) {}
    };
    var qd = "closure_listenable_" + (1E6 * Math.random() | 0),
        rd = 0;
    var sd = function(a, b, c, d, e) {
            this.listener = a;
            this.ba = null;
            this.src = b;
            this.type = c;
            this.capture = !!d;
            this.ka = e;
            this.key = ++rd;
            this.X = this.ha = !1
        },
        td = function(a) {
            a.X = !0;
            a.listener = null;
            a.ba = null;
            a.src = null;
            a.ka = null
        };
    var ud = function(a) {
        this.src = a;
        this.o = {};
        this.ea = 0
    };
    ud.prototype.add = function(a, b, c, d, e) {
        var f = a.toString();
        a = this.o[f];
        a || (a = this.o[f] = [], this.ea++);
        var g = wd(a, b, d, e); - 1 < g ? (b = a[g], c || (b.ha = !1)) : (b = new sd(b, this.src, f, !!d, e), b.ha = c, a.push(b));
        return b
    };
    ud.prototype.remove = function(a, b, c, d) {
        a = a.toString();
        if (!(a in this.o)) return !1;
        var e = this.o[a];
        b = wd(e, b, c, d);
        return -1 < b ? (td(e[b]), Array.prototype.splice.call(e, b, 1), 0 == e.length && (delete this.o[a], this.ea--), !0) : !1
    };
    ud.prototype.hasListener = function(a, b) {
        var c = void 0 !== a,
            d = c ? a.toString() : "",
            e = void 0 !== b;
        return Ka(this.o, function(a) {
            for (var f = 0; f < a.length; ++f)
                if (!(c && a[f].type != d || e && a[f].capture != b)) return !0;
            return !1
        })
    };
    var wd = function(a, b, c, d) {
        for (var e = 0; e < a.length; ++e) {
            var f = a[e];
            if (!f.X && f.listener == b && f.capture == !!c && f.ka == d) return e
        }
        return -1
    };
    var xd = "closure_lm_" + (1E6 * Math.random() | 0),
        yd = {},
        zd = 0,
        Bd = function(a, b, c, d, e) {
            if (d && d.once) Ad(a, b, c, d, e);
            else if ("array" == y(b))
                for (var f = 0; f < b.length; f++) Bd(a, b[f], c, d, e);
            else c = Cd(c), a && a[qd] ? a.$a(b, c, ra(d) ? !!d.capture : !!d, e) : Dd(a, b, c, !1, d, e)
        },
        Dd = function(a, b, c, d, e, f) {
            if (!b) throw Error("Invalid event type");
            var g = ra(e) ? !!e.capture : !!e,
                h = Ed(a);
            h || (a[xd] = h = new ud(a));
            c = h.add(b, c, d, g, f);
            if (!c.ba) {
                d = Fd();
                c.ba = d;
                d.src = a;
                d.listener = c;
                if (a.addEventListener) ld || (e = g), void 0 === e && (e = !1), a.addEventListener(b.toString(),
                    d, e);
                else if (a.attachEvent) a.attachEvent(Gd(b.toString()), d);
                else if (a.addListener && a.removeListener) a.addListener(d);
                else throw Error("addEventListener and attachEvent are unavailable.");
                zd++
            }
        },
        Fd = function() {
            var a = Hd,
                b = ad ? function(c) {
                    return a.call(b.src, b.listener, c)
                } : function(c) {
                    c = a.call(b.src, b.listener, c);
                    if (!c) return c
                };
            return b
        },
        Ad = function(a, b, c, d, e) {
            if ("array" == y(b))
                for (var f = 0; f < b.length; f++) Ad(a, b[f], c, d, e);
            else c = Cd(c), a && a[qd] ? a.ab(b, c, ra(d) ? !!d.capture : !!d, e) : Dd(a, b, c, !0, d, e)
        },
        Gd = function(a) {
            return a in
                yd ? yd[a] : yd[a] = "on" + a
        },
        Jd = function(a, b, c, d) {
            var e = !0;
            if (a = Ed(a))
                if (b = a.o[b.toString()])
                    for (b = b.concat(), a = 0; a < b.length; a++) {
                        var f = b[a];
                        f && f.capture == c && !f.X && (f = Id(f, d), e = e && !1 !== f)
                    }
            return e
        },
        Id = function(a, b) {
            var c = a.listener,
                d = a.ka || a.src;
            if (a.ha && !v(a) && a && !a.X) {
                var e = a.src;
                if (e && e[qd]) e.bb(a);
                else {
                    var f = a.type,
                        g = a.ba;
                    e.removeEventListener ? e.removeEventListener(f, g, a.capture) : e.detachEvent ? e.detachEvent(Gd(f), g) : e.addListener && e.removeListener && e.removeListener(g);
                    zd--;
                    if (f = Ed(e)) {
                        g = a.type;
                        var h;
                        if (h = g in f.o) {
                            h = f.o[g];
                            var l = ya(h, a),
                                k;
                            (k = 0 <= l) && Array.prototype.splice.call(h, l, 1);
                            h = k
                        }
                        h && (td(a), 0 == f.o[g].length && (delete f.o[g], f.ea--));
                        0 == f.ea && (f.src = null, e[xd] = null)
                    } else td(a)
                }
            }
            return c.call(d, b)
        },
        Hd = function(a, b) {
            if (a.X) return !0;
            if (!ad) {
                if (!b) a: {
                    b = ["window", "event"];
                    for (var c = r, d = 0; d < b.length; d++)
                        if (c = c[b[d]], null == c) {
                            b = null;
                            break a
                        }
                    b = c
                }
                d = b;
                b = new Y(d, this);
                c = !0;
                if (!(0 > d.keyCode || void 0 != d.returnValue)) {
                    a: {
                        var e = !1;
                        if (0 == d.keyCode) try {
                            d.keyCode = -1;
                            break a
                        } catch (g) {
                            e = !0
                        }
                        if (e || void 0 == d.returnValue) d.returnValue = !0
                    }
                    d = [];
                    for (e = b.currentTarget; e; e = e.parentNode) d.push(e);a = a.type;
                    for (e = d.length - 1; !b.la && 0 <= e; e--) {
                        b.currentTarget = d[e];
                        var f = Jd(d[e], a, !0, b);
                        c = c && f
                    }
                    for (e = 0; !b.la && e < d.length; e++) b.currentTarget = d[e],
                    f = Jd(d[e], a, !1, b),
                    c = c && f
                }
                return c
            }
            return Id(a, new Y(b, this))
        },
        Ed = function(a) {
            a = a[xd];
            return a instanceof ud ? a : null
        },
        Kd = "__closure_events_fn_" + (1E9 * Math.random() >>> 0),
        Cd = function(a) {
            if (A(a)) return a;
            a[Kd] || (a[Kd] = function(b) {
                return a.handleEvent(b)
            });
            return a[Kd]
        };
    var Ld = function(a) {
        var b = a._scs_,
            c = a._li_,
            d = Uc();
        if (d && d.getBoundingClientRect) {
            var e = 0;
            Bd(d, "mouseover", function() {
                ++e
            });
            Bd(d, "mousedown", function(a) {
                var f = d.getBoundingClientRect(),
                    h = 0;
                pd(a, 0) ? h = 1 : pd(a, 2) ? h = 4 : pd(a, 1) && (h = 2);
                h && a.shiftKey && (h |= 8);
                h && a.altKey && (h |= 16);
                h && a.ctrlKey && (h |= 32);
                var l = Math.floor(100 * Zc(d)),
                    k = Math.floor(a.clientX - f.left);
                f = Math.floor(a.clientY - f.top);
                var x = e;
                a = a.isTrusted;
                var t = document.defaultView && document.defaultView.mozPaintCount;
                t = void 0 === t ? -1 : v(t) && Number.isInteger(t) ?
                    0 > t ? -3 : t : -2;
                l = Q(Q(Q(Q(Q(Q(Q(Q(Q(Q(new N("//pagead2.googlesyndication.com/pagead/gen_204"), "id", "sodarde"), "v", 36), "nx", k), "ny", f), "bgai", b), "mb", h), "ox", l), "nm", x), "tr", Vc(a)), "mz", t);
                c && Q(l, "li", c);
                kc(window, l.toString())
            })
        }
    };
    var Md = document,
        Nd = window;
    var Od = !!window.google_async_iframe_id,
        Z = Od && window.parent || window;
    var Cc, Gc;
    if (Od && !fc(Z)) {
        var Pd = "." + Md.domain;
        try {
            for (; 2 < Pd.split(".").length && !fc(Z);) Md.domain = Pd = Pd.substr(Pd.indexOf(".") + 1), Z = window.parent
        } catch (a) {}
        fc(Z) || (Z = window)
    }
    var yc = Z,
        Bc = new zc;
    Cc = new function() {
        var a = void 0 === a ? Nd : a;
        this.Ta = "http:" === a.location.protocol ? "http:" : "https:";
        this.m = "pagead2.googlesyndication.com";
        this.j = "/pagead/gen_204?id=";
        this.Ja = .01;
        this.Va = Math.random()
    };
    Gc = new Dc;
    "complete" == yc.document.readyState ? yc.google_measure_js_timing || Bc.disable() : Bc.L && dc(yc, function() {
        yc.google_measure_js_timing || Bc.disable()
    });
    var Qd = function() {
        var a, b, c = new I(function(c, e) {
            a = c;
            b = e
        });
        return new Gb(c, a, b)
    }();

    function Rd(a) {
        a: {
            try {
                var b;
                if (!(b = a.contentWindow)) {
                    if (a.contentDocument) {
                        var c = a.contentDocument;
                        var d = c ? c.parentWindow || c.defaultView : window
                    } else d = null;
                    b = d
                }
                var e = b;
                break a
            } catch (f) {}
            e = null
        }
        Qd.resolve([(0 == a.src.indexOf("https:") ? "https" : "http") + "://tpc.googlesyndication.com", e])
    }

    function Sd() {
        for (var a = [new G(ab, "//"), new G(ab, "tpc.googlesyndication.com"), new G(ab, "/sodar/hhrtBw21.html")], b = "", c = 0; c < a.length; c++) {
            var d = a[c];
            b += d instanceof G && d.constructor === G && d.Ea === cb ? d.Aa : "type_error:Const"
        }
        a = new eb;
        a.wa = b;
        b = document.createElement("IFRAME".toString());
        Tc(b, ua(Rd, null, b));
        a instanceof eb && a.constructor === eb && a.Fa === db ? a = a.wa : (y(a), a = "type_error:TrustedResourceUrl");
        b.src = a;
        b.width = "0";
        b.height = "0";
        b.style.display = "none";
        document.body.appendChild(b)
    }

    function Td() {
        Qd.Sa.then(function(a) {
            var b = n(a);
            a = b.next().value;
            b = b.next().value;
            var c = Pc();
            var d = c._scs_;
            var e = c._bgu_,
                f = c._bgp_,
                g = c._li_,
                h = c._cv_;
            c = c._sid_;
            var l = document.location.origin,
                k = {};
            d = (k["0"] = "0", k["1"] = d || "", k["2"] = e.split("/").pop().replace(/\.js/g, ""), k["3"] = f, k["4"] = g || "", k["5"] = h || "", k["8"] = l && "null" != l ? l : "*", k["9"] = c || "", k);
            b ? b.postMessage(d, a) : V(3)
        })
    };
    (function(a, b, c) {
        for (var d = [], e = 2; e < arguments.length; ++e) d[e - 2] = arguments[e];
        Rc(a, b).apply(null, d instanceof Array ? d : ba(n(d)))
    })(function() {
        var a = !!window.postMessage,
            b = !1,
            c = null,
            d = null,
            e = null,
            f = null,
            g = Pc();
        g && (b = !0, c = g._scs_, d = g._li_, e = g._cv_, f = g._sid_, a ? (Sd(), Td()) : V(8, c, d, e, f), setTimeout(Hc(function() {
            return Ld(g)
        }), 0));
        Lc(b, a, c, d, e, f)
    }, "i:i");
}).call(this);
(function() {
    'use strict';
    var aa = Object.defineProperty,
        ba = globalThis;

    function ca(a, b) {
        if (b) a: {
            var c = ba;a = a.split(".");
            for (var d = 0; d < a.length - 1; d++) {
                var e = a[d];
                if (!(e in c)) break a;
                c = c[e]
            }
            a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && aa(c, a, {
                configurable: !0,
                writable: !0,
                value: b
            })
        }
    }
    ca("Symbol.dispose", function(a) {
        return a ? a : Symbol("Symbol.dispose")
    });
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var p = this || self;

    function da(a, b, c) {
        return a.call.apply(a.bind, arguments)
    }

    function r(a, b, c) {
        r = da;
        return r.apply(null, arguments)
    };

    function ea(a) {
        p.setTimeout(() => {
            throw a;
        }, 0)
    };
    var fa, t;
    a: {
        for (var ha = ["CLOSURE_FLAGS"], u = p, ia = 0; ia < ha.length; ia++)
            if (u = u[ha[ia]], u == null) {
                t = null;
                break a
            }
        t = u
    }
    var ja = t && t[748402147];
    fa = ja != null ? ja : !0;

    function ka(a) {
        ka[" "](a);
        return a
    }
    ka[" "] = function() {};

    function la(a, b) {
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = b
    };
    var ma = void 0;

    function na(a, b = !1) {
        return b && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol()
    }
    var oa = na(),
        pa = na("m_m", !0);
    var w = na("jas", !0);
    var qa = {};

    function ra(a, b) {
        return b === void 0 ? a.I !== x && !!(2 & (a.o[w] | 0)) : !!(2 & b) && a.I !== x
    }
    var x = {};

    function A(a) {
        a.ka = !0;
        return a
    };
    var sa = A(a => typeof a === "number"),
        ta = A(a => typeof a === "string"),
        ua = A(a => typeof a === "function");

    function C(a) {
        if (ta(a)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(a)) throw Error(String(a));
        } else if (sa(a) && !Number.isSafeInteger(a)) throw Error(String(a));
        return BigInt(a)
    }
    var za = A(a => a >= xa && a <= ya),
        xa = BigInt(Number.MIN_SAFE_INTEGER),
        ya = BigInt(Number.MAX_SAFE_INTEGER);
    var E = 0,
        F = 0;

    function Aa(a) {
        var b = a >>> 0;
        E = b;
        F = (a - b) / 4294967296 >>> 0
    };
    var Ba = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        Ca = Number.isSafeInteger,
        G = Number.isFinite,
        Da = Math.trunc;

    function Ea(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }
    var Fa = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function Ga(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return G(a);
            case "string":
                return Fa.test(a);
            default:
                return !1
        }
    }

    function Ha(a) {
        if (!G(a)) throw a = Error("enum"), la(a, "warning"), a;
        return a | 0
    }

    function Ia(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return G(a) ? a | 0 : void 0
    }

    function Ja(a) {
        var b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return C(Ba(64, a));
        if (Ga(a)) {
            if (b === "string") {
                var c = a;
                a = Da(Number(c));
                Ca(a) ? c = C(a) : (a = c.indexOf("."), a !== -1 && (c = c.substring(0, a)), c = C(Ba(64, BigInt(c))))
            } else {
                if (Ca(a)) c = a;
                else if (a = Da(a), Ca(a)) c = String(a);
                else {
                    if (a < 0) {
                        Aa(0 - a);
                        a = E;
                        b = F;
                        b = ~b;
                        a ? a = ~a + 1 : b += 1;
                        let [d, e] = [a, b];
                        E = d >>> 0;
                        F = e >>> 0
                    } else Aa(a);
                    a = E;
                    b = F;
                    b & 2147483648 ? c = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b >>>= 0, a >>>= 0, b <= 2097151 ? c = "" + (4294967296 * b + a) : c = "" + (BigInt(b) << BigInt(32) |
                        BigInt(a)))
                }
                c = C(c)
            }
            return c
        }
    };

    function Ka(a) {
        return a
    };

    function La(a, b, c, d) {
        var e = d !== void 0;
        d = !!d;
        var f = [],
            g = a.length,
            h = 4294967295,
            l = !1,
            k = !!(b & 64),
            m = k ? b & 128 ? 0 : -1 : void 0;
        if (!(b & 1)) {
            var n = g && a[g - 1];
            n != null && typeof n === "object" && n.constructor === Object ? (g--, h = g) : n = void 0;
            !k || b & 128 || e || (l = !0, h = (Ma ? ? Ka)(h - m, m, a, n, void 0) + m)
        }
        b = void 0;
        for (e = 0; e < g; e++) {
            let q = a[e];
            if (q != null && (q = c(q, d)) != null)
                if (k && e >= h) {
                    let v = e - m;
                    (b ? ? (b = {}))[v] = q
                } else f[e] = q
        }
        if (n)
            for (let q in n) {
                a = n[q];
                if (a == null || (a = c(a, d)) == null) continue;
                g = +q;
                let v;
                k && !Number.isNaN(g) && (v = g + m) < h ? f[v] = a : (b ? ?
                    (b = {}))[q] = a
            }
        b && (l ? f.push(b) : f[h] = b);
        return f
    }

    function Na(a) {
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return za(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    let b = a[w] | 0;
                    return a.length === 0 && b & 1 ? void 0 : La(a, b, Na)
                }
                if (a != null && a[pa] === qa) return Oa(a);
                return
        }
        return a
    }
    var Ma;

    function Oa(a) {
        a = a.o;
        return La(a, a[w] | 0, Na)
    };

    function Pa(a, b, c, d = 0) {
        if (a == null) {
            var e = 32;
            c ? (a = [c], e |= 128) : a = [];
            b && (e = e & -16760833 | (b & 1023) << 14)
        } else {
            if (!Array.isArray(a)) throw Error("narr");
            e = a[w] | 0;
            if (fa && 1 & e) throw Error("rfarr");
            2048 & e && !(2 & e) && Qa();
            if (e & 256) throw Error("farr");
            if (e & 64) return (e | d) !== e && (a[w] = e | d), a;
            if (c && (e |= 128, c !== a[0])) throw Error("mid");
            a: {
                c = a;e |= 64;
                var f = c.length;
                if (f) {
                    var g = f - 1;
                    let l = c[g];
                    if (l != null && typeof l === "object" && l.constructor === Object) {
                        b = e & 128 ? 0 : -1;
                        g -= b;
                        if (g >= 1024) throw Error("pvtlmt");
                        for (var h in l)
                            if (f = +h,
                                f < g) c[f + b] = l[h], delete l[h];
                            else break;
                        e = e & -16760833 | (g & 1023) << 14;
                        break a
                    }
                }
                if (b) {
                    h = Math.max(b, f - (e & 128 ? 0 : -1));
                    if (h > 1024) throw Error("spvt");
                    e = e & -16760833 | (h & 1023) << 14
                }
            }
        }
        a[w] = e | 64 | d;
        return a
    }

    function Qa() {
        if (fa) throw Error("carr");
        if (oa != null) {
            var a = ma ? ? (ma = {});
            var b = a[oa] || 0;
            b >= 5 || (a[oa] = b + 1, a = Error(), la(a, "incident"), ea(a))
        }
    };

    function Ra(a, b) {
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            var c = a[w] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = Sa(a, c, !1, b && !(c & 16)) : (a[w] |= 34, c & 4 && Object.freeze(a)));
            return a
        }
        if (a != null && a[pa] === qa) {
            c = a.o;
            let d = c[w] | 0;
            ra(a, d) || (d & 2 ? b = !0 : d & 32 && !(d & 4096) ? (c[w] = d | 2, a.I = x, b = !0) : b = !1, b ? (a = new a.constructor(c), a.ia = x) : a = Sa(c, d));
            return a
        }
    }

    function Sa(a, b, c, d) {
        d ? ? (d = !!(34 & b));
        a = La(a, b, Ra, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        a[w] = b;
        return a
    };
    var Ta = C(0);

    function H(a, b, c, d) {
        a: if (a = a.o, b === -1) b = null;
            else {
                var e = b + (c ? 0 : -1),
                    f = a.length - 1;
                if (f < 1 + (c ? 0 : -1)) b = void 0;
                else {
                    if (e >= f) {
                        var g = a[f];
                        if (g != null && typeof g === "object" && g.constructor === Object) {
                            c = g[b];
                            var h = !0
                        } else if (e === f) c = g;
                        else {
                            b = void 0;
                            break a
                        }
                    } else c = a[e];
                    if (d && c != null) {
                        d = d(c);
                        if (d == null) {
                            b = d;
                            break a
                        }
                        if (!Object.is(d, c)) {
                            h ? g[b] = d : a[e] = d;
                            b = d;
                            break a
                        }
                    }
                    b = c
                }
            }if (b !== null) return b
    }

    function Ua(a, b, c) {
        if (a.I === x) {
            var d = a.o;
            d = Sa(d, d[w] | 0);
            d[w] |= 2048;
            a.o = d;
            a.I = void 0;
            a.ia = void 0;
            d = !0
        } else d = !1;
        if (!d && ra(a, a.o[w] | 0)) throw Error();
        d = a.o;
        a: {
            var e = d[w] | 0;
            let f = b + -1,
                g = d.length - 1;
            if (g >= 0 && f >= g) {
                let h = d[g];
                if (h != null && typeof h === "object" && h.constructor === Object) {
                    h[b] = c;
                    break a
                }
            }
            f <= g ? d[f] = c : c !== void 0 && (e = (e ? ? d[w] | 0) >> 14 & 1023 || 536870912, b >= e ? c != null && (d[e + -1] = {
                [b]: c
            }) : d[f] = c)
        }
        return a
    }

    function I(a, b) {
        a = H(a, b);
        return (a == null || typeof a === "boolean" ? a : typeof a === "number" ? !!a : void 0) ? ? !1
    }

    function J(a, b) {
        a = H(a, b);
        return (a == null || typeof a === "string" ? a : void 0) ? ? ""
    }

    function Va(a, b) {
        a = H(a, b);
        return (a == null ? a : G(a) ? a | 0 : void 0) ? ? 0
    };
    var K = class {
        constructor(a) {
            this.o = Pa(a, void 0, void 0, 2048)
        }
        toJSON() {
            return Oa(this)
        }
    };
    K.prototype[pa] = qa;
    K.prototype.toString = function() {
        return this.o.toString()
    };

    function Wa(a) {
        return b => {
            if (b == null || b == "") b = new a;
            else {
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("dnarr");
                b[w] |= 32;
                b = new a(b)
            }
            return b
        }
    };
    var Xa = Wa(class extends K {
        getReactiveAdType() {
            return Ia(H(this, 12)) ? ? 0
        }
    });

    function Ya(a = window) {
        return a
    };

    function Za(a, b) {
        if (a)
            for (let c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function $a(a = document) {
        return a.createElement("img")
    };
    var L = [];

    function ab() {
        var a = L;
        L = [];
        for (let b of a) try {
            b()
        } catch {}
    };

    function bb(a) {
        var b = a.nodeType == 9 ? a : a.ownerDocument || a.document;
        return b.defaultView && b.defaultView.getComputedStyle && (a = b.defaultView.getComputedStyle(a, null)) ? a["float"] || a.getPropertyValue("float") || "" : ""
    };

    function N(a, b, c) {
        typeof a.addEventListener === "function" && a.addEventListener(b, c, !1)
    }

    function O(a, b, c) {
        typeof a.removeEventListener === "function" && a.removeEventListener(b, c, !1)
    }

    function cb(a, b) {
        a.readyState === "complete" || a.readyState === "interactive" ? (L.push(b), L.length === 1 && (window.Promise ? Promise.resolve().then(ab) : (a = window.setImmediate, ua(a) ? a(ab) : setTimeout(ab, 0)))) : a.addEventListener("DOMContentLoaded", b)
    };

    function hb(a, b, c = null, d = !1) {
        ib(a, b, c, d)
    }

    function ib(a, b, c, d) {
        a.google_image_requests || (a.google_image_requests = []);
        var e = $a(a.document);
        if (c || d) {
            let f = g => {
                c && c(g);
                if (d) {
                    g = a.google_image_requests;
                    let h = Array.prototype.indexOf.call(g, e, void 0);
                    h >= 0 && Array.prototype.splice.call(g, h, 1)
                }
                O(e, "load", f);
                O(e, "error", f)
            };
            N(e, "load", f);
            N(e, "error", f)
        }
        e.src = b;
        a.google_image_requests.push(e)
    }

    function jb(a, b) {
        var c;
        if (c = a.navigator) c = a.navigator.userAgent, c = !(!/Chrome/.test(c) || /Edge/.test(c));
        c && typeof a.navigator.sendBeacon === "function" ? a.navigator.sendBeacon(b) : hb(a, b, void 0, !1)
    };
    var kb = 0;

    function lb(a) {
        return (a = mb(a, document.currentScript)) && a.getAttribute("data-jc-version") || "unknown"
    }

    function mb(a, b = null) {
        return b && b.getAttribute("data-jc") === String(a) ? b : document.querySelector(`[data-jc="${a}"]`)
    };
    var nb = class {
        constructor(a, b) {
            this.error = a;
            this.meta = {};
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror"
        }
    };

    function ob(a) {
        var b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        if (a.stack) a: {
            a = a.stack;
            var c = b;
            try {
                a.indexOf(c) == -1 && (a = c + "\n" + a);
                let d;
                for (; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n");
                break a
            } catch (d) {
                b = c;
                break a
            }
            b = void 0
        }
        return b
    };
    var pb = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)"),
        qb = class {
            constructor(a, b) {
                this.i = a;
                this.j = b
            }
        },
        rb = class {
            constructor(a, b) {
                this.url = a;
                this.i = !!b;
                this.depth = null
            }
        };
    var P = null;

    function Q() {
        var a = p.performance;
        return a && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
    }

    function sb() {
        var a = p.performance;
        return a && a.now ? a.now() : null
    };
    var tb = class {
        constructor(a, b) {
            var c = sb() || Q();
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = 0;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        }
    };
    var R = p.performance,
        ub = !!(R && R.mark && R.measure && R.clearMarks),
        S = function(a) {
            var b = !1,
                c;
            return function() {
                b || (c = a(), b = !0);
                return c
            }
        }(() => {
            var a;
            if (a = ub) {
                var b;
                a = window;
                if (P === null) {
                    P = "";
                    try {
                        let c = "";
                        try {
                            c = a.top.location.hash
                        } catch (d) {
                            c = a.location.hash
                        }
                        c && (P = (b = c.match(/\bdeid=([\d,]+)/)) ? b[1] : "")
                    } catch (c) {}
                }
                b = P;
                a = !!b.indexOf && b.indexOf("1337") >= 0
            }
            return a
        });

    function vb(a) {
        a && R && S() && (R.clearMarks(`goog_${a.label}_${a.uniqueId}_start`), R.clearMarks(`goog_${a.label}_${a.uniqueId}_end`))
    };

    function T(a, b) {
        var c = {};
        c[a] = b;
        return [c]
    }

    function wb(a, b, c, d, e) {
        var f = [];
        Za(a, (g, h) => {
            (g = xb(g, b, c, d, e)) && f.push(`${encodeURIComponent(h)}=${g}`)
        });
        return f.join(b)
    }

    function xb(a, b, c, d, e) {
        if (a == null) return "";
        b = b || "&";
        c = c || ",$";
        ta(c) && (c = c.split(""));
        if (a instanceof Array) {
            if (d || (d = 0), d < c.length) {
                let f = [];
                for (let g = 0; g < a.length; g++) f.push(xb(a[g], b, c, d + 1, e));
                return f.join(c[d])
            }
        } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(wb(a, b, c, d, e + 1)) : "...";
        return encodeURIComponent(String(a))
    }

    function yb(a) {
        var b = 1;
        for (let c in a.j) c.length > b && (b = c.length);
        return 3997 - b - a.l.length - 1
    }

    function zb(a, b) {
        var c = yb(a) - b.length;
        if (c < 0) return "";
        b = "";
        a.i.sort((f, g) => f - g);
        var d = null,
            e = "";
        for (let f = 0; f < a.i.length; f++) {
            let g = a.i[f],
                h = a.j[g];
            for (let l = 0; l < h.length; l++) {
                if (!c) {
                    d = d == null ? g : d;
                    break
                }
                let k = wb(h[l], a.l, ",$");
                if (k) {
                    k = e + k;
                    if (c >= k.length) {
                        c -= k.length;
                        b += k;
                        e = a.l;
                        break
                    }
                    d = d == null ? g : d
                }
            }
        }
        a = "";
        d != null && (a = `${e}trn=${d}`);
        return b + a
    }

    function Ab(a, b, c, d) {
        return yb(a) - d.length < 0 ? "" : b + "//" + c + d + zb(a, d)
    }
    var Bb = class {
        constructor() {
            this.l = "&";
            this.j = {};
            this.m = 0;
            this.i = []
        }
    };
    var Cb = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function Db(a, b, c) {
        try {
            if (a.j && a.j.i) {
                var d = a.j.start(b.toString(), 3);
                var e = c();
                a.j.end(d)
            } else e = c()
        } catch (f) {
            c = !0;
            try {
                vb(d), c = a.m(b, new nb(f, {
                    message: ob(f)
                }), void 0, void 0)
            } catch (g) {
                a.J(217, g)
            }
            if (c) window.console ? .error ? .(f);
            else throw f;
        }
        return e
    }

    function Eb(a, b) {
        var c = U;
        return (...d) => Db(c, a, () => b.apply(void 0, d))
    }

    function Fb(a) {
        var b = U;
        a.catch(c => {
            c = c ? c : "unknown rejection";
            b.J(967, c instanceof Error ? c : Error(c), void 0, b.i || void 0)
        })
    }
    var Hb = class {
        constructor(a = null) {
            this.pinger = V;
            this.j = a;
            this.i = null;
            this.l = !1;
            this.m = this.J
        }
        J(a, b, c, d, e) {
            e = e || "jserror";
            var f = void 0;
            try {
                let B = new Bb;
                var g = B;
                g.i.push(1);
                g.j[1] = T("context", a);
                b.error && b.meta && b.id || (b = new nb(b, {
                    message: ob(b)
                }));
                g = b;
                if (g.msg) {
                    b = B;
                    var h = g.msg.substring(0, 512);
                    b.i.push(2);
                    b.j[2] = T("msg", h)
                }
                var l = g.meta || {};
                h = l;
                if (this.i) try {
                    this.i(h)
                } catch (z) {}
                if (d) try {
                    d(h)
                } catch (z) {}
                d = B;
                l = [l];
                d.i.push(3);
                d.j[3] = l;
                var k;
                if (!(k = q)) {
                    h = p;
                    l = [];
                    let z;
                    b = null;
                    do {
                        var m = h;
                        a: {
                            d = void 0;
                            try {
                                if (d = !!m && m.location.href != null) b: {
                                    try {
                                        ka(m.foo);
                                        d = !0;
                                        break b
                                    } catch (y) {}
                                    d = !1
                                }
                                var n = d;
                                break a
                            } catch {
                                n = !1;
                                break a
                            }
                            n = void 0
                        }
                        n ? (z = m.location.href, b = m.document && m.document.referrer || null) : (z = b, b = null);
                        l.push(new rb(z || ""));
                        try {
                            h = m.parent
                        } catch (y) {
                            h = null
                        }
                    } while (h && m !== h);
                    for (let y = 0, db = l.length - 1; y <= db; ++y) l[y].depth = db - y;
                    m = p;
                    if (m.location && m.location.ancestorOrigins && m.location.ancestorOrigins.length === l.length - 1)
                        for (n = 1; n < l.length; ++n) {
                            let y = l[n];
                            y.url || (y.url = m.location.ancestorOrigins[n - 1] || "", y.i = !0)
                        }
                    k =
                        l
                }
                var q = k;
                let Z = new rb(p.location.href, !1);
                k = null;
                let va = q.length - 1;
                for (m = va; m >= 0; --m) {
                    var v = q[m];
                    !k && pb.test(v.url) && (k = v);
                    if (v.url && !v.i) {
                        Z = v;
                        break
                    }
                }
                v = null;
                let hc = q.length && q[va].url;
                Z.depth !== 0 && hc && (v = q[va]);
                f = new qb(Z, v);
                if (f.j) {
                    q = B;
                    var D = f.j.url || "";
                    q.i.push(4);
                    q.j[4] = T("top", D)
                }
                var wa = {
                    url: f.i.url || ""
                };
                if (f.i.url) {
                    let z = f.i.url.match(Cb);
                    var M = z[1],
                        eb = z[3],
                        fb = z[4];
                    D = "";
                    M && (D += M + ":");
                    eb && (D += "//", D += eb, fb && (D += ":" + fb));
                    var gb = D
                } else gb = "";
                M = B;
                wa = [wa, {
                    url: gb
                }];
                M.i.push(5);
                M.j[5] = wa;
                Gb(this.pinger,
                    e, B, this.l, c)
            } catch (B) {
                try {
                    Gb(this.pinger, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: ob(B),
                        url: f ? .i.url ? ? ""
                    }, this.l, c)
                } catch (Z) {}
            }
            return !0
        }
    };
    class Ib {};

    function Gb(a, b, c, d = !1, e) {
        if ((d ? a.j : Math.random()) < (e || a.m)) try {
            let f;
            c instanceof Bb ? f = c : (f = new Bb, Za(c, (h, l) => {
                var k = f,
                    m = k.m++;
                h = T(l, h);
                k.i.push(m);
                k.j[m] = h
            }));
            let g = Ab(f, a.protocol, a.i(), a.path + b + "&");
            g && (a.l ? jb(p, g) : hb(p, g))
        } catch (f) {}
    }

    function Jb() {
        var a = V,
            b = window.google_srt;
        b >= 0 && b <= 1 && (a.j = b)
    }
    var Kb = class {
        constructor(a, b, c, d = !1) {
            this.domain = a;
            this.path = b;
            this.m = c;
            this.l = d;
            this.protocol = "https:";
            this.j = Math.random()
        }
        i() {
            return this.domain
        }
    };
    var V, U, Lb = !1;
    class Mb extends Kb {
        i() {
            if (Lb) {
                ({
                    ja: a = !1
                } = {
                    ja: !0
                });
                var a = a ? "connect.pagead2.googlesyndication.com" : "pagead2.googlesyndication.com"
            } else a = super.i();
            return a
        }
    }
    var W = new class {
        constructor(a, b) {
            this.events = [];
            this.j = b || p;
            var c = null;
            b && (b.google_js_reporting_queue = b.google_js_reporting_queue || [], this.events = b.google_js_reporting_queue, c = b.google_measure_js_timing);
            this.i = S() || (c != null ? c : Math.random() < a)
        }
        start(a, b) {
            if (!this.i) return null;
            a = new tb(a, b);
            b = `goog_${a.label}_${a.uniqueId}_start`;
            R && S() && R.mark(b);
            return a
        }
        end(a) {
            if (this.i && sa(a.value)) {
                a.duration = (sb() || Q()) - a.value;
                var b = `goog_${a.label}_${a.uniqueId}_end`;
                R && S() && R.mark(b);
                !this.i || this.events.length >
                    2048 || this.events.push(a)
            }
        }
    }(1, window);

    function Nb() {
        window.google_measure_js_timing || (W.i = !1, W.events !== W.j.google_js_reporting_queue && (S() && Array.prototype.forEach.call(W.events, vb, void 0), W.events.length = 0))
    }
    (function(a) {
        Lb = !1;
        V = a ? ? new Mb("pagead2.googlesyndication.com", "/pagead/gen_204?id=", .01);
        typeof window.google_srt !== "number" && (window.google_srt = Math.random());
        Jb();
        U = new Hb(W);
        U.i = b => {
            var c = kb;
            c !== 0 && (b.jc = String(c), b.shv = lb(c))
        };
        U.l = !0;
        window.document.readyState === "complete" ? Nb() : W.i && N(window, "load", () => {
            Nb()
        })
    })();

    function X(a, b) {
        return Eb(a, b)
    }

    function Ob(a, b, c) {
        var d = Ib;
        var e = "ga";
        d.ga && d.hasOwnProperty(e) || (e = new d, d.ga = e);
        d = [];
        !b.eid && d.length && (b.eid = d.toString());
        Gb(V, a, b, !0, c)
    };
    class Pb {
        constructor() {
            this.promise = new Promise((a, b) => {
                this.resolve = a;
                this.reject = b
            })
        }
    };

    function Qb(a, b) {
        b.google_llp || (b.google_llp = {});
        b = b.google_llp;
        var c = b[a];
        if (c) return c;
        var {
            promise: d,
            resolve: e
        } = new Pb;
        c = {
            promise: d,
            resolve: e
        };
        return b[a] = c
    };
    async function Rb() {
        return Qb(10, p).promise
    };

    function Sb(a) {
        za(a);
        return za(a) ? Number(a) : String(a)
    };

    function Tb(a, b) {
        N(a, "message", c => {
            try {
                var d = JSON.parse(c.data)
            } catch (e) {
                return
            }!d || d.googMsgType !== "aevi" || b(d, c)
        })
    };

    function Ub() {
        this.j = this.j;
        this.i = this.i
    }
    Ub.prototype.j = !1;
    Ub.prototype.dispose = function() {
        if (!this.j && (this.j = !0, this.i))
            for (; this.i.length;) this.i.shift()()
    };
    Ub.prototype[Symbol.dispose] = function() {
        this.dispose()
    };

    function Vb(a, b) {
        a.j ? b() : (a.i || (a.i = []), a.i.push(b))
    };
    var Wb = class extends Ub {
        constructor(a) {
            super();
            this.l = a;
            Vb(this, () => {
                this.l.close()
            })
        }
        m() {
            this.l.postMessage([])
        }
    };

    function Y(a, b, c = {}) {
        c.msg_type = b;
        c.googMsgType = "sth";
        b = JSON.stringify(c);
        a.parent.postMessage(b, "*")
    }

    function Xb(a) {
        Tb(a, b => {
            try {
                var c = a.parent;
                b.googMsgType = "aevi";
                c.postMessage(JSON.stringify(b), "*")
            } catch {}
        })
    }

    function Yb(a) {
        if (a.M || I(a.config, 2)) return !0;
        var b = !0,
            c = Zb(a);
        c && (b = c >= 36E5);
        if (b) try {
            a.i.localStorage.removeItem("LAST_INTERSTITIAL_TIME")
        } catch (d) {}
        return b
    }

    function Zb(a) {
        try {
            let b = +a.i.localStorage.getItem("LAST_INTERSTITIAL_TIME"),
                c = Date.now();
            if (b && b < c) return c - b
        } catch (b) {}
        return null
    }

    function $b(a) {
        var b = Sb(H(a.config, 26, void 0, Ja) ? ? Ta),
            c = () => {
                for (let d of a.j.document.getElementsByClassName("GoogleActiveViewElement")) d.removeAttribute("data-google-av-dm")
            };
        b > 0 ? setTimeout(() => c(), b) : c();
        a.maybeReportBeacon({
            isfsapi: !!a.l,
            avp: Q() - a.ha
        }, .01)
    }
    var ac = class {
        constructor(a, b, c, d) {
            this.i = a;
            this.j = b;
            this.C = !1;
            this.H = null;
            this.u = 0;
            this.config = c;
            this.ha = Q();
            I(c, 29) ? (b = a.parent, c = new MessageChannel, b.postMessage(JSON.stringify({
                googMsgType: "sth",
                msg_type: "i-hai-aux"
            }), "*", [c.port2]), b = new Wb(c.port1)) : b = null;
            this.aa = b;
            this.M = I(this.config, 11) || this.config.getReactiveAdType() === 10 || this.config.getReactiveAdType() === 11;
            this.l = d;
            d ? .enableCustomCloseButton();
            I(this.config, 36) && Xb(a)
        }
        Z() {}
        init() {
            (this.C = Yb(this)) ? this.listen(): this.l ? .notifyError("freq_cap")
        }
        v() {
            if (!this.u) {
                this.H &&
                    O(this.i, "storage", this.H);
                this.u = Date.now();
                if (!I(this.config, 2) && !this.M) try {
                    this.i.localStorage.setItem("LAST_INTERSTITIAL_TIME", "" + this.u)
                } catch (b) {}
                this.ea();
                if (this.j) {
                    try {
                        this.j.document ? .body ? .classList.add("mys-cta-effect-active")
                    } catch {}
                    var a = this.i.document.createEvent("Event");
                    a.initEvent("i-creative-view", !0, !1);
                    this.j.dispatchEvent(a);
                    a = this.i.document.createEvent("Event");
                    a.initEvent("onshow", !0, !1);
                    this.i.dispatchEvent(a)
                }
            }
        }
        getReactiveAdType() {
            return this.config.getReactiveAdType()
        }
        maybeReportBeacon(a,
            b) {
            J(this.config, 3) && (a.qid = J(this.config, 3));
            J(this.config, 10) && (a.eid = J(this.config, 10));
            a.rtype = this.config.getReactiveAdType();
            a.req = this.i.location.href;
            Ob(this.Z(), a, b)
        }
        N() {}
        listen() {
            var a = !1;
            if (this.l) {
                let b = this.l.waitForOnShow().then(() => {
                    this.v();
                    $b(this)
                });
                Fb(b);
                this.l.listenToBackButton(() => {
                    this.N()
                })
            } else this.i.IntersectionObserver && (H(this.config, 13, void 0, Ea) ? ? 0) > .01 && (a = !0, (new this.i.IntersectionObserver((b, c) => {
                b.forEach(d => {
                    d.intersectionRatio <= 0 || (this.v(), $b(this), c.disconnect())
                })
            }, {
                threshold: H(this.config, 13, void 0, Ea) ? ? 0
            })).observe(this.i.document.documentElement));
            N(this.i, "message", X(262, b => {
                a: {
                    var c = a;
                    if (b && (this.i.parent == b.source || this.i.parent.parent == b.source)) {
                        var d = {};
                        try {
                            d = this.i.JSON.parse(b.data)
                        } catch (e) {
                            b = void 0;
                            break a
                        }
                        switch (d ? .msg_type) {
                            case "i-view":
                                this.C && !c && this.v();
                                this.maybeReportBeacon({
                                    type: "viewmsg",
                                    has_iobs: !!this.i.IntersectionObserver
                                });
                                break;
                            case "r-back-button":
                                this.l == null && this.N()
                        }
                    }
                    b = void 0
                }
                return b
            }));
            this.M || (this.H = X(263, () => {
                this.C = Yb(this);
                if (!this.C) {
                    var b = {
                        i_tslv: Zb(this)
                    };
                    Y(this.i, "i-no", b)
                }
            }), N(this.i, "storage", this.H));
            this.l || Y(this.i, "i-adframe-load")
        }
        async ea(a) {
            var b;
            try {
                let c = Ya(this.j);
                if (this.l && c.itt) try {
                    let d = await Promise.race([this.l.getInterstitialTriggerType(), new Promise(e => {
                        setTimeout(() => e(4), 50)
                    })]);
                    c.itt(d)
                } catch (d) {}
                c.vv ? c.vv() : b = !0
            } catch (c) {
                U.J(533, c, void 0, void 0);
                return
            }
            a = a || 1;
            b ? (this.maybeReportBeacon({
                vf: a
            }), a >= 3 || this.i.setTimeout(r(ac.prototype.ea, this, a + 1), 3E3)) : a > 1 && this.maybeReportBeacon({
                vs: a
            })
        }
    };
    var bc = window;

    function cc(a) {
        window.parent.postMessage(JSON.stringify({
            type: "rewarded",
            message: a
        }), "*")
    };
    var dc = Wa(class extends K {});
    var ec = class extends K {};
    var fc = Wa(class extends K {});

    function ic(a) {
        return a.innerHeight >= a.innerWidth ? 1 : 2
    };

    function jc(a) {
        a = a.document;
        var b = {};
        a && (b = a.compatMode == "CSS1Compat" ? a.documentElement : a.body);
        return b || {}
    };

    function kc(a, b, c) {
        a = {
            context: "iaf::itf",
            req: bc.location.href,
            db: a ? 1 : 0,
            ls: b ? 1 : 0,
            eid: J(c, 10),
            qid: J(c, 3),
            rtype: c.getReactiveAdType()
        };
        Ob("jserror", a)
    }

    function lc(a, b) {
        mc(a, b) && (I(a.config, 35) ? p.setTimeout(() => {
            a.dismiss(2)
        }, 750) : (a.m.style.background = "rgba(192,192,192, .3)", p.setTimeout(() => {
            a.m.style.background = "transparent";
            a.dismiss(2)
        }, 750)))
    }

    function nc(a, b) {
        a.L.push(Eb(484, b))
    }

    function oc(a, b) {
        return b.some(c => c.type === "intervention" && c.body ? .id === "HeavyAdIntervention") ? (a.maybeReportBeacon({
            hai: "1"
        }, 1), a.aa ? .m(), a.u ? a.dismiss(8) : a.l ? a.l.notifyError("heavy_ads") : Y(a.i, "i_iif"), !0) : !1
    }

    function pc(a) {
        var b = X(259, r(function() {
            Y(this.i, "i-blur");
            O(this.i, "blur", b)
        }, a));
        N(a.i, "blur", b)
    }

    function qc(a) {
        a.B || a.u === 0 || (a.m.setAttribute("aria-label", J(a.config, 7)), a.m.setAttribute("role", "button"), a.m.setAttribute("tabindex", "0"), a.m.focus())
    }

    function rc(a, b, c) {
        I(a.config, 15) ? (cc("canceled"), cc("closed")) : a.l ? a.l.closeAd(c) : Y(a.i, b)
    }

    function sc(a, b) {
        var c = a.i.document.getElementById("creative");
        if (a.i.goog_vignette_survey) {
            var d = 1;
            I(a.config, 33) && (d = I(a.config, 34), d = bb(a.P) === "right" ? d ? 1 : 2 : d ? 2 : 1);
            a.i.goog_vignette_survey.display(c, () => {
                a.dismiss(3)
            }, () => {}, d);
            b && b.stopPropagation()
        }
    }

    function tc(a, b) {
        switch (b) {
            case 1:
                a.K.classList.add("controller-hidden");
                a.R.classList.remove("controller-hidden");
                break;
            case 0:
                a.K.classList.remove("controller-hidden"), a.R.classList.add("controller-hidden")
        }
        if (a.F) {
            var c = new ec;
            var d = a.G;
            d = d == null ? d : Ha(d);
            c = Ua(c, 1, d);
            var e = Ua(c, 2, b == null ? b : Ha(b));
            c = a.j;
            d = c.postMessage;
            var f = JSON,
                g = f.stringify;
            e = JSON.stringify(Oa(e));
            d.call(c, g.call(f, {
                type: "hybrid_wrapper_state_change",
                message: e
            }), "*")
        }
        a.G = b
    }

    function uc(a) {
        !a.ba && a.R && a.fa && (a.ba = !0, N(a.fa, "click", X(1737, () => {
            if (a.G === 1) {
                var b = J(a.config, 46);
                if (b && !a.F) {
                    for (let c of ["scrim", "banner"]) {
                        let d = a.K ? .querySelector("." + b + "-" + c);
                        d && (d.style.display = "")
                    }
                    a.m.classList.add(b + "-docked")
                }
                tc(a, 0)
            }
        })))
    }

    function vc(a) {
        a.G !== 1 && (uc(a), tc(a, 1))
    }

    function wc(a) {
        if (I(a.config, 44) && (vc(a), !I(a.config, 45))) return;
        I(a.config, 41) ? (a.i.addEventListener("message", b => {
            if (b.source === a.j) try {
                let f = JSON.parse(b.data);
                if (f.type === "creative_features") {
                    var c = dc(f.message);
                    Va(c, 1) === 1 && vc(a)
                } else {
                    var d;
                    if (d = f.type === "reactive_ad_wrapper_subscription") {
                        var e = fc(f.message);
                        d = Va(e, 1) === 1
                    }
                    d && (a.F = !0)
                }
            } catch (f) {}
        }), a.j.postMessage(JSON.stringify({
            type: "hybrid_wrapper_ready_for_subscription",
            message: ""
        }), "*")) : I(a.config, 42) && (vc(a), a.F = !0)
    }

    function xc(a) {
        a.B === !1 && a.enableDismissListeners();
        a.P && N(a.P, "click", X(261, c => sc(a, c)));
        var b = a.i.document.getElementById("card");
        b && b.addEventListener("click", X(909, c => {
            c ? .stopPropagation()
        }))
    }

    function yc(a) {
        zc(a, "visible", b => {
            a.X = !0;
            a.W = b;
            Ac(a)
        });
        zc(a, "prefetched", () => {
            a.D || (a.D = !0, Ac(a))
        });
        a.D || a.j.postMessage(JSON.stringify({
            type: "rewarded",
            message: "query_prefetched"
        }), "*")
    }

    function Bc(a) {
        N(a.i, "resize", () => {
            var b = ic(a.i);
            a.O ? (a.O = !1, a.U = b === 2) : (a.U ? b === 1 : b === 2) && a.dismiss(4)
        })
    }

    function Ac(a) {
        a.u && a.X && a.D && Cc(a)
    }

    function Cc(a) {
        a.j.postMessage(JSON.stringify(a.W || {
            type: "rewarded",
            message: "visible"
        }), "*")
    }

    function Dc(a) {
        a.i.addEventListener("message", b => {
            if (b.source === a.j) try {
                let c = JSON.parse(b.data);
                c.type === "rewarded" && c.message === "closed" && a.dismiss(a.config.getReactiveAdType() === 11 ? 6 : 1)
            } catch (c) {}
        })
    }

    function zc(a, b, c) {
        a.i.addEventListener("message", d => {
            try {
                var e = d.data,
                    f = typeof e;
                let g = f == "object" && e != null || f == "function" ? d.data : JSON.parse(d.data);
                g && g.type === "rewarded" && g.message === b && c(g, d)
            } catch (g) {}
        })
    }

    function mc(a, b) {
        if (!b) return !0;
        if ((ua(b.preventDefault) ? b.defaultPrevented : b.returnValue === !1) || b.target && b.target.ownerDocument == a.j.document) return !1;
        a = b.target;
        for (b = new Set("creative dismiss-button-protector skip-button-protector card-outer-container top-glasspane bottom-glasspane left-glasspane right-glasspane".split(" ")); a;) {
            if (b.has(a.id)) return !1;
            a = a.parentElement
        }
        return !0
    }
    var Ec = class extends ac {
        constructor(a, b, c, d, e, f, g, h, l) {
            super(a, b, h, l);
            this.m = c;
            this.K = d;
            this.P = e;
            this.fa = f;
            this.R = g;
            this.G = 0;
            this.ba = this.F = !1;
            this.V = 0;
            this.da = X(260, k => {
                this.dismiss(1);
                k && k.stopPropagation()
            });
            this.ca = k => lc(this, k);
            this.T = [];
            this.L = [];
            this.B = !1;
            this.Y = () => {};
            this.O = this.U = !1;
            this.A = null;
            I(h, 31) && nc(this, k => {
                k === 1 || k === 6 || k === 7 ? (this.j.postMessage(JSON.stringify({
                    type: "rewarded",
                    message: "closed"
                }), "*"), k = !0) : k = !1;
                return k ? Sb(H(h, 32, void 0, Ja) ? ? Ta) : 0
            });
            this.W = null;
            this.D = this.X = !1
        }
        init() {
            super.init();
            if (this.A = this.i.ReportingObserver ? new this.i.ReportingObserver((a, b) => {
                    oc(this, a) && b.disconnect()
                }, {
                    buffered: !0
                }) : null) this.aa && this.A.observe(), N(this.i, "pagehide", () => {
                oc(this, this.A.takeRecords());
                this.A.disconnect()
            })
        }
        Z() {
            return "ia_evt"
        }
        N() {
            this.B ? this.Y() : this.dismiss(9)
        }
        addViewListener(a) {
            a = Eb(483, a);
            this.u ? a() : this.T.push(a)
        }
        disableDismissListeners(a) {
            this.B = !0;
            this.Y = a;
            O(this.m, "click", this.da);
            O(this.i.document, "click", this.ca)
        }
        enableDismissListeners() {
            this.B = !1;
            N(this.m, "click", this.da);
            N(this.i.document, "click", this.ca);
            qc(this)
        }
        dismiss(a) {
            document.body.setAttribute("aria-hidden", "true");
            this.maybeReportBeacon({
                ttd: Date.now() - this.u,
                req: bc.location.href,
                pda: this.V,
                ds: a,
                idrw: I(this.config, 15) ? 1 : 0
            });
            this.V++ || pc(this);
            var b = 0;
            for (let d = 0; d < this.L.length; d++) b = Math.max(b, this.L[d](a));
            b = Math.min(b, 1E3);
            var c = "i-dismiss";
            a === 6 ? c = "r-dismiss-before-reward" : a === 7 && (c = "r-dismiss-after-reward");
            b === 0 ? rc(this, c, a) : p.setTimeout(() => {
                rc(this, c, a)
            }, b)
        }
        listen() {
            super.listen();
            wc(this);
            xc(this);
            I(this.config, 15) && yc(this)
        }
        v() {
            super.v();
            this.U = ic(this.i) === 2;
            this.O = this.i.innerWidth === 0 && this.i.innerHeight === 0;
            Bc(this);
            qc(this);
            var a = this.m.getBoundingClientRect(),
                b = a.bottom,
                c = a.right;
            var d = jc(this.i).clientHeight;
            var e = jc(this.i).clientWidth ? ? void 0;
            var f = Math.floor(b - d),
                g = Math.floor(c - e);
            if (f >= 0 || g > 5) b -= a.top, c -= a.left, a = this.i, this.maybeReportBeacon({
                dhb: f >= b ? 1 : 0,
                dhr: g >= c ? 1 : 0,
                h: d,
                w: e,
                bh: b,
                bw: c,
                opb: f,
                opr: g,
                pt: a.innerHeight >= a.innerWidth ? 1 : 0,
                req: this.i.location.href
            });
            I(this.config, 15) ?
                Ac(this) : Cc(this);
            for (d = 0; d < this.T.length; d++) this.T[d]();
            Dc(this);
            Math.random() > .01 || (d = mb(24, document.currentScript), d = `https://${d&&d.getAttribute("data-jc-rcd")==="true"?"pagead2.googlesyndication-cn.com":"pagead2.googlesyndication.com"}/pagead/gen_204?id=jca&jc=24&version=${lb(24)}&sample=0.01`, jb(window, d));
            d = this.i.navigator ? this.i.navigator.standalone === !0 : !1;
            e = window.matchMedia("(display-mode: standalone)").matches;
            this.maybeReportBeacon({
                wapp: d || e
            })
        }
        notifyRewardGranted() {
            this.j.postMessage(JSON.stringify({
                type: "rewarded",
                message: "granted"
            }), "*")
        }
        notifyRewardedEvent(a) {
            this.j.postMessage(JSON.stringify({
                type: "rewarded",
                message: a
            }), "*")
        }
    };
    kb = 24;
    var Fc = mb(24, document.currentScript);
    if (Fc == null) throw Error("JSC not found 24");
    var Gc = {},
        Hc = Fc.attributes;
    for (let a = Hc.length - 1; a >= 0; a--) {
        let b = Hc[a].name;
        b.indexOf("data-jcp-") === 0 && (Gc[b.substring(9)] = Hc[a].value)
    }
    (async function(a) {
        var b = window,
            c = Xa(a.config),
            d = X(258, async () => {
                var e = null;
                I(c, 25) && (e = await Rb()); {
                    var f = b.document.getElementById("ad_iframe").contentWindow;
                    var g = b.document,
                        h = f.document,
                        l = Va(c, 5);
                    let k = l === 0 || l === 2 ? h.getElementById(J(c, 6)) : g.getElementById(J(c, 6));
                    h = l === 0 ? h.getElementById(J(c, 8)) : g.getElementById(J(c, 8));
                    l = g.getElementById(J(c, 40));
                    let m = g.getElementById(J(c, 38));
                    g = g.getElementById(J(c, 39));
                    let n;
                    try {
                        n = !!b.localStorage
                    } catch (q) {}
                    k ? (n || kc(k, n, c), f = new Ec(b, f, k, l, h, m, g, c, e), f.init()) :
                        (kc(k, n, c), e ? e.notifyError("no_dismiss_button") : Y(b, "i_iif"), f = null)
                }
                b.interstitialAdFrame = f;
                Qb(9, b).resolve(f)
            });
        a = b.document.getElementById("ad_iframe");
        a.contentDocument != null && cb(a.contentDocument, () => void d())
    })(Gc);
}).call(this);
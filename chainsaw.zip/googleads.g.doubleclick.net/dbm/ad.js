if (!window.mraid) {
    document.write('\x3cdiv id="ad_unit"\x3e');
}
document.write('\x3cdiv class="GoogleActiveViewElement" ' + 'id="DfaVisibilityIdentifier_223125552"\x3e');
document.write('\x3cdiv class="GoogleCreativeContainerClass" ' + 'id="gcc_BOcCa5yMDLrG2fMP6JnQ2QQ"\x3e');
(function() {
    var m = document.createElement('meta');
    m.setAttribute('data-jc', '82');
    m.setAttribute('data-jc-version', 'r20261118');
    var ss = document.getElementsByTagName('script')[0];
    if (ss && ss.parentNode) {
        ss.parentNode.insertBefore(m, ss);
    }
})();
(function() { /*  Copyright The Closure Library Authors. SPDX-License-Identifier: Apache-2.0 */
    var h = this || self;

    function l(a, d, b) {
        if (a)
            for (var c = 0; a != null && c < 500 && !b(a); ++c) a = d(a)
    }

    function m(a, d) {
        l(a, function(b) {
            try {
                return b === b.parent ? null : b.parent
            } catch (c) {}
            return null
        }, d)
    }

    function n(a, d) {
        if (a.tagName == "IFRAME") d(a);
        else {
            a = a.querySelectorAll("IFRAME");
            for (var b = 0; b < a.length && !d(a[b]); ++b);
        }
    }

    function p(a) {
        return (a = a.ownerDocument) && (a.parentWindow || a.defaultView) || null
    }

    function q(a, d, b) {
        try {
            var c = JSON.parse(b.data)
        } catch (f) {}
        if (typeof c === "object" && c && c.type === "creativeLoad") {
            var g = p(a);
            if (b.source && g) {
                var e;
                m(b.source, function(f) {
                    try {
                        if (f.parent === g) return e = f, !0
                    } catch (k) {}
                });
                e && n(a, function(f) {
                    if (f.contentWindow === e) return d(c), !0
                })
            }
        }
    }

    function r(a) {
        return typeof a === "string" ? document.getElementById(a) : a
    };
    var t;
    t = t === void 0 ? window : t;
    t.clsn = function(a, d) {
        var b = r(a);
        if (b)
            if (b.onCreativeLoad) b.onCreativeLoad(d);
            else {
                var c = d ? [d] : [],
                    g = function(e) {
                        for (var f = 0; f < c.length; ++f) try {
                            c[f](1, e)
                        } catch (k) {}
                        c = {
                            push: function(k) {
                                k(1, e)
                            }
                        }
                    };
                b.onCreativeLoad = function(e) {
                    c.push(e)
                };
                b.setAttribute("data-creative-load-listener", "");
                b.addEventListener("creativeLoad", function(e) {
                    g(e.detail)
                });
                h.addEventListener("message", function(e) {
                    q(b, g, e)
                })
            }
    };
}).call(this);
clsn("gcc_BOcCa5yMDLrG2fMP6JnQ2QQ");
document.write('\x3ca target\x3d\x22_blank\x22 id\x3d\x22img_anch_CJyen8zQm5gDFTpjdggd6Aw0Sw\x22 href\x3d\x22https://adclick.g.doubleclick.net/pcs/click?xai\x3dAKAOjsv-hiMgG9M6O69jcqT3ZmGSf526-M_GF0BJ5H1o6Ysa_e-UtoKXroY9ElEjLedZyF1WpCW1CJXe-T8G01xuwSIlN6n9GYWKWSWoZK4xuPw1ClrO_4CPWAGFyz1lX-vDnCXnh1pjPh1w7Z6jjcBQklfFgKvmDOVA8s-bgOHR2xPOg3mp_XaQ_BwWgWHAO5js_zMIj7dIaTyLHI_dsZfi2uRAam2d9ZoxA8HSzi-PcF5KPwOr-DVN2s_saIpXtzbpnBeNXTIBhD8oLFbYs4UE8f7CKN9bOFJoU1Evy3flQcPisa7pFSjVeB29Hj6aBCqX9A_H_cuk0dmMMhBucM0wWF2QKWs2f6-DbKOOA5k3NZ-uxjh9TKEJ9JKcgFduiOakxnfekEFdYBWPc5MRxWcmA-uLEczvswzk1HZ1vVKL5lUnIDsKJfvB04KVCjjTwPk--8c-hCo_vuDf8PNLxbTikTmcyoBPH3LjgVzzXyNvOVRISBxbGe1ghC-EDbuKoPrLlZDxzJ4hLuZEEezfWzywMCMmFA8zaUNSLCfS-xv-tFx7Vp65J76m-5voB44d7M91-f0ghwgssPV0wdrlnnaGrxwJcALhHcxRoQ0wGW0XJ2lwcHpX22U1O6uTR5lbwwMnmgj_5Y-kiJdAX4ZMLj0xCUPf48nHiCQY0MyHPsGin3yArgtNDNZr2XZQ7aidYbIQovzU_lIkyXUb6I52IxpeBa6cWgqemOJRX0FUV6UQe_plTtdudiomtebvx5lU4PyNB0L9UjNGxPBrsjx1EKFtH7RiOxGG5Ph0fnYRCvakEliNK82JJ3fCpiWssCDLnWL4i4FcLp9OHIlJPJBTu9qktv5ah7mMezeQKjbkAiJTJQqhJPo-5m3oJkPozK1RorSGTd2B7NpYd36rRZNjGNomaIvnkKiV3wXtCuh0Pp2WgbyLKaD4JHFCdrzpouhW4J6MIppF8V-UKj8kIZWh6VPWp7PL10UdqtLIx5v_kJgwqjPF8MdIbTycAyN9Nhlwcp0Idf4Kq5Hn7oWfhvU0nS2ARMcEn60Mii-4oH44vgPsaJqQRqnmHkp8pmu_7XUGp5QnKDbEzSGh1v-MSh8GNm24T2izJBlpCE2dkt-K5NAouxsOTnhqbeLgvHMJciJzycxw1NDjMDEB7nYvetbJ9rAXUNrrds_nRp5U8dU0Vpwbt2mfma3KyhP_RA8XZFh_BOVjWsG1PfJV-oXVJt2V9xDBI-EaOEhfXmrMQHge2b_EOyuTtR1aGKE-3OosyqpaTzhgb7LcjfFT6X-9FMsEpQDdKCXBMi3g0pxxgEqO8XqaP0ZW90TfPpNm62583CPYxmjXDoL3Std-W_YUtEkljH7grvJhNOkw0hdMBLrHAR8ThU5kv2sQiQF8Da9LIomdeAAkq1wawWjY5ZmPC1GYW-KSYUxxEsencbClN0sSH_SHmMUtGyIZE1zHXcW-5spnm7P74uccF0Brl98ShKO1fKYo7p_8x-X2Sjj1HP5rJlIZ0EaAKUrE3VFajZnQxxIksxHomXkJJKyBNH3ICuO6OdM6jdrIb9t5cjQtfpUrUnC3EJAn7QPqXDhiMBx8ZliY8apAiu-sGwp38fXOISHGlWJ84BvrWlSC-_o54txwWFCtGPWmDH67UeEGXemldDRK75fQa-O9QDaoZmAVdMDfzJoBlZRJGl4WcET76ktueM5e_akFNCwlxB9Nn5XFeguLqFLzYqoNaRC7Ls3139Lu41H4weHJ-IpQdL3CpCVx_9SiWWLPuQDJ55BmtuagNHQB3aLuobOfDMJ3iwBlsBu4yW9eh-NCV3OhM-FIc9ve_eg7dAjv\x26amp;sai\x3dAMfl-YTfnhj7OifB22i59QsPrtVcy7vBeVXkYtQc36LFfsLIy3HI-MbDi5he24ZJVaOwnyTJh97nWTR5LfTq609Gc14k5Uu7gGM-CEbkGeVWzBnbRmj_Txp__AtbrPJQeWVcdPu4A7TBRg8ldQAMRuQ61O_NPeAJgSM1jGj6rWPlB03eCuXGqPJwHqf7wkxxr4u-z9bB_O-WUf6ZJu1L31ec7j06m7nFmxfXAOEXto8kcyWjv0id0TMr0vBboawTnRW1Lsb_a8DGMbzM5_BSiEE_CjAgrFbni7yjq4bUYAYTDoLQPaHgRFUQ4URAwNrvpZOWvuLr4OllJ6rEcLVRvmkJzeQecSk1Ddsm0jxi0dIGmEjXBNXh_LWLLwK-nmCqlEZ9wdgssK_DfsUXiDdzhq9eil2w2Pb06ZVoJSqw7sO2re4k3XWibweCBgzBW9IlkEh25Gb-TEGek8Jpxr97zVfR1vGtp9VQw0Fg_G07PjdvhdJHK5TZgFeQMDclw2nCCkpLzfBJ6WBjBluMC9Y0J6Bd4-tkJhc2TsCgVR245xkFFzyfX79fmirMq0v_iZAyQokHABGsNQFJcpiPEsZGT0fWQELFxGwxM2HOMMCJvICIFIMatXS29cg1puDGiyns7ia3P1TzGT3K4xf7pIjUp7Koo4tTKSg-6-ir38HI\x26amp;sig\x3dCg0ArKJSzI7567sVaBnR\x26amp;pr\x3d13:awLnAAAAAABwzFJPQCgMqT1SCEcvFN-gBun6Yg\x26amp;fbs_aeid\x3d%5Bgw_fbsaeid%5D\x26amp;urlfix\x3d1\x26amp;adurl\x3dhttps://asklocala.com/it%3Futm_source%3Dreferral%26utm_medium%3Dpaid%26utm_campaign%3Dadaptive-advertising-launch-2026%26utm_term%3D%26utm_content%3Dwpp-mpu\x22\x3e\x3cimg src\x3d\x22https://s0.2mdn.net/simgad/12431293831503081292\x22 alt\x3d\x22Advertisement\x22 border\x3d\x220\x22 width\x3d\x22300\x22 height\x3d\x22250\x22 style\x3d\x22display:block\x22\x3e\x3c/a\x3e\x3cscript data-jc\x3d\x2274\x22 data-jc-version\x3d\x22r20261118\x22 data-jcp-a-id\x3d\x22img_anch_CJyen8zQm5gDFTpjdggd6Aw0Sw\x22 data-jcp-cc-overlay\x3d\x22\x22 data-jcp-cc-button\x3d\x22\x22 data-jcp-is-fledge\x3d\x22false\x22 data-jcp-turtlex-event-ad-signals\x3d\x22\x22 data-jcp-turtlex-event-ad-metadata\x3d\x22\x22\x3e(function(){var aa\x3dtypeof Object.create\x3d\x3d\x22function\x22?Object.create:function(a){function b(){}b.prototype\x3da;return new b},ba\x3dtypeof Object.defineProperties\x3d\x3d\x22function\x22?Object.defineProperty:function(a,b,c){if(a\x3d\x3dArray.prototype||a\x3d\x3dObject.prototype)return a;a[b]\x3dc.value;return a}; function ca(a){a\x3d[\x22object\x22\x3d\x3dtypeof globalThis\x26\x26globalThis,a,\x22object\x22\x3d\x3dtypeof window\x26\x26window,\x22object\x22\x3d\x3dtypeof self\x26\x26self,\x22object\x22\x3d\x3dtypeof global\x26\x26global];for(var b\x3d0;b\x3ca.length;++b){var c\x3da[b];if(c\x26\x26c.Math\x3d\x3dMath)return c}throw Error(\x22Cannot find global object\x22);}var da\x3dca(this);function l(a,b){if(b)a:{var c\x3dda;a\x3da.split(\x22.\x22);for(var d\x3d0;d\x3ca.length-1;d++){var e\x3da[d];if(!(e in c))break a;c\x3dc[e]}a\x3da[a.length-1];d\x3dc[a];b\x3db(d);b!\x3dd\x26\x26b!\x3dnull\x26\x26ba(c,a,{configurable:!0,writable:!0,value:b})}}var r; if(typeof Object.setPrototypeOf\x3d\x3d\x22function\x22)r\x3dObject.setPrototypeOf;else{var t;a:{var ea\x3d{a:!0},u\x3d{};try{u.__proto__\x3dea;t\x3du.a;break a}catch(a){}t\x3d!1}r\x3dt?function(a,b){a.__proto__\x3db;if(a.__proto__!\x3d\x3db)throw new TypeError(a+\x22 is not extensible\x22);return a}:null}var v\x3dr; function w(a,b){a.prototype\x3daa(b.prototype);a.prototype.constructor\x3da;if(v)v(a,b);else for(var c in b)if(c!\x3d\x22prototype\x22)if(Object.defineProperties){var d\x3dObject.getOwnPropertyDescriptor(b,c);d\x26\x26Object.defineProperty(a,c,d)}else a[c]\x3db[c];a.B\x3db.prototype}l(\x22Number.isFinite\x22,function(a){return a?a:function(b){return typeof b!\x3d\x3d\x22number\x22?!1:!isNaN(b)\x26\x26b!\x3d\x3dInfinity\x26\x26b!\x3d\x3d-Infinity}});l(\x22Number.MAX_SAFE_INTEGER\x22,function(){return 9007199254740991});l(\x22Number.MIN_SAFE_INTEGER\x22,function(){return-9007199254740991}); l(\x22Number.isNaN\x22,function(a){return a?a:function(b){return typeof b\x3d\x3d\x3d\x22number\x22\x26\x26isNaN(b)}});/*  Copyright The Closure Library Authors. SPDX-License-Identifier: Apache-2.0 */ var x\x3dthis||self;function fa(a){x.setTimeout(function(){throw a;},0)};var y,z;a:{for(var ha\x3d[\x22CLOSURE_FLAGS\x22],A\x3dx,B\x3d0;B\x3cha.length;B++)if(A\x3dA[ha[B]],A\x3d\x3dnull){z\x3dnull;break a}z\x3dA}var ia\x3dz\x26\x26z[748402147];y\x3dia!\x3dnull?ia:!0;function ja(a,b){a.__closure__error__context__984382||(a.__closure__error__context__984382\x3d{});a.__closure__error__context__984382.severity\x3db};var ka\x3dvoid 0;function la(){var a\x3dError(\x22int32\x22);ja(a,\x22warning\x22);return a};var C\x3dtypeof Symbol\x3d\x3d\x3d\x22function\x22\x26\x26typeof Symbol()\x3d\x3d\x3d\x22symbol\x22;function D(a,b,c){return typeof Symbol\x3d\x3d\x3d\x22function\x22\x26\x26typeof Symbol()\x3d\x3d\x3d\x22symbol\x22?(c\x3d\x3d\x3dvoid 0?0:c)\x26\x26Symbol.for\x26\x26a?Symbol.for(a):a!\x3dnull?Symbol(a):Symbol():b}var na\x3dD(\x22jas\x22,void 0,!0),E\x3dD(void 0,\x220actk\x22),F\x3dD(\x22m_m\x22,\x22A\x22,!0);var oa\x3d{u:{value:0,configurable:!0,writable:!0,enumerable:!1}},pa\x3dObject.defineProperties,G\x3dC?na:\x22u\x22;function qa(a,b){C||G in a||pa(a,oa);a[G]|\x3db}function H(a,b){C||G in a||pa(a,oa);a[G]\x3db};var I\x3d{};function ra(a,b){return b\x3d\x3d\x3dvoid 0?a.i!\x3d\x3dJ\x26\x26!!(2\x26(a.h[G]|0)):!!(2\x26b)\x26\x26a.i!\x3d\x3dJ}var J\x3d{};var K\x3dtypeof x.BigInt\x3d\x3d\x3d\x22function\x22\x26\x26typeof x.BigInt(0)\x3d\x3d\x3d\x22bigint\x22;var sa\x3dNumber.MIN_SAFE_INTEGER.toString(),ta\x3dK?BigInt(Number.MIN_SAFE_INTEGER):void 0,ua\x3dNumber.MAX_SAFE_INTEGER.toString(),va\x3dK?BigInt(Number.MAX_SAFE_INTEGER):void 0;function wa(a,b){if(a.length\x3eb.length)return!1;if(a.length\x3cb.length||a\x3d\x3d\x3db)return!0;for(var c\x3d0;c\x3ca.length;c++){var d\x3da[c],e\x3db[c];if(d\x3ee)return!1;if(d\x3ce)return!0}};var xa\x3dNumber.isFinite;function ya(a){if(typeof a!\x3d\x3d\x22number\x22)throw la();if(!xa(a))throw la();return a|0};function za(a){return a};function L(a,b,c,d){var e\x3dd!\x3d\x3dvoid 0;d\x3d!!d;var g\x3d[],f\x3da.length,k\x3d4294967295,m\x3d!1,h\x3d!!(b\x2664),n\x3dh?b\x26128?0:-1:void 0;if(!(b\x261)){var p\x3df\x26\x26a[f-1];p!\x3dnull\x26\x26typeof p\x3d\x3d\x3d\x22object\x22\x26\x26p.constructor\x3d\x3d\x3dObject?(f--,k\x3df):p\x3dvoid 0;if(h\x26\x26!(b\x26128)\x26\x26!e){m\x3d!0;var q;k\x3d((q\x3dAa)!\x3dnull?q:za)(k-n,n,a,p,void 0)+n}}b\x3dvoid 0;for(e\x3d0;e\x3cf;e++)if(q\x3da[e],q!\x3dnull\x26\x26(q\x3dc(q,d))!\x3dnull)if(h\x26\x26e\x3e\x3dk){var La\x3de-n,ma\x3dvoid 0;((ma\x3db)!\x3dnull?ma:b\x3d{})[La]\x3dq}else g[e]\x3dq;if(p)for(var Q in p)a\x3dp[Q],a!\x3dnull\x26\x26(a\x3dc(a,d))!\x3dnull\x26\x26(f\x3d+Q,e\x3dvoid 0,h\x26\x26!Number.isNaN(f)\x26\x26 (e\x3df+n)\x3ck?g[e]\x3da:(f\x3dvoid 0,((f\x3db)!\x3dnull?f:b\x3d{})[Q]\x3da));b\x26\x26(m?g.push(b):g[k]\x3db);return g}function Ba(a){switch(typeof a){case \x22number\x22:return Number.isFinite(a)?a:\x22\x22+a;case \x22bigint\x22:return(K?a\x3e\x3dta\x26\x26a\x3c\x3dva:a[0]\x3d\x3d\x3d\x22-\x22?wa(a,sa):wa(a,ua))?Number(a):\x22\x22+a;case \x22boolean\x22:return a?1:0;case \x22object\x22:if(Array.isArray(a)){var b\x3da[G]|0;return a.length\x3d\x3d\x3d0\x26\x26b\x261?void 0:L(a,b,Ba)}if(a!\x3dnull\x26\x26a[F]\x3d\x3d\x3dI)return M(a);return}return a}var Aa;function M(a){a\x3da.h;return L(a,a[G]|0,Ba)};function N(a,b,c,d){d\x3dd\x3d\x3d\x3dvoid 0?0:d;if(a\x3d\x3dnull){var e\x3d32;c?(a\x3d[c],e|\x3d128):a\x3d[];b\x26\x26(e\x3de\x26-16760833|(b\x261023)\x3c\x3c14)}else{if(!Array.isArray(a))throw Error(\x22narr\x22);e\x3da[G]|0;if(y\x26\x261\x26e)throw Error(\x22rfarr\x22);2048\x26e\x26\x26!(2\x26e)\x26\x26Ca();if(e\x26256)throw Error(\x22farr\x22);if(e\x2664)return(e|d)!\x3d\x3de\x26\x26H(a,e|d),a;if(c\x26\x26(e|\x3d128,c!\x3d\x3da[0]))throw Error(\x22mid\x22);a:{c\x3da;e|\x3d64;var g\x3dc.length;if(g){var f\x3dg-1,k\x3dc[f];if(k!\x3dnull\x26\x26typeof k\x3d\x3d\x3d\x22object\x22\x26\x26k.constructor\x3d\x3d\x3dObject){b\x3de\x26128?0:-1;f-\x3db;if(f\x3e\x3d1024)throw Error(\x22pvtlmt\x22);for(var m in k)g\x3d +m,g\x3cf\x26\x26(c[g+b]\x3dk[m],delete k[m]);e\x3de\x26-16760833|(f\x261023)\x3c\x3c14;break a}}if(b){m\x3dMath.max(b,g-(e\x26128?0:-1));if(m\x3e1024)throw Error(\x22spvt\x22);e\x3de\x26-16760833|(m\x261023)\x3c\x3c14}}}H(a,e|64|d);return a}function Ca(){if(y)throw Error(\x22carr\x22);if(E!\x3dnull){var a;var b\x3d(a\x3dka)!\x3dnull?a:ka\x3d{};a\x3db[E]||0;a\x3e\x3d5||(b[E]\x3da+1,b\x3dError(),ja(b,\x22incident\x22),fa(b))}};function Da(a,b){if(typeof a!\x3d\x3d\x22object\x22)return a;if(Array.isArray(a)){var c\x3da[G]|0;a.length\x3d\x3d\x3d0\x26\x26c\x261?a\x3dvoid 0:c\x262||(!b||4096\x26c||16\x26c?a\x3dO(a,c,!1,b\x26\x26!(c\x2616)):(qa(a,34),c\x264\x26\x26Object.freeze(a)));return a}if(a!\x3dnull\x26\x26a[F]\x3d\x3d\x3dI){b\x3da.h;c\x3db[G]|0;if(!ra(a,c)){if(c\x262)var d\x3d!0;else c\x2632\x26\x26!(c\x264096)?(H(b,c|2),a.i\x3dJ,d\x3d!0):d\x3d!1;d?(a\x3dnew a.constructor(b),a.v\x3dJ):a\x3dO(b,c)}return a}}function O(a,b,c,d){d!\x3dnull||(d\x3d!!(34\x26b));a\x3dL(a,b,Da,d);d\x3d32;c\x26\x26(d|\x3d2);b\x3db\x2616769217|d;H(a,b);return a};function P(a,b,c){if(a.i\x3d\x3d\x3dJ){var d\x3da.h;d\x3dO(d,d[G]|0);qa(d,2048);a.h\x3dd;a.i\x3dvoid 0;a.v\x3dvoid 0;d\x3d!0}else d\x3d!1;if(!d\x26\x26ra(a,a.h[G]|0))throw Error();a\x3da.h;a:{var e\x3da[G]|0;d\x3db+-1;var g\x3da.length-1;if(g\x3e\x3d0\x26\x26d\x3e\x3dg){var f\x3da[g];if(f!\x3dnull\x26\x26typeof f\x3d\x3d\x3d\x22object\x22\x26\x26f.constructor\x3d\x3d\x3dObject){f[b]\x3dc;break a}}d\x3c\x3dg?a[d]\x3dc:c!\x3d\x3dvoid 0\x26\x26(e\x3d(e!\x3dnull?e:a[G]|0)\x3e\x3e14\x261023||536870912,b\x3e\x3de?c!\x3dnull\x26\x26(d\x3d{},a[e+-1]\x3d(d[b]\x3dc,d)):a[d]\x3dc)}}function R(a,b,c){if(c!\x3dnull\x26\x26typeof c!\x3d\x3d\x22string\x22)throw Error();P(a,b,c)};function S(a,b,c){this.h\x3dN(a,b,c,2048)}S.prototype.toJSON\x3dfunction(){return M(this)};S.prototype[F]\x3dI;S.prototype.toString\x3dfunction(){return this.h.toString()};function Ea(a){this.h\x3dN(a,void 0,void 0,2048)}w(Ea,S);function Fa(a){this.h\x3dN(a,void 0,void 0,2048)}w(Fa,S);function Ga(){var a\x3dx;return a\x3da\x3d\x3d\x3dvoid 0?window:a};/*  Copyright Google LLC SPDX-License-Identifier: Apache-2.0 */ var Ha\x3d/^\\s*(?!javascript:)(?:[\\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;var T;function Ia(a,b,c,d){var e\x3d/^(https?:[^:?]+[/]pcs[/]click[^/]+?)(?:\x26nx[^\x26]+\x26ny[^\x26]+\x26dim[^\x26]+)?(\x26adurl\x3d.*)/.exec(a);return e?e[1]+(\x22\x26nx\x3d\x22+b+\x22\x26ny\x3d\x22+c+\x22\x26dim\x3d\x22+d)+e[2]:a}function Ja(a){var b\x3da.currentTarget,c\x3db.querySelector(\x22img[alt]\x22);c\x26\x26(a\x3dU(a,c.offsetLeft,c.offsetTop,c.width,c.height),a\x3dIa(b.href,a.l,a.m,a.j),Ha.test(a)\x26\x26(b.href\x3da))}function Ka(a,b){var c,d;(c\x3dGa())\x3d\x3dnull||(d\x3dc.fence)\x3d\x3dnull||d.setReportEventDataForAutomaticBeacons({eventType:a,eventData:b,destination:[\x22buyer\x22],once:!0})} function Ma(a,b){var c,d;(c\x3dGa())\x3d\x3dnull||(d\x3dc.fence)\x3d\x3dnull||d.reportEvent({eventType:\x22click\x22,eventData:a,destination:[b]})}function V(a,b){var c\x3dnew Fa;R(c,1,a);a\x3dJSON.stringify(M(T));R(c,4,a);R(c,10,Date.now().toString());Ka(\x22reserved.top_navigation\x22,JSON.stringify(M(c)));Ka(\x22reserved.top_navigation_start\x22,JSON.stringify(M(c)));Ma(JSON.stringify(M(c)),\x22buyer\x22);Ma(b,\x22component-seller\x22)}function U(a,b,c,d,e){return{l:+Math.round(a.clientX-b),m:+Math.round(a.clientY-c),j:+d+\x22x\x22+ +e,o:void 0}};var W,X\x3ddocument.currentScript;W\x3d(X\x3dX\x3d\x3d\x3dvoid 0?null:X)\x26\x26X.getAttribute(\x22data-jc\x22)\x3d\x3d\x3d\x2274\x22?X:document.querySelector(\x27[data-jc\x3d\x2274\x22]\x27);if(W\x3d\x3dnull)throw Error(\x22JSC not found 74\x22);for(var Na\x3d{},Y\x3dW.attributes,Z\x3dY.length-1;Z\x3e\x3d0;Z--){var Oa\x3dY[Z].name;Oa.indexOf(\x22data-jcp-\x22)\x3d\x3d\x3d0\x26\x26(Na[Oa.substring(9)]\x3dY[Z].value)} (function(a){var b\x3ddocument.getElementById(a[\x22a-id\x22]),c\x3da[\x22cc-overlay\x22],d\x3da[\x22cc-button\x22],e\x3dc?document.getElementById(c):null,g\x3dd?document.getElementById(d):null;c\x3da[\x22is-fledge\x22]\x3d\x3d\x3d\x22true\x22;d\x3de\x26\x26g;T\x3dnew Ea;if(c){var f\x3dd?e:b.querySelector(\x22img[alt]\x22);(d?e:b).addEventListener(\x22mousedown\x22,function(h){var n\x3dU(h,f.offsetLeft,f.offsetTop,f.clientWidth,f.clientHeight);h\x3dn.l;var p\x3dn.m,q\x3dn.j;n\x3dn.o;h\x26\x26P(T,2,h\x3d\x3dnull?h:ya(h));p\x26\x26P(T,3,p\x3d\x3dnull?p:ya(p));q\x26\x26R(T,7,q);n\x26\x26R(T,4,n)});var k\x3da[\x22turtlex-event-ad-signals\x22], m\x3da[\x22turtlex-event-ad-metadata\x22];g?(g.addEventListener(\x22click\x22,function(){V(k,m)}),g.addEventListener(\x22auxclick\x22,function(){V(k,m)})):(b.addEventListener(\x22click\x22,function(){V(k,m)}),b.addEventListener(\x22auxclick\x22,function(){V(k,m)}))}else b.addEventListener(\x22mousedown\x22,Ja),d\x26\x26e.addEventListener(\x22mousedown\x22,function(h){h\x3dU(h,e.offsetLeft,e.offsetTop,e.clientWidth,e.clientHeight);h\x3dIa(g.href,h.l,h.m,h.j);Ha.test(h)\x26\x26(g.href\x3dh)})})(Na);}).call(this);\x3c/script\x3e');
document.write('\x3c/div\x3e');
document.write('\x3c/div\x3e');
document.write('\x3cstyle\x3ediv{margin:0;padding:0;}.abgcp{height:15px;padding-right:1px;padding-top:1px;padding-left:9px;padding-bottom:13px;right:0px;top:0px;position:absolute;width:31px;z-index:2147483646;}.abgc{display:block;height:15px;position:absolute;right:1px;top:1px;text-rendering:geometricPrecision;z-index:2147483646;}.abgb{display:inline-block;height:15px;}.abgc,.abgcp,.jar .abgc,.jar .abgcp,.jar .cbb{opacity:1;}.abgc{cursor:pointer;}.cbb{cursor:pointer;height:15px;width:15px;z-index:2147483646;background-color:#ffffff;opacity:0;}.cbb svg{position:absolute;top:0;right:0;height:15px;width:15px;stroke:;fill:#00aecd;stroke-width:1.25;}.abgb{position:absolute;right:16px;top:0px;}.cbb{position:absolute;right:0px;top:0px;}.abgs{display:none;height:100%;}.abgl{text-decoration:none;}.abgs svg,.abgb svg{display:inline-block;height:15px;width:auto;vertical-align:top;}.abgc .il-wrap{background-color:#ffffff;height:15px;white-space:nowrap;}.abgc .il-wrap.exp{border-bottom-left-radius:5px;}.abgc .il-text,.abgc .il-icon{display:inline-block;}.abgc .il-text{padding-right:1px;padding-left:5px;height:15px;width:55px;}.abgc .il-icon{height:15px;width:15px;}.abgc .il-text svg{fill:#000000;}.abgc .il-icon svg{fill:#00aecd}\x3c/style\x3e\x3cdiv id\x3d\x22abgcp\x22 class\x3d\x22abgcp\x22\x3e\x3cdiv id\x3d\x22abgc\x22 class\x3d\x22abgc\x22 dir\x3d\x22ltr\x22\x3e\x3cdiv id\x3d\x22abgb\x22 class\x3d\x22abgb\x22\x3e\x3cdiv class\x3d\x22il-wrap\x22\x3e\x3cdiv class\x3d\x22il-icon\x22\x3e\x3csvg xmlns\x3d\x22http://www.w3.org/2000/svg\x22 viewBox\x3d\x220 0 15 15\x22\x3e\x3cpath fill\x3d\x22#fff\x22 d\x3d\x22M0 0h15v15H0z\x22/\x3e\x3ccircle cx\x3d\x226\x22 cy\x3d\x226\x22 r\x3d\x22.67\x22/\x3e\x3cpath d\x3d\x22M4.2 11.3q-.9.5-.9-.55V4.1q0-1 1-.6L10.4 7q1.6.5 0 1l-3.75 2V7.75a.65.65 0 1 0-1.3 0v3a.9.9 0 0 0 1.3.8L12.7 8.2q1-.7 0-1.5L3.3 1.6q-1.1-.3-1.5.9v10q.4 1.4 1.5.8l1.5-.8a.3.3 0 1 0-.6-1.2\x22/\x3e\x3c/svg\x3e\x3c/div\x3e\x3c/div\x3e\x3c/div\x3e\x3cdiv id\x3d\x22abgs\x22 class\x3d\x22abgs\x22\x3e\x3ca id\x3d\x22abgl\x22 class\x3d\x22abgl\x22 href\x3d\x22https://adssettings.google.com/whythisad?source\x3ddisplay\x26amp;reasons\x3dAWJ47B0dEzvFGnBauuSvw6OVtsZyTDfptMOBC34ccNAtSO4g_eZgeuOTKsutAuvsXC2kPVz5Qj8PBUkp_HVaDigi2B0p27eR1iMVLxEOX6QFB9RPpC3IL-xquFv7Hl7L4GmwMxCu4ZFdQa3tUyZiqVX4Sr3pwJEbZyd4X6cWHOVNcrbwf4ce7SsqRibvszMNba4NxJLVV9H0EkfqE8PvikRPdQzKZcqKsWJ9JnGM3KaPWuEwtQvkezmw1ScX1-Vx3p-nAPVcfcO0UStqS8eQkETZW5R_K49pbQB9e5BmRRwtZX2gEtYf2xcV5Xo2a3uEgXbka5FqsGNfhGpgyO3mapFWIT9HZdXzE5RdV7JVtdtYc9_IjB2gve0B7pKJUemoOot_J-Gmy7iVDXd6E6xaVDpVJeoAXJ3tTHLkr6kc-ezETJBjk9mRfL0YHnh9uRS17te6C0Yst--W0s7r82SMmRo-wMztzeYzmROiH20ioUoz9Z2Me_GHijUkOxP6WCPaREoe7if7QCed2ezXKkG7TuQx7-28eS2rakgGG8lfDk7M66ihrsKPuCgo92yloIXd-gnvvQGJ9G9ZK7WLXGxQTFK28RAB8aAZfL0wW7g4HQlOBsu5XKgHb0fSdurnTAuMltGbeZGFuv48UFoBwv56qiPmGyn7gyaia1JEGNXbYH2Jf-vKKiGlQNODFO4H-bMWOIRXShXbzpklXKTCfNeYC__XSIS301Nr6DzCGPOcz8UHWNDLvMgyECYjrasBiqbGJTHdldvY5mG_CiX8H1cfwCq9QqqahAmgUkqOUfXpgWbpeW2K2joiMoAsD7MgAaTBuo-fTt2IRq_ZuDwZAFh_cb4A2Viio3-KuzrDBarCU1ZF34cVV5WzAw-ZcpKZUQ0OQ6YGtc9mJ9osW5duCTqRuEThzfFVpjA91iM-Ih1f2UY6ZiAVblgfArM_fT_QuZRy1fvcSS2cgRKeaEAp8I1VdqE1RzmPDWuDLzqhI0I6in4B7dVR_VcYu0Y7YYDYeGf9JeIeT2XSMV-2uKg3K1KSuSKZY8dzOuU-wUHsZt9PWBCxsZ8pndFi0l9Dmb4IKo3razdGThMsQjGCuDIRPURGtdMzNtundaeS0SQoFIlr18NX08qy8g4f04w8A-HqpucZrztVoQx8ZfNy4LLj-5MZAgBu_o5bPRfJ0YLQ0zYFX2Z_vaRmbiW7fYT2_2TlVr9IaofIA5UXzg-8IMZIDDaaaMJv3XMyIxm_WBUSTHadExjFN_CoZ1zoJB3Jgje8-Jrn7jM1mAZYx9oqS8Ib1cSc61n9okavNVmJQ35MqR6TDFpbPJ5d7dR34vTKQ8VywBLDUv69bY71GgYO897odqSS1VD6cPsu9Dq_-uFauiMFz4L7OLhOcAw6EropPwSVBh8UxflIlByAFDYzpublUdtFppw6vpshjo9Fs3xNTiC94NVEtb28hnKfLLdmVFUUNx9_GtJBHsDo7NcD5k2UqBmYnJzIPH_GW-ZAQ7srevEDao948Sh0Q8ozvPUD-jbw99a_bHZGgGt2JebAv510H16Xf74ijXPSJ6OPqp--8vN2YFwu7H6ZeXKJIX6qn0PSnXAyDD3FtBIlMyHlI32jVSqtwpytHoxeQG53rPHEECXGJwIxzD2Qgb6_PRzpTtDYOPcUIbcnvukzJxBrGzosHgt-5vlc5OV3x-x5iupxeaZgJB_5i7epXtQ8PUWNx5gGe_rOgpkcN2Hyt0ixmIQQC3G_llJNXeR6qZ-88JaQtApFHBUh7nc6sBGYy0uqFSHJTBYz9B_dINOUK9iM5TCFZLlefALiYKDhWiv8Rpmb1aGKWsUj3574ngeaUoBvWrt9lYoJiez_l5LIT08SaTjsmcVI3oTEK6Uq1bGxJl96gi1jx07SSl7cgIDNWXXTC56qt-BseajWD5kTJc-xE78Y8AzX8AZtcXUMe3_6YKF6yfrWZ-aeWAw06l0DrRYoQ3aHynPE-z1nGaozCdhJmOLMkeLjFiKuIF-zre4mo8pcf-TwUY0J-VCug11ZLgT6CSA_meNA6D9A6kFweO8nqWc1t2CfMk8pF4cYo0r8Gj_kUlpScnQyXlZ5-83FFKv_0_vjxCWLfaBl4l8UQJQNM1CoUxNcLkKw2-fpIfJYpcwMtlYDP-iXZRAHGN3_-ixqcaCeg9Va8fcbcfzUJVZCMan4hmwBOnzFQTaMFcMCigX46xNsRTFA7rGykKQmklOHncsL-EUiY7rE3QgxS89dHnjj\x26amp;opi\x3d122715837\x22 target\x3d\x22_blank\x22\x3e\x3c/a\x3e\x3c/div\x3e\x3cdiv id\x3d\x22cbb\x22 class\x3d\x22cbb\x22 tabindex\x3d\x220\x22 role\x3d\x22button\x22\x3e\x3csvg xmlns\x3d\x22http://www.w3.org/2000/svg\x22 width\x3d\x2215\x22 height\x3d\x2215\x22 fill\x3d\x22none\x22 viewBox\x3d\x220 0 15 15\x22\x3e\x3cg clip-path\x3d\x22url(#clip0_2157_481)\x22\x3e\x3cpath fill\x3d\x22#fff\x22 d\x3d\x22M15 0v15H0V0z\x22/\x3e\x3cpath fill\x3d\x22#fff\x22 d\x3d\x22M15 0v15H0V0z\x22/\x3e\x3ccircle cx\x3d\x227.5\x22 cy\x3d\x2211.5\x22 r\x3d\x221.5\x22 fill\x3d\x22#00aecd\x22 transform\x3d\x22rotate(-180 7.5 11.5)\x22/\x3e\x3ccircle cx\x3d\x227.5\x22 cy\x3d\x227.5\x22 r\x3d\x221.5\x22 fill\x3d\x22#00aecd\x22 transform\x3d\x22rotate(-180 7.5 7.5)\x22/\x3e\x3ccircle cx\x3d\x227.5\x22 cy\x3d\x223.5\x22 r\x3d\x221.5\x22 fill\x3d\x22#00aecd\x22 transform\x3d\x22rotate(-180 7.5 3.5)\x22/\x3e\x3c/g\x3e\x3cdefs\x3e\x3cclipPath id\x3d\x22clip0_2157_481\x22\x3e\x3cpath fill\x3d\x22#fff\x22 d\x3d\x22M15 0v15H0V0z\x22/\x3e\x3c/clipPath\x3e\x3c/defs\x3e\x3c/svg\x3e\x3c/div\x3e\x3c/div\x3e\x3c/div\x3e\x3cstyle\x3e.mute_panel{z-index:2147483646;}.abgac{position:absolute;left:0px;top:0px;z-index:2147483646;display:none;width:100%;height:100%;background-color:#FAFAFA;}.mlsc{height:100%;display:flex;justify-content:center;align-items:center;}.mls{animation:mlskf 2s linear infinite;height:50%;width:50%;}.mlsd{stroke-dasharray:1,189;stroke-dashoffset:0;animation:mlsdkf 1.4s ease-in-out infinite;}@keyframes mlskf{100%{transform:rotate(360deg);}}@keyframes mlsdkf{0%{stroke-dasharray:1,189;stroke-dashoffset:0;}50%{stroke-dasharray:134,189;stroke-dashoffset:-53px;}100%{stroke-dasharray:134,189;stroke-dashoffset:-188px;}}\x3c/style\x3e\x3cdiv id\x3d\x22mute_panel\x22 class\x3d\x22mute_panel\x22 aria-hidden\x3d\x22true\x22\x3e\x3cdiv id\x3d\x22abgac\x22 class\x3d\x22abgac\x22 aria-hidden\x3d\x22true\x22\x3e\x3cdiv id\x3d\x22mlsc\x22 class\x3d\x22mlsc\x22\x3e\x3csvg class\x3d\x22mls\x22 viewBox\x3d\x2250 50 100 100\x22\x3e\x3ccircle class\x3d\x22mlsd\x22 cx\x3d\x22100\x22 cy\x3d\x22100\x22 r\x3d\x2230\x22 fill\x3d\x22none\x22 stroke\x3d\x22#9E9E9E\x22 stroke-width\x3d\x223\x22/\x3e\x3c/svg\x3e\x3c/div\x3e\x3c/div\x3e\x3c/div\x3e\x3cscript data-jc\x3d\x2260\x22 src\x3d\x22https://pagead2.googlesyndication.com/pagead/js/r20261118/r20110914/abg_lite.js\x22 async data-jc-version\x3d\x22r20261118\x22 data-jcp-attribution-data\x3d\x22[[null,\x26quot;https://googleads.g.doubleclick.net/pagead/images/mtad/x_blue.png\x26quot;,null,\x26quot;https://googleads.g.doubleclick.net/pagead/images/mtad/x_blue.png\x26quot;,\x26quot;https://googleads.g.doubleclick.net/pagead/interaction/?ai\x3dCeAYqAOcCa9ioJqzB2fcPj9jMmAzD1a2UiwGuxPLZsxb7LhABILflhCFg_YKAgLARyAECqQKUoe5tr2ayPqgDAcgDmQSqBOsBT9C4NQmy_wqO-DrzkbFFieYG9hkWt9_0HFfErt-QT9KYCOY389vOQcGl6aRo2osbbdRMqnZsAH97nK8SHwcDTpCjIxVXMbJ94yJml9pgWUIIBdK55rNTRkQr-ADSJt1soDrmmToqI_0bDekbDmjd0QzLBoPj_F_gwLYpEgvFKtzna8__WP7i4tumcu_EvyAJ4ghIumc9MF9iRPyKuRxWBAjXZal70AKcxOuouuGqAhy0Idh72Z_DE1niUBA4dIES6TP0d0k5zv53mxRVb0Tft9w7dUX9KymEP89eW-_QndEjhYfUbGP6GAHFosAEk4mXqu8F4AQDiAWN0MOHW5AGAaAGAoAHusX_zx-oB6nrsQKoB6fMsQKoB6a-G6gHzM6xAqgH89EbqAeW2BuoB6qbsQKoB_7osQKoB47OG6gHk9gbqAfw4BuoB-6WsQKoB6--sQKoB5_hsQKoB6brsQKoB9XJG6gH2baxAqgHmgaoB_-esQKoB9-fsQKoB_jCsQKoB_vCsQKoB7_TsQKoB-fXsQLYBwDSCDcIgOGAEBABGF8yCaqCgICAgKCIAToRgMADgICEgICUruADqIeAmAFIvf3BOli7sMTK0JuYA2AB8ggNYmlkZGVyLTIyNjA0MYAKBMgLAYAMAaIMCCoGCgT28rECqg0CSVTwDQGIDg6wE7q81ibQEwDYEwPYFAHQFQHKFgIKAPgWAYAXAbIXEBgCKgo0MTE0MTkxMTQzUAayGAkSAuVZGAIiAQDQGQE\\u0026sigh\x3dSPQ3MUzbHhQ\\u0026cid\x3dCAQSuQEAogo4dXQ8mhYYcOuyvj22FNo3VDStCRW4w3s9PhjxbcGJM5mWy83wOFKgjHPDyjIyLMXUCdLdere_LJElYXTcgmfL9mOMy9mMyAfXCQ281Kl-SM4M8SBDn_rW77MhPEEW_WFY48uXMXGhk5vSEfCQTYYWaW6PoToGKeazGdPNoOY0DGPGwRXy2jmaz8NMJgLt_-BCuSL4Su3-jpI4d2_1lnBD2cN9rt96-kmqyp5Zq2q6KkCMez8dnBgB\x26quot;,\x26quot;D5Lr4uBbKsEIrsTy2bMWEI3Qw4dbGOKg0vofIg1hc2tsb2NhbGEuY29tMggIBRMY7pkWFEIXY2EtcHViLTU3MjI2MTAzNDc1NjUyNzRIGVgAcAHaARMInJ6fzNCbmAMVOmN2CB3oDDRL\x26quot;,[\x26quot;user_feedback_menu_interaction\x26quot;,\x26quot;\x26quot;,0],null,null,null,null,\x26quot;What was wrong with this ad?\x26quot;,null,\x26quot;https://googleads.g.doubleclick.net/pagead/images/mtad/back_blue.png\x26quot;,\x26quot;Thanks for the feedback!\x26quot;,\x26quot;We’ll review this ad to improve your experience in the future.\x26quot;,\x26quot;Thanks for the feedback!\x26quot;,\x26quot;We’ll use your feedback to review ads on this site.\x26quot;,null,null,null,\x26quot;Closing ad: %1$d\x26quot;,null,\x26quot;https://googleads.g.doubleclick.net/pagead/images/mtad/ad_choices_blue.png\x26quot;,\x26quot;https://www.google.com/url?ct\x3dabg\\u0026q\x3dhttps://www.google.com/adsense/support/bin/request.py%3Fcontact%3Dabg_afc%26url%3Dhttps://www.crazygames.com/game/chainsaw-dance%26gl%3DIT%26hl%3Den%26ai0%3D\\u0026usg\x3dAOvVaw1xTg0aweaTa-jUVDXPfwle\x26quot;,\x26quot;https://googleads.g.doubleclick.net/pagead/images/mtad/x_blue.png\x26quot;,0,[[\x26quot;Stop seeing this ad\x26quot;,[\x26quot;user_feedback_menu_option\x26quot;,\x26quot;1\x26quot;,1],[\x26quot;What was wrong with this ad?\x26quot;,[[\x26quot;Ad covered content\x26quot;,[\x26quot;mute_survey_option\x26quot;,\x26quot;3\x26quot;,1]],[\x26quot;Seen this ad multiple times\x26quot;,[\x26quot;mute_survey_option\x26quot;,\x26quot;2\x26quot;,1]],[\x26quot;Not interested in this ad\x26quot;,[\x26quot;mute_survey_option\x26quot;,\x26quot;7\x26quot;,1]],[\x26quot;Ad was inappropriate\x26quot;,[\x26quot;mute_survey_option\x26quot;,\x26quot;8\x26quot;,1]]]],[\x26quot;user_feedback_undo\x26quot;,\x26quot;1\x26quot;,1]]],[\x26quot;https://googleads.g.doubleclick.net/pagead/images/adchoices/iconx2-000000.png\x26quot;,\x26quot;AdChoices\x26quot;,\x26quot;Ad closed by %1$s\x26quot;,null,\x26quot;https://www.gstatic.com/images/branding/googlelogo/2x/googlelogo_dark_color_84x28dp.png\x26quot;,\x26quot;Stop seeing this ad\x26quot;,\x26quot;We\x26#39;ll try not to show that ad again\x26quot;,null,null,null,null,null,null,\x26quot;See my Google ad settings\x26quot;,null,\x26quot;https://www.gstatic.com\x26quot;,\x26quot;\x26quot;,\x26quot;Ads by %1$s\x26quot;,\x26quot;Ad settings\x26quot;,\x26quot;https://adssettings.google.com\x26quot;,null,null,null,0,null,null,null,0,1],\x26quot;AJdnK60AAAhFW1tbW251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxbWyJXUFAgTWVkaWEgUGx1cyBTLnIubC4iLCJJVCIsMSxudWxsLDFdLCI4NTc4Njk5MzYyIl1dLFtudWxsLCJodHRwczovL2dvb2dsZWFkcy5nLmRvdWJsZWNsaWNrLm5ldC9wYWdlYWQvaW50ZXJhY3Rpb24vP2FpPUNlQVlxQU9jQ2E5aW9KcXpCMmZjUGo5ak1tQXpEMWEyVWl3R3V4UExac3hiN0xoQUJJTGZsaENGZ19ZS0FnTEFSeUFFQ3FRS1VvZTV0cjJheVBxZ0RBY2dEbVFTcUJPc0JUOUM0TlFteV93cU8tRHJ6a2JGRmllWUc5aGtXdDlfMEhGZkVydC1RVDlLWUNPWTM4OXZPUWNHbDZhUm8yb3NiYmRSTXFuWnNBSDk3bks4U0h3Y0RUcENqSXhWWE1iSjk0eUptbDlwZ1dVSUlCZEs1NXJOVFJrUXItQURTSnQxc29Ecm1tVG9xSV8wYkRla2JEbWpkMFF6TEJvUGpfRl9nd0xZcEVndkZLdHpuYThfX1dQN2k0dHVtY3VfRXZ5QUo0Z2hJdW1jOU1GOWlSUHlLdVJ4V0JBalhaYWw3MEFLY3hPdW91dUdxQWh5MElkaDcyWl9ERTFuaVVCQTRkSUVTNlRQMGQwazV6djUzbXhSVmIwVGZ0OXc3ZFVYOUt5bUVQODllVy1fUW5kRWpoWWZVYkdQNkdBSEZvc0FFazRtWHF1OEY0QVFEaUFXTjBNT0hXNUFHQWFBR0FvQUh1c1hfengtb0I2bnJzUUtvQjZmTXNRS29CNmEtRzZnSHpNNnhBcWdIODlFYnFBZVcyQnVvQjZxYnNRS29CXzdvc1FLb0I0N09HNmdIazlnYnFBZnc0QnVvQi02V3NRS29CNi0tc1FLb0I1X2hzUUtvQjZicnNRS29COVhKRzZnSDJiYXhBcWdIbWdhb0JfLWVzUUtvQjktZnNRS29CX2pDc1FLb0JfdkNzUUtvQjdfVHNRS29CLWZYc1FMWUJ3RFNDRGNJZ09HQUVCQUJHRjh5Q2FxQ2dJQ0FnS0NJQVRvUmdNQURnSUNFZ0lDVXJ1QURxSWVBbUFGSXZmM0JPbGk3c01USzBKdVlBMkFCOGdnTlltbGtaR1Z5TFRJeU5qQTBNWUFLQk1nTEFZQU1BYUlNQ0NvR0NnVDI4ckVDcWcwQ1NWVHdEUUdJRGc2d0U3cTgxaWJRRXdEWUV3UFlGQUhRRlFIS0ZnSUtBUGdXQVlBWEFiSVhFQmdDS2dvME1URTBNVGt4TVRRelVBYXlHQWtTQXVWWkdBSWlBUURRR1FFXHUwMDI2c2lnaD1TUFEzTVV6YkhoUVx1MDAyNmNpZD1DQVFTdVFFQW9nbzRkWFE4bWhZWWNPdXl2ajIyRk5vM1ZEU3RDUlc0dzNzOVBoanhiY0dKTTVtV3k4M3dPRktnakhQRHlqSXlMTVhVQ2RMZGVyZV9MSkVsWVhUY2dtZkw5bU9NeTltTXlBZlhDUTI4MUtsLVNNNE04U0JEbl9yVzc3TWhQRUVXX1dGWTQ4dVhNWEdoazV2U0VmQ1FUWVlXYVc2UG9Ub0dLZWF6R2RQTm9PWTBER1BHd1JYeTJqbWF6OE5NSmdMdF8tQkN1U0w0U3UzLWpwSTRkMl8xbG5CRDJjTjlydDk2LWttcXlwNVpxMnE2S2tDTWV6OGRuQmdCIixbbnVsbCxudWxsLG51bGwsImh0dHBzOi8vZGlzcGxheWFkcy1mb3JtYXRzLmdvb2dsZXVzZXJjb250ZW50LmNvbS9hZHMvcHJldmlldy9jb250ZW50LmpzP2NsaWVudD13dGFcdTAwMjZvYmZ1c2NhdGVkQ3VzdG9tZXJJZD02MDY1MTY4MzM4XHUwMDI2Y3JlYXRpdmVJZD04MzE4MTE4NzExNjlcdTAwMjZ2ZXJzaW9uSWQ9MFx1MDAyNmFkR3JvdXBDcmVhdGl2ZUlkPTc2OTc5Mjk3NTQwNlx1MDAyNnNpZz1BQ2lWQl95a1dSb2pFQUZ0Q1F3QTIybmpGS1dCN0xHZnZRIl0sbnVsbCxudWxsLDIsIkQ1THI0dUJiS3NFSXJzVHkyYk1XRUkzUXc0ZGJHT0tnMHZvZklnMWhjMnRzYjJOaGJHRXVZMjl0TWdnSUJSTVk3cGtXRkVJWFkyRXRjSFZpTFRVM01qSTJNVEF6TkRjMU5qVXlOelJJR1ZnQWNBSGFBUk1Jbko2ZnpOQ2JtQU1WT21OMkNCM29ERFJMIiwiMjQ0NDM0MTQ1NDEiXSxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsIjgzMTgxMTg3MTE2OSIsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLDNdXSxbbnVsbCxudWxsLDEsMSwxXSxbbnVsbCxudWxsLCJJVCJdLG51bGwsbnVsbCxbMTIyNzE1ODM3XV1NA-GWvDI6rzWDCFfFGOz2wje9O9eTj8RKDca57E1DMOuFx1a2xsCDMmwtQ7O8P-UL8epMMqmxtUhUN86zVft1jUw0wysFRhC8xGnltz0vXMuJ-3JQMoVPce-1X0xxFwAxfRiIBz4SLZlaDTgCrXbulCyosrTLAYnqkylS9iZJhOCsexRiU7Dxwh1ovKXlzbgpY4ByDCx0Bx6Cuf09omk5blm13dwWFA_T3M29hSFiFJ20YgD4A3bjva85nev1CG0igSYI2Mu0CtdWyHeDZnO36Nyzy4XevyRRsB-oPYnGQGdbaKKNpsxzJYH8YH8sqvv2cQcNvb3z7xJ5yfGUv0LF,Gm8sJPlnjPJZ48giqtP6Vw\x26quot;,\x26quot;https://adssettings.google.com/whythisad?source\x3ddisplay\\u0026reasons\x3dAWJ47B0dEzvFGnBauuSvw6OVtsZyTDfptMOBC34ccNAtSO4g_eZgeuOTKsutAuvsXC2kPVz5Qj8PBUkp_HVaDigi2B0p27eR1iMVLxEOX6QFB9RPpC3IL-xquFv7Hl7L4GmwMxCu4ZFdQa3tUyZiqVX4Sr3pwJEbZyd4X6cWHOVNcrbwf4ce7SsqRibvszMNba4NxJLVV9H0EkfqE8PvikRPdQzKZcqKsWJ9JnGM3KaPWuEwtQvkezmw1ScX1-Vx3p-nAPVcfcO0UStqS8eQkETZW5R_K49pbQB9e5BmRRwtZX2gEtYf2xcV5Xo2a3uEgXbka5FqsGNfhGpgyO3mapFWIT9HZdXzE5RdV7JVtdtYc9_IjB2gve0B7pKJUemoOot_J-Gmy7iVDXd6E6xaVDpVJeoAXJ3tTHLkr6kc-ezETJBjk9mRfL0YHnh9uRS17te6C0Yst--W0s7r82SMmRo-wMztzeYzmROiH20ioUoz9Z2Me_GHijUkOxP6WCPaREoe7if7QCed2ezXKkG7TuQx7-28eS2rakgGG8lfDk7M66ihrsKPuCgo92yloIXd-gnvvQGJ9G9ZK7WLXGxQTFK28RAB8aAZfL0wW7g4HQlOBsu5XKgHb0fSdurnTAuMltGbeZGFuv48UFoBwv56qiPmGyn7gyaia1JEGNXbYH2Jf-vKKiGlQNODFO4H-bMWOIRXShXbzpklXKTCfNeYC__XSIS301Nr6DzCGPOcz8UHWNDLvMgyECYjrasBiqbGJTHdldvY5mG_CiX8H1cfwCq9QqqahAmgUkqOUfXpgWbpeW2K2joiMoAsD7MgAaTBuo-fTt2IRq_ZuDwZAFh_cb4A2Viio3-KuzrDBarCU1ZF34cVV5WzAw-ZcpKZUQ0OQ6YGtc9mJ9osW5duCTqRuEThzfFVpjA91iM-Ih1f2UY6ZiAVblgfArM_fT_QuZRy1fvcSS2cgRKeaEAp8I1VdqE1RzmPDWuDLzqhI0I6in4B7dVR_VcYu0Y7YYDYeGf9JeIeT2XSMV-2uKg3K1KSuSKZY8dzOuU-wUHsZt9PWBCxsZ8pndFi0l9Dmb4IKo3razdGThMsQjGCuDIRPURGtdMzNtundaeS0SQoFIlr18NX08qy8g4f04w8A-HqpucZrztVoQx8ZfNy4LLj-5MZAgBu_o5bPRfJ0YLQ0zYFX2Z_vaRmbiW7fYT2_2TlVr9IaofIA5UXzg-8IMZIDDaaaMJv3XMyIxm_WBUSTHadExjFN_CoZ1zoJB3Jgje8-Jrn7jM1mAZYx9oqS8Ib1cSc61n9okavNVmJQ35MqR6TDFpbPJ5d7dR34vTKQ8VywBLDUv69bY71GgYO897odqSS1VD6cPsu9Dq_-uFauiMFz4L7OLhOcAw6EropPwSVBh8UxflIlByAFDYzpublUdtFppw6vpshjo9Fs3xNTiC94NVEtb28hnKfLLdmVFUUNx9_GtJBHsDo7NcD5k2UqBmYnJzIPH_GW-ZAQ7srevEDao948Sh0Q8ozvPUD-jbw99a_bHZGgGt2JebAv510H16Xf74ijXPSJ6OPqp--8vN2YFwu7H6ZeXKJIX6qn0PSnXAyDD3FtBIlMyHlI32jVSqtwpytHoxeQG53rPHEECXGJwIxzD2Qgb6_PRzpTtDYOPcUIbcnvukzJxBrGzosHgt-5vlc5OV3x-x5iupxeaZgJB_5i7epXtQ8PUWNx5gGe_rOgpkcN2Hyt0ixmIQQC3G_llJNXeR6qZ-88JaQtApFHBUh7nc6sBGYy0uqFSHJTBYz9B_dINOUK9iM5TCFZLlefALiYKDhWiv8Rpmb1aGKWsUj3574ngeaUoBvWrt9lYoJiez_l5LIT08SaTjsmcVI3oTEK6Uq1bGxJl96gi1jx07SSl7cgIDNWXXTC56qt-BseajWD5kTJc-xE78Y8AzX8AZtcXUMe3_6YKF6yfrWZ-aeWAw06l0DrRYoQ3aHynPE-z1nGaozCdhJmOLMkeLjFiKuIF-zre4mo8pcf-TwUY0J-VCug11ZLgT6CSA_meNA6D9A6kFweO8nqWc1t2CfMk8pF4cYo0r8Gj_kUlpScnQyXlZ5-83FFKv_0_vjxCWLfaBl4l8UQJQNM1CoUxNcLkKw2-fpIfJYpcwMtlYDP-iXZRAHGN3_-ixqcaCeg9Va8fcbcfzUJVZCMan4hmwBOnzFQTaMFcMCigX46xNsRTFA7rGykKQmklOHncsL-EUiY7rE3QgxS89dHnjj\\u0026opi\x3d122715837\x26quot;,\x26quot;Why this ad?\x26quot;,1,0],null,null,0,null,0,0,1,0,0,0,1,0,0,0,null,0,1,0,null,[[\x26quot;post_click_menu_height_when_bottom_anchor_on_mobile\x26quot;,\x26quot;150\x26quot;],[\x26quot;show_ad_after_mute\x26quot;,\x26quot;true\x26quot;],[\x26quot;jake_ui_extension\x26quot;,\x26quot;jake_default_ui\x26quot;],[\x26quot;mute_survey_version\x26quot;,\x26quot;mute_panel\x26quot;],[\x26quot;survey_panel_version\x26quot;,\x26quot;survey_panel\x26quot;],[\x26quot;attribution_close_button_size\x26quot;,\x26quot;15\x26quot;],[\x26quot;survey_panel_enable_arrow_padding\x26quot;,\x26quot;false\x26quot;],[\x26quot;attribution_close_button_use_rounded_square\x26quot;,\x26quot;false\x26quot;]],250,300,0,null,null,0,null,null,\x26quot;right\x26quot;,0,null,\x26quot;r20261118/r20110914\x26quot;,null,0,null,0,null,0]\x22\x3e\x3c/script\x3e');
if (!window.mraid) {
    document.write('\x3c/div\x3e');
}(function() {
    var avDiv = document.getElementById("DfaVisibilityIdentifier_223125552");
    var avMarkup = {
        'active_view_class_name': 'GoogleActiveViewElement',
        'data-google-av-cxn': 'https://pagead2.googlesyndication.com/pcs/activeview?xai\x3dAKAOjsuaM7-5WC7Bssufdg1XsuTMIUeTfxOOad33xe6bA_uz9jlRJksGr1cLxbbubZ9gGgGaEhUDG7jqazFoGHU7dFWOdzYN616C-Pqyud2hU1GDqgDELxLNH1QNpZZjFnT-EfJn7tUVhWzkCDgRUjUWSMkOwDP4Rhe2zH4vxdATVkE\x26sig\x3dCg0ArKJSzGGCZhTvStq3EAE',
        'data-google-av-adk': '2314659896',
        'data-google-av-metadata': 'la\x3d0\x26',
        'data-google-av-ufs-integrator-metadata': 'CgIYABKTAgqEAmh0dHBzOi8vcGFnZWFkMi5nb29nbGVzeW5kaWNhdGlvbi5jb20vcGNzL2FjdGl2ZXZpZXc_eGFpPUFLQU9qc3VhTTctNVdDN0Jzc3VmZGcxWHN1VE1JVWVUZnhPT2FkMzN4ZTZiQV91ejlqbFJKa3NHcjFjTHhiYnViWjlnR2dHYUVoVURHN2pxYXpGb0dIVTdkRldPZHpZTjYxNkMtUHF5dWQyaFUxR0RxZ0RFTHhMTkgxUU5wWlpqRm5ULUVmSm43dFVWaFd6a0NEZ1JValVXU01rT3dEUDRSaGUyekg0dnhkQVRWa0Umc2lnPUNnMEFyS0pTekdHQ1poVHZTdHEzRUFFEgAaACABKAAwBDgAGh4KGkNKeWVuOHpRbTVnREZUcGpkZ2dkNkF3MFN3EAU',
        'data-google-av-override': '-1',
        'data-google-av-immediate': 'true',
        'data-google-av-aid': '0',
        'data-google-av-naid': '1',
        'data-google-av-slift': '',
        'data-google-av-cpmav': '',
        'data-google-av-btr': '',
        'data-google-av-itpl': '32',
        'data-google-av-rs': '6',
        'data-google-av-dm': '2',
        'data-google-av-flags': '[\x22x%278440\x279efotm(\x262006706?\x26\x3e`dopb/%\x3c1707200!\x3d8(\x262004521;\x26\x3e`dopb/%\x3c1712702!\x3dnehu`/!364?\x3c206!9abk{a($160?23?\x3d\x26\x3ccbotf+*015\x3d1304%2bejvf/%72\x3c4346:!\x3defdwa*\x2776330:04$?wqrf+*01254132%2bejvf/%72\x3c6\x3c104!\x3defdwa*\x2776307\x3e\x3c6$?ebkpb$\x2603371332*\x3ebgipf+!3\x3d215106%9aihwc)!725201\x3c?\x279efotm(\x2620556611\x26\x3e`dopb/%\x3c1347::6!\x3d|vqc)!7244017?\x2791z\x22]'
    };
    if (avDiv) {
        for (var key in avMarkup) {
            if (avMarkup.hasOwnProperty(key)) {
                avDiv.setAttribute(key, avMarkup[key]);
            }
        }
    }
})();
(function() {
    var glidar = document.createElement('script');
    glidar.type = 'text/javascript';
    glidar.async = true;
    glidar.src = 'https://pagead2.googlesyndication.com/pagead/managed/js/activeview/current/ufs_web_display.js?cache=r20110914';
    document.body.insertBefore(glidar, document.body.firstChild)
})();
(function() {
    (function() {
        var s = document.createElement('script');
        s.setAttribute('data-jc', '86');
        s.src = 'https://pagead2.googlesyndication.com/pagead/js/r20261118/r20110914/elements/html/omrhp.js';
        s.setAttribute('data-jc-version', 'r20261118');
        var ss = document.getElementsByTagName('script')[0];
        if (ss && ss.parentNode) {
            ss.parentNode.insertBefore(s, ss);
        }
    })();
    window.dicnf = {
        eavp: true,
        ebrp: true,
        apfa: true,
        atsb: true,
        bvst: 'r20261118',
        eeid: 'BOcCa5yMDLrG2fMP6JnQ2QQ',
        opxb: true,
        aunb: true,
        adsg: '',
        admetadata: '',
        uffp: true,
        rtit: true,
        arbpp: true,
    };
    (function() {
        var aa = typeof Object.create == "function" ? Object.create : function(a) {
                function b() {}
                b.prototype = a;
                return new b
            },
            ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
                if (a == Array.prototype || a == Object.prototype) return a;
                a[b] = c.value;
                return a
            };

        function ca(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        }
        var m = ca(this);

        function u(a, b) {
            if (b) a: {
                var c = m;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && ba(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        }
        var da;
        if (typeof Object.setPrototypeOf == "function") da = Object.setPrototypeOf;
        else {
            var ea;
            a: {
                var fa = {
                        a: !0
                    },
                    ia = {};
                try {
                    ia.__proto__ = fa;
                    ea = ia.a;
                    break a
                } catch (a) {}
                ea = !1
            }
            da = ea ? function(a, b) {
                a.__proto__ = b;
                if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
                return a
            } : null
        }
        var ja = da;

        function ka(a, b) {
            a.prototype = aa(b.prototype);
            a.prototype.constructor = a;
            if (ja) ja(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.pa = b.prototype
        }

        function la(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        }

        function F(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: la(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        }

        function ma(a) {
            if (!(a instanceof Array)) {
                a = F(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        }

        function K(a, b) {
            var c;
            b && !b.done && (c = a["return"]) && c.call(a)
        }
        var na = typeof Object.assign == "function" ? Object.assign : function(a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e])
            }
            return a
        };

        function oa() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        }
        u("globalThis", function(a) {
            return a || m
        });
        u("Promise", function(a) {
            function b(f) {
                this.i = 0;
                this.j = void 0;
                this.h = [];
                this.u = !1;
                var h = this.l();
                try {
                    f(h.resolve, h.reject)
                } catch (k) {
                    h.reject(k)
                }
            }

            function c() {
                this.h = null
            }

            function d(f) {
                return f instanceof b ? f : new b(function(h) {
                    h(f)
                })
            }
            if (a) return a;
            c.prototype.i = function(f) {
                if (this.h == null) {
                    this.h = [];
                    var h = this;
                    this.j(function() {
                        h.m()
                    })
                }
                this.h.push(f)
            };
            var e = m.setTimeout;
            c.prototype.j = function(f) {
                e(f, 0)
            };
            c.prototype.m = function() {
                for (; this.h && this.h.length;) {
                    var f = this.h;
                    this.h = [];
                    for (var h = 0; h < f.length; ++h) {
                        var k = f[h];
                        f[h] = null;
                        try {
                            k()
                        } catch (l) {
                            this.l(l)
                        }
                    }
                }
                this.h = null
            };
            c.prototype.l = function(f) {
                this.j(function() {
                    throw f;
                })
            };
            b.prototype.l = function() {
                function f(l) {
                    return function(n) {
                        k || (k = !0, l.call(h, n))
                    }
                }
                var h = this,
                    k = !1;
                return {
                    resolve: f(this.J),
                    reject: f(this.m)
                }
            };
            b.prototype.J = function(f) {
                if (f === this) this.m(new TypeError("A Promise cannot resolve to itself"));
                else if (f instanceof b) this.L(f);
                else {
                    a: switch (typeof f) {
                        case "object":
                            var h = f != null;
                            break a;
                        case "function":
                            h = !0;
                            break a;
                        default:
                            h = !1
                    }
                    h ? this.I(f) : this.o(f)
                }
            };
            b.prototype.I = function(f) {
                var h = void 0;
                try {
                    h = f.then
                } catch (k) {
                    this.m(k);
                    return
                }
                typeof h == "function" ? this.M(h, f) : this.o(f)
            };
            b.prototype.m = function(f) {
                this.A(2, f)
            };
            b.prototype.o = function(f) {
                this.A(1, f)
            };
            b.prototype.A = function(f, h) {
                if (this.i != 0) throw Error("Cannot settle(" + f + ", " + h + "): Promise already settled in state" + this.i);
                this.i = f;
                this.j = h;
                this.i === 2 && this.K();
                this.F()
            };
            b.prototype.K = function() {
                var f = this;
                e(function() {
                    if (f.H()) {
                        var h = m.console;
                        typeof h !== "undefined" && h.error(f.j)
                    }
                }, 1)
            };
            b.prototype.H = function() {
                if (this.u) return !1;
                var f = m.CustomEvent,
                    h = m.Event,
                    k = m.dispatchEvent;
                if (typeof k === "undefined") return !0;
                typeof f === "function" ? f = new f("unhandledrejection", {
                    cancelable: !0
                }) : typeof h === "function" ? f = new h("unhandledrejection", {
                    cancelable: !0
                }) : (f = m.document.createEvent("CustomEvent"), f.initCustomEvent("unhandledrejection", !1, !0, f));
                f.promise = this;
                f.reason = this.j;
                return k(f)
            };
            b.prototype.F = function() {
                if (this.h != null) {
                    for (var f = 0; f < this.h.length; ++f) g.i(this.h[f]);
                    this.h = null
                }
            };
            var g = new c;
            b.prototype.L = function(f) {
                var h = this.l();
                f.N(h.resolve, h.reject)
            };
            b.prototype.M = function(f, h) {
                var k = this.l();
                try {
                    f.call(h, k.resolve, k.reject)
                } catch (l) {
                    k.reject(l)
                }
            };
            b.prototype.then = function(f, h) {
                function k(v, A) {
                    return typeof v == "function" ? function(w) {
                        try {
                            l(v(w))
                        } catch (p) {
                            n(p)
                        }
                    } : A
                }
                var l, n, q = new b(function(v, A) {
                    l = v;
                    n = A
                });
                this.N(k(f, l), k(h, n));
                return q
            };
            b.prototype.catch = function(f) {
                return this.then(void 0, f)
            };
            b.prototype.N = function(f, h) {
                function k() {
                    switch (l.i) {
                        case 1:
                            f(l.j);
                            break;
                        case 2:
                            h(l.j);
                            break;
                        default:
                            throw Error("Unexpected state: " + l.i);
                    }
                }
                var l = this;
                this.h == null ? g.i(k) : this.h.push(k);
                this.u = !0
            };
            b.resolve = d;
            b.reject = function(f) {
                return new b(function(h, k) {
                    k(f)
                })
            };
            b.race = function(f) {
                return new b(function(h, k) {
                    for (var l = F(f), n = l.next(); !n.done; n = l.next()) d(n.value).N(h, k)
                })
            };
            b.all = function(f) {
                var h = F(f),
                    k = h.next();
                return k.done ? d([]) : new b(function(l, n) {
                    function q(w) {
                        return function(p) {
                            v[w] = p;
                            A--;
                            A == 0 && l(v)
                        }
                    }
                    var v = [],
                        A = 0;
                    do v.push(void 0), A++, d(k.value).N(q(v.length - 1), n), k = h.next(); while (!k.done)
                })
            };
            return b
        });
        u("Object.is", function(a) {
            return a ? a : function(b, c) {
                return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
            }
        });
        u("Array.prototype.includes", function(a) {
            return a ? a : function(b, c) {
                var d = this;
                d instanceof String && (d = String(d));
                var e = d.length;
                c = c || 0;
                for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                    var g = d[c];
                    if (g === b || Object.is(g, b)) return !0
                }
                return !1
            }
        });
        u("String.prototype.includes", function(a) {
            return a ? a : function(b, c) {
                if (this == null) throw new TypeError("The 'this' value for String.prototype.includes must not be null or undefined");
                if (b instanceof RegExp) throw new TypeError("First argument to String.prototype.includes must not be a regular expression");
                return this.indexOf(b, c || 0) !== -1
            }
        });
        u("Array.from", function(a) {
            return a ? a : function(b, c, d) {
                c = c != null ? c : function(h) {
                    return h
                };
                var e = [],
                    g = typeof Symbol != "undefined" && Symbol.iterator && b[Symbol.iterator];
                if (typeof g == "function") {
                    b = g.call(b);
                    for (var f = 0; !(g = b.next()).done;) e.push(c.call(d, g.value, f++))
                } else
                    for (g = b.length, f = 0; f < g; f++) e.push(c.call(d, b[f], f));
                return e
            }
        });
        u("Number.isFinite", function(a) {
            return a ? a : function(b) {
                return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
            }
        });
        u("Number.MAX_SAFE_INTEGER", function() {
            return 9007199254740991
        });
        u("Number.MIN_SAFE_INTEGER", function() {
            return -9007199254740991
        });
        u("Number.isNaN", function(a) {
            return a ? a : function(b) {
                return typeof b === "number" && isNaN(b)
            }
        }); /*  Copyright The Closure Library Authors. SPDX-License-Identifier: Apache-2.0 */
        var L = this || self;

        function pa(a, b) {
            a: {
                var c = ["CLOSURE_FLAGS"];
                for (var d = L, e = 0; e < c.length; e++)
                    if (d = d[c[e]], d == null) {
                        c = null;
                        break a
                    }
                c = d
            }
            a = c && c[a];
            return a != null ? a : b
        };

        function qa(a) {
            L.setTimeout(function() {
                throw a;
            }, 0)
        };
        var ra = pa(899588437, !1),
            sa = pa(748402147, !0);
        var ta = Array.prototype.indexOf ? function(a, b) {
                return Array.prototype.indexOf.call(a, b, void 0)
            } : function(a, b) {
                if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
                for (var c = 0; c < a.length; c++)
                    if (c in a && a[c] === b) return c;
                return -1
            },
            ua = Array.prototype.forEach ? function(a, b) {
                Array.prototype.forEach.call(a, b, void 0)
            } : function(a, b) {
                for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
            };

        function va(a) {
            va[" "](a);
            return a
        }
        va[" "] = function() {};
        var wa = {},
            xa = null;
        var za = void 0;
        var Aa = typeof Symbol === "function" && typeof Symbol() === "symbol";

        function Ba(a, b, c) {
            return typeof Symbol === "function" && typeof Symbol() === "symbol" ? (c === void 0 ? 0 : c) && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol() : b
        }
        var Ca = Ba("jas", void 0, !0),
            Da = Ba(void 0, "0actk"),
            Ea = Ba("m_m", "oa", !0);
        var Fa = {
                la: {
                    value: 0,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            },
            Ga = Object.defineProperties,
            M = Aa ? Ca : "la",
            Ha, Ia = [];
        N(Ia, 7);
        Ha = Object.freeze(Ia);

        function Ja(a, b) {
            Aa || M in a || Ga(a, Fa);
            a[M] |= b
        }

        function N(a, b) {
            Aa || M in a || Ga(a, Fa);
            a[M] = b
        };
        var Ka = {};

        function La(a, b) {
            return b === void 0 ? a.h !== Ma && !!(2 & (a.v[M] | 0)) : !!(2 & b) && a.h !== Ma
        }
        var Ma = {};

        function Na(a) {
            a.na = !0;
            return a
        };
        var Oa = Na(function(a) {
                return typeof a === "number"
            }),
            Pa = Na(function(a) {
                return typeof a === "string"
            }),
            Qa = Na(function(a) {
                return typeof a === "function"
            });
        var Ra = typeof L.BigInt === "function" && typeof L.BigInt(0) === "bigint";
        var Xa = Na(function(a) {
                return Ra ? a >= Sa && a <= Ta : a[0] === "-" ? Ua(a, Va) : Ua(a, Wa)
            }),
            Va = Number.MIN_SAFE_INTEGER.toString(),
            Sa = Ra ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
            Wa = Number.MAX_SAFE_INTEGER.toString(),
            Ta = Ra ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;

        function Ua(a, b) {
            if (a.length > b.length) return !1;
            if (a.length < b.length || a === b) return !0;
            for (var c = 0; c < a.length; c++) {
                var d = a[c],
                    e = b[c];
                if (d > e) return !1;
                if (d < e) return !0
            }
        };

        function Ya(a) {
            if (typeof a !== "boolean") {
                var b = typeof a;
                throw Error("Expected boolean but got " + (b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null") + ": " + a);
            }
            return a
        };

        function Za(a) {
            return a
        };

        function $a(a, b, c, d) {
            var e = d !== void 0;
            d = !!d;
            var g = [],
                f = a.length,
                h = 4294967295,
                k = !1,
                l = !!(b & 64),
                n = l ? b & 128 ? 0 : -1 : void 0;
            if (!(b & 1)) {
                var q = f && a[f - 1];
                q != null && typeof q === "object" && q.constructor === Object ? (f--, h = f) : q = void 0;
                if (l && !(b & 128) && !e) {
                    k = !0;
                    var v;
                    h = ((v = ab) != null ? v : Za)(h - n, n, a, q, void 0) + n
                }
            }
            b = void 0;
            for (e = 0; e < f; e++)
                if (v = a[e], v != null && (v = c(v, d)) != null)
                    if (l && e >= h) {
                        var A = e - n,
                            w = void 0;
                        ((w = b) != null ? w : b = {})[A] = v
                    } else g[e] = v;
            if (q)
                for (var p in q) a = q[p], a != null && (a = c(a, d)) != null && (f = +p, e = void 0, l && !Number.isNaN(f) && (e = f + n) < h ? g[e] = a : (f = void 0, ((f = b) != null ? f : b = {})[p] = a));
            b && (k ? g.push(b) : g[h] = b);
            return g
        }

        function bb(a) {
            switch (typeof a) {
                case "number":
                    return Number.isFinite(a) ? a : "" + a;
                case "bigint":
                    return Xa(a) ? Number(a) : "" + a;
                case "boolean":
                    return a ? 1 : 0;
                case "object":
                    if (Array.isArray(a)) {
                        var b = a[M] | 0;
                        return a.length === 0 && b & 1 ? void 0 : $a(a, b, bb)
                    }
                    if (a != null && a[Ea] === Ka) return cb(a);
                    return
            }
            return a
        }
        var ab;

        function cb(a) {
            a = a.v;
            return $a(a, a[M] | 0, bb)
        };

        function db(a, b, c, d) {
            d = d === void 0 ? 0 : d;
            if (a == null) {
                var e = 32;
                c ? (a = [c], e |= 128) : a = [];
                b && (e = e & -16760833 | (b & 1023) << 14)
            } else {
                if (!Array.isArray(a)) throw Error("narr");
                e = a[M] | 0;
                if (sa && 1 & e) throw Error("rfarr");
                2048 & e && !(2 & e) && eb();
                if (e & 256) throw Error("farr");
                if (e & 64) return (e | d) !== e && N(a, e | d), a;
                if (c && (e |= 128, c !== a[0])) throw Error("mid");
                a: {
                    c = a;e |= 64;
                    var g = c.length;
                    if (g) {
                        var f = g - 1,
                            h = c[f];
                        if (h != null && typeof h === "object" && h.constructor === Object) {
                            b = e & 128 ? 0 : -1;
                            f -= b;
                            if (f >= 1024) throw Error("pvtlmt");
                            for (var k in h) g = +k, g < f && (c[g + b] = h[k], delete h[k]);
                            e = e & -16760833 | (f & 1023) << 14;
                            break a
                        }
                    }
                    if (b) {
                        k = Math.max(b, g - (e & 128 ? 0 : -1));
                        if (k > 1024) throw Error("spvt");
                        e = e & -16760833 | (k & 1023) << 14
                    }
                }
            }
            N(a, e | 64 | d);
            return a
        }

        function eb() {
            if (sa) throw Error("carr");
            if (Da != null) {
                var a;
                var b = (a = za) != null ? a : za = {};
                a = b[Da] || 0;
                a >= 5 || (b[Da] = a + 1, b = Error(), b.__closure__error__context__984382 || (b.__closure__error__context__984382 = {}), b.__closure__error__context__984382.severity = "incident", qa(b))
            }
        };

        function gb(a, b) {
            if (typeof a !== "object") return a;
            if (Array.isArray(a)) {
                var c = a[M] | 0;
                a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = hb(a, c, !1, b && !(c & 16)) : (Ja(a, 34), c & 4 && Object.freeze(a)));
                return a
            }
            if (a != null && a[Ea] === Ka) {
                b = a.v;
                c = b[M] | 0;
                if (!La(a, c)) {
                    if (c & 2) var d = !0;
                    else !(c & 32) || c & 4096 ? d = !1 : (N(b, c | 2), a.h = Ma, d = !0);
                    d ? (a = new a.constructor(b), a.i = Ma) : a = hb(b, c)
                }
                return a
            }
        }

        function hb(a, b, c, d) {
            d != null || (d = !!(34 & b));
            a = $a(a, b, gb, d);
            d = 32;
            c && (d |= 2);
            b = b & 16769217 | d;
            N(a, b);
            return a
        }

        function ib(a) {
            if (a.h === Ma) {
                var b = a.v;
                b = hb(b, b[M] | 0);
                Ja(b, 2048);
                a.v = b;
                a.h = void 0;
                a.i = void 0;
                b = !0
            } else b = !1;
            if (!b && La(a, a.v[M] | 0)) throw Error();
        };

        function jb(a, b, c) {
            ib(a);
            var d = a.v;
            kb(d, d[M] | 0, b, c);
            return a
        }

        function kb(a, b, c, d) {
            var e = c + -1,
                g = a.length - 1;
            if (g >= 0 && e >= g) {
                var f = a[g];
                if (f != null && typeof f === "object" && f.constructor === Object) return f[c] = d, b
            }
            if (e <= g) return a[e] = d, b;
            if (d !== void 0) {
                var h;
                g = ((h = b) != null ? h : b = a[M] | 0) >> 14 & 1023 || 536870912;
                c >= g ? d != null && (e = {}, a[g + -1] = (e[c] = d, e)) : a[e] = d
            }
            return b
        }

        function O(a, b, c) {
            if (c != null && typeof c !== "string") throw Error();
            return jb(a, b, c)
        };

        function lb(a, b, c) {
            this.v = db(a, b, c, 2048)
        }
        lb.prototype.toJSON = function() {
            return cb(this)
        };
        lb.prototype[Ea] = Ka;
        lb.prototype.toString = function() {
            return this.v.toString()
        };

        function mb(a, b) {
            b = b === void 0 ? !1 : b;
            this.key = a;
            this.defaultValue = b;
            this.valueType = "boolean"
        };
        var nb = new mb("45357156", !0),
            ob = new mb("45414892"),
            pb = new mb("45835923"),
            qb = new mb("45716539", !0),
            rb = new mb("45710312", !0);
        var sb = RegExp("ad\\.doubleclick\\.net/(ddm/trackimp|pcs/view)"),
            tb = ["A7CQXglZzTrThjGTBEn1rWTxHOEtkWivwzgea+NjyardrwlieSjVuyG44PkYgIPGs8Q9svD8sF3Yedn0BBBjXAkAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=="];

        function ub(a, b) {
            return a.substring(a.length - 7) == "&adurl=" ? a.substring(0, a.length - 7) + b + "&adurl=" : a + b
        };

        function P(a) {
            return a = a === void 0 ? window : a
        };
        var S = L.dicnf || {};

        function vb() {
            return S.imprtype == "1" ? 1 : S.imprtype == "2" ? 2 : S.imprtype == "3" ? 3 : 0
        };

        function wb(a, b) {
            if (a)
                for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
        };

        function xb(a) {
            try {
                var b;
                if (b = !!a && a.location.href != null) a: {
                    try {
                        va(a.foo);
                        b = !0;
                        break a
                    } catch (c) {}
                    b = !1
                }
                return b
            } catch (c) {
                return !1
            }
        }

        function yb(a, b) {
            b = b === void 0 ? !1 : b;
            var c = c === void 0 ? L : c;
            for (var d = 0; c && d++ < 40 && (!b && !xb(c) || !a(c));) a: {
                try {
                    var e = c.parent;
                    if (e && e !== c) {
                        c = e;
                        break a
                    }
                } catch (g) {}
                c = null
            }
        };

        function zb(a) {
            var b = !1,
                c;
            return function() {
                b || (c = a(), b = !0);
                return c
            }
        };

        function Ab() {
            if (!globalThis.crypto) return Math.random();
            try {
                var a = new Uint32Array(1);
                globalThis.crypto.getRandomValues(a);
                return a[0] / 65536 / 65536
            } catch (b) {
                return Math.random()
            }
        };

        function Bb(a, b) {
            b = b === void 0 ? document : b;
            return b.createElement(String(a).toLowerCase())
        };
        var Cb = [];

        function Db() {
            var a = Cb;
            Cb = [];
            a = F(a);
            var b = a.next();
            try {
                for (; !b.done; b = a.next()) {
                    var c = b.value;
                    try {
                        c()
                    } catch (d) {}
                }
            } finally {
                K(a, b)
            }
        };

        function Eb(a, b, c) {
            typeof a.addEventListener === "function" && a.addEventListener(b, c, !1)
        }

        function Fb(a, b, c) {
            typeof a.removeEventListener === "function" && a.removeEventListener(b, c, !1)
        }

        function Gb(a, b) {
            a.readyState === "complete" || a.readyState === "interactive" ? (Cb.push(b), Cb.length === 1 && (window.Promise ? Promise.resolve().then(Db) : (a = window.setImmediate, Qa(a) ? a(Db) : setTimeout(Db, 0)))) : a.addEventListener("DOMContentLoaded", b)
        };

        function T(a, b, c, d, e) {
            return Hb(a, b, c === void 0 ? null : c, !1, d === void 0 ? !1 : d, e === void 0 ? !1 : e)
        }

        function Hb(a, b, c, d, e, g) {
            g = g === void 0 ? !1 : g;
            a.google_image_requests || (a.google_image_requests = []);
            var f = Bb("IMG", a.document);
            if (c || e) {
                var h = function(k) {
                    c && c(k);
                    if (e) {
                        k = a.google_image_requests;
                        var l = ta(k, f);
                        l >= 0 && Array.prototype.splice.call(k, l, 1)
                    }
                    Fb(f, "load", h);
                    Fb(f, "error", h)
                };
                Eb(f, "load", h);
                Eb(f, "error", h)
            }
            d && (f.referrerPolicy = "no-referrer");
            g && (f.attributionSrc = "");
            f.src = b;
            a.google_image_requests.push(f);
            return f
        }

        function Ib(a) {
            var b = b === void 0 ? !1 : b;
            var c;
            if (c = L.navigator) c = L.navigator.userAgent, c = !(!/Chrome/.test(c) || /Edge/.test(c));
            c && typeof L.navigator.sendBeacon === "function" ? L.navigator.sendBeacon(a) : T(L, a, void 0, b)
        }

        function Jb(a, b) {
            var c = c === void 0 ? !1 : c;
            var d = d === void 0 ? !1 : d;
            return a.fetch ? (c = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }, d && (c.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? c.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false"
            } : c.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            }), a.fetch(b, c)) : T(a, b, void 0, c, d)
        }
        var Kb = zb(function() {
            return "referrerPolicy" in Bb("IMG")
        });

        function Lb() {
            this.h = {}
        }

        function U(a) {
            Mb || (Mb = new Nb);
            var b = Mb.h[a.key];
            if (a.valueType === "proto") {
                try {
                    var c = JSON.parse(b);
                    if (Array.isArray(c)) return c
                } catch (d) {}
                return a.defaultValue
            }
            return typeof b === typeof a.defaultValue ? b : a.defaultValue
        };

        function Nb() {
            this.h = {};
            var a = document.currentScript;
            a = (a = (a = a === void 0 ? null : a) && a.getAttribute("data-jc") === "0" ? a : document.querySelector('[data-jc="0"]')) && a.getAttribute("data-jc-flags") || "";
            try {
                var b = JSON.parse(a)[0];
                a = "";
                for (var c = 0; c < b.length; c++) a += String.fromCharCode(b.charCodeAt(c) ^ "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(c % 10));
                this.h = JSON.parse(a)
            } catch (d) {}
        }
        var Mb;
        ka(Nb, Lb);

        function Ob(a, b) {
            var c = c === void 0 ? {} : c;
            this.error = a;
            this.meta = c;
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror"
        };

        function Pb(a) {
            var b = a.toString();
            a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
            a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
            if (a.stack) a: {
                a = a.stack;
                var c = b;
                try {
                    a.indexOf(c) == -1 && (a = c + "\n" + a);
                    for (var d; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                    b = a.replace(RegExp("\n *", "g"), "\n");
                    break a
                } catch (e) {
                    b = c;
                    break a
                }
                b = void 0
            }
            return b
        };
        var Qb = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");

        function Rb(a, b) {
            this.h = a;
            this.i = b
        }

        function Sb(a, b) {
            this.url = a;
            this.h = !!b;
            this.depth = null
        };
        var Tb = null;

        function Ub() {
            var a = a === void 0 ? L : a;
            return (a = a.performance) && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
        }

        function Vb() {
            var a = a === void 0 ? L : a;
            return (a = a.performance) && a.now ? a.now() : null
        };

        function Wb(a, b) {
            var c = Vb() || Ub();
            var d = d === void 0 ? 0 : d;
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = d;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        };
        var V = L.performance,
            Xb = !!(V && V.mark && V.measure && V.clearMarks),
            Yb = zb(function() {
                var a;
                if (a = Xb) {
                    var b = b === void 0 ? window : b;
                    if (Tb === null) {
                        Tb = "";
                        try {
                            a = "";
                            try {
                                a = b.top.location.hash
                            } catch (d) {
                                a = b.location.hash
                            }
                            if (a) {
                                var c = a.match(/\bdeid=([\d,]+)/);
                                Tb = c ? c[1] : ""
                            }
                        } catch (d) {}
                    }
                    b = Tb;
                    a = !!b.indexOf && b.indexOf("1337") >= 0
                }
                return a
            });

        function Zb() {
            var a = window;
            this.i = [];
            this.j = a || L;
            var b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.i = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.h = Yb() || (b != null ? b : Math.random() < 1)
        }

        function $b(a) {
            a && V && Yb() && (V.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"), V.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"))
        }
        Zb.prototype.start = function(a, b) {
            if (!this.h) return null;
            a = new Wb(a, b);
            b = "goog_" + a.label + "_" + a.uniqueId + "_start";
            V && Yb() && V.mark(b);
            return a
        };
        Zb.prototype.end = function(a) {
            if (this.h && Oa(a.value)) {
                a.duration = (Vb() || Ub()) - a.value;
                var b = "goog_" + a.label + "_" + a.uniqueId + "_end";
                V && Yb() && V.mark(b);
                !this.h || this.i.length > 2048 || this.i.push(a)
            }
        };

        function ac() {
            this.j = "&";
            this.i = {};
            this.l = 0;
            this.h = []
        }

        function fc(a, b) {
            var c = {};
            c[a] = b;
            return [c]
        }

        function hc(a, b, c, d, e) {
            var g = [];
            wb(a, function(f, h) {
                (f = ic(f, b, c, d, e)) && g.push(encodeURIComponent(h) + "=" + f)
            });
            return g.join(b)
        }

        function ic(a, b, c, d, e) {
            if (a == null) return "";
            b = b || "&";
            c = c || ",$";
            Pa(c) && (c = c.split(""));
            if (a instanceof Array) {
                if (d || (d = 0), d < c.length) {
                    for (var g = [], f = 0; f < a.length; f++) g.push(ic(a[f], b, c, d + 1, e));
                    return g.join(c[d])
                }
            } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(hc(a, b, c, d, e + 1)) : "...";
            return encodeURIComponent(String(a))
        }

        function jc(a, b, c, d) {
            return kc(a) - d.length < 0 ? "" : b + "//" + c + d + lc(a, d)
        }

        function lc(a, b) {
            var c = kc(a) - b.length;
            if (c < 0) return "";
            b = "";
            a.h.sort(function(n, q) {
                return n - q
            });
            for (var d = null, e = "", g = 0; g < a.h.length; g++)
                for (var f = a.h[g], h = a.i[f], k = 0; k < h.length; k++) {
                    if (!c) {
                        d = d == null ? f : d;
                        break
                    }
                    var l = hc(h[k], a.j, ",$");
                    if (l) {
                        l = e + l;
                        if (c >= l.length) {
                            c -= l.length;
                            b += l;
                            e = a.j;
                            break
                        }
                        d = d == null ? f : d
                    }
                }
            a = "";
            d != null && (a = e + "trn=" + d);
            return b + a
        }

        function kc(a) {
            var b = 1,
                c;
            for (c in a.i) c.length > b && (b = c.length);
            return 3997 - b - a.j.length - 1
        };
        var mc = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

        function nc(a, b, c) {
            c = c === void 0 ? null : c;
            this.m = a;
            this.o = b;
            this.h = c;
            this.i = null;
            this.j = !1;
            this.u = this.l
        }

        function oc(a, b, c, d) {
            try {
                if (a.h && a.h.h) {
                    var e = a.h.start(b.toString(), 3);
                    var g = c();
                    a.h.end(e)
                } else g = c()
            } catch (k) {
                c = a.o;
                try {
                    $b(e), c = a.u(b, new Ob(k, {
                        message: Pb(k)
                    }), void 0, d)
                } catch (l) {
                    a.l(217, l)
                }
                if (c) {
                    var f, h;
                    (f = window.console) == null || (h = f.error) == null || h.call(f, k)
                } else throw k;
            }
            return g
        }

        function pc(a, b, c, d, e) {
            return function() {
                var g = oa.apply(0, arguments);
                return oc(a, b, function() {
                    return c.apply(d, g)
                }, e)
            }
        }
        nc.prototype.l = function(a, b, c, d, e) {
            e = e || "jserror";
            var g = void 0;
            try {
                var f = new ac;
                f.h.push(1);
                f.i[1] = fc("context", a);
                b.error && b.meta && b.id || (b = new Ob(b, {
                    message: Pb(b)
                }));
                if (b.msg) {
                    var h = b.msg.substring(0, 512);
                    f.h.push(2);
                    f.i[2] = fc("msg", h)
                }
                var k = b.meta || {};
                if (this.i) try {
                    this.i(k)
                } catch (J) {}
                if (d) try {
                    d(k)
                } catch (J) {}
                d = [k];
                f.h.push(3);
                f.i[3] = d;
                var l;
                if (!(l = w)) {
                    h = L;
                    d = [];
                    k = null;
                    do {
                        var n = h;
                        if (xb(n)) {
                            var q = n.location.href;
                            k = n.document && n.document.referrer || null
                        } else q = k, k = null;
                        d.push(new Sb(q || ""));
                        try {
                            h = n.parent
                        } catch (J) {
                            h = null
                        }
                    } while (h && n !== h);
                    q = 0;
                    for (var v = d.length - 1; q <= v; ++q) d[q].depth = v - q;
                    n = L;
                    if (n.location && n.location.ancestorOrigins && n.location.ancestorOrigins.length === d.length - 1)
                        for (v = 1; v < d.length; ++v) {
                            var A = d[v];
                            A.url || (A.url = n.location.ancestorOrigins[v - 1] || "", A.h = !0)
                        }
                    l = d
                }
                var w = l;
                var p = new Sb(L.location.href, !1);
                l = null;
                var y = w.length - 1;
                for (n = y; n >= 0; --n) {
                    var z = w[n];
                    !l && Qb.test(z.url) && (l = z);
                    if (z.url && !z.h) {
                        p = z;
                        break
                    }
                }
                z = null;
                var G = w.length && w[y].url;
                p.depth !== 0 && G && (z = w[y]);
                g = new Rb(p, z);
                if (g.i) {
                    var D = g.i.url || "";
                    f.h.push(4);
                    f.i[4] = fc("top", D)
                }
                var B = {
                    url: g.h.url || ""
                };
                if (g.h.url) {
                    var C = g.h.url.match(mc),
                        r = C[1],
                        x = C[3],
                        t = C[4];
                    w = "";
                    r && (w += r + ":");
                    x && (w += "//", w += x, t && (w += ":" + t));
                    var H = w
                } else H = "";
                B = [B, {
                    url: H
                }];
                f.h.push(5);
                f.i[5] = B;
                qc(this.m, e, f, this.j, c)
            } catch (J) {
                try {
                    var E, I;
                    qc(this.m, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Pb(J),
                        url: (I = (E = g) == null ? void 0 : E.h.url) != null ? I : ""
                    }, this.j, c)
                } catch (Q) {}
            }
            return this.o
        };

        function rc(a) {
            var b = "T";
            if (a.T && a.hasOwnProperty(b)) return a.T;
            b = new a;
            return a.T = b
        };

        function sc() {};

        function tc(a, b, c, d) {
            d = d === void 0 ? !1 : d;
            this.domain = a;
            this.path = b;
            this.l = c;
            this.j = d;
            this.protocol = "https:";
            this.i = Math.random()
        }

        function uc() {
            var a = vc,
                b = window.google_srt;
            b >= 0 && b <= 1 && (a.i = b)
        }

        function qc(a, b, c, d, e) {
            if (((d === void 0 ? 0 : d) ? a.i : Math.random()) < (e || a.l)) try {
                if (c instanceof ac) var g = c;
                else g = new ac, wb(c, function(h, k) {
                    var l = g,
                        n = l.l++;
                    h = fc(k, h);
                    l.h.push(n);
                    l.i[n] = h
                });
                var f = jc(g, a.protocol, a.h(), a.path + b + "&");
                f && (a.j ? Ib(f) : T(L, f))
            } catch (h) {}
        }
        tc.prototype.h = function() {
            return this.domain
        };
        var vc, wc, xc = !1;

        function yc() {
            tc.apply(this, arguments)
        }
        ka(yc, tc);
        yc.prototype.h = function() {
            if (xc) {
                var a = {
                    ma: !0
                };
                a = (a === void 0 ? {} : a).ma;
                a = (a === void 0 ? 0 : a) ? "connect.pagead2.googlesyndication.com" : "pagead2.googlesyndication.com"
            } else a = tc.prototype.h.call(this);
            return a
        };
        var W = new Zb;

        function zc() {
            window.google_measure_js_timing || (W.h = !1, W.i !== W.j.google_js_reporting_queue && (Yb() && ua(W.i, $b), W.i.length = 0))
        }(function(a) {
            xc = !1;
            vc = a != null ? a : new yc("pagead2.googlesyndication.com", "/pagead/gen_204?id=", .01);
            typeof window.google_srt !== "number" && (window.google_srt = Math.random());
            uc();
            wc = new nc(vc, !0, W);
            wc.i = function() {};
            wc.j = !0;
            window.document.readyState === "complete" ? zc() : W.h && Eb(window, "load", function() {
                zc()
            })
        })();

        function Ac(a, b) {
            return pc(wc, a, b)
        };
        var Bc = ["FRAME", "IMG", "IFRAME"],
            Cc = /^[01](px)?$/;

        function Dc() {
            this.u = this.i = this.l = this.m = this.A = this.h = this.o = this.j = !1
        }

        function Ec(a) {
            var b = new Dc;
            b.j = a;
            return b
        }

        function Fc(a, b) {
            a.o = b;
            return a
        }

        function Gc(a, b) {
            a.h = b;
            return a
        }

        function Hc(a, b) {
            a.A = b;
            return a
        }

        function Ic(a, b) {
            a.m = b;
            return a
        }

        function Jc(a, b) {
            a.l = b;
            return a
        }

        function Kc(a, b) {
            a.i = b;
            return a
        }

        function Lc(a, b) {
            a.u = b;
            return a
        }

        function Mc(a) {
            return Pa(a) ? document.getElementById(a) : a
        }

        function Nc(a, b) {
            b = b === void 0 ? !1 : b;
            if (a.tagName === "IMG") {
                if (a.complete && (!a.naturalWidth || !a.naturalHeight)) return !0;
                var c;
                if (b && ((c = a.style) == null ? void 0 : c.display) === "none") return !0
            }
            var d, e;
            return Cc.test((d = a.getAttribute("width")) != null ? d : "") && Cc.test((e = a.getAttribute("height")) != null ? e : "")
        }

        function Oc(a, b) {
            if (a.tagName === "IMG") return !(!a.naturalWidth || !a.naturalHeight);
            try {
                if (a.readyState) var c = a.readyState;
                else {
                    var d, e;
                    c = (d = a.contentWindow) == null ? void 0 : (e = d.document) == null ? void 0 : e.readyState
                }
                return c === "complete"
            } catch (g) {
                return b === void 0 ? !1 : b
            }
        }

        function Pc(a) {
            a || (a = function(b, c, d) {
                b.addEventListener(c, d)
            });
            return a
        }

        function Qc(a) {
            if (L.document.readyState === "complete") a(5);
            else {
                var b = Pc(b);
                b(L, "load", function() {
                    a(4)
                })
            }
        }

        function Rc(a, b, c, d) {
            function e(y) {
                g || (g = !0, b(y))
            }
            c = c === void 0 ? new Dc : c;
            a = Mc(a);
            if (!a) return !1;
            d = Pc(d);
            for (var g = !1, f, h = 2, k = 0; k < Bc.length; ++k)
                if (Bc[k] === a.tagName) {
                    h = 3;
                    f = [a];
                    break
                }
            f || (f = a.querySelectorAll(Bc.join(",")));
            var l = 0,
                n = 0,
                q = !c.h,
                v = a = !1;
            k = {};
            for (var A = 0; A < f.length; k = {
                    P: void 0
                }, A++) {
                var w = f[A];
                if (!Nc(w, c.h))
                    if (k.P = w.tagName === "IMG", Oc(w, c.j)) a = !0, k.P && (q = !0);
                    else {
                        l++;
                        var p = function(y) {
                            return function(z) {
                                l--;
                                !l && q && e(h);
                                y.P && (z = z && z.type === "error", n--, z || (q = !0), !n && v && q && e(h))
                            }
                        }(k);
                        d(w, "load", p);
                        k.P && (n++, d(w, "error", p))
                    }
            }
            n === 0 && (q = !0);
            f = null;
            f = L.document.readyState === "complete";
            if (c.A && f) {
                if (n > 0) return v = !0, !1;
                h = 5
            } else if (l === 0 && !a && f) h = 5;
            else if (l || !a) return d(L, "load", function() {
                !c.o || !n && q ? e(4) : v = !0
            }), !1;
            e(h);
            return !0
        }

        function Sc(a, b, c, d) {
            function e() {
                B = !0;
                C = 4;
                n();
                L.removeEventListener("load", e)
            }

            function g(r) {
                if (!y) {
                    y = !0;
                    w && w.disconnect();
                    var x = F(p),
                        t = x.next();
                    try {
                        for (; !t.done; t = x.next()) l(t.value)
                    } finally {
                        K(x, t)
                    }
                    p = [];
                    c.m && L.document.removeEventListener && L.document.removeEventListener("readystatechange", k);
                    c.i && (L.removeEventListener && L.removeEventListener("pagehide", f), G && (D == null || D.removeEventListener("pagehide", h)));
                    b(r)
                }
            }

            function f() {
                if (!y) {
                    var r = G && z;
                    p.length !== 0 || r || g(5)
                }
            }

            function h() {
                z = !0
            }

            function k() {
                n()
            }

            function l(r) {
                var x = F(r.O),
                    t = x.next();
                try {
                    for (; !t.done; t = x.next()) {
                        var H = t.value;
                        r.element.removeEventListener(H.type, H.handler)
                    }
                } finally {
                    K(x, t)
                }
                r.O = []
            }

            function n() {
                var r = L.document.readyState === "complete",
                    x = !c.h,
                    t = !1,
                    H = !1,
                    E = !1,
                    I = !0,
                    J = F(p),
                    Q = J.next();
                try {
                    for (; !Q.done; Q = J.next()) {
                        var R = Q.value;
                        R.completed ? (t = !0, R.da && (H = !0, R.ca || (x = !0))) : (I = !1, R.da && (E = !0))
                    }
                } finally {
                    K(J, Q)
                }
                x = !H || x;
                if (I && t && x) return g(C), !0;
                r && (B = !0, C = 5);
                r = !c.o || !E && x;
                return B && r ? (g(C), !0) : !1
            }

            function q(r) {
                r = F(r);
                var x = r.next();
                try {
                    for (var t = {}; !x.done; t = {
                            B: void 0,
                            D: void 0,
                            R: void 0
                        }, x = r.next())
                        if (t.B = x.value, !p.some(function(E) {
                                return function(I) {
                                    return I.element === E.B
                                }
                            }(t)) && !Nc(t.B, c.h)) {
                            t.R = t.B.tagName === "IMG";
                            t.D = {
                                element: t.B,
                                da: t.R,
                                ca: !1,
                                O: [],
                                completed: !1
                            };
                            if (Oc(t.B, c.j)) t.D.completed = !0;
                            else {
                                var H = function(E) {
                                    return function(I) {
                                        E.D.completed = !0;
                                        E.R && I && I.type === "error" && (E.D.ca = !0);
                                        l(E.D);
                                        n()
                                    }
                                }(t);
                                d(t.B, "load", H);
                                t.D.O.push({
                                    type: "load",
                                    handler: H
                                });
                                t.R && (d(t.B, "error", H), t.D.O.push({
                                    type: "error",
                                    handler: H
                                }))
                            }
                            p.push(t.D)
                        }
                } finally {
                    K(r, x)
                }
            }

            function v(r) {
                return Bc.some(function(x) {
                    return String(x) === r.tagName
                }) ? (C = 3, [r]) : Array.from(r.querySelectorAll(Bc.join(",")))
            }

            function A(r) {
                w = new L.MutationObserver(function(E) {
                    p = p.filter(function(fb) {
                        if (c.l) {
                            var ya = fb.element;
                            if (typeof ya.isConnected === "boolean") var ha = ya.isConnected;
                            else {
                                var bc, cc, dc;
                                ha = (dc = (bc = ya.ownerDocument) == null ? void 0 : (cc = bc.documentElement) == null ? void 0 : cc.contains(ya)) != null ? dc : !1
                            }
                            ha = !ha
                        } else ha = !fb.element.isConnected;
                        return ha ? (l(fb), !1) : !0
                    });
                    var I = [];
                    E = F(E);
                    var J = E.next();
                    try {
                        for (; !J.done; J = E.next())
                            for (var Q = J.value, R = 0; R < Q.addedNodes.length; R++) {
                                var ec = Q.addedNodes[R];
                                ec.nodeType === 1 && I.push.apply(I, ma(v(ec)))
                            }
                    } finally {
                        K(E, J)
                    }
                    q(I);
                    n()
                });
                var x;
                if (x = r.tagName === "BODY" && r.ownerDocument) {
                    try {
                        var t = L.top === L
                    } catch (E) {
                        t = !1
                    }
                    x = !t
                }
                r = x ? r.ownerDocument : r;
                var H;
                (H = w) == null || H.observe(r, {
                    childList: !0,
                    subtree: !0
                })
            }
            c = c === void 0 ? new Dc : c;
            a = Mc(a);
            if (!a) return !1;
            d = Pc(d);
            var w = null,
                p = [],
                y = !1,
                z = !1,
                G = c.i && c.u,
                D = G ? xb(L.top) ? L.top : null : null;
            G && (D ? D.addEventListener("pagehide", h) : z = !0);
            var B = !1,
                C = 2;
            q(v(a));
            c.l ? typeof L.MutationObserver === "function" && A(a) : A(a);
            if (n()) return !0;
            d(L, "load", e);
            c.m && d(L.document, "readystatechange", k);
            c.i && d(L, "pagehide", f);
            return !1
        };

        function Tc(a, b, c) {
            if (a)
                for (var d = 0; a != null && d < 500 && !c(a); ++d) a = b(a)
        }

        function Uc(a, b) {
            Tc(a, function(c) {
                try {
                    return c === c.parent ? null : c.parent
                } catch (d) {}
                return null
            }, b)
        }

        function Vc(a, b) {
            if (a.tagName == "IFRAME") b(a);
            else {
                a = a.querySelectorAll("IFRAME");
                for (var c = 0; c < a.length && !b(a[c]); ++c);
            }
        }

        function Wc(a) {
            return (a = a.ownerDocument) && (a.parentWindow || a.defaultView) || null
        }

        function Xc(a, b, c) {
            try {
                var d = JSON.parse(c.data)
            } catch (f) {}
            if (typeof d === "object" && d && d.type === "creativeLoad") {
                var e = Wc(a);
                if (c.source && e) {
                    var g;
                    Uc(c.source, function(f) {
                        try {
                            if (f.parent === e) return g = f, !0
                        } catch (h) {}
                    });
                    g && Vc(a, function(f) {
                        if (f.contentWindow === g) return b(d), !0
                    })
                }
            }
        }

        function Yc(a) {
            return typeof a === "string" ? document.getElementById(a) : a
        }

        function Zc(a, b) {
            var c = Yc(a);
            if (c)
                if (c.onCreativeLoad) c.onCreativeLoad(b);
                else {
                    var d = b ? [b] : [],
                        e = function(g) {
                            for (var f = 0; f < d.length; ++f) try {
                                d[f](1, g)
                            } catch (h) {}
                            d = {
                                push: function(h) {
                                    h(1, g)
                                }
                            }
                        };
                    c.onCreativeLoad = function(g) {
                        d.push(g)
                    };
                    c.setAttribute("data-creative-load-listener", "");
                    c.addEventListener("creativeLoad", function(g) {
                        e(g.detail)
                    });
                    L.addEventListener("message", function(g) {
                        Xc(c, e, g)
                    })
                }
        };

        function X(a) {
            var b = this;
            this.i = !1;
            this.h = [];
            a(function(c) {
                $c(b, c)
            })
        }

        function $c(a, b) {
            if (!a.i)
                if (b instanceof X) b.then(function(c) {
                    $c(a, c)
                });
                else {
                    a.i = !0;
                    a.j = b;
                    for (b = 0; b < a.h.length; ++b) ad(a, a.h[b]);
                    a.h = []
                }
        }

        function ad(a, b) {
            a.i ? b(a.j) : a.h.push(b)
        }
        X.prototype.then = function(a) {
            var b = this;
            return new X(function(c) {
                ad(b, function(d) {
                    c(a(d))
                })
            })
        };

        function bd(a) {
            var b = a.length,
                c = 0;
            return new X(function(d) {
                if (b == 0) d([]);
                else
                    for (var e = [], g = {
                            G: 0
                        }; g.G < b; g = {
                            G: g.G
                        }, ++g.G) a[g.G].then(function(f) {
                        return function(h) {
                            e[f.G] = h;
                            ++c == b && d(e)
                        }
                    }(g))
            })
        }

        function cd() {
            var a, b = new X(function(c) {
                a = c
            });
            return new dd(b, a)
        }

        function dd(a, b) {
            this.promise = a;
            this.resolve = b
        };

        function ed(a) {
            if (a.prerendering) return 3;
            var b;
            return (b = {
                visible: 1,
                hidden: 2,
                prerender: 3,
                preview: 4,
                unloaded: 5,
                "": 0
            }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""]) != null ? b : 0
        }

        function fd(a) {
            var b;
            a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
            return b
        };

        function gd(a, b, c) {
            function d(k) {
                try {
                    var l = typeof k.data === "object" ? k.data : JSON.parse(k.data);
                    f === l.paw_id && (window.clearTimeout(h), window.removeEventListener("message", d), l.signal ? b(l.signal) : l.error && c(l.error))
                } catch (n) {
                    k = {
                        msg: "postmessageError",
                        err: n instanceof Error ? n.message : "nonError",
                        data: k.data == null ? "null" : k.data.length > 500 ? k.data.substring(0, 500) : k.data
                    }, rc(sc), l = [], !k.eid && l.length && (k.eid = l.toString()), qc(vc, "paw_sigs", k, !0)
                }
            }
            var e = {},
                g = 200;
            e = e === void 0 ? {} : e;
            b = b === void 0 ? function() {} : b;
            c = c === void 0 ? function() {} : c;
            g = g === void 0 ? 200 : g;
            var f = String(Math.floor(Ab() * 2147483647)),
                h = 0;
            window.addEventListener("message", function(k) {
                Ac(903, function() {
                    d(k)
                })()
            });
            a.postMessage(na({}, {
                paw_id: f
            }, e));
            h = window.setTimeout(function() {
                window.removeEventListener("message", d);
                c("PAW GMA postmessage timed out.")
            }, g)
        }

        function hd() {
            var a = window,
                b, c;
            if (a.gmaSdk || ((b = a.webkit) == null ? 0 : (c = b.messageHandlers) == null ? 0 : c.getGmaViewSignals)) return a;
            try {
                var d = window.parent,
                    e, g;
                if (d.gmaSdk || ((e = d.webkit) == null ? 0 : (g = e.messageHandlers) == null ? 0 : g.getGmaViewSignals)) return d
            } catch (f) {}
            return null
        };

        function id(a) {
            this.v = db(a, void 0, void 0, 2048)
        }
        ka(id, lb);

        function jd(a) {
            this.v = db(a, void 0, void 0, 2048)
        }
        ka(jd, lb);

        function kd(a, b) {
            return O(a, 2, b)
        }

        function ld(a, b) {
            return O(a, 3, b)
        }

        function md(a, b) {
            return O(a, 4, b)
        }

        function nd(a, b) {
            return O(a, 5, b)
        }

        function od(a, b) {
            return O(a, 9, b)
        }

        function pd(a, b) {
            ib(a);
            var c = a.v,
                d = c[M] | 0;
            if (b == null) kb(c, d, 10);
            else {
                for (var e = b === Ha ? 7 : b[M] | 0, g = e, f = !!(2 & e) && !!(4 & e) || !!(256 & e), h = f || Object.isFrozen(b), k = !0, l = !0, n = 0; n < b.length; n++) {
                    var q = b[n];
                    f || (q = La(q), k && (k = !q), l && (l = q))
                }
                f || (e = k ? 13 : 5, e = l ? e & -4097 : e | 4096);
                h && e === g || (b = Array.prototype.slice.call(b), g = 0, e = (2 & d ? e | 2 : e & -3) & -273);
                e !== g && N(b, e);
                d = kb(c, d, 10, b);
                2 & e || !(4096 & e || 16 & e) || (d === void 0 && (d = c[M] | 0), d & 32 && !(d & 4096) && N(c, d | 4096))
            }
            return a
        }

        function qd(a, b) {
            return jb(a, 11, b == null ? b : Ya(b))
        }

        function rd(a, b) {
            return O(a, 1, b)
        }

        function sd(a, b) {
            return jb(a, 7, b == null ? b : Ya(b))
        };
        var td = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

        function ud(a) {
            var b;
            return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
        }

        function vd(a) {
            var b, c;
            return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
        }

        function wd(a) {
            if (!vd(a)) return null;
            var b = ud(a);
            if (b.uach_promise) return b.uach_promise;
            a = a.navigator.userAgentData.getHighEntropyValues(td).then(function(c) {
                b.uach != null || (b.uach = c);
                return c
            });
            return b.uach_promise = a
        }

        function xd(a) {
            var b;
            return qd(pd(nd(kd(rd(md(sd(od(ld(new jd, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), ((b = a.fullVersionList) == null ? void 0 : b.map(function(c) {
                var d = new id;
                d = O(d, 1, c.brand);
                return O(d, 2, c.version)
            })) || []), a.wow64 || !1)
        }

        function yd(a) {
            var b, c;
            return (c = (b = wd(a)) == null ? void 0 : b.then(function(d) {
                return xd(d)
            })) != null ? c : null
        };

        function zd(a) {
            return ["omid_v1_present", "omid_v1_present_web", "omid_v1_present_app"].some(function(b) {
                try {
                    var c = a.frames && !!a.frames[b]
                } catch (d) {
                    c = !1
                }
                return c
            })
        };

        function Ad() {
            this.h = L.document;
            this.u = L;
            this.i = null;
            this.j = this.l = "";
            this.C = Bd();
            this.m = null;
            Cd(this)
        }

        function Cd(a) {
            var b = [],
                c = !!S.eppbtr || S.rcsbtr;
            if (S.aub || S.aunb) {
                var d = yd(a.u);
                d && (d = d.then(function(p) {
                    var y = JSON.stringify(cb(p));
                    p = [];
                    for (var z = 0, G = 0; G < y.length; G++) {
                        var D = y.charCodeAt(G);
                        if (D > 255) {
                            var B = Error("go/unicode-to-byte-error");
                            ra && qa(B);
                            p[z++] = D & 255;
                            D >>= 8
                        }
                        p[z++] = D
                    }
                    y = 3;
                    y === void 0 && (y = 0);
                    if (!xa)
                        for (xa = {}, z = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), G = ["+/=", "+/", "-_=", "-_.", "-_"], D = 0; D < 5; D++) {
                            B = z.concat(G[D].split(""));
                            wa[D] = B;
                            for (var C = 0; C < B.length; C++) {
                                var r = B[C];
                                xa[r] === void 0 && (xa[r] = C)
                            }
                        }
                    y = wa[y];
                    z = Array(Math.floor(p.length / 3));
                    G = y[64] || "";
                    for (D = B = 0; B < p.length - 2; B += 3) {
                        var x = p[B],
                            t = p[B + 1];
                        r = p[B + 2];
                        C = y[x >> 2];
                        x = y[(x & 3) << 4 | t >> 4];
                        t = y[(t & 15) << 2 | r >> 6];
                        r = y[r & 63];
                        z[D++] = C + x + t + r
                    }
                    C = 0;
                    r = G;
                    switch (p.length - B) {
                        case 2:
                            C = p[B + 1], r = y[(C & 15) << 2] || G;
                        case 1:
                            p = p[B], z[D] = y[p >> 2] + y[(p & 3) << 4 | C >> 4] + r + G
                    }
                    a.l = z.join("")
                }), S.aub && b.push(d))
            }
            if (U(nb) || U(ob)) {
                d = hd();
                var e;
                if (d == null ? 0 : (e = d.gmaSdk) == null ? 0 : e.getViewSignals)(e = d.gmaSdk.getViewSignals()) && !U(ob) && (a.j = "&ms=" + e);
                else {
                    var g, f;
                    if (d == null ? 0 : (g = d.webkit) == null ? 0 : (f = g.messageHandlers) == null ? 0 : f.getGmaViewSignals) {
                        var h, k;
                        gd(d == null ? void 0 : (h = d.webkit) == null ? void 0 : (k = h.messageHandlers) == null ? void 0 : k.getGmaViewSignals, function(p) {
                            U(ob) || (a.j = "&" + p)
                        }, function() {})
                    }
                }
            }
            S.umi && (e = new X(function(p) {
                a.i = p
            }), b.push(e));
            if (vb() || S.ebtrg || S.opxdv || c) {
                var l = cd();
                vb() === 2 || vb() === 3 || c ? S.ebtrg && b.push(l.promise) : b.push(l.promise);
                var n = function(p) {
                        S.ebtrg && p && (a.m = p);
                        l.resolve()
                    },
                    q;
                c = (q = S.ebtro) != null ? q : 0;
                var v = Lc(Kc(Jc(Ic(Hc(Gc(Fc(Ec(!!(c & 2)), !!(c & 4)), !!(c & 8)), !!(c & 16)), !!(c & 64)), !!(c & 128)), !!(c & 256)), !!(c & 512)),
                    A = c & 32 ? Sc : Rc;
                S.ebtrg && c && c & 1 ? A(a.h.body, n, v) : Gb(a.h, function() {
                    A(a.h.body, n, v)
                })
            }
            ed(a.h) == 3 && ed(a.h) == 3 && b.push(Dd(a));
            if (S.opxdv && a.C) {
                var w = cd();
                b.push(w.promise);
                q = L.omrhp;
                typeof q === "function" ? q(w.resolve) : (q = L.document.querySelector("script[data-jc='86']")) && q.addEventListener("load", function() {
                    L.omrhp(w.resolve)
                })
            }
            a.o = bd(b)
        }

        function Ed(a) {
            if (S.atsb) Ib(a);
            else if (U(rb)) {
                if (U(pb)) {
                    var b = null;
                    try {
                        b = xb(L.top) ? L.top : null
                    } catch (d) {}
                    if (b && b !== L && typeof b.fetch === "function") try {
                        var c = Jb(b, a)
                    } catch (d) {
                        c = T(L, a)
                    } else c = Jb(L, a)
                } else c = Jb(L, a);
                U(qb) && c instanceof Promise && c.then(function(d) {
                    var e = {};
                    if (d = d.headers.get("X-Ad-Event-Value")) try {
                        var g = JSON.parse(d);
                        e.revenueCurrency = g.currency;
                        e.revenueMicros = g.value;
                        var f = L.parent;
                        e.googMsgType = "aevi";
                        f.postMessage(JSON.stringify(e), "*")
                    } catch (h) {}
                })
            } else T(L, a)
        }

        function Bd() {
            var a = P(L).omid3p,
                b = !!a && typeof a.registerSessionObserver === "function" && typeof a.addEventListener === "function";
            b || yb(function(c) {
                zd(c) && (b = !0);
                return b
            }, !0);
            return b
        }

        function Dd(a) {
            return new X(function(b) {
                var c = fd(a.h);
                if (c) {
                    var d = function() {
                        ed(a.h) != 3 && (Fb(a.h, c, d), b())
                    };
                    Eb(a.h, c, d)
                }
            })
        };

        function Y() {
            return (new Date).getTime()
        }

        function Fd() {
            try {
                var a = a === void 0 ? document : a;
                var b;
                return !((b = a.featurePolicy) == null || !b.features().includes("attribution-reporting"))
            } catch (c) {
                return !1
            }
        }
        var Gd = new nc(new tc("pagead2.googlesyndication.com", "/pagead/gen_204?id=", .01), !1);

        function Hd(a) {
            a.umi = S.umi ? 1 : 0;
            a.bvst = S.bvst || "n";
            a.opxb = S.opxb ? 1 : 0;
            a.aunb = S.aunb ? 1 : 0;
            a.aub = S.aub ? 1 : 0;
            a.fld = S.fld ? 1 : 0;
            a.uffp = S.uffp ? 1 : 0;
            a.espa = S.espa ? 1 : 0;
            a.aifbl = S.aifbl ? 1 : 0;
            a.lrsc = S.lrsc ? 1 : 0;
            Z && (a.omid = Z.C ? 1 : 0)
        }

        function Id(a, b) {
            this.F = a;
            this.o = this.m = this.i = !1;
            this.h = this.j = this.X = 1;
            this.aa = !!S.opxb;
            this.K = this.u = null;
            this.S = cd();
            this.W = Y();
            this.V = null;
            this.fa = Math.random() < .001;
            this.ba = S.eeid || "";
            this.J = this.l = null;
            this.ha = (Math.random() + "").slice(-5);
            this.C = !1;
            this.A = null;
            this.I = 0;
            this.L = this.M = null;
            this.ka = !!S.uffp;
            this.ja = !!S.espa;
            var c, d;
            this.ea = ((c = L.navigator) == null ? void 0 : (d = c.userAgent) == null ? void 0 : d.indexOf("Firefox")) != -1;
            this.Z = !!S.lrsc;
            this.U = !!S.btrb;
            this.ia = !!S.umi;
            this.H = null;
            this.ga = !!S.elodp;
            this.Y = !1;
            Jd(this, b)
        }
        var Z;

        function Kd(a, b) {
            a.h !== 0 && (b ? (a.J = Y() - a.W, Ld(a, b).then(function(c) {
                c && (a.u = c);
                a.o = !0;
                Md(a)
            })) : !a.ia && a.Z && Ld(a).then(function() {
                a.o = !0;
                Md(a)
            }))
        }

        function Nd() {
            try {
                yb(function(a) {
                    a = a.document;
                    if (tb.length && a.head) {
                        var b = F(tb),
                            c = b.next();
                        try {
                            for (; !c.done; c = b.next()) {
                                var d = c.value;
                                if (d && a.head) {
                                    var e = Bb("META");
                                    a.head.appendChild(e);
                                    e.httpEquiv = "origin-trial";
                                    e.content = d
                                }
                            }
                        } finally {
                            K(b, c)
                        }
                    }
                    return !1
                }, !1)
            } catch (a) {}
        }

        function Jd(a, b) {
            Kd(a, b);
            Nd();
            a.h !== 0 || a.j !== 0 ? Od(a) ? Pd(a).then(function() {
                Qd(a)
            }) : Qd(a) : a.A = 1;
            rc(Ad).o.then(function() {
                a.i = !0;
                Md(a)
            });
            Rd(a);
            Md(a)
        }

        function Ld(a, b) {
            return new X(function(c) {
                function d(g, f) {
                    a.K = g;
                    c(f)
                }
                if (b) {
                    Zc(b, d);
                    var e = Hc(Gc(Fc(Ec(!1), !0), a.ea), a.Z);
                    Rc(b, d, e)
                } else Qc(d)
            })
        }

        function Od(a) {
            a.C = Bd();
            a.A = a.C ? 4 : 1;
            return a.C
        }

        function Pd(a) {
            return new X(function(b) {
                var c = pc(Gd, 1184, function(e) {
                        a.A = 3;
                        e && (a.M = e.src, a.L = e.sdk);
                        b()
                    }, null, Hd),
                    d = L.omrhp;
                typeof d === "function" ? d(c) : (d = L.document.querySelector("script[data-jc='86']")) && d.addEventListener("load", pc(Gd, 1183, function() {
                    L.omrhp(c)
                }, null, Hd))
            })
        }

        function Qd(a) {
            a.m = !0;
            Md(a)
        }

        function Sd(a) {
            return !a.aa && a.U ? a.i && a.o : a.i && a.m && a.o
        }

        function Md(a) {
            if (a.i) {
                var b = null,
                    c = 0;
                a.X !== 2 ? b = 0 : a.j === 1 && a.i && a.m ? b = 12 : a.h === 1 && Sd(a) && (b = 11);
                if (b != null) a: {
                    if (b === 0 ? a.h === 1 && Sd(a) ? c = 2 : a.j === 1 && a.i && a.m && (c = 1) : b === 12 && a.h === 1 && Sd(a) && (c = 2), a.ga && !a.Y && b === 0) {
                        a.Y = !0;
                        var d = Td(a, 19, 0, Y());
                        Ud(a, d, !0)
                    }
                    if (a.aa && (a.fa && a.F !== "" && a.C && (a.l || b !== 0 || Vd(a, !0), b !== 12 && c !== 1 && c !== 2 || Vd(a, !1)), b === 0 && c === 0)) break a;
                    if (!a.U || b !== 0 || c === 2) {
                        d = Y();
                        var e = Td(a, b, c, d);
                        b === 0 && (a.X = 2, a.V = d);
                        if (b === 12 || c) a.j = 2;
                        if (b === 11 || c === 2) a.h = 2;
                        Ud(a, e);
                        b === 0 && a.S.resolve()
                    }
                }
            }
        }

        function Vd(a, b) {
            var c = b ? "d" : "o",
                d = null;
            b ? a.l = Y() : d = a.l ? Y() - a.l : "?";
            a = "https://pagead2.googlesyndication.com/pagead/gen_204?id=opxhb&evt=" + c + ("&eid=" + encodeURIComponent(a.ba)) + (d == null ? "" : "&ttp=" + d);
            Ed(a)
        }

        function Td(a, b, c, d) {
            if (a.F === "") return null;
            var e = {
                omid: a.C ? 1 : 0,
                rm: a.A,
                ctpt: d - a.W
            };
            b !== 0 && (e.vt = b, b !== 19 && (e.dtpt = d - (a.V || 0)), b === 11 && S.arbpp && a.F.includes("/pcs/view") && (e.igpp = 1));
            c !== 0 && (e.cbvp = c);
            a.K && (e.dett = a.K);
            a.u && (e.beid = a.u.eventId, e.vend = a.u.vendor);
            a.J != null && (e.cstd = a.J);
            (b = S.bvst) && (e.cisv = b + ("." + a.ha));
            a.I !== 0 && (e.vwbs = a.I);
            a.M && (e.oprs = a.M);
            a.L && (e.opsd = a.L);
            (b = rc(Ad).l) && (e.uach = b);
            S.rtit && a.H !== null && (e.itt = a.H);
            e.arae = Number(Fd());
            var g = "";
            wb(e, function(f, h) {
                g += "&" + h + "=" + encodeURIComponent(f)
            });
            return ub(a.F, g)
        }

        function Ud(a, b, c) {
            b && (((c = !(c === void 0 ? 0 : c) && a.ja && Fd()) || a.ka) && L.fetch ? (a = {
                method: "GET",
                keepalive: !0,
                credentials: "include"
            }, c ? "setAttributionReporting" in XMLHttpRequest.prototype ? (a.attributionReporting = {
                eventSourceEligible: !0,
                triggerEligible: !1
            }, a.mode = "no-cors") : a.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            } : a.mode = "no-cors", L.fetch(ub(b, "&ftch=1"), a)) : Ed(b))
        }

        function Rd(a) {
            var b = a.ba;
            if (b && (b = L["bllsn" + b], typeof b === "function")) try {
                b(function(c) {
                    c && (a.I = c.block ? 2 : 1)
                })
            } catch (c) {}
        };
        P().btrp = function(a, b) {
            return oc(Gd, 1183, function() {
                var c = Z = new Id(a, b);
                return pc(Gd, 1183, function(d) {
                    Kd(c, d)
                }, Hd)
            }, Hd)
        };
        P().pdib3 = function(a, b) {
            oc(Gd, 1185, function() {
                Z.S.promise.then(function() {
                    var c = a,
                        d = Fd();
                    if (sb.test(c)) {
                        var e = c.lastIndexOf(";");
                        c = e === -1 ? c : c.substring(0, e) + ";tpsrc=cis" + c.substring(e)
                    }
                    if (b)
                        if (e = !1, e = e === void 0 ? !1 : e, d = d === void 0 ? !1 : d, Kb()) Hb(window, c, null, !0, e, d);
                        else {
                            var g = L.document;
                            if (g.body) {
                                var f = g.getElementById("goog-srcless-iframe");
                                f || (f = Bb("IFRAME"), f.style.display = "none", f.id = "goog-srcless-iframe", g.body.appendChild(f));
                                g = f
                            } else g = null;
                            g && g.contentWindow && Hb(g.contentWindow, c, null, !0, e, d)
                        }
                    else T(L, c, null, !1, d)
                })
            }, Hd)
        };
        P().vv = function() {
            var a = rc(Ad);
            if (!a.i) throw Error("aiv::err");
            a.i()
        };
        P().sasrc = function(a) {
            Z.S.promise.then(function() {
                var b = L.document.createElement("img");
                b.style.display = "none";
                b.attributionSrc = a;
                L.document.body.appendChild(b)
            })
        };
        P().itt = Ac(1639, function(a) {
            var b = Z;
            b && (b.H = a)
        });
    }).call(this);
    window.stcc = btrp("https://googleads4.g.doubleclick.net/pcs/view?xai\x3dAKAOjsviw9xRtA8InOIIN5NHCZ_ogfRG5EIkeMPF6u1KnK-u3RT-I_loja1FRnF-mELgrAdy7x66774syCYUEXsO8AXfQoSHla0vR2RI1WsX-OUBAGWN615ICnxXuHrEugFUpUAkciLh7KN1aCM2pg9-JUq8ngprpEc6MhfaoqqJinKdvDJBNxjLtByFzqeX0-8jUVl9fWYnPRyZEzjn3-jOfUyfUaPQ6HtT2BxA2zxR0bHL6n4l9kZPvoBBUGcvemCQ4LMYsI5GZY2HI2nHx0NViuldoVhj5NtE7eI1E2OqFH096vDDNFaXu1cw_D7F9-40wHckGOx_VDXcLRr8MT-PxZOs0f3e5fqjhtb74pEQEqN9y595hXyxwoCw8xonh8JjBtK_jji8nTTCv94nXrncIMKS8ByyZqA6Q8nvo9HkWieKSSnAGPVNCDHua_HN8P-_8k8Ptixn5-DQPpQ6vbdry2cWWG6yDFqNb16QvW55_4lKcN0gBX2U-HP9Fu6QbyfK9XQmqpnPc06-NqpqjEmqo5_moH7uYUPriPXytTbUxCewR4zOHTXW1boWCVSmOz6LJYEU59XQLCuiDLvCFAhrtVJgAaHAyTVAvj4Nftfa7fADbDKcY_xVdbm-gvYN_HMKuwBg_HE_rGsi0LJ9bYI7sgVOiUGHmbavrw7PT_emoGXZEVndAnG4Nt20hybmY-AFKLBItyS1hOqP56BKf7Tm2u5eTuXJd-fdtrX8JHO2QI3MEj-B9aHZNVkMSZwoOBj8z0E8jXW3oYq9XhS7iTgFj-HLQlpW_ObDkyumGRlyDW9ynzWKndy255JOAB725YG4VF0wcRLQvh2keehqyqCnfyLocnqNBm8CjOo56Bpjrh2a4Mp0QqJjJVRl47ExBSHaJ2wNHbQOpmFs_yLnkS5bGmQkvSiBztanIlPn201kz8B6ECIT7s4MrfM4vBZgovOXFH3tNgfQHmWOGHBWB-j_Hkt2Z4eZGgW8oeKExT1Z_bt-kpHucbLb9-3mDZloeV-Y-by9NDIOygSIEzrhrSgBqIEBBRFtD2vZqZ5Z0clfRqFapE3wgbcN2RGNix4bqfibKJh7iJX8_LdPrha2o1lxRigs3TgX0Pbop-Tcx1TvvIyhCnlKlqYvLPtCHjL8zcRxECG3E8dmCQI_GNvaZMh34uCXtCyva2wdW1tD6hbYjfuV4pOkkYO4sFJM0jUZG_GIu6dUnXsAf0hEwgS9FvgP1k-qKMpngsmp-lSPkyI68kQJVNndVhK_ZmahexautD9WZCYeooLV_jxpRbYmVH7AtlNNn65sL1wafIrGSHzgKJ0YnXuxJ9_p14-ao3oUaQW6Hi1khSyINhAlM9tcZZrJGrr6WuuRhao-DBwHyjjm2wxLFMYwo-E93ms-m2YACP03IVW77VdT8XEYZloY6X8sP1aQtWeu0lNwkXc5cl_lT8S69kEGsPP4n2GpIAlonqiQjUBTdtug81Z8SVcDmhflqjZQ6hsSfG3t7xkb9AoYxLM4e2JbYNGUEXnVw0UMgFuLl4z31W02p-TmoNibqaFcO7h4LVhdILvXM5d4de6mm3gSvt51Puc\x26sai\x3dAMfl-YTw4KuVs5QlxP1Vbw0K0v7UJHRVyO8KRr2kO8Up788-FH4CJcshOdF8C84H6DqJ_ZJVaBaRFJsZVY6nqcuVzSEFOX8APHrsyvnDGHt4-sNQim7bQwQSnKneIT4o5w0CQa0S_VEmF1P1SJMuVMxn3S85SsvDD-Q2GDA_YccYPAND-9738jGov0Zdj0ReMEDY2xsubq07wlLun6lmxsCRmyN_FUEbibL8bZCJqXH8MfinImyWyHoo7fybIaCJICzHnGsr5dhB1B8sFAinOhtIy5LvgrdxAUggw6yKNSLUfX2SiXOW0vJ8cWxK4U8iDRprcyBF7z1lbHouht97KvMDetjmhCMGYqzNmIIj_jrq-XyoAp_J1_4vonIjAWlcyeF3JWpxnMFOw_Vm1t3FgNfTCUn5orH6KbSd7iyEVpNyoyCrS63Dnjae3adT8AlL5d_-Nq7EYW6aTeZvEEV9HqxS3kZzg5nUVlsDcF4oAu0gOF2L-opTh-biXjbZw2OM0aWm_-IE9ByCcvQbORzHviA9jbjaBIygth0qmD91igT5qG62yT6BQQ2aO9HD2WMyOlfvB9JX45qJ52AeGdu7c3QI1o2tdTZUxVvXUrtUfNMljB2_xnj_q56vMIEVfSXdeYrMSk9Q4g4zG4Y-NKhyssciWg\x26sig\x3dCg0ArKJSzI3jc2yNKps5EAE\x26uach_m\x3d%5BUACH%5D\x26pr\x3d13:awLnAAAAAABwzFJPQCgMqT1SCEcvFN-gBun6Yg\x26fbs_aeid\x3d%5Bgw_fbsaeid%5D\x26urlfix\x3d1\x26adurl\x3d", document.getElementById("gcc_BOcCa5yMDLrG2fMP6JnQ2QQ"));
})();
(function() {
    if (!window.GoogleTyFxhY || typeof window.GoogleTyFxhY.push !== 'function') {
        window.GoogleTyFxhY = [];
    }
    window.GoogleTyFxhY.push({
        '_scs_': 'BpxPfBOcCa5yMDLrG2fMP6JnQ2QQAAAAAOAHgBAI',
        '_bgu_': 'https://pagead2.googlesyndication.com/bg/XmnnX5zmlCqF9ze0osNRx80LC2gwoq0EGiIFpO-DhmM.js',
        '_bgp_': 'cthuFUMvgBaYzV/+8Xe9oYjFpUvDAc6roJIygN2Yh7MwpL5Jp7wKt0Jl8LnlM1b7z6iH6yN+fN8RbCUbUvo1wlTaKPmSQUnjQjrt3PzLNUpQL9KB+81yvF/2+ZmW1d2RS0Brg55KM+c/X2ztY+z/mujhp8l0zM7qlvN6HwIHvO15PKHYCfyglJSAf1umSdGtHuuS7cxjFBvFKPslGDYVWgyxHZIgUOAehOTevVMEoBPugFAEGlRQBjs+ZDKJGS0lj0RZ0apT5m6vYqmtPfQI0e8XXfL86hq69FTcJJyzUQbmRsWdRL8hH+1O2+T3gR7IsgfWxVIbsCcD0g3M+YK+bwLiNHSw9U7500Dbgn7Te0F8CFA8xtjCDMr01Szja0gHKEZehlW7w4tIY/Rf4iMnlX6q7X6SI0clqM5iruFv1vhSfJvtQJh7TvZYYo7Z+D9/aDCO6CuKlx2VAkhhw+cLHTMll+vKl/uWU/rbmlug/YHS5FVTllUYv17lb71Siqf8vH1rNPPQ3zzTzSFUhBFJc16EayPlKNMg2XSgEFhBvEmwfvL5LtAYnrQltSOCkwylXp1Lwugo3S98IrOQe3wZg+kdyLumKa7Kw6Ikv7V//Y2JowlXrqO7YtHwXoqpBeAO0gcQefCZf4l3UcCdTcJjHlokg1NCn2CN+5anOO0udD2RZ8YH5cJpXakEwp6cC+afavVZKNX9kmu7F8pJZr/s/loJpMoE0sWmIDwc7bLqJn8U+3fzy0IV7s7CahUTl5PP3P6pdxaF5I4E/hBC+m4H8x4eEnIcPQuB7GeF8dv0fIwCbLfQ/mSyrzWgF2SBSfpvegV63z4xRhKQoyI3eBHHlVUbn5S88w0ZxPphN8mfgcI6y91/LXjUdvWPzaSww5hfMkaDQ/5Rn/h/uBgxXW1+fXr1rxUOGpjssJYdLBTlfts6tClMFcgEULoQo1FSC47hTwapdPcmTUVVTbsXQ8YZCP4eBiONwyDoaOP5vb9bEK9V/AMcTp7jaE6SLan1xmAm8LKhSgrazHuJgGazrnAFyb3Vs4710DRSxq/Qe1MpfxjdODuaLT3KUGiqQ3L3gGjerMCq8dB1EtvfteZ9LLS4M/1sQ0Wz846/v6HTKccmP45Dn4ky72HvRHPwSOQD+B6EmKtoP2mcr8kDq5hoQ4grfj0B1PIy9xb+b370v3IWPaMKDSldmr5fnmLhM3ybep+kOBcVPw3m+hJ8Fqr6RY5/yHLsWgxIWfJvTw4jxKaDDOLRPFeXpAbE1vV41SBnKsBQ/pSen0QGV0vBlVC2HMxCMwLY60h4Xj+OuBZIgY3uGNGNo3+FfFtyC4p8D1DNNa+k5DzsyJ6Zcg9kD/nz0ojq7c5Bb5kT7vCqiLFLGqE1ovZQE7s6b0FyhN7Wlbt4tkvxaJxpWBJS7dEolXCpUCzWFaHtbha4Gtb2mlRm3PeQP0jpI4eor0XyjlU4iA6bCokadElOKTM+OEXDtT5CHDbZKmlG2xG304dtQpWjSjVYIQi5EeuKtS0jqggyMWqzDM0yXMR8Hscglr2QfFDFd/7UJtsmLSEymLSsx0K0LrZsmMiYVIxp3JxcOc7faUGrLq+X7/slts0YsNzc0lJ/dinbYPIjk5oIlDe37grGCyOX/yx0l7BiA4YoXEjP+D33wVc5DLYtv8dP0XQazXtNocjSHkNACr1DOmLzTd1o+h2EmppoJbzRBYOv314OrWLWFKemba8vp1ZFFYjIKhBlKTTkdwGa1dA/vrbu6SyVpxR9VNIvI2CVJMrGLGubIP8Fgxqrqc86SagQL2Dgxw1Y5x0yC1bJKfqi9NVsDICGrgV53PgDYyC+Cx4wDzsKx58mkV/crkFGEG+Ux4USMlQt9rqygtAJEZD7yBsU75QuUJt4dcj0nqERa9O7W53X1XSc8o0cAVj2Dx0TX48vv0iGrHYh6ULtS3qfjHj4Mg0TN5g3ULjjHqZ+Ff4m58AOct1JvFNxLm9FRqWOuReg7JY8Uj4KzN41SHf1ekXJetBXohbD3NhxFkLpU6oFJhEokzV4tTd6t0EXVFierhbbqxcdXi06PDt/04Omr96TptlxzYxynQiDsaIsz4Ogl3u2FaFaxgTECSKQfOMB6gOj34tkAscYNVWOxFaIx4BGyuGU2zXocAAja1MdSs2z6VlFQ4nrTawPmmLvYQMmM6K15SyecOnZGjWzrXZlkADsk0lPuNgz8jBg9hNCsL3rBEU5nAS0UzMuBlx48RVb1r4yhdChjbPGM8HmB8I6PEKm5wgtvQ9hrRYnJpLdYPoFpIISnpUisQEVMJR/1BAItbGcy744F0XmEEWYD6tO2j5DU4OmxYjMDIyzAYOCtp7BTtP64ilp0fM7540EPNOI+yBmCh6ITjsgVWewBN44129CTUnqE/vfWHWkpHamzOzuPTB8GJzViHjTKH6WIZzwIgrekOWyk5JXchsaV/O32Dox4krXMAKpQ0oxaU0kPLthAN8qpcgrQPcY6YYNFJRf4uRqrRIRgumQNFksDUEyS/DUM4vjva0Wpo2Bm6HB/tO54yMcSUESvhRejLWExP3qYNF9YTew7DvfC2swHCcaIql80Z6dazU/x7RvqvdAOEmqdEmGtNxlY+30lQXHRZ4l6RvASBm8ySC6jvBYOXN2lUmZTSnpclivqTeBAOYT2J/sQWH7TrBT1xQiKpdoDR9bS3jp/NIR6YWGybnZV4tcdqJPegvrC50n5L7j1kLCRVzH1r007su3+guh+2lxgqAUzHxLjrTaoNkIujy6aYX8jva6b6vme28jEbPolvqLacOHUCKB6zn8UrW/zy7NXwiPyCMa4X9t9JYdNjxpizJstgJ3ql7+U0MkZt2dvo1SDIoEq8XqAhl+EFPoXFUMnXSOQEpx5dlhyBuvx1neFHUlDsNdFNuhniP4ILzblwCEfW2WQWmYgXpoDqQjnST1FiafUme55NpwfIidDGKMy/qj6ZF0d0x5RjNknkhgRIxKDWRrHrAVlEFYBF5uqudYKQ7Iti9Bbag47U0Eg1EI/Z7lGBcaWfxtAmjJzlz007ykpgFKXoNo/g7shKq0llEAurpqTZiZbV+senROAHtQBsyprDXpfilzSoG4TPxOhk4u06BWqCTQNTc14gFbrBznB+/z8AS5bVC6CJ/TZ/EidtRn4CMdOOhu5UyLTK3jY3RWuVNsmefZyozcbJYjDsORFJZLel4jRCx9kG8wFHsO0REAuWMJ3cA4pt4z35s9LHJdVT8jXX7gBnQFKPzEnofuuyDOkCSI01ntqL8M4A9R1NupC7PqNIhZMvaFA1xCY9p1j84cFLAnjIIVRkLgnZU+q0Mam/2ddvqQuHvxJNQOtyYC/LaOfm6P/2e+HkJi+5X7vGfpwPnY0V/uWYaQgcPDP6WwFWAy1TYSM0cMIWjWRkH7n9p7JV2V7g9bCB5OcLrmva4teQ1G2wgcLVAPl68kvr6iMgz/c7JzOr0+q40s7mKqzIp2YNQV3NOdogM4Xltx2O1IloGM4+bcRJAut7z0IowG1L/QgX1WcqwX0s47P+vZsIyPDHNfalz4WkRthhABeHzQlN1n+rM6ep0bi3iG20gpiETq5SYYN8S1Lk15UatDG84S0FD9qAtvDiR5MCVexBXuzo990BJ2nL4OcZZv28JFHhtNgdU5GW3tiTlRAzArKxHHSEfnX423xQFvNqRaLhN61qvx+UsrnMLSQg0Udsqe2nOlyNoBC6eswxNUMvbfXAY3m51TXAhNB4v+9q93UT/C2GjbRO+Jq7gN+H4GcbjE03VUx+EueyKMpka1rtbf8mCTSGHLqE0rLz6scQaJ5K0jxvk3GGB4R+cfgvOw7y8oz6yNallV+wYzORuYhgPmdOTvvV2B/LfBYz20OUld8cMr+xFtEiKHw8+9dZ8YtjXEOQTarHi5ESKfO/tBeFF1Dmov4yL/QcgHRBHo+bM3i+zvnkRfIjNR3e0LnwSsfy0AfoAGJctOINXpeg1eOy07+4vA2oLzUHvkFskx5j5QIXXP3EL/aUbhBV/yqAXEwoeW6ub1+ztLup2/CopgggmBIcwTsAhc6V8bvdpokQTPxQFvxn1i8e9PAxyDgs3ZvBS4mliHxTNNJ8HLP4GhOt8XsnwfkXhEqAvVirXc0Y/O3tjp1rvIzMagIvAQf2ZuHn0EqnAJwma1VBgtCymrkqBgUgI8TjA4IfjdCa/WJtAFaDk+9fGWHk7BO534dRxf4YV99PcSfRqQDoj5Qa8WGvjHxe2+hqFvQbc/Huw/bONAJ+HjiNT83khbLu6VlZGcAI17i0ZqphqFqp+aq9xoHwooGwrWSVRkXkne+rhmTTdNUMuIsjQwQOFOPlXYHj8IaF+aO871XJKRrGHt8fDimgCrzbLC8A0XaABZ/xjxnciT99QE1DIMf3ksSEtkHBAJr6C43Hld1hFqr/QYsNagOOyHL+DNd80y0peg8JLoliTiQMs89APxCqA9C9fpnh4Iym3lhReLjfQMMO5O+3VLpwIsn3EkDv+Mi6zG+LRNUHhGDZlfWSXgs9rwkQbgTpUOguLbAO7c7IOov9KaF1adJBLOflnqAI4b2U5mDHwQSgN/nEdDyzP+kmIXSJjCR0nZQAB/sf6ipEQOwa9ula9AvUfq4oLSd2I04XGveP/tCGRgHkLj+dynaoY+Ch1PFMWvPw9RKRq7iO+U3L3luFp0ibrI+QxqI5Lnd/ip65+6c6ZIlD8SivcnD4Q0il53HGktbjMp+QH7+x3DXnTOUQZW5Xhiv7gQxN3k/Tz4j2wgXmqNQrFDIA8h4bjZDzVtAFzq2aDpBBnEpln4845VWPyesLaufd5WKPlLmBgbXdNkb3vqBtrT2JMVUcgTFIs38azLbgm3zbL+rp9DOJVXSQ2shJCoaOVhdaVnrOxZon1/6xCjXlZqo2NIYtMSxax41E8LPdF8A59UpZQz3JxYxwavUZe3mUTLsZfOf4n+nTuXvcNYuzHtrwK9igtZBEAnn0zabaGuKJ1Z316bU+GXo8fi7bFu1siJLh+Vj9fACAB16R6DhhwBkZDhyGXPeHjJV9S0v8nMQ8A4QZc7I9v+3pqoTLsalN1t1JpuAGwHIUrfjQAjxv7L3nMyGRXcGj+EXE7pU9UCYQWV/Z2XRhnu9z5kz8dO1Rr5czfPHYvWK7Mqsym+xL4oCYt3oYwDiIui/p+wFjXRSQ43TLr6y+FaIvi0MXoynTrsx29ntFq2b7zOYfwhOHIJxWpmmye2Jv8FPk7DXA5HV2gEB6nb5BRUndAtgY1GGRgVFSlPEKM0F08k0i82l9sTWvmpR1xLPe5Rd2mTRvWvWkWO9QCxaHZ2by8ILlsN0RHmp+4eTgGAoRunAr0N0Jom3XUujdE9sYfb80fmBFK83uaHhOzYch89/zPDwxwUCmbq+dQ9PBPbTHwS6A4OWPQuKkob+jwolp3AShX+3fBmC2snWvLfrq8NBzRK0P2he+aIG4Q+AuKenN15kZ/9/jpNeRce/1zW+vkP4ZDz06Q5ntlKNfBw7je/dwTq/wvNFDtyTXMKnavNvuapAvmdofXwbmWFVpmXEXbLms+kC/kTefvtwI7dO4nfi5wyJnJZOHR3wdJ/Kj4jckMduLPHPHIkPgskYbrCElULOjWag8Ib3EEZ+/5qcTxygez0k1qSPynUm+wgm7Z5znBowztlOS4/Mh+Rp1NiD8md78buk5a+3svEbpp+4A1lHsgfkYpEVi52Z+wUngreMhEotK45qr3mGJVTt3vm1c6ygtNvFkqwrdbL8mCfjvJlNAfK+9TY/Fdz5Zx/XKKE/5X/tE/kQwQ52MKnGERufWTEy3Ymd2rpLwwMEZHw7yKTIEj3DX5E9cHAKr8I5bdzh5CUR/fvyBF/945qleMawwyv0Rti1a/xIHjk41UH7oO3jH52yk198ixKO4YKH4cuaiwItg/5IlOF7oPu5txbOv1lD2N4XBEsRhrkkTl+5ZlDdqthWXZKhfcYqHU30gZX89B9eFCg1z7HqvmVUgAZ7Bzn6JTDxuV+3u3+wvGiZMgt5siBOEwrbfz9bT1PaOKm/iCX4q7wOukZpZiQdsnObKH1r+yNiM6ZcgzXAyrm6QvQknudbF5zqIiPmknxkoveNYISGa2mfVwP4NszmgyebQCOwiHNS8IORslFmUqUXn5FDEEhVTfNug248yZYMkptEX7aCoZuNAxRjkhHoCA2zSVKZVDwVkg30KbM439K+nfwjyV/oEXSLUh2lxVlPYzHFEtn2g5TJYB4oZmdwjNNIHnKiTLSUVEF3tUyx40zY1DyXXxJfKfPiPUDuxBoqLo1k7Rxsks05GqiEk0uOFwnZ3uDpCOROFAFnPbKxleIJ0DoDbAYksFna7L9U1Q/nEUmOHzyYm+9KUI9OQIYFYkf4dbF5X4g+neiQJZg5fXX/qeOcassUbtSZYvS51HsFtIB0BqQbacVkJ9K7vTnPtR+Cqp1bKg+3rx37R0YCOUrjRMqsAlvADdF0u0Ze23XWN89VAFQDQaVrSnvSg6Sv7p/O9lcMydw2ETfobujNqr4AOk/g5GAVz/MCF5lDK152wEIS1uNVzA25aXNTffJtSvhYms7+wMFuzJSBvsiUcZP/fXwMvMetuQhbVez8VOGoaduLe+YLNyLLa754lxK/NRNJeR7jpcf6KZyoOp33/ltO/7J1AcMY0YaMsRgANEXgUcdjTW+aXXDo1hvOCu1MwsKibW3CFCoZvoW+j3jogf84FEHxROwqIFOwhapxD5PQCQSLAnWk2fABdIoB5Sm7vQALfdZMn2XvnN0536VRcW2GyzKAYkilKUwYVmnaXALRFHr8+wscEDVqP+cTC4svZV8Za7ouMPya+PUiKDO7VWJZjxXNHj/cIk5N2Vwjd8uCVJNwrN6IPAE1vHd3kH51dw+ERAhXUFLfEn6BcEvcNNVbJUgPUORck+KCYyfiy7f2E/5CoPVK6/JrHCqvNJw60f1hpusGAIBToETPtZgJ9uEaTAj8yO39v//x49ti1Kua+HepPn9j4cc6ilCjkKQ8OAxtX8I4GjfNcIXSWXn+ytTCbEQsHsbfHatoKAZtZOY9KNhpQIbsUqeR5RVQ07+beKTwFkgyd93weYzbX5JhmK0gpNl3ujeJ6AgzFJcMKjyQVgJKq8dc+5dQynknvz30eT35j3WRWEcSDLU/PGUSMsGU646lA2pZc8BTELDLuxA2tsuwi6lBsem5bY1JMlDRKDTGixtVuF1FrtJ4uTDWRZRrBlhN3OHe/OQCDr9rMtCHwXGgc6k3rHHEGjR8MzgxUKU1/WTF2lraLoM+f2W0f79Gi2vH3B7EeRv8vT8PP/sJTeSs8diAEa9MmBH8SpnuyBsxDteel/VjyoC9DE0qKnS5ichwVXarNZGV2ov49bd6sSQ4z8exozgYJHfdTD77kXstnx4LV6OYGzPXi8oxKbPVasvQgd80zXAQDDJGl5qFN9TECitI02e0svvN7YkKMToesAFccd6m6SfZk7lNMAB5J7CEQpM6tku8TmhMEUT+kxihO/BR/ePJgxMVGYcagcvOSoZvxQ+W6+n15qBY+nzuRtL/jpjs73RndwNkJlujF+HNLhLZJ9PsD4v7t8zlmrKqoqjId8h8ApagqH6obHYXVCnwgkIsZk1mda6jRmJ+sZpXSIrLf17zzIF5SIyczu0MfwzASv/JQz3bKWTGH2wyUroYnoSFIAsRo+EAvp/ZW+mOoanM+T0Ob4ZmK1kBT8wJ3Hu6pisiuoL0z1APvPyQhl+i2uYQuBZ/VaQiAKrgZR9rllZSpjUl3iID6rp6Poc1zxNzp16RQFRoYcQ6RJX30pj03tEcJuLMWWnV5MIALJX+kRHSAB/ilTkOtBgZqZynjlmJpAkl7nOppClFjHs71QPtQWocqT2bqRkJDMt4aHJOJfu0uytJ7oxZ83gaUlSrBevxJ1198BQK274Oh++6VaAKeGCg9+lxSItraI7nOekJAMCEXfpkgjN1kG+BubnG4K/JomutQIIWJlrf4+0ZbJDTnRQd0f1ZeLpr338gdtgx643mycnj6ClgHe6tb9G/F8mqz+oWvReC/ktkuW5EG7EeNHd1lnUrbQgyDudCVmgttD4njRWYhQGbqPqZVJKMoY/aRwKuoth0SILgJ2874D0Ld91CMaujl6ioaZjE8d1WiYALQ7NQ0J9QKYcweRsMVw9c9lVxHTXeskPw8jw66AvTmK4ApfYzqO0YGP3lhQrq3Y+hF4D0acm0WPlTWqnUl7MX1XDOVjlpUvBQqoyUpW27D3lqxfkglg2RQWH76vbUWtd+2Gk7D1lJmIhIv367YAxRDpbXeqoxEevCpOfShGU2reTSv6eT/5xWL51TERXqCpRGcsf39hvWHC+LhviO4kh1MoN7Ifdv/hTCE3ApOWWP2ijHZOI+7zj3BLGZAntdxfPPv9/jnzBlu8BdxtR9VwLcU23UJY0x8TLdpR79+wBrnoOuyWnRi/fcezAKh+LB25ysIzi0rxkWIclkPqahq51UfgdHoOA0hQBFtl+bLVDD/GDgfumSs2n41UDC5KYEWzFU2axoZj8FU1Edw7Z0Kj6R/dm9fh+zlEnpQes+CkZc3/peAV59+8Br3UeYp+aW+hM+Y6gyu38XfXWZcglNEib3nNmw5xdsYJkjb4AgfThRvhOQKZ6fA43m/o9jkbmQoNcSiKkeuOuDXesN/lYkixUuDs3y9+D3Dh2phTup2cetfVKEs8I2ys75HJtOorMinmVJxbRTOvc36G2ICiQcCfZP5K7hXO+dWF6mDW03Xy8b/cvk/fjjCloQpQZGl4cpmACv7NQM3/vS2L3gm5QoblssPIhQmkC7cZr+QOkYammR1FDS0+QL/+BvDY53Fw74mJD4DezUYrpoco2kqYAZInqF+K5kJLqQVOz9mYWdC6BasTFWp4pD8LZ0U8IDWbeJKm/FzncGd9gZEW3yF7CZm5W9MuQV4nqeBSSJJHmS2ALymS5+rXucM+yR9lpZO0KrTIS48WeDZqriUX3tX5QOOdmU8UE4h1CNuLMcVJO4iKbtU9yJxrUUBKOz2OQfmnI0q6RZqoiu82zUFQ/x/jf3kQC8iGnfR8xVoTW0AGX5IcJsOh/COH/3kzMv4l5KLPI8lq3kPO4xflHe59bWNDsicU/24/qwP4vqo/A/8UJn4XYBs+TJCdbE7aRl7iMBub5Dhx+Iv/X3/lMJYenqyuMDHIfXu3yNAYCfxgJsQ0OmmIBlM+yi3Yad/LZZ16rIKnAafqQ+rhWFaxwgB3p911PCZ2/NETGBoPqGmmM16PTYyu/yOlfDSIfdX5I93blEVjAeMP7nnTfBi2LYc3ctaT5Ri3UoCctbSJ/ysjyJ4RfNFcgpKFxsQ3U9HxSCQhgUGF0v1BLi7uHIDnAJK9VtOkcn/hH5eAL90qzyXwUGu1fA6vcimqlVoSoKpBgu2vJfVOO8YtCeGGU6tWXra9b7XKddRx06+1OOcWOLA2KamGVDoGaeRNPp69T3e86/a/9IP+u32tpBuhQHgncvH3zVLQPw3qzcMtwIrBnQ3GoLalanFASYOlaaxGOIHmuoPq2bCyIw+rdJa42A3H0yGNz6kI0EYIVtazA3AXf4viWIy8aaqiZ5RVUvhM3pe6ii3XkUf6b5Ob01QFqrdgTctdk3XYxAdZr16Wy/D+gGd0JhqBx29Z9V13jmLX/uFuVK4+BFolYj7B7YPGP8iAnfXkIB0mHOX5ZCklLPgFyict4Cm3hKbSZBl1vHE0on75+gdU2SmSqgT89RVhUOiO2hFN412w6dOQrzeNZKp+kBD5ghFh2/YpIvq1eD5QOurIwVen5R5SGSDq/vGBWDeMu2OQS/E5/MIDUv94te0/+ZuD04GlLGqC+8vqyVt/PZLwHF4h7t/Pa6YnbUANKKiz7sYfgqk/lXvdL/YMDdTVFR68A53vOYlHZ2rJK+ryXKPmn0HXfKbOKbuBJ6OTeYYegjvvYzs95HdhqQm4Br1ADAXwHhY74AnzmgrJot1yvqNutxjZlse41yrIHcExJ+MjhuPbNZ85pauFbS8gqAsRpk++8zAnNytkqFIemgwcNKl0TGRNsGnmTghr7LRzFEh+C0dXQqV3SwW8Vrq3hsouS4F4o0sJp+B59ewAPlkedvPWhONNXyc6nnCENTZ+5kC+LWG36FxXm7BAPgX6BKas2lE0hviHeW3lLY+R89zoZrlIZgT/XBEpsLPooyDCbClJ0KmLXX1zue1wj7iSVO7bqI4qT3+eljow4AlW4irYY7mgVftzZHwajx/WUCZWZAGbm60PSNiQQVdggpg+Pch+8d8vg9WjcFgDAbyE4QjSYJzRaOyxJ0aMMtEnEGvyoTAbZ7HLMQCB2737pumMjOi2udQZVBeTqpa03vUOGGH4zR17ofko9NgHlHLisHtrPnc23TWI3KAnVuIxkZa6wKkI0Om3DxBdebeOgvrzkdXhhI02HtmTr3vUR6P8uz41vaOfTTK/zMupYsVzWfZc04GvhH8tYPiKF/byg0v3l+timtLQDpVj7aAb0wBlAXCRKmIk8SrjGenP4HEQxNCLgJ5dEv3Y1cmjg4pOrjA/uk6Y7V+Dtm9tD7LEatmOW1cXKJlDYNgVhuC2YNJHKVs0dTa5Nkb888hBwV8QV2JS62+rMHxoBmK6UvGChD3G21D2d16AffsnDkXoh61/GCbg9brrwdlbg/gPFz1pO5+CPvEBtxpmZHiZfy/ajllo9KMPDZU1pg+gLaHd4WIb/EEf6VgDcCbV1ocEefZ1bq5Ez55H1sb0DrJcL5j6wM0xqVGww0vs2u9lUJrx52qFRJ33cP9wEwzjMvQbKe6NTusRd0YwpVXbf5pOa8sS2L35PVMoTF91p7aP4QUph9/oAL0xGGxenBGogsWN5PhgYi7QYBQCSbRmJxaN+JcJMQaWGlo1xa//+w8/MpqdicqfZ+zU9NcKbcSLwohXQPHTC+538p7jXefij35zEvSn3sH7jQEzKo6oWKzdo9CmzC4ye0K7vKq8dp88JPTgn0fr7xrlmL5EybV69RfR9QQbOR8jCfPeRD2mNND4nFHLb+BVteBC3JQhr7rija/wNgkmvDpEak4HYxUowAHIraWRuvwXdisxrWP7brE5WpJnvReILN/c0Q9iDHNb4gcIGFolJmajofciJsVpu2zzAJSfoxQqQ11RNpVJwJCWINdIGTZYd4K+knyVxvivMDTSFP0KDMBfxJak87ELJNCI5As9G4AWjXVyCr384bH235pqUt8+QhKThirZiuCeM3s58MFBlYL+SACXOXbD6xkYYCoC8CW6wV0j5qSI151u5KZP2d8YTr0J1dCfzsHPZM72l7UENVB/3wUnXRNS7d8vgfm015cxl3Mu5fAt+waDcSzDej5UYM26mn4p3Yl6VbvhSY9w6CoJS707O56AnZaV2DxBYM4nz4aR2nnz7r5wzXWnZwKe5NVg8+4J4ahcNCWXH8UAPiVqEMzjzp5Tr/KA17ockU2exqC1tKmAYG11bNH5g4DwqzFB2RZt1CmDVijhPSA+iyVqy7cX2tdbms40G6e6M/NZs9kgWH9JejRe6BpDd7xT5GDqHxyYkYdE+77oDHkdlojrZQTmguBSOgu1w47wdCpF+UJ5ExKNdV8tZedy4zSudmTVXSyJxwvxOlbNjxUw8i6APcu6m07enFEQUyCrryNI1zGhblWCexkVqH8NCl5feJq421JVhIwSlzQ2NhyHJA2fiRluZXLmF3lsFA2Vi4NmuiBVx48lQc5zyXyVnDOdmheJr6Xe0RDqal8xWk+FG96U+clXdC2ojkgTQB9NVmHgLqCP9Ez4jZ76C0zQLPqFPJa9vxNU6LUeTezaQuqJugNsAevsbhY0oJwfOXE2pGDvpwC3SEzzhlwfq9bLRhW8ulNi6qkpvbP/zuyJYede7uW8jA/mVWfpNrAgsi/WJzX7zUvZQj7ewJymojyr+mrL4U33BKFFX/TZ4kL+SJRt46WSqYTQVyQWaeT5KC3R/PSgG404oFLc04G9E0z2sdJFm1ivnJiklxvqMne97tXViIhVdVPLFun/ufK8q6lbpgqq6QxCDQau0JHIKpNaWleOox/n2zFWVhMBZdDjVSi7EugnLFPgtFE4JENXLYmP6iWnxYbO/8OGuzEzlfMJe1BE35S2qvLKXQ8YK60qhlmYLVz/gUgZGWjw9AHFYzMlJxoy2nRpbmzUjUOGp+pV+Beo+2+I/0DE3Zp+zus801D29vKgGbO/kFl+elzsHzhb7ISZHNDHPiyp9bZaFEltODU0P2VS/3WHxUAxcpJ0V9WTaCuJCmK3iTCsXa3ATiLAiBjnFWH4q+2H75VAw3ttVLcf8Cab8WfpSd1OLbvUYRd8Uruu4q7U5TFx44X+4CxHndbkRrAGhsBuQsHcB69gHp5IgHOrlBm9XQ/o/pLybG0w5mh6HcC8T17gtz9RTkKrbulq5cZXMym/t9h1MK1yrVt0YfHnBv/OKviEnHGbbgttSM3Z2iEmUWjUaIREyfapydN/zdGSXgFu4G3JFB4Soo2I16uWfRUiXDb/ytArgMex98U8303PaJsi/0YJ+xo0e787WGfKa67PNCzvEMTSeCwrOy9p0p3wjG0hnHrJk1zT7KEYvAYligsZau39+90t2BYNX8JRygbD9fU7cdjwIVT352hAxp4ImYCHcx8GXe0vZnNRpsBa1Tp1Md1JJdC3DQvrfqZ1bn93eF6v3SEi+5JCmJXSQsY1dk5/yd/TA8+vr+XnPVOaMH71qUAa9D3RR5Yyog0QdsgCjgC3otZegxElnG94i3ExanJ4XV5+SbGgzyWG2Us7SEuYFn751h8wbcKlbd5aAlK7lC96UdrV+9LPadStHD4t/0CS4vA0ny/3oAA9FQuYVfC73//DcVof4fWEV6SPBgymcRUqIK8Omp7qK4xMClIpT0Ta12Ia5PfFctIKFwEQh1fxs0FzCLxAH+eOaEe9WONuvl3HY7dFnhZbEuMkAVgtRoluqjcZQKwHCPyeprOeso1Jr/fYNq54MMAI/nxy50cJk6lWKUbleHA2PJMzC662nGvgVr1kmNfbG0Ws65TT+ezp9r6AN+wuPFGKYr5mV26Uk0AQ/Cw4C0cyYTp3OrHpBeAyN0cPgovJpvnz5A42Yr4aP82a+DNhuSmGKkNL090BrpfkimKVJ1vJEPCo4J9Qqas2iD5qCcepYICF7S/gCS1S8QHrXwP+ec3IsbwWJHPgijLEICWSrXKMmAaDvTBTB+bSZvILomMw9651EPaB8Q/HkKQ+01hbaTTY/UgDgXWykCb45gJJv2G+UblcJQEAAJyAUhHz+VUs2Rs9JGCdzwJhx7o6bniHi4s0j7IwEiYwUfG+6yDfYDOnuxEYnGoDg2bvsFcoHD8yTrdw4be26LcQb+9781ArENxmH/LoFDX1jYXwAemKRgjjBbrnb8CIIwbH4AEN6mpIYxGXUPiCw76J2Pjdjesy0vVvDEDzawt8f4SHdWzPq2j+5/F7Ks4ktxD8iPu8+Dl2Ks6xOK7wIYe+ADrwjLF4OLxr0bezJ/5fvf16noZdATScFVkjLHXHbCIFZz4PWjTwW19DI2V9zkELSJUZ9LS+yOUu+Ngxhn8tYxMRkl2a2az8j/vYcb1Mqwu89TRx3gsEoUwUrMTjA60GjbvDQjYdGQr4UrgnJA0/Raw4BxtKKIbE1f/rcDgAAUQIpsp/yQudXYqdgDdhjpkjXNaH0hzXli6EhQYAlFinoxrJAhVNGNXdjPD8H6S+XSeybihvIsWYvN0ySxyIK6iwLsqYMzT0i3REbaLN72/DfOkp3YT/PBu4D6f1H0PGFlwALEQTRHqCCP7lRNq+zY3/eEt6CYYfMgk8tNcVc3ojea+ErO56kRa9mNd96HCwmO5i5/K1wrIK1KbOhjpYkicgTN3iZdI5SR7+VhqA5p3dH0aPO2UO8Uqxt+HqNLTFIGkZbVISFKfWwUt9jpAmLbhV/4PDDYCvvWUromPQutry1MynbII6A9ZuAePNMD/Lmpg8sKe+Q13BpIbDKr3RNlu7LDQIiCnFlpvINIjSqbTfw+pfjpq4d0Ufr2cCa22MQoWvLh0eXUbORcdjr4gnfb7hibrcNFfkNdE2OYUFdIoZvqhC49ITRHkprzvwkWqOwFCEmBzfCwb14Gf0pjAlcnDjPRk12oTQrVtP4gTIO0ACyjV+PV9MycPlcrvrswdwsYs7RCrdMR9kqNALlZmHibLKdXGMwh1DWqM7G+l8hvxeitJH1VGJkVmcSKuGGkmCOfvPh8iwUj0MtxqmrRClJE0g0rJgQ5Tez8H92odeZ1jfkD9EPcKCpPMRl9yDNRSCDLbF64WQPR3I3+rPbA88rvkj7Y1G+6ZPCYKG8dPYpNZM/kkvGZE9tZYvePs9Lt11XjsFrOQk9Wf8c9LGpACBc1be7mjwlvTw5FyVDd7TN+f5fVt+JwXWRwoPqMFCGFD1+hNp1rs/jpy6r+ohW78fq52kUJdReKjaF2M7i69Q4cYTbbeMmgGjbcqycjy/z9V3O4XV33JAtpKzP1PkAgYnRMFylkP28kJ9GUuF6zJa2lQCcBHYKrYWjTxbnQsNzGDbem1WuDT5r7jlv9kpNxXpN0KsUX5qtAtvv13RNr1Q6lcad/XZAkFp37LVkrckLi0cWHbNMwUI8G+v1ED0JI8MbG0uBEySCR4QE8EZa31pvzQ5+C0z5K0/RfX2t1JfKjjHtkAJNNvWwFcdujMZYinVG8FdCpTayU8jz5BC4jun68rGSws9cxyYcFpE3NfAWidfV8tFhaSbOjCte3+5vdK39zKGyITSl2Pxns8Yy9sCuUFT20OF3KqX/+hOCtPLJ4Qf/GKvSxbagzABbXW1yduZvzZaPTnWOwuif1ZA+38MZVQaf1Ibb8W7auCnZuNZKNn2ELCXYUS+Kxj17bnQF7QNDQiAzOdLF0SZWOjdkRJkMzE+UshVYXnX5LeAFwKIr7daGiSbeIDI6RfzB/jLLUKYH5uKA8WuT2EQv7QozC6OHrCf9cSD2ORsPMsUzrrpuMsae5QvQZ3fnCJvXW1kUz68+dwF6O6YBuMC6ypSOPlGF4oYMoW38VZIu3x/QZRS9LnTyntruCKA2wfJ1K+87+rZGW9ZA8/0HfYSEZ9JzCPuzHhtrvaTWXSfr+04NtrJRheuDM1F4l7wam3i3LHai/A3muBUBNviM1wxazoslJQ2KBuFHRxWKUYuFrviKoM04NTK4KLl18E79eMQZRXqRCEdErCF03KD22A9YMQjl2zdzTyDY289jW/gi8K1QHWt2/FSygRBzrnzwUvmZnByKuxFb2Udcme4NLDdjx7QaQV3uzRdr4++RJrzhPYuH20Kb4vkz3CGPgatmcg9J/QV5LV5ZbJebGoddiokDZD7vY2O7Mo+NwQTqGdAZu0bIJVcZmhU6Hb1zJ2GZjIP6wh9QuuvZ9RFpgyHKDufFYtNAqH+GvM/T1roUUye6Nsqw788yV8pM8/zJCkFgRn5h09ncOSuDleznudbvvTgt0AYIKpGbkf642XKXhzHvZigXQI21HCMq6TVfYV1VfiCcsewPh1zdXkqHy+nDkhqFkReOwlqxD5ibCoJEm5R1m0d+8cQI1cFlJYGSsGwTm8OYahPNJv9O3Tsl4kbQjMxo/OASz8LxfxtWdFSUM8DhXJ8/FRuaNL6+bYwnJKz3fbu8ryC2AJEOnAZM6FtGAvpf1pLnqFYR7urD2u+l2NEq5z2SgQoaq0i4VAK9NXoWpeLg4sUDqDioXEiuHhG6LqHkDXsbLvPvt0BO3FuGWz3gSje4dokFaEqY9ogs+6YPtP8k9NBCyK4ZQDDSnxhN0D0JMAHu50u7B5D7XTE9QTpsBj77a8tRoMljzArMqJ2Bqif35LMfYB8pMB2VNeAnHsNodl65w2jlMuRe1pnBhdUKfA3aDmpFBGKPz03ykIXDsO2nSBehKe0Z5w1Fywg1FgXeO06qar5TWZqcyUuC+kpaHMBr4kxk+sms/TQtD5rb8VKvx6hiNqDZVqx8J7+wtLI7NcLStGTj82sKyHn7FovUsPtIKppPSezPAukc3pgcRv4Oa0EzxCPS2Sz+AVDAMZktlt5PjSOK4OdwvsZXKboe1VzrxrikMVxITXynxvCatqpOT+1hG3fDH+ptcRBaY+oVwasZb8qkuLYeRpfO+dsAiF4ap1vKazdbvmE+l+ySe423+GCb1Q7ssHeNmKshv9qOzT/97e8gLsjLAdQlRu5Uq+ywwE6jfDGDJaQ6e/bzAtBBPiY4o4w1PxTFWcAWKtoe1/AOqvYM80qaf56Hifdw2T2wHeyDJSXwzbKdPWOhXImB4XLy1dsK0rivCEP3jZDSdQx2S0R4w4XJgdp9DMfe3rFqr8UhDP9CoBoo6EAC/5TBnFx7pl8Ifa/S9YTcco6AYGx0TekGAxteGCNP8LMv6EWzYK2aCPvMYfBeAj3z1x6OAdeUWrbdP32j2Kx+xmn961huFkd4sifwCfEVu9idsU1I+Nd5av3ehiTrl6hbmWjKmPlROLfzaIYKfygZrWIIFpXMUxSNUIbLAUtfu4WyfxWXUeWvzvY9wg/evpJYYVfCw9++S8EszjvFfJYjWBf8Ff3l7VRmh5e4pvF6Q3n65QAwGks7fhILknN+CJFHhVWNmZB5Rngm1rrRXrhcUY3jUenlP6K6pVe0BnpFxRM1Ks01gVm91omagU30gp1+Ms4uwRkwk73UuDiPcYe0Xs/ieGNF2QsOp0lwF2yuOai2jla0iNRxRMJoUFEcfCWlUVBzMlfXKOodq9cDntEAbPQ1qUPFKWMdvVgrAKuLwFoy2xqilm3dNVICkJuUtywX6Z4+vs9Pb1hYGdRctXDCQMa83ydKj2SSNiROdR2x7Ju6Pe/DqHxaOdiDAqEMBnoykujL7V3lGZNhl2tyj9Gcpw3hbUJDaZmlY8lckqRjY4NhV5KvEOet1HqBz+GSj0WvklktIFwsYfx4zWbTMIru86LjycutEVYgN8ULbrAP1V+IxvC/u40LoCZgIYMokJiNKTKBLFXAMkZAWPxwVKc1LPmUUo9pYdrplDvMxeHPnZPigG8rjkkdJo6VP382BAX+vnq5g3YuKj3R0+UMdlh9RsFHkko5y8ciHw0HtXEfDvFmM7VtYaYdoMlJSgqwUdavy9ok0bmr+FMvEm32IdX715iUj4wfMjbQfDbhoJI+OQM97lJmFTrpdLjLVa2bfJwfiM8EWzGJ1Kw8d5DwtM9wXzhNCOFJsch25FtjO0hxwK/5hNs15nHpx4Bf98q+NN3wnciUtTlw4kJ124b3DQ+XjI3rZlxZL70GupDdiTIveIHF8RaTOiNPdqEA5esrDtDLXGGnsC57LK8bn+ZNpyoTFGF3Favzc1JdUA\x3d',
        '_ifr_': 'false',
        '_isfl_': 'false'
    });
    var gsodar = document.createElement('script');
    gsodar.type = 'text/javascript';
    gsodar.async = true;
    gsodar.src = '//ep2.adtrafficquality.google/sodar/VFc2VJAc.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gsodar, s);
})();
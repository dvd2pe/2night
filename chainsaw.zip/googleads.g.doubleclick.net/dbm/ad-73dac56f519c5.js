if (!window.mraid) {
    document.write('\x3cdiv id="ad_unit"\x3e');
}
document.write('\x3cdiv class="GoogleActiveViewElement" ' + 'id="DfaVisibilityIdentifier_3868148515"\x3e');
document.write('\x3cdiv class="GoogleCreativeContainerClass" ' + 'id="gcc_BOcCa-_xHqKztfAPwpfhyAU"\x3e');
(function() {
    var m = document.createElement('meta');
    m.setAttribute('data-jc', '82');
    m.setAttribute('data-jc-version', 'r20261118');
    var ss = document.getElementsByTagName('script')[0];
    if (ss && ss.parentNode) {
        ss.parentNode.insertBefore(m, ss);
    }
})();
(function() { /*  Copyright The Closure Library Authors. SPDX-License-Identifier: Apache-2.0 */
    var h = this || self;

    function l(a, d, b) {
        if (a)
            for (var c = 0; a != null && c < 500 && !b(a); ++c) a = d(a)
    }

    function m(a, d) {
        l(a, function(b) {
            try {
                return b === b.parent ? null : b.parent
            } catch (c) {}
            return null
        }, d)
    }

    function n(a, d) {
        if (a.tagName == "IFRAME") d(a);
        else {
            a = a.querySelectorAll("IFRAME");
            for (var b = 0; b < a.length && !d(a[b]); ++b);
        }
    }

    function p(a) {
        return (a = a.ownerDocument) && (a.parentWindow || a.defaultView) || null
    }

    function q(a, d, b) {
        try {
            var c = JSON.parse(b.data)
        } catch (f) {}
        if (typeof c === "object" && c && c.type === "creativeLoad") {
            var g = p(a);
            if (b.source && g) {
                var e;
                m(b.source, function(f) {
                    try {
                        if (f.parent === g) return e = f, !0
                    } catch (k) {}
                });
                e && n(a, function(f) {
                    if (f.contentWindow === e) return d(c), !0
                })
            }
        }
    }

    function r(a) {
        return typeof a === "string" ? document.getElementById(a) : a
    };
    var t;
    t = t === void 0 ? window : t;
    t.clsn = function(a, d) {
        var b = r(a);
        if (b)
            if (b.onCreativeLoad) b.onCreativeLoad(d);
            else {
                var c = d ? [d] : [],
                    g = function(e) {
                        for (var f = 0; f < c.length; ++f) try {
                            c[f](1, e)
                        } catch (k) {}
                        c = {
                            push: function(k) {
                                k(1, e)
                            }
                        }
                    };
                b.onCreativeLoad = function(e) {
                    c.push(e)
                };
                b.setAttribute("data-creative-load-listener", "");
                b.addEventListener("creativeLoad", function(e) {
                    g(e.detail)
                });
                h.addEventListener("message", function(e) {
                    q(b, g, e)
                })
            }
    };
}).call(this);
clsn("gcc_BOcCa-_xHqKztfAPwpfhyAU");
document.write('\x3ca target\x3d\x22_blank\x22 id\x3d\x22img_anch_CO-DsszQm5gDFaJZDQgdwksYWQ\x22 href\x3d\x22https://adclick.g.doubleclick.net/pcs/click?xai\x3dAKAOjsuurMnmfp17XPfKebt4R5UHH78WkJjrYf3c0u30ONSS7qCrk-PNXpO-ljZ87xqVosL0N4RpO1r8zKgGPxO_6cQRJ8nAXikrD1lv2Tm9oB4WOiKP-UFjNM8JxDbR21oGy2pWeyJMdS_a0pueSvX3Jovd7ycXZLpE6Mkb0GYAHqww6TgA-L77nbyh9zLQzVAZ9k9N0u66heKtFK3cZJ8JTnqpZFCc2LxMymoCv0A97zynaSrR6fUXk7CmUK1sg2DWvMto70iv-9YP4PW1N79CoW_fpFVwr8UkY_RhmSZi4hZWyz3Q-D17PVSvkrztZhV3Q4G6bKQX9uPSHdRCKrnkStWb6vcFUFJ2I6nCx5bpfBwDqL3jc9DlTMzfyC5By8RgL9lAEV18jKQkFNN2I_hhfy-1zGLfDm5nrSNHeCLuwDTR03jTb2pVO-X88GlREhf0G5wjhNPBndP7DI8tq7dQqOkYZme5yVpILVwyOXqjOx-5VGhedf3StafOsPNmplrklVH-YDjB6hErkuAHMORuXsZlsT4Gi7-wztSVOZkU3NKH8z7jiyBFudFU3O-sDippaLznZnfU37aEeitv1uy5nc53vISxArlqzdGkH5LFCHcu-u6pg36xpUucJbXLCzLbDmVoas4XwD7PGy0a0e8n5kZpmqEWVWiSXah9divN8kzGfUwP91fLHdDWvful7idyGda1PBRTjkQGfzlhO-i04G5gEAuvk8uu2DPYE2_fovZHUimqT955Jfv74YMTwt0PYQVl1nNQ1ewMAzO79GTX26-6J9Nk6Q_8eiuHRFEpn6rEBaLF3_5z5IIJ-1pXqA0m-P762Fiw3y-mcmr7dXMuZw08DxTVFZuHuVj4Z-eqHHZx4pfCTTT2XOrrK0mcIPhWX6ZUAWXJL3fINBPtdDNWh6WvMru8dU1mzwFmsVAjMmtnEtAEBqQdD0Xo9HqsBMSYLKU049Gmf-4dEaxLtVXFLYYtsv_C8rbUmoVi2xWkzvbZOqqNOjhktv8bpK_m8j4Pk-BiBQPAVt-4kP-VlnJuGYEPm-41IL4Mm9pKN2hLraUiKN5YwETMe4na_Qg1V5GME0CA3Yox0ptXnnMzMONLn8-cAl8REFR1Hy_JBvU7U4ZBPJulNm1M0EPn_mUhqyyLLOXfTwvmKRdLMRvJzkoiPd6KMOL3hwJE1pZ80Lm_oZ1CMgzNDJtkcuTerwSDzPufjhE526ImXMP0JjSQPfv0p-EtpgJvFsyWkkRHzjermz6eDJu-qQ6vQc3ABy2qfjA_5rQfDc5TrRG7A2ok1iHR182pRnDvxkoOa147c3ITkFOeiwiF-ngWEmcMCIUELFwVMli6eMLiaM9QQiAwAiR37pt6fOy5t3d3F5tknjjMMIK606lv3i6NST5RLk4_HntvOD8-N1Btar304mOs7hxOowYDQTRQI8CUQEWTBHzELKN5bK82bSFG7PNCSYpUY4uJQRoIj61ht3P8TKXzYs5fEB33fXHyWdCCdvjI4k6EmbBaNDtHWutwNmSd_5k449sGDMAqKJzkNOCNuBIu3X_fBZv20E5eZ2vMW1lo-02WwH2EJ5vQo05UG5o4I4eJWQ2Qiit4dQOZShVSWdS8ZRQ7OSs41-_VuaRc4hzDfu7bfKmtgb1X76RitU7A_2u3buROsKRNkoQO-xtW2lxUehApo1InlGRWaP3XAK7tVePomTj88tiSBPOyLc5HrAXSws0sDXauUQYIOSwcUoJml7zfJS_xnOQSZB4b2n1s6Nro8FweszVSgL4eF--bmpyLByCeWGNH8WE4UNPUbhzm8EloC_61AmB0zVh8lZ1TRwbkrg\x26amp;sai\x3dAMfl-YTPEEtJAY637eRKDz1S1opYAfKKzrJmkf-D5Vm6_hAG_U60nNy-rMV_7KQmMX9lDEzCLwczaBiiIsVj0Y5ojvMkIFDPkXNWDlnSIO4W9PlkwOaA7yRHUTfy2Ru-EODZLOT2TX-Lf83ClSEvZgsB2IzKQDoduwECJGp_lpm_JX_at7WlXTAS2shN-o8cG5UYsqkVuYLLhlEV9doIM0isZ5-kTnOheq1C-A0CeN1bLxZd2r_Y7zlqB1XbPCglWIh8dGeae4T5HQbFhbMJIJHxTbPmB0u8NTMy6lY04JAI8zctY2EnGqCxJu6ExAMTFuzfr3RWV3tE0nRC0dEXs8cIy6qnKmEhFT3lTmFwsnkdcPP8RdZmw2UihwWnuMLLPdPtL3IBVADT_d_E2oJrHN3MXh_YtgSYTiCBjd5IIZ4xoQrVOwmzGeRl9U8VvUKdwbeNAcOA7pclokkXNfojZrE4Od7ngNYXJQoOIQqHyu5MD-woQKDkvExmUvuQ_YDiYtDPHNfCXm490wwBx-dL2vUnGstJUXJWfh_iIuR02UE3EWF4vtS3NVkhM9X5QKJ-2J5suwB8eW5NoNbSjft-ndVIE0cdTEN3cy82cci-ti0a-Tey3wsWlv1eBaXSlkwT7bp9lTtiWO18Je1wrQAzVapKEUwal1KcLDM1XO-f\x26amp;sig\x3dCg0ArKJSzKN-boXh_1Bv\x26amp;pr\x3d13:awLnAAAAAAAB-LULImTcMtWzd_xMVO1jwNNwHg\x26amp;fbs_aeid\x3d%5Bgw_fbsaeid%5D\x26amp;urlfix\x3d1\x26amp;adurl\x3dhttps://asklocala.com/it%3Futm_source%3Dreferral%26utm_medium%3Dpaid%26utm_campaign%3Dadaptive-advertising-launch-2026%26utm_term%3D%26utm_content%3Dwpp-banner\x22\x3e\x3cimg src\x3d\x22https://s0.2mdn.net/simgad/15293361278206779308\x22 alt\x3d\x22Advertisement\x22 border\x3d\x220\x22 width\x3d\x22320\x22 height\x3d\x2250\x22 style\x3d\x22display:block\x22\x3e\x3c/a\x3e\x3cscript data-jc\x3d\x2274\x22 data-jc-version\x3d\x22r20261118\x22 data-jcp-a-id\x3d\x22img_anch_CO-DsszQm5gDFaJZDQgdwksYWQ\x22 data-jcp-cc-overlay\x3d\x22\x22 data-jcp-cc-button\x3d\x22\x22 data-jcp-is-fledge\x3d\x22false\x22 data-jcp-turtlex-event-ad-signals\x3d\x22\x22 data-jcp-turtlex-event-ad-metadata\x3d\x22\x22\x3e(function(){var aa\x3dtypeof Object.create\x3d\x3d\x22function\x22?Object.create:function(a){function b(){}b.prototype\x3da;return new b},ba\x3dtypeof Object.defineProperties\x3d\x3d\x22function\x22?Object.defineProperty:function(a,b,c){if(a\x3d\x3dArray.prototype||a\x3d\x3dObject.prototype)return a;a[b]\x3dc.value;return a}; function ca(a){a\x3d[\x22object\x22\x3d\x3dtypeof globalThis\x26\x26globalThis,a,\x22object\x22\x3d\x3dtypeof window\x26\x26window,\x22object\x22\x3d\x3dtypeof self\x26\x26self,\x22object\x22\x3d\x3dtypeof global\x26\x26global];for(var b\x3d0;b\x3ca.length;++b){var c\x3da[b];if(c\x26\x26c.Math\x3d\x3dMath)return c}throw Error(\x22Cannot find global object\x22);}var da\x3dca(this);function l(a,b){if(b)a:{var c\x3dda;a\x3da.split(\x22.\x22);for(var d\x3d0;d\x3ca.length-1;d++){var e\x3da[d];if(!(e in c))break a;c\x3dc[e]}a\x3da[a.length-1];d\x3dc[a];b\x3db(d);b!\x3dd\x26\x26b!\x3dnull\x26\x26ba(c,a,{configurable:!0,writable:!0,value:b})}}var r; if(typeof Object.setPrototypeOf\x3d\x3d\x22function\x22)r\x3dObject.setPrototypeOf;else{var t;a:{var ea\x3d{a:!0},u\x3d{};try{u.__proto__\x3dea;t\x3du.a;break a}catch(a){}t\x3d!1}r\x3dt?function(a,b){a.__proto__\x3db;if(a.__proto__!\x3d\x3db)throw new TypeError(a+\x22 is not extensible\x22);return a}:null}var v\x3dr; function w(a,b){a.prototype\x3daa(b.prototype);a.prototype.constructor\x3da;if(v)v(a,b);else for(var c in b)if(c!\x3d\x22prototype\x22)if(Object.defineProperties){var d\x3dObject.getOwnPropertyDescriptor(b,c);d\x26\x26Object.defineProperty(a,c,d)}else a[c]\x3db[c];a.B\x3db.prototype}l(\x22Number.isFinite\x22,function(a){return a?a:function(b){return typeof b!\x3d\x3d\x22number\x22?!1:!isNaN(b)\x26\x26b!\x3d\x3dInfinity\x26\x26b!\x3d\x3d-Infinity}});l(\x22Number.MAX_SAFE_INTEGER\x22,function(){return 9007199254740991});l(\x22Number.MIN_SAFE_INTEGER\x22,function(){return-9007199254740991}); l(\x22Number.isNaN\x22,function(a){return a?a:function(b){return typeof b\x3d\x3d\x3d\x22number\x22\x26\x26isNaN(b)}});/*  Copyright The Closure Library Authors. SPDX-License-Identifier: Apache-2.0 */ var x\x3dthis||self;function fa(a){x.setTimeout(function(){throw a;},0)};var y,z;a:{for(var ha\x3d[\x22CLOSURE_FLAGS\x22],A\x3dx,B\x3d0;B\x3cha.length;B++)if(A\x3dA[ha[B]],A\x3d\x3dnull){z\x3dnull;break a}z\x3dA}var ia\x3dz\x26\x26z[748402147];y\x3dia!\x3dnull?ia:!0;function ja(a,b){a.__closure__error__context__984382||(a.__closure__error__context__984382\x3d{});a.__closure__error__context__984382.severity\x3db};var ka\x3dvoid 0;function la(){var a\x3dError(\x22int32\x22);ja(a,\x22warning\x22);return a};var C\x3dtypeof Symbol\x3d\x3d\x3d\x22function\x22\x26\x26typeof Symbol()\x3d\x3d\x3d\x22symbol\x22;function D(a,b,c){return typeof Symbol\x3d\x3d\x3d\x22function\x22\x26\x26typeof Symbol()\x3d\x3d\x3d\x22symbol\x22?(c\x3d\x3d\x3dvoid 0?0:c)\x26\x26Symbol.for\x26\x26a?Symbol.for(a):a!\x3dnull?Symbol(a):Symbol():b}var na\x3dD(\x22jas\x22,void 0,!0),E\x3dD(void 0,\x220actk\x22),F\x3dD(\x22m_m\x22,\x22A\x22,!0);var oa\x3d{u:{value:0,configurable:!0,writable:!0,enumerable:!1}},pa\x3dObject.defineProperties,G\x3dC?na:\x22u\x22;function qa(a,b){C||G in a||pa(a,oa);a[G]|\x3db}function H(a,b){C||G in a||pa(a,oa);a[G]\x3db};var I\x3d{};function ra(a,b){return b\x3d\x3d\x3dvoid 0?a.i!\x3d\x3dJ\x26\x26!!(2\x26(a.h[G]|0)):!!(2\x26b)\x26\x26a.i!\x3d\x3dJ}var J\x3d{};var K\x3dtypeof x.BigInt\x3d\x3d\x3d\x22function\x22\x26\x26typeof x.BigInt(0)\x3d\x3d\x3d\x22bigint\x22;var sa\x3dNumber.MIN_SAFE_INTEGER.toString(),ta\x3dK?BigInt(Number.MIN_SAFE_INTEGER):void 0,ua\x3dNumber.MAX_SAFE_INTEGER.toString(),va\x3dK?BigInt(Number.MAX_SAFE_INTEGER):void 0;function wa(a,b){if(a.length\x3eb.length)return!1;if(a.length\x3cb.length||a\x3d\x3d\x3db)return!0;for(var c\x3d0;c\x3ca.length;c++){var d\x3da[c],e\x3db[c];if(d\x3ee)return!1;if(d\x3ce)return!0}};var xa\x3dNumber.isFinite;function ya(a){if(typeof a!\x3d\x3d\x22number\x22)throw la();if(!xa(a))throw la();return a|0};function za(a){return a};function L(a,b,c,d){var e\x3dd!\x3d\x3dvoid 0;d\x3d!!d;var g\x3d[],f\x3da.length,k\x3d4294967295,m\x3d!1,h\x3d!!(b\x2664),n\x3dh?b\x26128?0:-1:void 0;if(!(b\x261)){var p\x3df\x26\x26a[f-1];p!\x3dnull\x26\x26typeof p\x3d\x3d\x3d\x22object\x22\x26\x26p.constructor\x3d\x3d\x3dObject?(f--,k\x3df):p\x3dvoid 0;if(h\x26\x26!(b\x26128)\x26\x26!e){m\x3d!0;var q;k\x3d((q\x3dAa)!\x3dnull?q:za)(k-n,n,a,p,void 0)+n}}b\x3dvoid 0;for(e\x3d0;e\x3cf;e++)if(q\x3da[e],q!\x3dnull\x26\x26(q\x3dc(q,d))!\x3dnull)if(h\x26\x26e\x3e\x3dk){var La\x3de-n,ma\x3dvoid 0;((ma\x3db)!\x3dnull?ma:b\x3d{})[La]\x3dq}else g[e]\x3dq;if(p)for(var Q in p)a\x3dp[Q],a!\x3dnull\x26\x26(a\x3dc(a,d))!\x3dnull\x26\x26(f\x3d+Q,e\x3dvoid 0,h\x26\x26!Number.isNaN(f)\x26\x26 (e\x3df+n)\x3ck?g[e]\x3da:(f\x3dvoid 0,((f\x3db)!\x3dnull?f:b\x3d{})[Q]\x3da));b\x26\x26(m?g.push(b):g[k]\x3db);return g}function Ba(a){switch(typeof a){case \x22number\x22:return Number.isFinite(a)?a:\x22\x22+a;case \x22bigint\x22:return(K?a\x3e\x3dta\x26\x26a\x3c\x3dva:a[0]\x3d\x3d\x3d\x22-\x22?wa(a,sa):wa(a,ua))?Number(a):\x22\x22+a;case \x22boolean\x22:return a?1:0;case \x22object\x22:if(Array.isArray(a)){var b\x3da[G]|0;return a.length\x3d\x3d\x3d0\x26\x26b\x261?void 0:L(a,b,Ba)}if(a!\x3dnull\x26\x26a[F]\x3d\x3d\x3dI)return M(a);return}return a}var Aa;function M(a){a\x3da.h;return L(a,a[G]|0,Ba)};function N(a,b,c,d){d\x3dd\x3d\x3d\x3dvoid 0?0:d;if(a\x3d\x3dnull){var e\x3d32;c?(a\x3d[c],e|\x3d128):a\x3d[];b\x26\x26(e\x3de\x26-16760833|(b\x261023)\x3c\x3c14)}else{if(!Array.isArray(a))throw Error(\x22narr\x22);e\x3da[G]|0;if(y\x26\x261\x26e)throw Error(\x22rfarr\x22);2048\x26e\x26\x26!(2\x26e)\x26\x26Ca();if(e\x26256)throw Error(\x22farr\x22);if(e\x2664)return(e|d)!\x3d\x3de\x26\x26H(a,e|d),a;if(c\x26\x26(e|\x3d128,c!\x3d\x3da[0]))throw Error(\x22mid\x22);a:{c\x3da;e|\x3d64;var g\x3dc.length;if(g){var f\x3dg-1,k\x3dc[f];if(k!\x3dnull\x26\x26typeof k\x3d\x3d\x3d\x22object\x22\x26\x26k.constructor\x3d\x3d\x3dObject){b\x3de\x26128?0:-1;f-\x3db;if(f\x3e\x3d1024)throw Error(\x22pvtlmt\x22);for(var m in k)g\x3d +m,g\x3cf\x26\x26(c[g+b]\x3dk[m],delete k[m]);e\x3de\x26-16760833|(f\x261023)\x3c\x3c14;break a}}if(b){m\x3dMath.max(b,g-(e\x26128?0:-1));if(m\x3e1024)throw Error(\x22spvt\x22);e\x3de\x26-16760833|(m\x261023)\x3c\x3c14}}}H(a,e|64|d);return a}function Ca(){if(y)throw Error(\x22carr\x22);if(E!\x3dnull){var a;var b\x3d(a\x3dka)!\x3dnull?a:ka\x3d{};a\x3db[E]||0;a\x3e\x3d5||(b[E]\x3da+1,b\x3dError(),ja(b,\x22incident\x22),fa(b))}};function Da(a,b){if(typeof a!\x3d\x3d\x22object\x22)return a;if(Array.isArray(a)){var c\x3da[G]|0;a.length\x3d\x3d\x3d0\x26\x26c\x261?a\x3dvoid 0:c\x262||(!b||4096\x26c||16\x26c?a\x3dO(a,c,!1,b\x26\x26!(c\x2616)):(qa(a,34),c\x264\x26\x26Object.freeze(a)));return a}if(a!\x3dnull\x26\x26a[F]\x3d\x3d\x3dI){b\x3da.h;c\x3db[G]|0;if(!ra(a,c)){if(c\x262)var d\x3d!0;else c\x2632\x26\x26!(c\x264096)?(H(b,c|2),a.i\x3dJ,d\x3d!0):d\x3d!1;d?(a\x3dnew a.constructor(b),a.v\x3dJ):a\x3dO(b,c)}return a}}function O(a,b,c,d){d!\x3dnull||(d\x3d!!(34\x26b));a\x3dL(a,b,Da,d);d\x3d32;c\x26\x26(d|\x3d2);b\x3db\x2616769217|d;H(a,b);return a};function P(a,b,c){if(a.i\x3d\x3d\x3dJ){var d\x3da.h;d\x3dO(d,d[G]|0);qa(d,2048);a.h\x3dd;a.i\x3dvoid 0;a.v\x3dvoid 0;d\x3d!0}else d\x3d!1;if(!d\x26\x26ra(a,a.h[G]|0))throw Error();a\x3da.h;a:{var e\x3da[G]|0;d\x3db+-1;var g\x3da.length-1;if(g\x3e\x3d0\x26\x26d\x3e\x3dg){var f\x3da[g];if(f!\x3dnull\x26\x26typeof f\x3d\x3d\x3d\x22object\x22\x26\x26f.constructor\x3d\x3d\x3dObject){f[b]\x3dc;break a}}d\x3c\x3dg?a[d]\x3dc:c!\x3d\x3dvoid 0\x26\x26(e\x3d(e!\x3dnull?e:a[G]|0)\x3e\x3e14\x261023||536870912,b\x3e\x3de?c!\x3dnull\x26\x26(d\x3d{},a[e+-1]\x3d(d[b]\x3dc,d)):a[d]\x3dc)}}function R(a,b,c){if(c!\x3dnull\x26\x26typeof c!\x3d\x3d\x22string\x22)throw Error();P(a,b,c)};function S(a,b,c){this.h\x3dN(a,b,c,2048)}S.prototype.toJSON\x3dfunction(){return M(this)};S.prototype[F]\x3dI;S.prototype.toString\x3dfunction(){return this.h.toString()};function Ea(a){this.h\x3dN(a,void 0,void 0,2048)}w(Ea,S);function Fa(a){this.h\x3dN(a,void 0,void 0,2048)}w(Fa,S);function Ga(){var a\x3dx;return a\x3da\x3d\x3d\x3dvoid 0?window:a};/*  Copyright Google LLC SPDX-License-Identifier: Apache-2.0 */ var Ha\x3d/^\\s*(?!javascript:)(?:[\\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i;var T;function Ia(a,b,c,d){var e\x3d/^(https?:[^:?]+[/]pcs[/]click[^/]+?)(?:\x26nx[^\x26]+\x26ny[^\x26]+\x26dim[^\x26]+)?(\x26adurl\x3d.*)/.exec(a);return e?e[1]+(\x22\x26nx\x3d\x22+b+\x22\x26ny\x3d\x22+c+\x22\x26dim\x3d\x22+d)+e[2]:a}function Ja(a){var b\x3da.currentTarget,c\x3db.querySelector(\x22img[alt]\x22);c\x26\x26(a\x3dU(a,c.offsetLeft,c.offsetTop,c.width,c.height),a\x3dIa(b.href,a.l,a.m,a.j),Ha.test(a)\x26\x26(b.href\x3da))}function Ka(a,b){var c,d;(c\x3dGa())\x3d\x3dnull||(d\x3dc.fence)\x3d\x3dnull||d.setReportEventDataForAutomaticBeacons({eventType:a,eventData:b,destination:[\x22buyer\x22],once:!0})} function Ma(a,b){var c,d;(c\x3dGa())\x3d\x3dnull||(d\x3dc.fence)\x3d\x3dnull||d.reportEvent({eventType:\x22click\x22,eventData:a,destination:[b]})}function V(a,b){var c\x3dnew Fa;R(c,1,a);a\x3dJSON.stringify(M(T));R(c,4,a);R(c,10,Date.now().toString());Ka(\x22reserved.top_navigation\x22,JSON.stringify(M(c)));Ka(\x22reserved.top_navigation_start\x22,JSON.stringify(M(c)));Ma(JSON.stringify(M(c)),\x22buyer\x22);Ma(b,\x22component-seller\x22)}function U(a,b,c,d,e){return{l:+Math.round(a.clientX-b),m:+Math.round(a.clientY-c),j:+d+\x22x\x22+ +e,o:void 0}};var W,X\x3ddocument.currentScript;W\x3d(X\x3dX\x3d\x3d\x3dvoid 0?null:X)\x26\x26X.getAttribute(\x22data-jc\x22)\x3d\x3d\x3d\x2274\x22?X:document.querySelector(\x27[data-jc\x3d\x2274\x22]\x27);if(W\x3d\x3dnull)throw Error(\x22JSC not found 74\x22);for(var Na\x3d{},Y\x3dW.attributes,Z\x3dY.length-1;Z\x3e\x3d0;Z--){var Oa\x3dY[Z].name;Oa.indexOf(\x22data-jcp-\x22)\x3d\x3d\x3d0\x26\x26(Na[Oa.substring(9)]\x3dY[Z].value)} (function(a){var b\x3ddocument.getElementById(a[\x22a-id\x22]),c\x3da[\x22cc-overlay\x22],d\x3da[\x22cc-button\x22],e\x3dc?document.getElementById(c):null,g\x3dd?document.getElementById(d):null;c\x3da[\x22is-fledge\x22]\x3d\x3d\x3d\x22true\x22;d\x3de\x26\x26g;T\x3dnew Ea;if(c){var f\x3dd?e:b.querySelector(\x22img[alt]\x22);(d?e:b).addEventListener(\x22mousedown\x22,function(h){var n\x3dU(h,f.offsetLeft,f.offsetTop,f.clientWidth,f.clientHeight);h\x3dn.l;var p\x3dn.m,q\x3dn.j;n\x3dn.o;h\x26\x26P(T,2,h\x3d\x3dnull?h:ya(h));p\x26\x26P(T,3,p\x3d\x3dnull?p:ya(p));q\x26\x26R(T,7,q);n\x26\x26R(T,4,n)});var k\x3da[\x22turtlex-event-ad-signals\x22], m\x3da[\x22turtlex-event-ad-metadata\x22];g?(g.addEventListener(\x22click\x22,function(){V(k,m)}),g.addEventListener(\x22auxclick\x22,function(){V(k,m)})):(b.addEventListener(\x22click\x22,function(){V(k,m)}),b.addEventListener(\x22auxclick\x22,function(){V(k,m)}))}else b.addEventListener(\x22mousedown\x22,Ja),d\x26\x26e.addEventListener(\x22mousedown\x22,function(h){h\x3dU(h,e.offsetLeft,e.offsetTop,e.clientWidth,e.clientHeight);h\x3dIa(g.href,h.l,h.m,h.j);Ha.test(h)\x26\x26(g.href\x3dh)})})(Na);}).call(this);\x3c/script\x3e');
document.write('\x3c/div\x3e');
document.write('\x3c/div\x3e');
document.write('\x3cstyle\x3ediv{margin:0;padding:0;}.abgcp{height:15px;padding-right:1px;padding-top:1px;padding-left:9px;padding-bottom:9px;right:0px;top:0px;position:absolute;width:31px;z-index:2147483646;}.abgc{display:block;height:15px;position:absolute;right:1px;top:1px;text-rendering:geometricPrecision;z-index:2147483646;}.abgb{display:inline-block;height:15px;}.abgc,.abgcp,.jar .abgc,.jar .abgcp,.jar .cbb{opacity:1;}.abgc{cursor:pointer;}.cbb{cursor:pointer;height:15px;width:15px;z-index:2147483646;background-color:#ffffff;opacity:0;}.cbb svg{position:absolute;top:0;right:0;height:15px;width:15px;stroke:;fill:#00aecd;stroke-width:1.25;}.abgb{position:absolute;right:16px;top:0px;}.cbb{position:absolute;right:0px;top:0px;}.abgs{display:none;height:100%;}.abgl{text-decoration:none;}.abgs svg,.abgb svg{display:inline-block;height:15px;width:auto;vertical-align:top;}.abgc .il-wrap{background-color:#ffffff;height:15px;white-space:nowrap;}.abgc .il-wrap.exp{border-bottom-left-radius:5px;}.abgc .il-text,.abgc .il-icon{display:inline-block;}.abgc .il-text{padding-right:1px;padding-left:5px;height:15px;width:55px;}.abgc .il-icon{height:15px;width:15px;}.abgc .il-text svg{fill:#000000;}.abgc .il-icon svg{fill:#00aecd}\x3c/style\x3e\x3cdiv id\x3d\x22abgcp\x22 class\x3d\x22abgcp\x22\x3e\x3cdiv id\x3d\x22abgc\x22 class\x3d\x22abgc\x22 dir\x3d\x22ltr\x22\x3e\x3cdiv id\x3d\x22abgb\x22 class\x3d\x22abgb\x22\x3e\x3cdiv class\x3d\x22il-wrap\x22\x3e\x3cdiv class\x3d\x22il-icon\x22\x3e\x3csvg xmlns\x3d\x22http://www.w3.org/2000/svg\x22 viewBox\x3d\x220 0 15 15\x22\x3e\x3cpath fill\x3d\x22#fff\x22 d\x3d\x22M0 0h15v15H0z\x22/\x3e\x3ccircle cx\x3d\x226\x22 cy\x3d\x226\x22 r\x3d\x22.67\x22/\x3e\x3cpath d\x3d\x22M4.2 11.3q-.9.5-.9-.55V4.1q0-1 1-.6L10.4 7q1.6.5 0 1l-3.75 2V7.75a.65.65 0 1 0-1.3 0v3a.9.9 0 0 0 1.3.8L12.7 8.2q1-.7 0-1.5L3.3 1.6q-1.1-.3-1.5.9v10q.4 1.4 1.5.8l1.5-.8a.3.3 0 1 0-.6-1.2\x22/\x3e\x3c/svg\x3e\x3c/div\x3e\x3c/div\x3e\x3c/div\x3e\x3cdiv id\x3d\x22abgs\x22 class\x3d\x22abgs\x22\x3e\x3ca id\x3d\x22abgl\x22 class\x3d\x22abgl\x22 href\x3d\x22https://adssettings.google.com/whythisad?source\x3ddisplay\x26amp;reasons\x3dAWJ47B3F5AO3zhpeDsFzwaiYKdaPPIvpS12nNinoJ0hvQzQ5-7MNVEs_z6Svt1aGADF9zDM82AszIQ-fNEfwfwLZs62mJBHqKlZ0D4lCcV9Gp0fmZSzRkHrCNgMJ_NUKXzBlo-pstqgu_WuI237641EViLBaFNB-X507BbGajWF1wHQm7G3MB5wSTH2kN0fHsssUD8qr73rxfy8EzTk3EfDnr_mI_HFimE5ubLnRVSJS_v_H4_IlXGknrcZliuq0haWBE7JRLLW6ecpF-3YEYMk0Dkcv7gWfRz2BIJtxul0rSdqxDEVtMCNgmBn9_INSspDOEbqzeXBc3qma48J0vWTMx1DCDvL6vz1cKYwtPktUsXwVT0JOp-miV2pSZFA0tgG7rTVuqcWsxVBo0775K7kDG-vugI04Oi4YY7mgB8gUr1gZbCBRpdwpZTVj_NN3U7Dv1l-nfk3k6dbQlXvsgnWLg57ywiYCZJR7DnMUWBQxz1Cb0qpdqzvSTJNMHH6_n7OE1XPRPUZlZmuNmS4aH9aFNl3zKwAYIjCYPMrGV-XzS8dAFdeLVuW9tXASQvw9vqKyYJmIIiMRke6gxVdaTo0KdkqFkSTFHnZRun_jKk9OLEIsCrkPz2iiO_JKQqocMcbJ-1i1qlP4sHJ33OLsAvqkG9TetoZCb3lmrJXZ-LnKh3OAdCrBaz_7Um1dmVi-RnxtWO7hhpn_NWr--kOcYRPmOyVxqg9rwYyGzKNcHwgHNk-CfdYgp-kckyowVqzGkkpxLHdLHPtk9UhCUzG6HILDs0FdIMCi0KlgG674vEdB4Cc9ioetdAmgfmXfR4RmS-R7AQ3-J_uuRzBwHm6qd6W-f48xu6v54G2NVAPxE6wdrMZdBOVb9Mc-E8-7gDu9ll4R-SHpTybjm5flK_JSy_JMtwj2VYvpu7LzdPSBFQPRYnHM6iz0nVKQtzA0vKQXjAsXIprjF0oXe3tlV6_S7Rt_VJoZREfZ3CFa70XaqCWOhfCpJpNAmGh5Rj97T0g7LEggVjFap-FPGmgFcpoRdbXWb5crITlfgETkepYKrzIbnLOdjB9RkevgfLA02-s_Wu8UQmO85wiDBOIB3q9BFkvvmxzDittMcpKlAvuLs-5yDpP90IaQrTVDQ5y5CfuvEZxBvNqoySzJc5Yi8h0uqshlGNJE5Q6-8D4CBSvUtdPDrawPjOEwP1gcvHGZoYWMRGYRidIhYIJLD1r4l0TZ8CPWAszUgt8FQ3UNkvQBrZ34KKGF-x6bVVybl0cuXU5HfDfKN4WEyou9jXM6QHv9T3R_NxRamFHKE9dcMem945G7TocflRoLu27LW8lPZEU55NUQ_keOrYtcGQ8j37kp8UtB-cnZYPJonxTqz7so2AuHdB9MRUzecvh9yHqoPyH0_-XF_2v4vIf8FAnl4SzRyIf05066LSOoCKDQrQKCOWsJDXZDWKU_-MHpv8FNCtrkZ9ZvNFAaxywFSLnXEae1P26r80bh1c-UWYZQyPNTITcZn1iOtPN6_BZHtVZxU0sT2dueEEYYd4fnFBp_i-AfZgDxqCra56XSoZ8epG2RriPXuBYxKvqB6y9kifJTGVipzG91DB1Bg1tDNZbkWyWL4HqoOvLSnHJQbxBAV4L6kbyOlIJ7tH3gdH21nFhZZnXNKtm1LDN5O59Sp5JggEUcx6MtppAG4_lbdIJ__UT5S9E_GulPwH6fyFXwGE2HtlRXgXC63jay7yHPklLmLPojF6IeJztfZugZYcVZF5MJY8XVxK65GfgBaw6AE8HMqTN5maePf_92LjsesNprIO_pnZ3RbbssRgEmOCD3ZcablqWICNHUDB8eEcULdpeCgRl7fbzyv5AYCiG5RH1hcbcWF5uJCHMfAE69kZaWesVjv9hDCfLq8-_3t36dLaJXLxYJo7amADaql6NbQOgqsJy0OstO2JzknR-Cz6flnhVKKxZeY1jNiBu6V_4fHiEqMyRGR9G8tyBZjxSGq9tf8fMbKNGAlJcFaQkzHX8q3fLVwEBtc3r5m2ooLNjvFYaVpvlzNa0o5H7np-4wW3j8JPGc8xJ1Qf8Y8l_MS8Pj0SCxYU5bvWyWGsuSvCMCym69gtK0IdOSw5ZuGq-Ya47qiCYk-8QPUlFsIFLvqRpTxy2JHvuPxSJiIlVeEFPH4q_1uGYXjFFfuoWxsV8UukeF_qyuW1oDTLyPvBSRgt_SI1OL4SMWgB3IHNWwc2DKjhoDvFEDqa4CHKo3vA\x26amp;opi\x3d122715837\x22 target\x3d\x22_blank\x22\x3e\x3c/a\x3e\x3c/div\x3e\x3cdiv id\x3d\x22cbb\x22 class\x3d\x22cbb\x22 tabindex\x3d\x220\x22 role\x3d\x22button\x22\x3e\x3csvg xmlns\x3d\x22http://www.w3.org/2000/svg\x22 width\x3d\x2215\x22 height\x3d\x2215\x22 fill\x3d\x22none\x22 viewBox\x3d\x220 0 15 15\x22\x3e\x3cg clip-path\x3d\x22url(#clip0_2157_481)\x22\x3e\x3cpath fill\x3d\x22#fff\x22 d\x3d\x22M15 0v15H0V0z\x22/\x3e\x3cpath fill\x3d\x22#fff\x22 d\x3d\x22M15 0v15H0V0z\x22/\x3e\x3ccircle cx\x3d\x227.5\x22 cy\x3d\x2211.5\x22 r\x3d\x221.5\x22 fill\x3d\x22#00aecd\x22 transform\x3d\x22rotate(-180 7.5 11.5)\x22/\x3e\x3ccircle cx\x3d\x227.5\x22 cy\x3d\x227.5\x22 r\x3d\x221.5\x22 fill\x3d\x22#00aecd\x22 transform\x3d\x22rotate(-180 7.5 7.5)\x22/\x3e\x3ccircle cx\x3d\x227.5\x22 cy\x3d\x223.5\x22 r\x3d\x221.5\x22 fill\x3d\x22#00aecd\x22 transform\x3d\x22rotate(-180 7.5 3.5)\x22/\x3e\x3c/g\x3e\x3cdefs\x3e\x3cclipPath id\x3d\x22clip0_2157_481\x22\x3e\x3cpath fill\x3d\x22#fff\x22 d\x3d\x22M15 0v15H0V0z\x22/\x3e\x3c/clipPath\x3e\x3c/defs\x3e\x3c/svg\x3e\x3c/div\x3e\x3c/div\x3e\x3c/div\x3e\x3cstyle\x3e.mute_panel{z-index:2147483646;}.abgac{position:absolute;left:0px;top:0px;z-index:2147483646;display:none;width:100%;height:100%;background-color:#FAFAFA;}.mlsc{height:100%;display:flex;justify-content:center;align-items:center;}.mls{animation:mlskf 2s linear infinite;height:50%;width:50%;}.mlsd{stroke-dasharray:1,189;stroke-dashoffset:0;animation:mlsdkf 1.4s ease-in-out infinite;}@keyframes mlskf{100%{transform:rotate(360deg);}}@keyframes mlsdkf{0%{stroke-dasharray:1,189;stroke-dashoffset:0;}50%{stroke-dasharray:134,189;stroke-dashoffset:-53px;}100%{stroke-dasharray:134,189;stroke-dashoffset:-188px;}}\x3c/style\x3e\x3cdiv id\x3d\x22mute_panel\x22 class\x3d\x22mute_panel\x22 aria-hidden\x3d\x22true\x22\x3e\x3cdiv id\x3d\x22abgac\x22 class\x3d\x22abgac\x22 aria-hidden\x3d\x22true\x22\x3e\x3cdiv id\x3d\x22mlsc\x22 class\x3d\x22mlsc\x22\x3e\x3csvg class\x3d\x22mls\x22 viewBox\x3d\x2250 50 100 100\x22\x3e\x3ccircle class\x3d\x22mlsd\x22 cx\x3d\x22100\x22 cy\x3d\x22100\x22 r\x3d\x2230\x22 fill\x3d\x22none\x22 stroke\x3d\x22#9E9E9E\x22 stroke-width\x3d\x223\x22/\x3e\x3c/svg\x3e\x3c/div\x3e\x3c/div\x3e\x3c/div\x3e\x3cscript data-jc\x3d\x2260\x22 src\x3d\x22https://pagead2.googlesyndication.com/pagead/js/r20261118/r20110914/abg_lite.js\x22 async data-jc-version\x3d\x22r20261118\x22 data-jcp-attribution-data\x3d\x22[[null,\x26quot;https://googleads.g.doubleclick.net/pagead/images/mtad/x_blue.png\x26quot;,null,\x26quot;https://googleads.g.doubleclick.net/pagead/images/mtad/x_blue.png\x26quot;,\x26quot;https://googleads.g.doubleclick.net/pagead/interaction/?ai\x3dCd4tZAOcCa_edJqfZx_APm5HxkAXD1a2UiwHew_LZsxb7LhABILflhCFg_YKAgLARyAECqQKUoe5tr2ayPqgDAcgDmQSqBOcBT9CG5VT8pK48skqCOP1I3DXu4oRH68svvGFAGB3GedACxtRclkEHxMpmW0kn9036ywdpxbNYJMovg9gHDEVFNvv0oRVTa1QXwhJsrkU52ejHiGG48TyEM40bEieAYO1zkw4uX9UZp1ppysNVkJ6IOr7oUvW5QXby7ma_24Zk0D7ilrwvv_cV8nHcigOQOKaI_fBSHIJmCZGLeas8awn6yAnRsxQymmaJUzf2GFr2QHmyd1JFD5QQB6ANaBPWYlhl7svcsZWePAi7g9GK5OEdkc77SSSy6IJZEWFZ0HtIXHHESFtYHXn2wASTiZeq7wXgBAOIBY3Qw4dbkAYBoAYCgAe6xf_PH6gHqeuxAqgHp8yxAqgHpr4bqAfMzrECqAfz0RuoB5bYG6gHqpuxAqgH_uixAqgHjs4bqAeT2BuoB_DgG6gH7paxAqgHr76xAqgHn-GxAqgHpuuxAqgH1ckbqAfZtrECqAeaBqgH_56xAqgH35-xAqgH-MKxAqgH-8KxAqgHv9OxAqgH59exAtgHANIINwiA4YAQEAEYXzIJqoKAgICAoIgBOhGAwAOAgISAgJSu4AOoh4CYAUi9_cE6WJHAxMrQm5gDYAHyCA1iaWRkZXItNTEyODA5gAoEyAsBgAwBogwIKgYKBPbysQKqDQJJVPANAYgODrATurzWJtATANgTA9gUAdAVAcoWAgoA-BYBgBcBshcQGAIqCjUwODg1MjYzNDdQBrIYCRIC5VkYAiIBANAZAQ\\u0026sigh\x3d2anXc0gN-Wk\\u0026cid\x3dCAQSuQEAogo4dadEldMjS48NSwoQp-ZWjA5xS6aM1kL_fwGC5WejCuKn20nPmYZHJmBWgEi7h1HX8aJMsSHLcrW5HrDrPfqsgFUTkbw950048Ud6ipE1Uw5xtXI4J9kx-chmZkrZs458o91if8qlnVZ6zkjYIPw_en335hIGzoEWVtrwe5cgPLusuAOpB6qslDbzfggSPgtu_VnYFVjby1ckUdHw_WzkLlzOcOclMjyOCljBerTOJdLyINfbVxgB\x26quot;,\x26quot;AhcrK_uptpMI3sPy2bMWEI3Qw4dbGOKg0vofIg1hc2tsb2NhbGEuY29tMggIBRMY7pkWFEIXY2EtcHViLTU3MjI2MTAzNDc1NjUyNzRIGVgAcAHaARMI74OyzNCbmAMVolkNCB3CSxhZ\x26quot;,[\x26quot;user_feedback_menu_interaction\x26quot;,\x26quot;\x26quot;,0],null,null,null,null,\x26quot;What was wrong with this ad?\x26quot;,null,\x26quot;https://googleads.g.doubleclick.net/pagead/images/mtad/back_blue.png\x26quot;,\x26quot;Thanks for the feedback!\x26quot;,\x26quot;We’ll review this ad to improve your experience in the future.\x26quot;,\x26quot;Thanks for the feedback!\x26quot;,\x26quot;We’ll use your feedback to review ads on this site.\x26quot;,null,null,null,\x26quot;Closing ad: %1$d\x26quot;,null,\x26quot;https://googleads.g.doubleclick.net/pagead/images/mtad/ad_choices_blue.png\x26quot;,\x26quot;https://www.google.com/url?ct\x3dabg\\u0026q\x3dhttps://www.google.com/adsense/support/bin/request.py%3Fcontact%3Dabg_afc%26url%3Dhttps://www.crazygames.com/game/chainsaw-dance%26gl%3DIT%26hl%3Den%26ai0%3D\\u0026usg\x3dAOvVaw1xTg0aweaTa-jUVDXPfwle\x26quot;,\x26quot;https://googleads.g.doubleclick.net/pagead/images/mtad/x_blue.png\x26quot;,0,[[\x26quot;Stop seeing this ad\x26quot;,[\x26quot;user_feedback_menu_option\x26quot;,\x26quot;1\x26quot;,1],[\x26quot;What was wrong with this ad?\x26quot;,[[\x26quot;Ad covered content\x26quot;,[\x26quot;mute_survey_option\x26quot;,\x26quot;3\x26quot;,1]],[\x26quot;Seen this ad multiple times\x26quot;,[\x26quot;mute_survey_option\x26quot;,\x26quot;2\x26quot;,1]],[\x26quot;Not interested in this ad\x26quot;,[\x26quot;mute_survey_option\x26quot;,\x26quot;7\x26quot;,1]],[\x26quot;Ad was inappropriate\x26quot;,[\x26quot;mute_survey_option\x26quot;,\x26quot;8\x26quot;,1]]]],[\x26quot;user_feedback_undo\x26quot;,\x26quot;1\x26quot;,1]]],[\x26quot;https://googleads.g.doubleclick.net/pagead/images/adchoices/iconx2-000000.png\x26quot;,\x26quot;AdChoices\x26quot;,\x26quot;Ad closed by %1$s\x26quot;,null,\x26quot;https://www.gstatic.com/images/branding/googlelogo/2x/googlelogo_dark_color_84x28dp.png\x26quot;,\x26quot;Stop seeing this ad\x26quot;,\x26quot;We\x26#39;ll try not to show that ad again\x26quot;,null,null,null,null,null,null,\x26quot;See my Google ad settings\x26quot;,null,\x26quot;https://www.gstatic.com\x26quot;,\x26quot;\x26quot;,\x26quot;Ads by %1$s\x26quot;,\x26quot;Ad settings\x26quot;,\x26quot;https://adssettings.google.com\x26quot;,null,null,null,0,null,null,null,0,1],\x26quot;AJdnK60AAAhAW1tbW251bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxbWyJXUFAgTWVkaWEgUGx1cyBTLnIubC4iLCJJVCIsMSxudWxsLDFdLCI4NTc4Njk5MzYyIl1dLFtudWxsLCJodHRwczovL2dvb2dsZWFkcy5nLmRvdWJsZWNsaWNrLm5ldC9wYWdlYWQvaW50ZXJhY3Rpb24vP2FpPUNkNHRaQU9jQ2FfZWRKcWZaeF9BUG01SHhrQVhEMWEyVWl3SGV3X0xac3hiN0xoQUJJTGZsaENGZ19ZS0FnTEFSeUFFQ3FRS1VvZTV0cjJheVBxZ0RBY2dEbVFTcUJPY0JUOUNHNVZUOHBLNDhza3FDT1AxSTNEWHU0b1JINjhzdnZHRkFHQjNHZWRBQ3h0UmNsa0VIeE1wbVcwa245MDM2eXdkcHhiTllKTW92ZzlnSERFVkZOdnYwb1JWVGExUVh3aEpzcmtVNTJlakhpR0c0OFR5RU00MGJFaWVBWU8xemt3NHVYOVVacDFwcHlzTlZrSjZJT3I3b1V2VzVRWGJ5N21hXzI0WmswRDdpbHJ3dnZfY1Y4bkhjaWdPUU9LYUlfZkJTSElKbUNaR0xlYXM4YXduNnlBblJzeFF5bW1hSlV6ZjJHRnIyUUhteWQxSkZENVFRQjZBTmFCUFdZbGhsN3N2Y3NaV2VQQWk3ZzlHSzVPRWRrYzc3U1NTeTZJSlpFV0ZaMEh0SVhISEVTRnRZSFhuMndBU1RpWmVxN3dYZ0JBT0lCWTNRdzRkYmtBWUJvQVlDZ0FlNnhmX1BINmdIcWV1eEFxZ0hwOHl4QXFnSHByNGJxQWZNenJFQ3FBZnowUnVvQjViWUc2Z0hxcHV4QXFnSF91aXhBcWdIanM0YnFBZVQyQnVvQl9EZ0c2Z0g3cGF4QXFnSHI3NnhBcWdIbi1HeEFxZ0hwdXV4QXFnSDFja2JxQWZadHJFQ3FBZWFCcWdIXzU2eEFxZ0gzNS14QXFnSC1NS3hBcWdILThLeEFxZ0h2OU94QXFnSDU5ZXhBdGdIQU5JSU53aUE0WUFRRUFFWVh6SUpxb0tBZ0lDQW9JZ0JPaEdBd0FPQWdJU0FnSlN1NEFPb2g0Q1lBVWk5X2NFNldKSEF4TXJRbTVnRFlBSHlDQTFpYVdSa1pYSXROVEV5T0RBNWdBb0V5QXNCZ0F3Qm9nd0lLZ1lLQlBieXNRS3FEUUpKVlBBTkFZZ09EckFUdXJ6V0p0QVRBTmdUQTlnVUFkQVZBY29XQWdvQS1CWUJnQmNCc2hjUUdBSXFDalV3T0RnMU1qWXpORGRRQnJJWUNSSUM1VmtZQWlJQkFOQVpBUVx1MDAyNnNpZ2g9MmFuWGMwZ04tV2tcdTAwMjZjaWQ9Q0FRU3VRRUFvZ280ZGFkRWxkTWpTNDhOU3dvUXAtWldqQTV4UzZhTTFrTF9md0dDNVdlakN1S24yMG5QbVlaSEptQldnRWk3aDFIWDhhSk1zU0hMY3JXNUhyRHJQZnFzZ0ZVVGtidzk1MDA0OFVkNmlwRTFVdzV4dFhJNEo5a3gtY2htWmtyWnM0NThvOTFpZjhxbG5WWjZ6a2pZSVB3X2VuMzM1aElHem9FV1Z0cndlNWNnUEx1c3VBT3BCNnFzbERiemZnZ1NQZ3R1X1ZuWUZWamJ5MWNrVWRId19XemtMbHpPY09jbE1qeU9DbGpCZXJUT0pkTHlJTmZiVnhnQiIsW251bGwsbnVsbCxudWxsLCJodHRwczovL2Rpc3BsYXlhZHMtZm9ybWF0cy5nb29nbGV1c2VyY29udGVudC5jb20vYWRzL3ByZXZpZXcvY29udGVudC5qcz9jbGllbnQ9d3RhXHUwMDI2b2JmdXNjYXRlZEN1c3RvbWVySWQ9NjA2NTE2ODMzOFx1MDAyNmNyZWF0aXZlSWQ9ODMxODY3MzM5NTE3XHUwMDI2dmVyc2lvbklkPTBcdTAwMjZhZEdyb3VwQ3JlYXRpdmVJZD03Njk3OTI5NzUzMjZcdTAwMjZzaWc9QUNpVkJfeXhIVDd2Q0RKZmVpdkNsMVc0VUpSMkJMUjVMUSJdLG51bGwsbnVsbCwyLCJBaGNyS191cHRwTUkzc1B5MmJNV0VJM1F3NGRiR09LZzB2b2ZJZzFoYzJ0c2IyTmhiR0V1WTI5dE1nZ0lCUk1ZN3BrV0ZFSVhZMkV0Y0hWaUxUVTNNakkyTVRBek5EYzFOalV5TnpSSUdWZ0FjQUhhQVJNSTc0T3l6TkNibUFNVm9sa05DQjNDU3hoWiIsIjI0NDQzNDE0NTQxIl0sbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLCI4MzE4NjczMzk1MTciLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCxudWxsLG51bGwsbnVsbCwzXV0sW251bGwsbnVsbCwxLDEsMV0sW251bGwsbnVsbCwiSVQiXSxudWxsLG51bGwsWzEyMjcxNTgzN11dlJfoMzXfDb-xRlVKOENXQ7ixARtGzMmu4hYuU9CP8RfywA6xnEq7rQDKemYYnOLJae7F5E0tt-HXCibzX0FFWTSITupx0g55MYKLcC39Esomu9CYCesauPehBx6GSMqpoi2HdsOPnZtIdyXnKDVwhSbuCUY5NCC3nuB_5ZUa9SQzZLf46kpE1FgbD8jqVBmBrnfenPvvSh93M_Vn6Xx9VDXk10JQ27plZnhVEzoTRd3A4hwOLwrX8R8p6eGkW-kcKdheo6xWlQhggQ9eBqbkdNpUdukqgJNur7RH5mdBJO9PzY3r3Q46cBba9aKz9hDYVdPr5yWHh9XdECZkb5VCaQ,s_ZuVeFlN448gj7YaSkCsQ\x26quot;,\x26quot;https://adssettings.google.com/whythisad?source\x3ddisplay\\u0026reasons\x3dAWJ47B3F5AO3zhpeDsFzwaiYKdaPPIvpS12nNinoJ0hvQzQ5-7MNVEs_z6Svt1aGADF9zDM82AszIQ-fNEfwfwLZs62mJBHqKlZ0D4lCcV9Gp0fmZSzRkHrCNgMJ_NUKXzBlo-pstqgu_WuI237641EViLBaFNB-X507BbGajWF1wHQm7G3MB5wSTH2kN0fHsssUD8qr73rxfy8EzTk3EfDnr_mI_HFimE5ubLnRVSJS_v_H4_IlXGknrcZliuq0haWBE7JRLLW6ecpF-3YEYMk0Dkcv7gWfRz2BIJtxul0rSdqxDEVtMCNgmBn9_INSspDOEbqzeXBc3qma48J0vWTMx1DCDvL6vz1cKYwtPktUsXwVT0JOp-miV2pSZFA0tgG7rTVuqcWsxVBo0775K7kDG-vugI04Oi4YY7mgB8gUr1gZbCBRpdwpZTVj_NN3U7Dv1l-nfk3k6dbQlXvsgnWLg57ywiYCZJR7DnMUWBQxz1Cb0qpdqzvSTJNMHH6_n7OE1XPRPUZlZmuNmS4aH9aFNl3zKwAYIjCYPMrGV-XzS8dAFdeLVuW9tXASQvw9vqKyYJmIIiMRke6gxVdaTo0KdkqFkSTFHnZRun_jKk9OLEIsCrkPz2iiO_JKQqocMcbJ-1i1qlP4sHJ33OLsAvqkG9TetoZCb3lmrJXZ-LnKh3OAdCrBaz_7Um1dmVi-RnxtWO7hhpn_NWr--kOcYRPmOyVxqg9rwYyGzKNcHwgHNk-CfdYgp-kckyowVqzGkkpxLHdLHPtk9UhCUzG6HILDs0FdIMCi0KlgG674vEdB4Cc9ioetdAmgfmXfR4RmS-R7AQ3-J_uuRzBwHm6qd6W-f48xu6v54G2NVAPxE6wdrMZdBOVb9Mc-E8-7gDu9ll4R-SHpTybjm5flK_JSy_JMtwj2VYvpu7LzdPSBFQPRYnHM6iz0nVKQtzA0vKQXjAsXIprjF0oXe3tlV6_S7Rt_VJoZREfZ3CFa70XaqCWOhfCpJpNAmGh5Rj97T0g7LEggVjFap-FPGmgFcpoRdbXWb5crITlfgETkepYKrzIbnLOdjB9RkevgfLA02-s_Wu8UQmO85wiDBOIB3q9BFkvvmxzDittMcpKlAvuLs-5yDpP90IaQrTVDQ5y5CfuvEZxBvNqoySzJc5Yi8h0uqshlGNJE5Q6-8D4CBSvUtdPDrawPjOEwP1gcvHGZoYWMRGYRidIhYIJLD1r4l0TZ8CPWAszUgt8FQ3UNkvQBrZ34KKGF-x6bVVybl0cuXU5HfDfKN4WEyou9jXM6QHv9T3R_NxRamFHKE9dcMem945G7TocflRoLu27LW8lPZEU55NUQ_keOrYtcGQ8j37kp8UtB-cnZYPJonxTqz7so2AuHdB9MRUzecvh9yHqoPyH0_-XF_2v4vIf8FAnl4SzRyIf05066LSOoCKDQrQKCOWsJDXZDWKU_-MHpv8FNCtrkZ9ZvNFAaxywFSLnXEae1P26r80bh1c-UWYZQyPNTITcZn1iOtPN6_BZHtVZxU0sT2dueEEYYd4fnFBp_i-AfZgDxqCra56XSoZ8epG2RriPXuBYxKvqB6y9kifJTGVipzG91DB1Bg1tDNZbkWyWL4HqoOvLSnHJQbxBAV4L6kbyOlIJ7tH3gdH21nFhZZnXNKtm1LDN5O59Sp5JggEUcx6MtppAG4_lbdIJ__UT5S9E_GulPwH6fyFXwGE2HtlRXgXC63jay7yHPklLmLPojF6IeJztfZugZYcVZF5MJY8XVxK65GfgBaw6AE8HMqTN5maePf_92LjsesNprIO_pnZ3RbbssRgEmOCD3ZcablqWICNHUDB8eEcULdpeCgRl7fbzyv5AYCiG5RH1hcbcWF5uJCHMfAE69kZaWesVjv9hDCfLq8-_3t36dLaJXLxYJo7amADaql6NbQOgqsJy0OstO2JzknR-Cz6flnhVKKxZeY1jNiBu6V_4fHiEqMyRGR9G8tyBZjxSGq9tf8fMbKNGAlJcFaQkzHX8q3fLVwEBtc3r5m2ooLNjvFYaVpvlzNa0o5H7np-4wW3j8JPGc8xJ1Qf8Y8l_MS8Pj0SCxYU5bvWyWGsuSvCMCym69gtK0IdOSw5ZuGq-Ya47qiCYk-8QPUlFsIFLvqRpTxy2JHvuPxSJiIlVeEFPH4q_1uGYXjFFfuoWxsV8UukeF_qyuW1oDTLyPvBSRgt_SI1OL4SMWgB3IHNWwc2DKjhoDvFEDqa4CHKo3vA\\u0026opi\x3d122715837\x26quot;,\x26quot;Why this ad?\x26quot;,1,0],null,null,0,null,0,0,1,0,0,0,1,0,0,0,null,0,1,0,null,[[\x26quot;post_click_menu_height_when_bottom_anchor_on_mobile\x26quot;,\x26quot;150\x26quot;],[\x26quot;show_ad_after_mute\x26quot;,\x26quot;true\x26quot;],[\x26quot;jake_ui_extension\x26quot;,\x26quot;jake_default_ui\x26quot;],[\x26quot;mute_survey_version\x26quot;,\x26quot;mute_panel\x26quot;],[\x26quot;survey_panel_version\x26quot;,\x26quot;survey_panel\x26quot;],[\x26quot;attribution_close_button_size\x26quot;,\x26quot;15\x26quot;],[\x26quot;survey_panel_enable_arrow_padding\x26quot;,\x26quot;false\x26quot;],[\x26quot;attribution_close_button_use_rounded_square\x26quot;,\x26quot;false\x26quot;]],50,320,0,null,null,0,null,null,\x26quot;right\x26quot;,0,null,\x26quot;r20261118/r20110914\x26quot;,null,0,null,0,null,0]\x22\x3e\x3c/script\x3e');
if (!window.mraid) {
    document.write('\x3c/div\x3e');
}(function() {
    var avDiv = document.getElementById("DfaVisibilityIdentifier_3868148515");
    var avMarkup = {
        'active_view_class_name': 'GoogleActiveViewElement',
        'data-google-av-cxn': 'https://pagead2.googlesyndication.com/pcs/activeview?xai\x3dAKAOjsuSvUq3_TiGGMjQLkduSKU7j98Kj7PxUIsPbMKmwBXyEZONYwn4FCK8dV4LVrRxSoobYyaaMCRm5A47VygQkRVEs2jM4ej5CDl0wquAOeSrkt689rAnotN1ngdQsLILEZUPJQPD5qUGSdszn9npVjw5kHkU4uN36oWRM7RKDPY\x26sig\x3dCg0ArKJSzFfxwCYOJsapEAE',
        'data-google-av-adk': '1040146551',
        'data-google-av-metadata': 'la\x3d0\x26',
        'data-google-av-ufs-integrator-metadata': 'CgIYABKTAgqEAmh0dHBzOi8vcGFnZWFkMi5nb29nbGVzeW5kaWNhdGlvbi5jb20vcGNzL2FjdGl2ZXZpZXc_eGFpPUFLQU9qc3VTdlVxM19UaUdHTWpRTGtkdVNLVTdqOThLajdQeFVJc1BiTUttd0JYeUVaT05Zd240RkNLOGRWNExWclJ4U29vYll5YWFNQ1JtNUE0N1Z5Z1FrUlZFczJqTTRlajVDRGwwd3F1QU9lU3JrdDY4OXJBbm90TjFuZ2RRc0xJTEVaVVBKUVBENXFVR1Nkc3puOW5wVmp3NWtIa1U0dU4zNm9XUk03UktEUFkmc2lnPUNnMEFyS0pTekZmeHdDWU9Kc2FwRUFFEgAaACABKAAwBDgAGh4KGkNPLURzc3pRbTVnREZhSlpEUWdkd2tzWVdREAU',
        'data-google-av-override': '-1',
        'data-google-av-immediate': 'true',
        'data-google-av-aid': '0',
        'data-google-av-naid': '1',
        'data-google-av-slift': '',
        'data-google-av-cpmav': '',
        'data-google-av-btr': '',
        'data-google-av-itpl': '32',
        'data-google-av-rs': '6',
        'data-google-av-dm': '2',
        'data-google-av-flags': '[\x22x%278440\x279efotm(\x262006706?\x26\x3e`dopb/%\x3c1707200!\x3d8(\x262004521;\x26\x3e`dopb/%\x3c1712702!\x3dnehu`/!364?\x3c206!9abk{a($160?23?\x3d\x26\x3ccbotf+*015\x3d1304%2bejvf/%72\x3c4346:!\x3defdwa*\x2776330:04$?wqrf+*01254132%2bejvf/%72\x3c6\x3c104!\x3defdwa*\x2776307\x3e\x3c6$?ebkpb$\x2603371332*\x3ebgipf+!3\x3d215106%9aihwc)!725201\x3c?\x279efotm(\x2620556611\x26\x3e`dopb/%\x3c1347::6!\x3d|vqc)!7244017?\x2791z\x22]'
    };
    if (avDiv) {
        for (var key in avMarkup) {
            if (avMarkup.hasOwnProperty(key)) {
                avDiv.setAttribute(key, avMarkup[key]);
            }
        }
    }
})();
(function() {
    var glidar = document.createElement('script');
    glidar.type = 'text/javascript';
    glidar.async = true;
    glidar.src = 'https://pagead2.googlesyndication.com/pagead/managed/js/activeview/current/ufs_web_display.js?cache=r20110914';
    document.body.insertBefore(glidar, document.body.firstChild)
})();
(function() {
    (function() {
        var s = document.createElement('script');
        s.setAttribute('data-jc', '86');
        s.src = 'https://pagead2.googlesyndication.com/pagead/js/r20261118/r20110914/elements/html/omrhp.js';
        s.setAttribute('data-jc-version', 'r20261118');
        var ss = document.getElementsByTagName('script')[0];
        if (ss && ss.parentNode) {
            ss.parentNode.insertBefore(s, ss);
        }
    })();
    window.dicnf = {
        eavp: true,
        ebrp: true,
        apfa: true,
        atsb: true,
        bvst: 'r20261118',
        eeid: 'BOcCa-_xHqKztfAPwpfhyAU',
        opxb: true,
        aunb: true,
        adsg: '',
        admetadata: '',
        uffp: true,
        rtit: true,
        arbpp: true,
    };
    (function() {
        var aa = typeof Object.create == "function" ? Object.create : function(a) {
                function b() {}
                b.prototype = a;
                return new b
            },
            ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
                if (a == Array.prototype || a == Object.prototype) return a;
                a[b] = c.value;
                return a
            };

        function ca(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        }
        var m = ca(this);

        function u(a, b) {
            if (b) a: {
                var c = m;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && ba(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        }
        var da;
        if (typeof Object.setPrototypeOf == "function") da = Object.setPrototypeOf;
        else {
            var ea;
            a: {
                var fa = {
                        a: !0
                    },
                    ia = {};
                try {
                    ia.__proto__ = fa;
                    ea = ia.a;
                    break a
                } catch (a) {}
                ea = !1
            }
            da = ea ? function(a, b) {
                a.__proto__ = b;
                if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
                return a
            } : null
        }
        var ja = da;

        function ka(a, b) {
            a.prototype = aa(b.prototype);
            a.prototype.constructor = a;
            if (ja) ja(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.pa = b.prototype
        }

        function la(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        }

        function F(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: la(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        }

        function ma(a) {
            if (!(a instanceof Array)) {
                a = F(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        }

        function K(a, b) {
            var c;
            b && !b.done && (c = a["return"]) && c.call(a)
        }
        var na = typeof Object.assign == "function" ? Object.assign : function(a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) Object.prototype.hasOwnProperty.call(d, e) && (a[e] = d[e])
            }
            return a
        };

        function oa() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        }
        u("globalThis", function(a) {
            return a || m
        });
        u("Promise", function(a) {
            function b(f) {
                this.i = 0;
                this.j = void 0;
                this.h = [];
                this.u = !1;
                var h = this.l();
                try {
                    f(h.resolve, h.reject)
                } catch (k) {
                    h.reject(k)
                }
            }

            function c() {
                this.h = null
            }

            function d(f) {
                return f instanceof b ? f : new b(function(h) {
                    h(f)
                })
            }
            if (a) return a;
            c.prototype.i = function(f) {
                if (this.h == null) {
                    this.h = [];
                    var h = this;
                    this.j(function() {
                        h.m()
                    })
                }
                this.h.push(f)
            };
            var e = m.setTimeout;
            c.prototype.j = function(f) {
                e(f, 0)
            };
            c.prototype.m = function() {
                for (; this.h && this.h.length;) {
                    var f = this.h;
                    this.h = [];
                    for (var h = 0; h < f.length; ++h) {
                        var k = f[h];
                        f[h] = null;
                        try {
                            k()
                        } catch (l) {
                            this.l(l)
                        }
                    }
                }
                this.h = null
            };
            c.prototype.l = function(f) {
                this.j(function() {
                    throw f;
                })
            };
            b.prototype.l = function() {
                function f(l) {
                    return function(n) {
                        k || (k = !0, l.call(h, n))
                    }
                }
                var h = this,
                    k = !1;
                return {
                    resolve: f(this.J),
                    reject: f(this.m)
                }
            };
            b.prototype.J = function(f) {
                if (f === this) this.m(new TypeError("A Promise cannot resolve to itself"));
                else if (f instanceof b) this.L(f);
                else {
                    a: switch (typeof f) {
                        case "object":
                            var h = f != null;
                            break a;
                        case "function":
                            h = !0;
                            break a;
                        default:
                            h = !1
                    }
                    h ? this.I(f) : this.o(f)
                }
            };
            b.prototype.I = function(f) {
                var h = void 0;
                try {
                    h = f.then
                } catch (k) {
                    this.m(k);
                    return
                }
                typeof h == "function" ? this.M(h, f) : this.o(f)
            };
            b.prototype.m = function(f) {
                this.A(2, f)
            };
            b.prototype.o = function(f) {
                this.A(1, f)
            };
            b.prototype.A = function(f, h) {
                if (this.i != 0) throw Error("Cannot settle(" + f + ", " + h + "): Promise already settled in state" + this.i);
                this.i = f;
                this.j = h;
                this.i === 2 && this.K();
                this.F()
            };
            b.prototype.K = function() {
                var f = this;
                e(function() {
                    if (f.H()) {
                        var h = m.console;
                        typeof h !== "undefined" && h.error(f.j)
                    }
                }, 1)
            };
            b.prototype.H = function() {
                if (this.u) return !1;
                var f = m.CustomEvent,
                    h = m.Event,
                    k = m.dispatchEvent;
                if (typeof k === "undefined") return !0;
                typeof f === "function" ? f = new f("unhandledrejection", {
                    cancelable: !0
                }) : typeof h === "function" ? f = new h("unhandledrejection", {
                    cancelable: !0
                }) : (f = m.document.createEvent("CustomEvent"), f.initCustomEvent("unhandledrejection", !1, !0, f));
                f.promise = this;
                f.reason = this.j;
                return k(f)
            };
            b.prototype.F = function() {
                if (this.h != null) {
                    for (var f = 0; f < this.h.length; ++f) g.i(this.h[f]);
                    this.h = null
                }
            };
            var g = new c;
            b.prototype.L = function(f) {
                var h = this.l();
                f.N(h.resolve, h.reject)
            };
            b.prototype.M = function(f, h) {
                var k = this.l();
                try {
                    f.call(h, k.resolve, k.reject)
                } catch (l) {
                    k.reject(l)
                }
            };
            b.prototype.then = function(f, h) {
                function k(v, A) {
                    return typeof v == "function" ? function(w) {
                        try {
                            l(v(w))
                        } catch (p) {
                            n(p)
                        }
                    } : A
                }
                var l, n, q = new b(function(v, A) {
                    l = v;
                    n = A
                });
                this.N(k(f, l), k(h, n));
                return q
            };
            b.prototype.catch = function(f) {
                return this.then(void 0, f)
            };
            b.prototype.N = function(f, h) {
                function k() {
                    switch (l.i) {
                        case 1:
                            f(l.j);
                            break;
                        case 2:
                            h(l.j);
                            break;
                        default:
                            throw Error("Unexpected state: " + l.i);
                    }
                }
                var l = this;
                this.h == null ? g.i(k) : this.h.push(k);
                this.u = !0
            };
            b.resolve = d;
            b.reject = function(f) {
                return new b(function(h, k) {
                    k(f)
                })
            };
            b.race = function(f) {
                return new b(function(h, k) {
                    for (var l = F(f), n = l.next(); !n.done; n = l.next()) d(n.value).N(h, k)
                })
            };
            b.all = function(f) {
                var h = F(f),
                    k = h.next();
                return k.done ? d([]) : new b(function(l, n) {
                    function q(w) {
                        return function(p) {
                            v[w] = p;
                            A--;
                            A == 0 && l(v)
                        }
                    }
                    var v = [],
                        A = 0;
                    do v.push(void 0), A++, d(k.value).N(q(v.length - 1), n), k = h.next(); while (!k.done)
                })
            };
            return b
        });
        u("Object.is", function(a) {
            return a ? a : function(b, c) {
                return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
            }
        });
        u("Array.prototype.includes", function(a) {
            return a ? a : function(b, c) {
                var d = this;
                d instanceof String && (d = String(d));
                var e = d.length;
                c = c || 0;
                for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                    var g = d[c];
                    if (g === b || Object.is(g, b)) return !0
                }
                return !1
            }
        });
        u("String.prototype.includes", function(a) {
            return a ? a : function(b, c) {
                if (this == null) throw new TypeError("The 'this' value for String.prototype.includes must not be null or undefined");
                if (b instanceof RegExp) throw new TypeError("First argument to String.prototype.includes must not be a regular expression");
                return this.indexOf(b, c || 0) !== -1
            }
        });
        u("Array.from", function(a) {
            return a ? a : function(b, c, d) {
                c = c != null ? c : function(h) {
                    return h
                };
                var e = [],
                    g = typeof Symbol != "undefined" && Symbol.iterator && b[Symbol.iterator];
                if (typeof g == "function") {
                    b = g.call(b);
                    for (var f = 0; !(g = b.next()).done;) e.push(c.call(d, g.value, f++))
                } else
                    for (g = b.length, f = 0; f < g; f++) e.push(c.call(d, b[f], f));
                return e
            }
        });
        u("Number.isFinite", function(a) {
            return a ? a : function(b) {
                return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
            }
        });
        u("Number.MAX_SAFE_INTEGER", function() {
            return 9007199254740991
        });
        u("Number.MIN_SAFE_INTEGER", function() {
            return -9007199254740991
        });
        u("Number.isNaN", function(a) {
            return a ? a : function(b) {
                return typeof b === "number" && isNaN(b)
            }
        }); /*  Copyright The Closure Library Authors. SPDX-License-Identifier: Apache-2.0 */
        var L = this || self;

        function pa(a, b) {
            a: {
                var c = ["CLOSURE_FLAGS"];
                for (var d = L, e = 0; e < c.length; e++)
                    if (d = d[c[e]], d == null) {
                        c = null;
                        break a
                    }
                c = d
            }
            a = c && c[a];
            return a != null ? a : b
        };

        function qa(a) {
            L.setTimeout(function() {
                throw a;
            }, 0)
        };
        var ra = pa(899588437, !1),
            sa = pa(748402147, !0);
        var ta = Array.prototype.indexOf ? function(a, b) {
                return Array.prototype.indexOf.call(a, b, void 0)
            } : function(a, b) {
                if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
                for (var c = 0; c < a.length; c++)
                    if (c in a && a[c] === b) return c;
                return -1
            },
            ua = Array.prototype.forEach ? function(a, b) {
                Array.prototype.forEach.call(a, b, void 0)
            } : function(a, b) {
                for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
            };

        function va(a) {
            va[" "](a);
            return a
        }
        va[" "] = function() {};
        var wa = {},
            xa = null;
        var za = void 0;
        var Aa = typeof Symbol === "function" && typeof Symbol() === "symbol";

        function Ba(a, b, c) {
            return typeof Symbol === "function" && typeof Symbol() === "symbol" ? (c === void 0 ? 0 : c) && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol() : b
        }
        var Ca = Ba("jas", void 0, !0),
            Da = Ba(void 0, "0actk"),
            Ea = Ba("m_m", "oa", !0);
        var Fa = {
                la: {
                    value: 0,
                    configurable: !0,
                    writable: !0,
                    enumerable: !1
                }
            },
            Ga = Object.defineProperties,
            M = Aa ? Ca : "la",
            Ha, Ia = [];
        N(Ia, 7);
        Ha = Object.freeze(Ia);

        function Ja(a, b) {
            Aa || M in a || Ga(a, Fa);
            a[M] |= b
        }

        function N(a, b) {
            Aa || M in a || Ga(a, Fa);
            a[M] = b
        };
        var Ka = {};

        function La(a, b) {
            return b === void 0 ? a.h !== Ma && !!(2 & (a.v[M] | 0)) : !!(2 & b) && a.h !== Ma
        }
        var Ma = {};

        function Na(a) {
            a.na = !0;
            return a
        };
        var Oa = Na(function(a) {
                return typeof a === "number"
            }),
            Pa = Na(function(a) {
                return typeof a === "string"
            }),
            Qa = Na(function(a) {
                return typeof a === "function"
            });
        var Ra = typeof L.BigInt === "function" && typeof L.BigInt(0) === "bigint";
        var Xa = Na(function(a) {
                return Ra ? a >= Sa && a <= Ta : a[0] === "-" ? Ua(a, Va) : Ua(a, Wa)
            }),
            Va = Number.MIN_SAFE_INTEGER.toString(),
            Sa = Ra ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
            Wa = Number.MAX_SAFE_INTEGER.toString(),
            Ta = Ra ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;

        function Ua(a, b) {
            if (a.length > b.length) return !1;
            if (a.length < b.length || a === b) return !0;
            for (var c = 0; c < a.length; c++) {
                var d = a[c],
                    e = b[c];
                if (d > e) return !1;
                if (d < e) return !0
            }
        };

        function Ya(a) {
            if (typeof a !== "boolean") {
                var b = typeof a;
                throw Error("Expected boolean but got " + (b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null") + ": " + a);
            }
            return a
        };

        function Za(a) {
            return a
        };

        function $a(a, b, c, d) {
            var e = d !== void 0;
            d = !!d;
            var g = [],
                f = a.length,
                h = 4294967295,
                k = !1,
                l = !!(b & 64),
                n = l ? b & 128 ? 0 : -1 : void 0;
            if (!(b & 1)) {
                var q = f && a[f - 1];
                q != null && typeof q === "object" && q.constructor === Object ? (f--, h = f) : q = void 0;
                if (l && !(b & 128) && !e) {
                    k = !0;
                    var v;
                    h = ((v = ab) != null ? v : Za)(h - n, n, a, q, void 0) + n
                }
            }
            b = void 0;
            for (e = 0; e < f; e++)
                if (v = a[e], v != null && (v = c(v, d)) != null)
                    if (l && e >= h) {
                        var A = e - n,
                            w = void 0;
                        ((w = b) != null ? w : b = {})[A] = v
                    } else g[e] = v;
            if (q)
                for (var p in q) a = q[p], a != null && (a = c(a, d)) != null && (f = +p, e = void 0, l && !Number.isNaN(f) && (e = f + n) < h ? g[e] = a : (f = void 0, ((f = b) != null ? f : b = {})[p] = a));
            b && (k ? g.push(b) : g[h] = b);
            return g
        }

        function bb(a) {
            switch (typeof a) {
                case "number":
                    return Number.isFinite(a) ? a : "" + a;
                case "bigint":
                    return Xa(a) ? Number(a) : "" + a;
                case "boolean":
                    return a ? 1 : 0;
                case "object":
                    if (Array.isArray(a)) {
                        var b = a[M] | 0;
                        return a.length === 0 && b & 1 ? void 0 : $a(a, b, bb)
                    }
                    if (a != null && a[Ea] === Ka) return cb(a);
                    return
            }
            return a
        }
        var ab;

        function cb(a) {
            a = a.v;
            return $a(a, a[M] | 0, bb)
        };

        function db(a, b, c, d) {
            d = d === void 0 ? 0 : d;
            if (a == null) {
                var e = 32;
                c ? (a = [c], e |= 128) : a = [];
                b && (e = e & -16760833 | (b & 1023) << 14)
            } else {
                if (!Array.isArray(a)) throw Error("narr");
                e = a[M] | 0;
                if (sa && 1 & e) throw Error("rfarr");
                2048 & e && !(2 & e) && eb();
                if (e & 256) throw Error("farr");
                if (e & 64) return (e | d) !== e && N(a, e | d), a;
                if (c && (e |= 128, c !== a[0])) throw Error("mid");
                a: {
                    c = a;e |= 64;
                    var g = c.length;
                    if (g) {
                        var f = g - 1,
                            h = c[f];
                        if (h != null && typeof h === "object" && h.constructor === Object) {
                            b = e & 128 ? 0 : -1;
                            f -= b;
                            if (f >= 1024) throw Error("pvtlmt");
                            for (var k in h) g = +k, g < f && (c[g + b] = h[k], delete h[k]);
                            e = e & -16760833 | (f & 1023) << 14;
                            break a
                        }
                    }
                    if (b) {
                        k = Math.max(b, g - (e & 128 ? 0 : -1));
                        if (k > 1024) throw Error("spvt");
                        e = e & -16760833 | (k & 1023) << 14
                    }
                }
            }
            N(a, e | 64 | d);
            return a
        }

        function eb() {
            if (sa) throw Error("carr");
            if (Da != null) {
                var a;
                var b = (a = za) != null ? a : za = {};
                a = b[Da] || 0;
                a >= 5 || (b[Da] = a + 1, b = Error(), b.__closure__error__context__984382 || (b.__closure__error__context__984382 = {}), b.__closure__error__context__984382.severity = "incident", qa(b))
            }
        };

        function gb(a, b) {
            if (typeof a !== "object") return a;
            if (Array.isArray(a)) {
                var c = a[M] | 0;
                a.length === 0 && c & 1 ? a = void 0 : c & 2 || (!b || 4096 & c || 16 & c ? a = hb(a, c, !1, b && !(c & 16)) : (Ja(a, 34), c & 4 && Object.freeze(a)));
                return a
            }
            if (a != null && a[Ea] === Ka) {
                b = a.v;
                c = b[M] | 0;
                if (!La(a, c)) {
                    if (c & 2) var d = !0;
                    else !(c & 32) || c & 4096 ? d = !1 : (N(b, c | 2), a.h = Ma, d = !0);
                    d ? (a = new a.constructor(b), a.i = Ma) : a = hb(b, c)
                }
                return a
            }
        }

        function hb(a, b, c, d) {
            d != null || (d = !!(34 & b));
            a = $a(a, b, gb, d);
            d = 32;
            c && (d |= 2);
            b = b & 16769217 | d;
            N(a, b);
            return a
        }

        function ib(a) {
            if (a.h === Ma) {
                var b = a.v;
                b = hb(b, b[M] | 0);
                Ja(b, 2048);
                a.v = b;
                a.h = void 0;
                a.i = void 0;
                b = !0
            } else b = !1;
            if (!b && La(a, a.v[M] | 0)) throw Error();
        };

        function jb(a, b, c) {
            ib(a);
            var d = a.v;
            kb(d, d[M] | 0, b, c);
            return a
        }

        function kb(a, b, c, d) {
            var e = c + -1,
                g = a.length - 1;
            if (g >= 0 && e >= g) {
                var f = a[g];
                if (f != null && typeof f === "object" && f.constructor === Object) return f[c] = d, b
            }
            if (e <= g) return a[e] = d, b;
            if (d !== void 0) {
                var h;
                g = ((h = b) != null ? h : b = a[M] | 0) >> 14 & 1023 || 536870912;
                c >= g ? d != null && (e = {}, a[g + -1] = (e[c] = d, e)) : a[e] = d
            }
            return b
        }

        function O(a, b, c) {
            if (c != null && typeof c !== "string") throw Error();
            return jb(a, b, c)
        };

        function lb(a, b, c) {
            this.v = db(a, b, c, 2048)
        }
        lb.prototype.toJSON = function() {
            return cb(this)
        };
        lb.prototype[Ea] = Ka;
        lb.prototype.toString = function() {
            return this.v.toString()
        };

        function mb(a, b) {
            b = b === void 0 ? !1 : b;
            this.key = a;
            this.defaultValue = b;
            this.valueType = "boolean"
        };
        var nb = new mb("45357156", !0),
            ob = new mb("45414892"),
            pb = new mb("45835923"),
            qb = new mb("45716539", !0),
            rb = new mb("45710312", !0);
        var sb = RegExp("ad\\.doubleclick\\.net/(ddm/trackimp|pcs/view)"),
            tb = ["A7CQXglZzTrThjGTBEn1rWTxHOEtkWivwzgea+NjyardrwlieSjVuyG44PkYgIPGs8Q9svD8sF3Yedn0BBBjXAkAAACFeyJvcmlnaW4iOiJodHRwczovL2RvdWJsZWNsaWNrLm5ldDo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=="];

        function ub(a, b) {
            return a.substring(a.length - 7) == "&adurl=" ? a.substring(0, a.length - 7) + b + "&adurl=" : a + b
        };

        function P(a) {
            return a = a === void 0 ? window : a
        };
        var S = L.dicnf || {};

        function vb() {
            return S.imprtype == "1" ? 1 : S.imprtype == "2" ? 2 : S.imprtype == "3" ? 3 : 0
        };

        function wb(a, b) {
            if (a)
                for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
        };

        function xb(a) {
            try {
                var b;
                if (b = !!a && a.location.href != null) a: {
                    try {
                        va(a.foo);
                        b = !0;
                        break a
                    } catch (c) {}
                    b = !1
                }
                return b
            } catch (c) {
                return !1
            }
        }

        function yb(a, b) {
            b = b === void 0 ? !1 : b;
            var c = c === void 0 ? L : c;
            for (var d = 0; c && d++ < 40 && (!b && !xb(c) || !a(c));) a: {
                try {
                    var e = c.parent;
                    if (e && e !== c) {
                        c = e;
                        break a
                    }
                } catch (g) {}
                c = null
            }
        };

        function zb(a) {
            var b = !1,
                c;
            return function() {
                b || (c = a(), b = !0);
                return c
            }
        };

        function Ab() {
            if (!globalThis.crypto) return Math.random();
            try {
                var a = new Uint32Array(1);
                globalThis.crypto.getRandomValues(a);
                return a[0] / 65536 / 65536
            } catch (b) {
                return Math.random()
            }
        };

        function Bb(a, b) {
            b = b === void 0 ? document : b;
            return b.createElement(String(a).toLowerCase())
        };
        var Cb = [];

        function Db() {
            var a = Cb;
            Cb = [];
            a = F(a);
            var b = a.next();
            try {
                for (; !b.done; b = a.next()) {
                    var c = b.value;
                    try {
                        c()
                    } catch (d) {}
                }
            } finally {
                K(a, b)
            }
        };

        function Eb(a, b, c) {
            typeof a.addEventListener === "function" && a.addEventListener(b, c, !1)
        }

        function Fb(a, b, c) {
            typeof a.removeEventListener === "function" && a.removeEventListener(b, c, !1)
        }

        function Gb(a, b) {
            a.readyState === "complete" || a.readyState === "interactive" ? (Cb.push(b), Cb.length === 1 && (window.Promise ? Promise.resolve().then(Db) : (a = window.setImmediate, Qa(a) ? a(Db) : setTimeout(Db, 0)))) : a.addEventListener("DOMContentLoaded", b)
        };

        function T(a, b, c, d, e) {
            return Hb(a, b, c === void 0 ? null : c, !1, d === void 0 ? !1 : d, e === void 0 ? !1 : e)
        }

        function Hb(a, b, c, d, e, g) {
            g = g === void 0 ? !1 : g;
            a.google_image_requests || (a.google_image_requests = []);
            var f = Bb("IMG", a.document);
            if (c || e) {
                var h = function(k) {
                    c && c(k);
                    if (e) {
                        k = a.google_image_requests;
                        var l = ta(k, f);
                        l >= 0 && Array.prototype.splice.call(k, l, 1)
                    }
                    Fb(f, "load", h);
                    Fb(f, "error", h)
                };
                Eb(f, "load", h);
                Eb(f, "error", h)
            }
            d && (f.referrerPolicy = "no-referrer");
            g && (f.attributionSrc = "");
            f.src = b;
            a.google_image_requests.push(f);
            return f
        }

        function Ib(a) {
            var b = b === void 0 ? !1 : b;
            var c;
            if (c = L.navigator) c = L.navigator.userAgent, c = !(!/Chrome/.test(c) || /Edge/.test(c));
            c && typeof L.navigator.sendBeacon === "function" ? L.navigator.sendBeacon(a) : T(L, a, void 0, b)
        }

        function Jb(a, b) {
            var c = c === void 0 ? !1 : c;
            var d = d === void 0 ? !1 : d;
            return a.fetch ? (c = {
                keepalive: !0,
                credentials: "include",
                redirect: "follow",
                method: "get",
                mode: "no-cors"
            }, d && (c.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? c.attributionReporting = {
                eventSourceEligible: "true",
                triggerEligible: "false"
            } : c.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            }), a.fetch(b, c)) : T(a, b, void 0, c, d)
        }
        var Kb = zb(function() {
            return "referrerPolicy" in Bb("IMG")
        });

        function Lb() {
            this.h = {}
        }

        function U(a) {
            Mb || (Mb = new Nb);
            var b = Mb.h[a.key];
            if (a.valueType === "proto") {
                try {
                    var c = JSON.parse(b);
                    if (Array.isArray(c)) return c
                } catch (d) {}
                return a.defaultValue
            }
            return typeof b === typeof a.defaultValue ? b : a.defaultValue
        };

        function Nb() {
            this.h = {};
            var a = document.currentScript;
            a = (a = (a = a === void 0 ? null : a) && a.getAttribute("data-jc") === "0" ? a : document.querySelector('[data-jc="0"]')) && a.getAttribute("data-jc-flags") || "";
            try {
                var b = JSON.parse(a)[0];
                a = "";
                for (var c = 0; c < b.length; c++) a += String.fromCharCode(b.charCodeAt(c) ^ "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(c % 10));
                this.h = JSON.parse(a)
            } catch (d) {}
        }
        var Mb;
        ka(Nb, Lb);

        function Ob(a, b) {
            var c = c === void 0 ? {} : c;
            this.error = a;
            this.meta = c;
            this.context = b.context;
            this.msg = b.message || "";
            this.id = b.id || "jserror"
        };

        function Pb(a) {
            var b = a.toString();
            a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
            a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
            if (a.stack) a: {
                a = a.stack;
                var c = b;
                try {
                    a.indexOf(c) == -1 && (a = c + "\n" + a);
                    for (var d; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                    b = a.replace(RegExp("\n *", "g"), "\n");
                    break a
                } catch (e) {
                    b = c;
                    break a
                }
                b = void 0
            }
            return b
        };
        var Qb = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)");

        function Rb(a, b) {
            this.h = a;
            this.i = b
        }

        function Sb(a, b) {
            this.url = a;
            this.h = !!b;
            this.depth = null
        };
        var Tb = null;

        function Ub() {
            var a = a === void 0 ? L : a;
            return (a = a.performance) && a.now && a.timing ? Math.floor(a.now() + a.timing.navigationStart) : Date.now()
        }

        function Vb() {
            var a = a === void 0 ? L : a;
            return (a = a.performance) && a.now ? a.now() : null
        };

        function Wb(a, b) {
            var c = Vb() || Ub();
            var d = d === void 0 ? 0 : d;
            this.label = a;
            this.type = b;
            this.value = c;
            this.duration = d;
            this.taskId = this.slotId = void 0;
            this.uniqueId = Math.random()
        };
        var V = L.performance,
            Xb = !!(V && V.mark && V.measure && V.clearMarks),
            Yb = zb(function() {
                var a;
                if (a = Xb) {
                    var b = b === void 0 ? window : b;
                    if (Tb === null) {
                        Tb = "";
                        try {
                            a = "";
                            try {
                                a = b.top.location.hash
                            } catch (d) {
                                a = b.location.hash
                            }
                            if (a) {
                                var c = a.match(/\bdeid=([\d,]+)/);
                                Tb = c ? c[1] : ""
                            }
                        } catch (d) {}
                    }
                    b = Tb;
                    a = !!b.indexOf && b.indexOf("1337") >= 0
                }
                return a
            });

        function Zb() {
            var a = window;
            this.i = [];
            this.j = a || L;
            var b = null;
            a && (a.google_js_reporting_queue = a.google_js_reporting_queue || [], this.i = a.google_js_reporting_queue, b = a.google_measure_js_timing);
            this.h = Yb() || (b != null ? b : Math.random() < 1)
        }

        function $b(a) {
            a && V && Yb() && (V.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_start"), V.clearMarks("goog_" + a.label + "_" + a.uniqueId + "_end"))
        }
        Zb.prototype.start = function(a, b) {
            if (!this.h) return null;
            a = new Wb(a, b);
            b = "goog_" + a.label + "_" + a.uniqueId + "_start";
            V && Yb() && V.mark(b);
            return a
        };
        Zb.prototype.end = function(a) {
            if (this.h && Oa(a.value)) {
                a.duration = (Vb() || Ub()) - a.value;
                var b = "goog_" + a.label + "_" + a.uniqueId + "_end";
                V && Yb() && V.mark(b);
                !this.h || this.i.length > 2048 || this.i.push(a)
            }
        };

        function ac() {
            this.j = "&";
            this.i = {};
            this.l = 0;
            this.h = []
        }

        function fc(a, b) {
            var c = {};
            c[a] = b;
            return [c]
        }

        function hc(a, b, c, d, e) {
            var g = [];
            wb(a, function(f, h) {
                (f = ic(f, b, c, d, e)) && g.push(encodeURIComponent(h) + "=" + f)
            });
            return g.join(b)
        }

        function ic(a, b, c, d, e) {
            if (a == null) return "";
            b = b || "&";
            c = c || ",$";
            Pa(c) && (c = c.split(""));
            if (a instanceof Array) {
                if (d || (d = 0), d < c.length) {
                    for (var g = [], f = 0; f < a.length; f++) g.push(ic(a[f], b, c, d + 1, e));
                    return g.join(c[d])
                }
            } else if (typeof a === "object") return e || (e = 0), e < 2 ? encodeURIComponent(hc(a, b, c, d, e + 1)) : "...";
            return encodeURIComponent(String(a))
        }

        function jc(a, b, c, d) {
            return kc(a) - d.length < 0 ? "" : b + "//" + c + d + lc(a, d)
        }

        function lc(a, b) {
            var c = kc(a) - b.length;
            if (c < 0) return "";
            b = "";
            a.h.sort(function(n, q) {
                return n - q
            });
            for (var d = null, e = "", g = 0; g < a.h.length; g++)
                for (var f = a.h[g], h = a.i[f], k = 0; k < h.length; k++) {
                    if (!c) {
                        d = d == null ? f : d;
                        break
                    }
                    var l = hc(h[k], a.j, ",$");
                    if (l) {
                        l = e + l;
                        if (c >= l.length) {
                            c -= l.length;
                            b += l;
                            e = a.j;
                            break
                        }
                        d = d == null ? f : d
                    }
                }
            a = "";
            d != null && (a = e + "trn=" + d);
            return b + a
        }

        function kc(a) {
            var b = 1,
                c;
            for (c in a.i) c.length > b && (b = c.length);
            return 3997 - b - a.j.length - 1
        };
        var mc = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

        function nc(a, b, c) {
            c = c === void 0 ? null : c;
            this.m = a;
            this.o = b;
            this.h = c;
            this.i = null;
            this.j = !1;
            this.u = this.l
        }

        function oc(a, b, c, d) {
            try {
                if (a.h && a.h.h) {
                    var e = a.h.start(b.toString(), 3);
                    var g = c();
                    a.h.end(e)
                } else g = c()
            } catch (k) {
                c = a.o;
                try {
                    $b(e), c = a.u(b, new Ob(k, {
                        message: Pb(k)
                    }), void 0, d)
                } catch (l) {
                    a.l(217, l)
                }
                if (c) {
                    var f, h;
                    (f = window.console) == null || (h = f.error) == null || h.call(f, k)
                } else throw k;
            }
            return g
        }

        function pc(a, b, c, d, e) {
            return function() {
                var g = oa.apply(0, arguments);
                return oc(a, b, function() {
                    return c.apply(d, g)
                }, e)
            }
        }
        nc.prototype.l = function(a, b, c, d, e) {
            e = e || "jserror";
            var g = void 0;
            try {
                var f = new ac;
                f.h.push(1);
                f.i[1] = fc("context", a);
                b.error && b.meta && b.id || (b = new Ob(b, {
                    message: Pb(b)
                }));
                if (b.msg) {
                    var h = b.msg.substring(0, 512);
                    f.h.push(2);
                    f.i[2] = fc("msg", h)
                }
                var k = b.meta || {};
                if (this.i) try {
                    this.i(k)
                } catch (J) {}
                if (d) try {
                    d(k)
                } catch (J) {}
                d = [k];
                f.h.push(3);
                f.i[3] = d;
                var l;
                if (!(l = w)) {
                    h = L;
                    d = [];
                    k = null;
                    do {
                        var n = h;
                        if (xb(n)) {
                            var q = n.location.href;
                            k = n.document && n.document.referrer || null
                        } else q = k, k = null;
                        d.push(new Sb(q || ""));
                        try {
                            h = n.parent
                        } catch (J) {
                            h = null
                        }
                    } while (h && n !== h);
                    q = 0;
                    for (var v = d.length - 1; q <= v; ++q) d[q].depth = v - q;
                    n = L;
                    if (n.location && n.location.ancestorOrigins && n.location.ancestorOrigins.length === d.length - 1)
                        for (v = 1; v < d.length; ++v) {
                            var A = d[v];
                            A.url || (A.url = n.location.ancestorOrigins[v - 1] || "", A.h = !0)
                        }
                    l = d
                }
                var w = l;
                var p = new Sb(L.location.href, !1);
                l = null;
                var y = w.length - 1;
                for (n = y; n >= 0; --n) {
                    var z = w[n];
                    !l && Qb.test(z.url) && (l = z);
                    if (z.url && !z.h) {
                        p = z;
                        break
                    }
                }
                z = null;
                var G = w.length && w[y].url;
                p.depth !== 0 && G && (z = w[y]);
                g = new Rb(p, z);
                if (g.i) {
                    var D = g.i.url || "";
                    f.h.push(4);
                    f.i[4] = fc("top", D)
                }
                var B = {
                    url: g.h.url || ""
                };
                if (g.h.url) {
                    var C = g.h.url.match(mc),
                        r = C[1],
                        x = C[3],
                        t = C[4];
                    w = "";
                    r && (w += r + ":");
                    x && (w += "//", w += x, t && (w += ":" + t));
                    var H = w
                } else H = "";
                B = [B, {
                    url: H
                }];
                f.h.push(5);
                f.i[5] = B;
                qc(this.m, e, f, this.j, c)
            } catch (J) {
                try {
                    var E, I;
                    qc(this.m, e, {
                        context: "ecmserr",
                        rctx: a,
                        msg: Pb(J),
                        url: (I = (E = g) == null ? void 0 : E.h.url) != null ? I : ""
                    }, this.j, c)
                } catch (Q) {}
            }
            return this.o
        };

        function rc(a) {
            var b = "T";
            if (a.T && a.hasOwnProperty(b)) return a.T;
            b = new a;
            return a.T = b
        };

        function sc() {};

        function tc(a, b, c, d) {
            d = d === void 0 ? !1 : d;
            this.domain = a;
            this.path = b;
            this.l = c;
            this.j = d;
            this.protocol = "https:";
            this.i = Math.random()
        }

        function uc() {
            var a = vc,
                b = window.google_srt;
            b >= 0 && b <= 1 && (a.i = b)
        }

        function qc(a, b, c, d, e) {
            if (((d === void 0 ? 0 : d) ? a.i : Math.random()) < (e || a.l)) try {
                if (c instanceof ac) var g = c;
                else g = new ac, wb(c, function(h, k) {
                    var l = g,
                        n = l.l++;
                    h = fc(k, h);
                    l.h.push(n);
                    l.i[n] = h
                });
                var f = jc(g, a.protocol, a.h(), a.path + b + "&");
                f && (a.j ? Ib(f) : T(L, f))
            } catch (h) {}
        }
        tc.prototype.h = function() {
            return this.domain
        };
        var vc, wc, xc = !1;

        function yc() {
            tc.apply(this, arguments)
        }
        ka(yc, tc);
        yc.prototype.h = function() {
            if (xc) {
                var a = {
                    ma: !0
                };
                a = (a === void 0 ? {} : a).ma;
                a = (a === void 0 ? 0 : a) ? "connect.pagead2.googlesyndication.com" : "pagead2.googlesyndication.com"
            } else a = tc.prototype.h.call(this);
            return a
        };
        var W = new Zb;

        function zc() {
            window.google_measure_js_timing || (W.h = !1, W.i !== W.j.google_js_reporting_queue && (Yb() && ua(W.i, $b), W.i.length = 0))
        }(function(a) {
            xc = !1;
            vc = a != null ? a : new yc("pagead2.googlesyndication.com", "/pagead/gen_204?id=", .01);
            typeof window.google_srt !== "number" && (window.google_srt = Math.random());
            uc();
            wc = new nc(vc, !0, W);
            wc.i = function() {};
            wc.j = !0;
            window.document.readyState === "complete" ? zc() : W.h && Eb(window, "load", function() {
                zc()
            })
        })();

        function Ac(a, b) {
            return pc(wc, a, b)
        };
        var Bc = ["FRAME", "IMG", "IFRAME"],
            Cc = /^[01](px)?$/;

        function Dc() {
            this.u = this.i = this.l = this.m = this.A = this.h = this.o = this.j = !1
        }

        function Ec(a) {
            var b = new Dc;
            b.j = a;
            return b
        }

        function Fc(a, b) {
            a.o = b;
            return a
        }

        function Gc(a, b) {
            a.h = b;
            return a
        }

        function Hc(a, b) {
            a.A = b;
            return a
        }

        function Ic(a, b) {
            a.m = b;
            return a
        }

        function Jc(a, b) {
            a.l = b;
            return a
        }

        function Kc(a, b) {
            a.i = b;
            return a
        }

        function Lc(a, b) {
            a.u = b;
            return a
        }

        function Mc(a) {
            return Pa(a) ? document.getElementById(a) : a
        }

        function Nc(a, b) {
            b = b === void 0 ? !1 : b;
            if (a.tagName === "IMG") {
                if (a.complete && (!a.naturalWidth || !a.naturalHeight)) return !0;
                var c;
                if (b && ((c = a.style) == null ? void 0 : c.display) === "none") return !0
            }
            var d, e;
            return Cc.test((d = a.getAttribute("width")) != null ? d : "") && Cc.test((e = a.getAttribute("height")) != null ? e : "")
        }

        function Oc(a, b) {
            if (a.tagName === "IMG") return !(!a.naturalWidth || !a.naturalHeight);
            try {
                if (a.readyState) var c = a.readyState;
                else {
                    var d, e;
                    c = (d = a.contentWindow) == null ? void 0 : (e = d.document) == null ? void 0 : e.readyState
                }
                return c === "complete"
            } catch (g) {
                return b === void 0 ? !1 : b
            }
        }

        function Pc(a) {
            a || (a = function(b, c, d) {
                b.addEventListener(c, d)
            });
            return a
        }

        function Qc(a) {
            if (L.document.readyState === "complete") a(5);
            else {
                var b = Pc(b);
                b(L, "load", function() {
                    a(4)
                })
            }
        }

        function Rc(a, b, c, d) {
            function e(y) {
                g || (g = !0, b(y))
            }
            c = c === void 0 ? new Dc : c;
            a = Mc(a);
            if (!a) return !1;
            d = Pc(d);
            for (var g = !1, f, h = 2, k = 0; k < Bc.length; ++k)
                if (Bc[k] === a.tagName) {
                    h = 3;
                    f = [a];
                    break
                }
            f || (f = a.querySelectorAll(Bc.join(",")));
            var l = 0,
                n = 0,
                q = !c.h,
                v = a = !1;
            k = {};
            for (var A = 0; A < f.length; k = {
                    P: void 0
                }, A++) {
                var w = f[A];
                if (!Nc(w, c.h))
                    if (k.P = w.tagName === "IMG", Oc(w, c.j)) a = !0, k.P && (q = !0);
                    else {
                        l++;
                        var p = function(y) {
                            return function(z) {
                                l--;
                                !l && q && e(h);
                                y.P && (z = z && z.type === "error", n--, z || (q = !0), !n && v && q && e(h))
                            }
                        }(k);
                        d(w, "load", p);
                        k.P && (n++, d(w, "error", p))
                    }
            }
            n === 0 && (q = !0);
            f = null;
            f = L.document.readyState === "complete";
            if (c.A && f) {
                if (n > 0) return v = !0, !1;
                h = 5
            } else if (l === 0 && !a && f) h = 5;
            else if (l || !a) return d(L, "load", function() {
                !c.o || !n && q ? e(4) : v = !0
            }), !1;
            e(h);
            return !0
        }

        function Sc(a, b, c, d) {
            function e() {
                B = !0;
                C = 4;
                n();
                L.removeEventListener("load", e)
            }

            function g(r) {
                if (!y) {
                    y = !0;
                    w && w.disconnect();
                    var x = F(p),
                        t = x.next();
                    try {
                        for (; !t.done; t = x.next()) l(t.value)
                    } finally {
                        K(x, t)
                    }
                    p = [];
                    c.m && L.document.removeEventListener && L.document.removeEventListener("readystatechange", k);
                    c.i && (L.removeEventListener && L.removeEventListener("pagehide", f), G && (D == null || D.removeEventListener("pagehide", h)));
                    b(r)
                }
            }

            function f() {
                if (!y) {
                    var r = G && z;
                    p.length !== 0 || r || g(5)
                }
            }

            function h() {
                z = !0
            }

            function k() {
                n()
            }

            function l(r) {
                var x = F(r.O),
                    t = x.next();
                try {
                    for (; !t.done; t = x.next()) {
                        var H = t.value;
                        r.element.removeEventListener(H.type, H.handler)
                    }
                } finally {
                    K(x, t)
                }
                r.O = []
            }

            function n() {
                var r = L.document.readyState === "complete",
                    x = !c.h,
                    t = !1,
                    H = !1,
                    E = !1,
                    I = !0,
                    J = F(p),
                    Q = J.next();
                try {
                    for (; !Q.done; Q = J.next()) {
                        var R = Q.value;
                        R.completed ? (t = !0, R.da && (H = !0, R.ca || (x = !0))) : (I = !1, R.da && (E = !0))
                    }
                } finally {
                    K(J, Q)
                }
                x = !H || x;
                if (I && t && x) return g(C), !0;
                r && (B = !0, C = 5);
                r = !c.o || !E && x;
                return B && r ? (g(C), !0) : !1
            }

            function q(r) {
                r = F(r);
                var x = r.next();
                try {
                    for (var t = {}; !x.done; t = {
                            B: void 0,
                            D: void 0,
                            R: void 0
                        }, x = r.next())
                        if (t.B = x.value, !p.some(function(E) {
                                return function(I) {
                                    return I.element === E.B
                                }
                            }(t)) && !Nc(t.B, c.h)) {
                            t.R = t.B.tagName === "IMG";
                            t.D = {
                                element: t.B,
                                da: t.R,
                                ca: !1,
                                O: [],
                                completed: !1
                            };
                            if (Oc(t.B, c.j)) t.D.completed = !0;
                            else {
                                var H = function(E) {
                                    return function(I) {
                                        E.D.completed = !0;
                                        E.R && I && I.type === "error" && (E.D.ca = !0);
                                        l(E.D);
                                        n()
                                    }
                                }(t);
                                d(t.B, "load", H);
                                t.D.O.push({
                                    type: "load",
                                    handler: H
                                });
                                t.R && (d(t.B, "error", H), t.D.O.push({
                                    type: "error",
                                    handler: H
                                }))
                            }
                            p.push(t.D)
                        }
                } finally {
                    K(r, x)
                }
            }

            function v(r) {
                return Bc.some(function(x) {
                    return String(x) === r.tagName
                }) ? (C = 3, [r]) : Array.from(r.querySelectorAll(Bc.join(",")))
            }

            function A(r) {
                w = new L.MutationObserver(function(E) {
                    p = p.filter(function(fb) {
                        if (c.l) {
                            var ya = fb.element;
                            if (typeof ya.isConnected === "boolean") var ha = ya.isConnected;
                            else {
                                var bc, cc, dc;
                                ha = (dc = (bc = ya.ownerDocument) == null ? void 0 : (cc = bc.documentElement) == null ? void 0 : cc.contains(ya)) != null ? dc : !1
                            }
                            ha = !ha
                        } else ha = !fb.element.isConnected;
                        return ha ? (l(fb), !1) : !0
                    });
                    var I = [];
                    E = F(E);
                    var J = E.next();
                    try {
                        for (; !J.done; J = E.next())
                            for (var Q = J.value, R = 0; R < Q.addedNodes.length; R++) {
                                var ec = Q.addedNodes[R];
                                ec.nodeType === 1 && I.push.apply(I, ma(v(ec)))
                            }
                    } finally {
                        K(E, J)
                    }
                    q(I);
                    n()
                });
                var x;
                if (x = r.tagName === "BODY" && r.ownerDocument) {
                    try {
                        var t = L.top === L
                    } catch (E) {
                        t = !1
                    }
                    x = !t
                }
                r = x ? r.ownerDocument : r;
                var H;
                (H = w) == null || H.observe(r, {
                    childList: !0,
                    subtree: !0
                })
            }
            c = c === void 0 ? new Dc : c;
            a = Mc(a);
            if (!a) return !1;
            d = Pc(d);
            var w = null,
                p = [],
                y = !1,
                z = !1,
                G = c.i && c.u,
                D = G ? xb(L.top) ? L.top : null : null;
            G && (D ? D.addEventListener("pagehide", h) : z = !0);
            var B = !1,
                C = 2;
            q(v(a));
            c.l ? typeof L.MutationObserver === "function" && A(a) : A(a);
            if (n()) return !0;
            d(L, "load", e);
            c.m && d(L.document, "readystatechange", k);
            c.i && d(L, "pagehide", f);
            return !1
        };

        function Tc(a, b, c) {
            if (a)
                for (var d = 0; a != null && d < 500 && !c(a); ++d) a = b(a)
        }

        function Uc(a, b) {
            Tc(a, function(c) {
                try {
                    return c === c.parent ? null : c.parent
                } catch (d) {}
                return null
            }, b)
        }

        function Vc(a, b) {
            if (a.tagName == "IFRAME") b(a);
            else {
                a = a.querySelectorAll("IFRAME");
                for (var c = 0; c < a.length && !b(a[c]); ++c);
            }
        }

        function Wc(a) {
            return (a = a.ownerDocument) && (a.parentWindow || a.defaultView) || null
        }

        function Xc(a, b, c) {
            try {
                var d = JSON.parse(c.data)
            } catch (f) {}
            if (typeof d === "object" && d && d.type === "creativeLoad") {
                var e = Wc(a);
                if (c.source && e) {
                    var g;
                    Uc(c.source, function(f) {
                        try {
                            if (f.parent === e) return g = f, !0
                        } catch (h) {}
                    });
                    g && Vc(a, function(f) {
                        if (f.contentWindow === g) return b(d), !0
                    })
                }
            }
        }

        function Yc(a) {
            return typeof a === "string" ? document.getElementById(a) : a
        }

        function Zc(a, b) {
            var c = Yc(a);
            if (c)
                if (c.onCreativeLoad) c.onCreativeLoad(b);
                else {
                    var d = b ? [b] : [],
                        e = function(g) {
                            for (var f = 0; f < d.length; ++f) try {
                                d[f](1, g)
                            } catch (h) {}
                            d = {
                                push: function(h) {
                                    h(1, g)
                                }
                            }
                        };
                    c.onCreativeLoad = function(g) {
                        d.push(g)
                    };
                    c.setAttribute("data-creative-load-listener", "");
                    c.addEventListener("creativeLoad", function(g) {
                        e(g.detail)
                    });
                    L.addEventListener("message", function(g) {
                        Xc(c, e, g)
                    })
                }
        };

        function X(a) {
            var b = this;
            this.i = !1;
            this.h = [];
            a(function(c) {
                $c(b, c)
            })
        }

        function $c(a, b) {
            if (!a.i)
                if (b instanceof X) b.then(function(c) {
                    $c(a, c)
                });
                else {
                    a.i = !0;
                    a.j = b;
                    for (b = 0; b < a.h.length; ++b) ad(a, a.h[b]);
                    a.h = []
                }
        }

        function ad(a, b) {
            a.i ? b(a.j) : a.h.push(b)
        }
        X.prototype.then = function(a) {
            var b = this;
            return new X(function(c) {
                ad(b, function(d) {
                    c(a(d))
                })
            })
        };

        function bd(a) {
            var b = a.length,
                c = 0;
            return new X(function(d) {
                if (b == 0) d([]);
                else
                    for (var e = [], g = {
                            G: 0
                        }; g.G < b; g = {
                            G: g.G
                        }, ++g.G) a[g.G].then(function(f) {
                        return function(h) {
                            e[f.G] = h;
                            ++c == b && d(e)
                        }
                    }(g))
            })
        }

        function cd() {
            var a, b = new X(function(c) {
                a = c
            });
            return new dd(b, a)
        }

        function dd(a, b) {
            this.promise = a;
            this.resolve = b
        };

        function ed(a) {
            if (a.prerendering) return 3;
            var b;
            return (b = {
                visible: 1,
                hidden: 2,
                prerender: 3,
                preview: 4,
                unloaded: 5,
                "": 0
            }[a.visibilityState || a.webkitVisibilityState || a.mozVisibilityState || ""]) != null ? b : 0
        }

        function fd(a) {
            var b;
            a.visibilityState ? b = "visibilitychange" : a.mozVisibilityState ? b = "mozvisibilitychange" : a.webkitVisibilityState && (b = "webkitvisibilitychange");
            return b
        };

        function gd(a, b, c) {
            function d(k) {
                try {
                    var l = typeof k.data === "object" ? k.data : JSON.parse(k.data);
                    f === l.paw_id && (window.clearTimeout(h), window.removeEventListener("message", d), l.signal ? b(l.signal) : l.error && c(l.error))
                } catch (n) {
                    k = {
                        msg: "postmessageError",
                        err: n instanceof Error ? n.message : "nonError",
                        data: k.data == null ? "null" : k.data.length > 500 ? k.data.substring(0, 500) : k.data
                    }, rc(sc), l = [], !k.eid && l.length && (k.eid = l.toString()), qc(vc, "paw_sigs", k, !0)
                }
            }
            var e = {},
                g = 200;
            e = e === void 0 ? {} : e;
            b = b === void 0 ? function() {} : b;
            c = c === void 0 ? function() {} : c;
            g = g === void 0 ? 200 : g;
            var f = String(Math.floor(Ab() * 2147483647)),
                h = 0;
            window.addEventListener("message", function(k) {
                Ac(903, function() {
                    d(k)
                })()
            });
            a.postMessage(na({}, {
                paw_id: f
            }, e));
            h = window.setTimeout(function() {
                window.removeEventListener("message", d);
                c("PAW GMA postmessage timed out.")
            }, g)
        }

        function hd() {
            var a = window,
                b, c;
            if (a.gmaSdk || ((b = a.webkit) == null ? 0 : (c = b.messageHandlers) == null ? 0 : c.getGmaViewSignals)) return a;
            try {
                var d = window.parent,
                    e, g;
                if (d.gmaSdk || ((e = d.webkit) == null ? 0 : (g = e.messageHandlers) == null ? 0 : g.getGmaViewSignals)) return d
            } catch (f) {}
            return null
        };

        function id(a) {
            this.v = db(a, void 0, void 0, 2048)
        }
        ka(id, lb);

        function jd(a) {
            this.v = db(a, void 0, void 0, 2048)
        }
        ka(jd, lb);

        function kd(a, b) {
            return O(a, 2, b)
        }

        function ld(a, b) {
            return O(a, 3, b)
        }

        function md(a, b) {
            return O(a, 4, b)
        }

        function nd(a, b) {
            return O(a, 5, b)
        }

        function od(a, b) {
            return O(a, 9, b)
        }

        function pd(a, b) {
            ib(a);
            var c = a.v,
                d = c[M] | 0;
            if (b == null) kb(c, d, 10);
            else {
                for (var e = b === Ha ? 7 : b[M] | 0, g = e, f = !!(2 & e) && !!(4 & e) || !!(256 & e), h = f || Object.isFrozen(b), k = !0, l = !0, n = 0; n < b.length; n++) {
                    var q = b[n];
                    f || (q = La(q), k && (k = !q), l && (l = q))
                }
                f || (e = k ? 13 : 5, e = l ? e & -4097 : e | 4096);
                h && e === g || (b = Array.prototype.slice.call(b), g = 0, e = (2 & d ? e | 2 : e & -3) & -273);
                e !== g && N(b, e);
                d = kb(c, d, 10, b);
                2 & e || !(4096 & e || 16 & e) || (d === void 0 && (d = c[M] | 0), d & 32 && !(d & 4096) && N(c, d | 4096))
            }
            return a
        }

        function qd(a, b) {
            return jb(a, 11, b == null ? b : Ya(b))
        }

        function rd(a, b) {
            return O(a, 1, b)
        }

        function sd(a, b) {
            return jb(a, 7, b == null ? b : Ya(b))
        };
        var td = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

        function ud(a) {
            var b;
            return (b = a.google_tag_data) != null ? b : a.google_tag_data = {}
        }

        function vd(a) {
            var b, c;
            return typeof((b = a.navigator) == null ? void 0 : (c = b.userAgentData) == null ? void 0 : c.getHighEntropyValues) === "function"
        }

        function wd(a) {
            if (!vd(a)) return null;
            var b = ud(a);
            if (b.uach_promise) return b.uach_promise;
            a = a.navigator.userAgentData.getHighEntropyValues(td).then(function(c) {
                b.uach != null || (b.uach = c);
                return c
            });
            return b.uach_promise = a
        }

        function xd(a) {
            var b;
            return qd(pd(nd(kd(rd(md(sd(od(ld(new jd, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), ((b = a.fullVersionList) == null ? void 0 : b.map(function(c) {
                var d = new id;
                d = O(d, 1, c.brand);
                return O(d, 2, c.version)
            })) || []), a.wow64 || !1)
        }

        function yd(a) {
            var b, c;
            return (c = (b = wd(a)) == null ? void 0 : b.then(function(d) {
                return xd(d)
            })) != null ? c : null
        };

        function zd(a) {
            return ["omid_v1_present", "omid_v1_present_web", "omid_v1_present_app"].some(function(b) {
                try {
                    var c = a.frames && !!a.frames[b]
                } catch (d) {
                    c = !1
                }
                return c
            })
        };

        function Ad() {
            this.h = L.document;
            this.u = L;
            this.i = null;
            this.j = this.l = "";
            this.C = Bd();
            this.m = null;
            Cd(this)
        }

        function Cd(a) {
            var b = [],
                c = !!S.eppbtr || S.rcsbtr;
            if (S.aub || S.aunb) {
                var d = yd(a.u);
                d && (d = d.then(function(p) {
                    var y = JSON.stringify(cb(p));
                    p = [];
                    for (var z = 0, G = 0; G < y.length; G++) {
                        var D = y.charCodeAt(G);
                        if (D > 255) {
                            var B = Error("go/unicode-to-byte-error");
                            ra && qa(B);
                            p[z++] = D & 255;
                            D >>= 8
                        }
                        p[z++] = D
                    }
                    y = 3;
                    y === void 0 && (y = 0);
                    if (!xa)
                        for (xa = {}, z = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), G = ["+/=", "+/", "-_=", "-_.", "-_"], D = 0; D < 5; D++) {
                            B = z.concat(G[D].split(""));
                            wa[D] = B;
                            for (var C = 0; C < B.length; C++) {
                                var r = B[C];
                                xa[r] === void 0 && (xa[r] = C)
                            }
                        }
                    y = wa[y];
                    z = Array(Math.floor(p.length / 3));
                    G = y[64] || "";
                    for (D = B = 0; B < p.length - 2; B += 3) {
                        var x = p[B],
                            t = p[B + 1];
                        r = p[B + 2];
                        C = y[x >> 2];
                        x = y[(x & 3) << 4 | t >> 4];
                        t = y[(t & 15) << 2 | r >> 6];
                        r = y[r & 63];
                        z[D++] = C + x + t + r
                    }
                    C = 0;
                    r = G;
                    switch (p.length - B) {
                        case 2:
                            C = p[B + 1], r = y[(C & 15) << 2] || G;
                        case 1:
                            p = p[B], z[D] = y[p >> 2] + y[(p & 3) << 4 | C >> 4] + r + G
                    }
                    a.l = z.join("")
                }), S.aub && b.push(d))
            }
            if (U(nb) || U(ob)) {
                d = hd();
                var e;
                if (d == null ? 0 : (e = d.gmaSdk) == null ? 0 : e.getViewSignals)(e = d.gmaSdk.getViewSignals()) && !U(ob) && (a.j = "&ms=" + e);
                else {
                    var g, f;
                    if (d == null ? 0 : (g = d.webkit) == null ? 0 : (f = g.messageHandlers) == null ? 0 : f.getGmaViewSignals) {
                        var h, k;
                        gd(d == null ? void 0 : (h = d.webkit) == null ? void 0 : (k = h.messageHandlers) == null ? void 0 : k.getGmaViewSignals, function(p) {
                            U(ob) || (a.j = "&" + p)
                        }, function() {})
                    }
                }
            }
            S.umi && (e = new X(function(p) {
                a.i = p
            }), b.push(e));
            if (vb() || S.ebtrg || S.opxdv || c) {
                var l = cd();
                vb() === 2 || vb() === 3 || c ? S.ebtrg && b.push(l.promise) : b.push(l.promise);
                var n = function(p) {
                        S.ebtrg && p && (a.m = p);
                        l.resolve()
                    },
                    q;
                c = (q = S.ebtro) != null ? q : 0;
                var v = Lc(Kc(Jc(Ic(Hc(Gc(Fc(Ec(!!(c & 2)), !!(c & 4)), !!(c & 8)), !!(c & 16)), !!(c & 64)), !!(c & 128)), !!(c & 256)), !!(c & 512)),
                    A = c & 32 ? Sc : Rc;
                S.ebtrg && c && c & 1 ? A(a.h.body, n, v) : Gb(a.h, function() {
                    A(a.h.body, n, v)
                })
            }
            ed(a.h) == 3 && ed(a.h) == 3 && b.push(Dd(a));
            if (S.opxdv && a.C) {
                var w = cd();
                b.push(w.promise);
                q = L.omrhp;
                typeof q === "function" ? q(w.resolve) : (q = L.document.querySelector("script[data-jc='86']")) && q.addEventListener("load", function() {
                    L.omrhp(w.resolve)
                })
            }
            a.o = bd(b)
        }

        function Ed(a) {
            if (S.atsb) Ib(a);
            else if (U(rb)) {
                if (U(pb)) {
                    var b = null;
                    try {
                        b = xb(L.top) ? L.top : null
                    } catch (d) {}
                    if (b && b !== L && typeof b.fetch === "function") try {
                        var c = Jb(b, a)
                    } catch (d) {
                        c = T(L, a)
                    } else c = Jb(L, a)
                } else c = Jb(L, a);
                U(qb) && c instanceof Promise && c.then(function(d) {
                    var e = {};
                    if (d = d.headers.get("X-Ad-Event-Value")) try {
                        var g = JSON.parse(d);
                        e.revenueCurrency = g.currency;
                        e.revenueMicros = g.value;
                        var f = L.parent;
                        e.googMsgType = "aevi";
                        f.postMessage(JSON.stringify(e), "*")
                    } catch (h) {}
                })
            } else T(L, a)
        }

        function Bd() {
            var a = P(L).omid3p,
                b = !!a && typeof a.registerSessionObserver === "function" && typeof a.addEventListener === "function";
            b || yb(function(c) {
                zd(c) && (b = !0);
                return b
            }, !0);
            return b
        }

        function Dd(a) {
            return new X(function(b) {
                var c = fd(a.h);
                if (c) {
                    var d = function() {
                        ed(a.h) != 3 && (Fb(a.h, c, d), b())
                    };
                    Eb(a.h, c, d)
                }
            })
        };

        function Y() {
            return (new Date).getTime()
        }

        function Fd() {
            try {
                var a = a === void 0 ? document : a;
                var b;
                return !((b = a.featurePolicy) == null || !b.features().includes("attribution-reporting"))
            } catch (c) {
                return !1
            }
        }
        var Gd = new nc(new tc("pagead2.googlesyndication.com", "/pagead/gen_204?id=", .01), !1);

        function Hd(a) {
            a.umi = S.umi ? 1 : 0;
            a.bvst = S.bvst || "n";
            a.opxb = S.opxb ? 1 : 0;
            a.aunb = S.aunb ? 1 : 0;
            a.aub = S.aub ? 1 : 0;
            a.fld = S.fld ? 1 : 0;
            a.uffp = S.uffp ? 1 : 0;
            a.espa = S.espa ? 1 : 0;
            a.aifbl = S.aifbl ? 1 : 0;
            a.lrsc = S.lrsc ? 1 : 0;
            Z && (a.omid = Z.C ? 1 : 0)
        }

        function Id(a, b) {
            this.F = a;
            this.o = this.m = this.i = !1;
            this.h = this.j = this.X = 1;
            this.aa = !!S.opxb;
            this.K = this.u = null;
            this.S = cd();
            this.W = Y();
            this.V = null;
            this.fa = Math.random() < .001;
            this.ba = S.eeid || "";
            this.J = this.l = null;
            this.ha = (Math.random() + "").slice(-5);
            this.C = !1;
            this.A = null;
            this.I = 0;
            this.L = this.M = null;
            this.ka = !!S.uffp;
            this.ja = !!S.espa;
            var c, d;
            this.ea = ((c = L.navigator) == null ? void 0 : (d = c.userAgent) == null ? void 0 : d.indexOf("Firefox")) != -1;
            this.Z = !!S.lrsc;
            this.U = !!S.btrb;
            this.ia = !!S.umi;
            this.H = null;
            this.ga = !!S.elodp;
            this.Y = !1;
            Jd(this, b)
        }
        var Z;

        function Kd(a, b) {
            a.h !== 0 && (b ? (a.J = Y() - a.W, Ld(a, b).then(function(c) {
                c && (a.u = c);
                a.o = !0;
                Md(a)
            })) : !a.ia && a.Z && Ld(a).then(function() {
                a.o = !0;
                Md(a)
            }))
        }

        function Nd() {
            try {
                yb(function(a) {
                    a = a.document;
                    if (tb.length && a.head) {
                        var b = F(tb),
                            c = b.next();
                        try {
                            for (; !c.done; c = b.next()) {
                                var d = c.value;
                                if (d && a.head) {
                                    var e = Bb("META");
                                    a.head.appendChild(e);
                                    e.httpEquiv = "origin-trial";
                                    e.content = d
                                }
                            }
                        } finally {
                            K(b, c)
                        }
                    }
                    return !1
                }, !1)
            } catch (a) {}
        }

        function Jd(a, b) {
            Kd(a, b);
            Nd();
            a.h !== 0 || a.j !== 0 ? Od(a) ? Pd(a).then(function() {
                Qd(a)
            }) : Qd(a) : a.A = 1;
            rc(Ad).o.then(function() {
                a.i = !0;
                Md(a)
            });
            Rd(a);
            Md(a)
        }

        function Ld(a, b) {
            return new X(function(c) {
                function d(g, f) {
                    a.K = g;
                    c(f)
                }
                if (b) {
                    Zc(b, d);
                    var e = Hc(Gc(Fc(Ec(!1), !0), a.ea), a.Z);
                    Rc(b, d, e)
                } else Qc(d)
            })
        }

        function Od(a) {
            a.C = Bd();
            a.A = a.C ? 4 : 1;
            return a.C
        }

        function Pd(a) {
            return new X(function(b) {
                var c = pc(Gd, 1184, function(e) {
                        a.A = 3;
                        e && (a.M = e.src, a.L = e.sdk);
                        b()
                    }, null, Hd),
                    d = L.omrhp;
                typeof d === "function" ? d(c) : (d = L.document.querySelector("script[data-jc='86']")) && d.addEventListener("load", pc(Gd, 1183, function() {
                    L.omrhp(c)
                }, null, Hd))
            })
        }

        function Qd(a) {
            a.m = !0;
            Md(a)
        }

        function Sd(a) {
            return !a.aa && a.U ? a.i && a.o : a.i && a.m && a.o
        }

        function Md(a) {
            if (a.i) {
                var b = null,
                    c = 0;
                a.X !== 2 ? b = 0 : a.j === 1 && a.i && a.m ? b = 12 : a.h === 1 && Sd(a) && (b = 11);
                if (b != null) a: {
                    if (b === 0 ? a.h === 1 && Sd(a) ? c = 2 : a.j === 1 && a.i && a.m && (c = 1) : b === 12 && a.h === 1 && Sd(a) && (c = 2), a.ga && !a.Y && b === 0) {
                        a.Y = !0;
                        var d = Td(a, 19, 0, Y());
                        Ud(a, d, !0)
                    }
                    if (a.aa && (a.fa && a.F !== "" && a.C && (a.l || b !== 0 || Vd(a, !0), b !== 12 && c !== 1 && c !== 2 || Vd(a, !1)), b === 0 && c === 0)) break a;
                    if (!a.U || b !== 0 || c === 2) {
                        d = Y();
                        var e = Td(a, b, c, d);
                        b === 0 && (a.X = 2, a.V = d);
                        if (b === 12 || c) a.j = 2;
                        if (b === 11 || c === 2) a.h = 2;
                        Ud(a, e);
                        b === 0 && a.S.resolve()
                    }
                }
            }
        }

        function Vd(a, b) {
            var c = b ? "d" : "o",
                d = null;
            b ? a.l = Y() : d = a.l ? Y() - a.l : "?";
            a = "https://pagead2.googlesyndication.com/pagead/gen_204?id=opxhb&evt=" + c + ("&eid=" + encodeURIComponent(a.ba)) + (d == null ? "" : "&ttp=" + d);
            Ed(a)
        }

        function Td(a, b, c, d) {
            if (a.F === "") return null;
            var e = {
                omid: a.C ? 1 : 0,
                rm: a.A,
                ctpt: d - a.W
            };
            b !== 0 && (e.vt = b, b !== 19 && (e.dtpt = d - (a.V || 0)), b === 11 && S.arbpp && a.F.includes("/pcs/view") && (e.igpp = 1));
            c !== 0 && (e.cbvp = c);
            a.K && (e.dett = a.K);
            a.u && (e.beid = a.u.eventId, e.vend = a.u.vendor);
            a.J != null && (e.cstd = a.J);
            (b = S.bvst) && (e.cisv = b + ("." + a.ha));
            a.I !== 0 && (e.vwbs = a.I);
            a.M && (e.oprs = a.M);
            a.L && (e.opsd = a.L);
            (b = rc(Ad).l) && (e.uach = b);
            S.rtit && a.H !== null && (e.itt = a.H);
            e.arae = Number(Fd());
            var g = "";
            wb(e, function(f, h) {
                g += "&" + h + "=" + encodeURIComponent(f)
            });
            return ub(a.F, g)
        }

        function Ud(a, b, c) {
            b && (((c = !(c === void 0 ? 0 : c) && a.ja && Fd()) || a.ka) && L.fetch ? (a = {
                method: "GET",
                keepalive: !0,
                credentials: "include"
            }, c ? "setAttributionReporting" in XMLHttpRequest.prototype ? (a.attributionReporting = {
                eventSourceEligible: !0,
                triggerEligible: !1
            }, a.mode = "no-cors") : a.headers = {
                "Attribution-Reporting-Eligible": "event-source"
            } : a.mode = "no-cors", L.fetch(ub(b, "&ftch=1"), a)) : Ed(b))
        }

        function Rd(a) {
            var b = a.ba;
            if (b && (b = L["bllsn" + b], typeof b === "function")) try {
                b(function(c) {
                    c && (a.I = c.block ? 2 : 1)
                })
            } catch (c) {}
        };
        P().btrp = function(a, b) {
            return oc(Gd, 1183, function() {
                var c = Z = new Id(a, b);
                return pc(Gd, 1183, function(d) {
                    Kd(c, d)
                }, Hd)
            }, Hd)
        };
        P().pdib3 = function(a, b) {
            oc(Gd, 1185, function() {
                Z.S.promise.then(function() {
                    var c = a,
                        d = Fd();
                    if (sb.test(c)) {
                        var e = c.lastIndexOf(";");
                        c = e === -1 ? c : c.substring(0, e) + ";tpsrc=cis" + c.substring(e)
                    }
                    if (b)
                        if (e = !1, e = e === void 0 ? !1 : e, d = d === void 0 ? !1 : d, Kb()) Hb(window, c, null, !0, e, d);
                        else {
                            var g = L.document;
                            if (g.body) {
                                var f = g.getElementById("goog-srcless-iframe");
                                f || (f = Bb("IFRAME"), f.style.display = "none", f.id = "goog-srcless-iframe", g.body.appendChild(f));
                                g = f
                            } else g = null;
                            g && g.contentWindow && Hb(g.contentWindow, c, null, !0, e, d)
                        }
                    else T(L, c, null, !1, d)
                })
            }, Hd)
        };
        P().vv = function() {
            var a = rc(Ad);
            if (!a.i) throw Error("aiv::err");
            a.i()
        };
        P().sasrc = function(a) {
            Z.S.promise.then(function() {
                var b = L.document.createElement("img");
                b.style.display = "none";
                b.attributionSrc = a;
                L.document.body.appendChild(b)
            })
        };
        P().itt = Ac(1639, function(a) {
            var b = Z;
            b && (b.H = a)
        });
    }).call(this);
    window.stcc = btrp("https://googleads4.g.doubleclick.net/pcs/view?xai\x3dAKAOjsskcFzuM_AjHsZ1CYgZqC85wWoEoNrt0wx8qOQLj6tu0z8JoFRwaPQ7gi0mLty1YWapC8SM271syL0-M3RP3SCen_J2zmCVtAv799qwUcy3_d0ar3MGG26RMiAUnCkh1bejJZWHppFpc_K7Gjj2kTfzamI7bzAabH3qXDWNiFrkd6Bb0M4pEUzECFE6okOpzKcZP8s0tDlmpe3fo5FY8ikrMq5SBhshe9qW6s7sRQlwznGHzazgASFMv3FJwSZsjm2wyfOzNHD1hmCzC3MVQ-YIJUFRN-zDKqtmcOjFODo0FaPjlikAgDWuI9KTS2prhUT9RhlFdcSlCv-DKMLlZjchtEGgJyKQ_SZl6bdX9lcmVRLRZAkgpfU-uQ7qhPXrWu5eoCeoXk0QArZTFaXmDSFICke-6McIMHy34tMDpYWOc9XBdMEmHbGtOJOAGUj-KdZGIzLL9i41Mzy_12w1GvyhUUkp6HL1JzCqisb5U9SpQ5eo57GrzZoudqsoeO4afxuOczB4mDCbjtGvJasrovnc19orNwS56PHeUmtkWlg1LxWahNIGQSCKJEm4rgbvH_u0V1zZdw0w_utXpAcJBK-ighN_FdaNYvvByzRBi-WHY4Tch35HU5FUspN96iCnYFGj1btkKYqdeo2kg3jUTmCQtg5BEClOTvdL26DD3qRLGlR4GPNQt-_R-Xkbsk2oKvERzIClh1JFoVfga--8dT6fl4rNWtweL5RFVojteN59zAAJklNRKsIbO2zcDRishVjCeFbTNgEpDMrORk52gi18gJJzJ-qqDujDiq9a8gzw73eKNOgOscZDB_Z5unIuAZfkIgBXGfTL3YUlpDBNoaOtsDzi1PrPf1LwEILUO5qxXHMnUJK8rW_brUx8YdrV3kS0m2AUXKO7T9PeONnGe-jWKnFuhXsD03bWtViFDXzc-xlDxcXncZkwaOrNbwXfADGpo1trxGxDR7AQqpoCfweSfx0_nWGS2wMcrqozhbiYGmpE5oTrWp5AsCIzYdxs0tWbKymrclMw9w_FercaoyESJ15p3qjGRqQfCh205Pp30dRXH4LuH4NBUBOGIaw00iO5Lcuj4yKeL7R10qkIMVwBa68tZRWqfJuwJQvBQsSQPyvCIH_BtbTdWf4pEJkDu_LDOSgT8zoR9krGTTG9rVpUcBaBJ9qP4nTNR0vrR8jEtMm-aLEDJAJfmrNoE6NCCrwMmXwc9QBw1NMyj7yoOB_5v1G_xOvf1AHTR_NApFXTfDR7eSss0-9w4n-Ltvx6912cCfHvRjzeOFq8ToDaFPJSeDtqWw1yfRwg_q2pHoATuVxUv4Vkp7oQtswQQkLHDzwaGMecwUaUp57cjRIZDYd-kFy3M2AuXPKKlKuTUBcqPwFZMAAPu3f-ymCMCy8CAbhTam3-bFJ6B-du67DQH9BBvcIaNA5GU92R5KI-x1ncKQj_OIgfDE3gubxkiLdkqxeIp9RNEP_6zvgaqZnNmLVLOc3alsQQO2SirAR0IRNO1gyPc2uuqHCZIWozweY5GDodNQpcrzJg4by8z9pzJUQE1Ls7gqeEZgGZvbMdFIFA\x26sai\x3dAMfl-YSIftHBne9t0g-cfABKhjctcELqq87WEqdG1pdCQINLG3gGRywHGXtTOTOLrv025TpvBHa6-R-ntEkroQ_Vor6wdEjUOwrPRB88N3bFLksxtPmczvo-I7fQ0HHEy6oeKL5CMr5H_i7rxZl2LJuU_soiqsqh4ynCD0N7DuSQgLzSGFCwnE_ccs6aRKGR-psvm-xXNXrh4MyC-jgLAKaWgSMmEeGezd5fvJbDxp6D2MxOJoZAv7rq58C7cTYwBe9VDxK3jwjKi6Wk4fRLVTkPbKLAHZQk-_STSywfTcHHo7VVDVx741cbTWIqVC2g0dztPODxKvjceFuwbwSgYHSqWzn5cZ3oyzgrmxs1bDEoyZi5wHhCfWgrrpOhp4h38cYDkk4IHHuY_DXyH_3LaEGPWGlqPb6ydM5l_gfA-pIZptE4anZkS3f7f_T5G1sdfSz4S4aLy9MWNbSrDUZ0a0MFBLpBKwh91Viph_e_XdgUc3ZtNuj3YEwrRQt-f6WPlzmjm8RanBjKRJfipK6NJUMonHQKYsxKYIAteTh_I0B027v8cYdWgtL6HJaWCARH2b5mysdbE8iIDigT5pP8yH6ykESg2mn1nGzPQrVUVd-brcqb_w6IKO4cW-q336s5d6HZkrR1sXF6cldjEL9b6McI6Q\x26sig\x3dCg0ArKJSzPD4k-2roVwMEAE\x26uach_m\x3d%5BUACH%5D\x26pr\x3d13:awLnAAAAAAAB-LULImTcMtWzd_xMVO1jwNNwHg\x26fbs_aeid\x3d%5Bgw_fbsaeid%5D\x26urlfix\x3d1\x26adurl\x3d", document.getElementById("gcc_BOcCa-_xHqKztfAPwpfhyAU"));
})();
(function() {
    if (!window.GoogleTyFxhY || typeof window.GoogleTyFxhY.push !== 'function') {
        window.GoogleTyFxhY = [];
    }
    window.GoogleTyFxhY.push({
        '_scs_': 'BkGkKBOcCa-_xHqKztfAPwpfhyAUAAAAAOAHgBAI',
        '_bgu_': 'https://pagead2.googlesyndication.com/bg/XmnnX5zmlCqF9ze0osNRx80LC2gwoq0EGiIFpO-DhmM.js',
        '_bgp_': 'cthVFgG3TlOQ8ZRyGUm6G813gxGOiyFyViUn092FQVldU2DpCE5rKo+L6vcALMJzC17q6U9QDLu6fQhR6519v1Db0knnIQSRtyKoBKHlCOotppm2JFZNq1jjVdVDLQ5RlY098D/kd44+9J/cOYjXiK8FNdgssbKSxwhlnKVlXGGzmmbYI0w9v1ukD/5M+CdzpX/Cdqrfd72sl86VTkEHoHifkqqbbtFDiN5B01AiDlp/Eb4Taq7tDoWSbcOZ4NGTSof5dlNmDBQnoIbW19dqh/J7jxirlQSMGMlPPWt+zAfYzLZvuMbzTiGqyAJL0VUr4B+dz61iAMvdEq6xA+gpKx/n/jxk4bFjQDmMNZPxA27rowIgFq0kpdbI1dlQ3jLt5U+4AT2oKoRUiSKEjs9EjaZEmwja0gjB4ZcukgFkn62TS//ZpXUfbA2qBqiZ8BRHMIAzTauub5Vz1iX+EZKOdZwwx7ufrzKt7PcKYIUpSdQkOI15CS4kPXrXXaOET2HUo/amfAL7XDna6+0RrClZx5uMDVpVzeAbBhq4L8dXI10VrpE/GFBcYJpDjjYzjuqlaYXte4CX54jRfv3RrNn8LDSHhfzwY0Hq4rY1IXuA6ZGk8NGELoZhFgMEFgNDvpzG6Juk1J1jGIJON46foqADXkOIwZebsIKcf+2buR8AtSxCKKmlh4BHbYGk5S9mIrFufBV6Wug5BwXp+a7mBVCkZQ6fVUDh4ooVjfh4zLAShD6GKT8hujKqQI2UmF12J5SwOBMprYBi+CCA8orrbud8z21xYlmdcHfwIBPJ7ZrnWGaXywBBIKnMyZ5xYQOVWFt8JvfBn1BL26Bf2RBRC09s+iaervzN7J4R8XUU30m+IZlnZohvMcVbP4Nxe2E/UEwIIS1NT4y/9yhRIw6c+W7am8Hy3Pk8zC1gFJ65/x5tflBM5lgBnC6VF/iLxAC0Y4+MdyNx44Unkey+uLVMjMbPp+i2TsrvCqqbUGY+0HEDOqjwxBbxy0jkMqZU1wvOY869Trp2tnEMBfiLhX6rdsi5FVTiEvbyznbDjZMb7GJc/siuwgFOO57P1xxrW0LazjpKWdgjWUpwuIP2xgzC0sKMEkYamVcoJs05iNHSgvqzgtvk/1BY8oGLpTgsu6wdcQLmYeHW3SGCQ5ewioLLFcoGTmSTWU8c6bYAvWHXR162nINcvuKfjwBOaQpIp7GF4AZre0marPKBlEIT5+aDj+7kxvDesIBQwCQfdgr8JvFYa6kBez1ghjW637K8xjfV0KEKBV4RpBs+Hp1QGwQHBNoMioZTS/t1xuiXPqG++iZqqcR5iDvYfYlKkUf+ToTGYsKXIorFqyCIENEMNCYOMZRRo+ZrnyLYFCSNhvijh0ibBktSeiarX5GcVUsxWzI6eDGOp/MuB48NyssqN5kySrYk3Vsi1adKbLQMC/PIw8EgV3KhIHpg+AzbFlm7Chh9U8TyNBDz8BB7CGxNVgos4ah67CGQ72nOUDHJDT24L0j4ZQ3oGTppBaauD6QekZfig3GUHnZiQ1AJjnAiFs3Q15AIWrBWEbBwcG8uqXr8SD+pF2BPtWso6Ehhi+dZOoNMIot+Ck80jMwWkxa/pILSMXNpRiWIfj6e/+GPL0mbH1FCmEc7S+wfoyX1/lvXty3KU4ha+kiacwGiqk1UidQ9NBUzvd3EbCNYfULg2/5P2aYEosN+aoA8DfwsOWE8mK5uD4MxvSJ5jZZc6DHL7lylHCBhfhcSOTKshfYX7lBsK2t3RYyYxPZ8sRDMtSJNifrpLRiYrD0V5KWKgaiP5Du+0z4gwxtOnZrUaag9jMHImp2HVhmWJQJ0Ed0gD5TPnLaQhN2IaN0L/58SCwVeLE57JsK80mLa63aLIuDrJ5/aAe/UFsfbQKXkWWt2LzgLvpGC7opLS+Ri7H1XiQHCkNOnrGNvRpDlExFi4w0+5O6hIfB/0LFTUFyXKanqCYT/tjy43ao+VqmlR2dXpGrwbvInjDJkr7FqnDeVuL/UvKT1VpZp2cZSGKRIwi10QugO1sM3rEGmOL7Cu52S+h6rEXvuNKmmpUbQL5+uHJf2Gfh7K+X48Km6QC8wXo9rVdtGGHdyL8cdIDc08pdJS7eI1M99VNxPe0WBWQ2vjT0IrhxdF84CKS89M2onVLTdZuRtTvAYmL/UKAb8BIPOHUG9LhbEnNUJwppQUFmEVLvBr/J8U8FBor4uRqojhEdB1865I4mBU2p9ka6yRttZxOpiEnDNIb5ejmwLAuo8/FJ5fNBA0G1NqEgNhqZxm66Y5JVuIOnKEZnNLYy9F7uR5YZf7VM8Ty2DdRqqY3ujzC3x4yPJWua8lgQB98R5+8L0AA9gH0OgPHu+lHbo2L/MHIJm0iZa8S+gUQn+DFKdtLFuUyEos+Kk8h8Au6ROYH8EiVuWKex8RciFpVn6Iikf+yZaU43tEgwT3nfEJrthNSx6px13avlbKn/QbUhfHqMNMYqwhIIEyj8BW8jMecmnevYJVtVCqr4joTmjS5zZ3De4EuiLWSdyQ7lQMolQeoyUFrhRn4iby5jLP3iHilArV4xmU2jrii0hD0+3g9xC7sJVlYDPH7yoWZZRSvHw8Szmhf9L1Ym8QL0FgWBCD6chIXrD1Iqw6iMpFl1tQYXg9x8d9pEYcgmpnFpWaTQSIAx05rE44/Jhn3lbG4wrg2oS26fnSwx8sdmiozzlbBiJo8CQMMKpqkQ1dBA6Xinsu5omWCOntU51gfLh0Da9VYSgxoZyjd/bYTn8aiuefKt4fzGKfs/W0GCcbjEnkBD0XWcm1Y05sVTqMrmXp3Cv5JV+8fdbZ9bcVIKbcF6c7p2MzkCSUaFTskGEp5A0PIMXhY9SpYncH1LzlIkZT7eil/9NPp/2GFgOUxAyD1aJDTC/apybzSG1U2mk237v5ZKb6QtAqGiS/xeCe2nkvYs2pZBZCNoaGb3ucdSuYAmp7FwPWUi0ofiqOdiGsGZ7QFs3rXN4UgwAKaVuATFuwo0ogICZJZs+iNTYfcpwS6/ZkJrINiIu5bI/wvXvrWYDQibm6GCfmIJQpo0kskMr84tECGM0gMfU5Yk/9EgkiApmKkQyYsUvhdyyMcB+1YbwQR3cTVL8+t/4CHdGjzrGJMqtzwPP+YmTAILj5Ed2DhkVycX+gDZ22AFrJaNZaEK7ttVXCx8RJXO0Pcw2xlQqzT84OOQZlSCnYXOs2YKDk3uT+L6lbR1v0mARSFF5T2dk4ckpRet0xKyL3TzXQOSRa/stGtkSnE827gYhEAuB2/RsZ2Q9zYwLqnZQPRk1Z61755Y3wy78zilX5vat+ca/IvtqmI8NRd8xF9zDkTqdvcXRmi6P9GxrLDufwu+mq1Ckn7dRrM6b3KJj7k92E/8CIu96YaoXel6bGBaQLasMaOui0i8uh0f+Lgcd8Gr/aLMLIPvOd7xRzJhnNKGuM5JAyGpwdlSWXUu79Sok3hSUm7uJhkjt8FpL5z3hHtkX94O4Ds/+62gU1+PJWxeFZOlQEmNFaRzrDb3y4QFZf2zzpHjt0/B416uZUVsxkSCLdGjyOykquT7u1dpacT5/pH+Hz+QtXh2Eb86hJHKnRRDQu2NbN9xQHMOpCe26wslDECzX6JPcvQgtM+tHny4uLdMFCFrvFvScx9uyZ1ZuxPo7CqKG93PX93fRurENl4SvUDIFwsIsSLVksZjogOseRcBd2UXeUPTBHGQ2AJazpY80QqvcR3dQsP1DEf4dT29V0o3BImkYbBn8xFjUkJiF2lllw+SGm2n5foTs53tfUFYzoyUmW7rBYabMbJPVf4V/1ubVdpMZK2NI43oNyCR9naqWveEZnkZesenjY8YcR8m8vXvHlKMeIqKI0INMaRcCOKyxyYCrF0xKqi/a52XWZVPFPo+LRJlegnggRIT95ICTK50wNAMcRY4LTSp9VyK4rYn9Hg20umTob5uXzhYMXmRO04HsdKW0ARRyyHT1sWLf4vFTK3b/gR3BKwU0Bbt+Qk07vMlT3u5xK/r+gBqOrJqMpngfD/dUvHqyucZBMjuqZL2bRqCxDYZv3lTOlEhA5q9fe5DZEo03XerSeRw5AAgzbUy8rRMtJf2LBU7njfYpWe3tlRD7PB07/laJv7tZbFdhOilJ4y++1bfyKKmqnpXknsN8Hk7LED/qLYsCmQ9qfMiJy9DwNV42Jxcygam1XoFXxxO0OxlcrskZ0cnSVZsFYu9M91qBId+6ichI8RfYkCaRERXyu5VpKbZlikPaahN4UK3z+PqfeX2WrXBP9k+3gy25Es1ozsk5fPpdV/wogRTs3StSas3VO6NwxkSzjS1wOBR6aHiTLTT/FB8fsERMRt2osHOf8DSdw6ovELjhBAa0eqVzep/1yvvkS7zm5Yvtz9ooijnwjBuJwi1BIv4cB8PEF61EW6j9EYuwK2qRM7rFgTld2FNrLiC6JyPnMWwItFQPX02xTD67NRPS4mQK2yMbszOjnRwa8J1B6yImSU0Mt0OlZhMuEPo0GMgiIsMDY45CxJnNBovUFJWj+AzykhHznvFRk/+N6Zdprv9TgYuYg6HcyK11Qg5XQb931I8gpnR38MZElb+f00tpbE2p+UzrVOZ4upzJrnaxHIOohV2GC2r76Jn1SZEUy6MpvND5Y+bnulqukrEXSq3TOA2yh4VUaSxvfGJxT99/A4LNrVy9i0lIPlEKSdY6f/atCuqsgS3Trf6UniARfR8WnDy3MUUtWFM5fJKGHErRhM/opIA9JqVKcLSMwGJ0cMkd4VeOMET7SR8Wt1t7/7XxwP/HWHXiO06tDDckF7gByX3OMv8Lcoel2izCKwnOJlvp7GWC02gJTBtRn2XAN6SI2KbeYh6NLgRtPTUVdlnp4ljY7IphvvRAG8a8YVxEjo1EOcff1vLtvImBvufVzd/1oEy3rf/xgEl2kimD3mSdGYTB0tGmRgABV2eUMMekLBgFI+2B/uMWISGFRXAX0O6svNdGskv0eVXSr4ZgnwETm0OxpmBX27doXiNLQUB2bvVNgfcRuQqAnzQ8g6m1iVJD0uQg6uESu+A9g8c2DiOi/NHyf8g6xiQGmxIqi+DX02yef8Vyx4vm0PenFSALb6JlOSzoNKBuQYlUjTrX4eEwPEBlvd3WNJk2HC/sMC5jHDjr4HaBpgfgw3SrUDWvolRCWxtMoejFVaw3c5IzS2ov578NACUcjJJIJTjzJIAtAz2bUHds7B1iIRt+SHzwtyf9fXq7x0E6Lvb6hkZMQBWHRYIB4miEUwp3GqUQeR37ECKpYBkdbHAmjIHeCd9HkKqNfJbxPIuSVHjcPSzcnDF3KD3oF+whUab2hVUpJdYrL5CM/3kOw5wu5Bbhxm0MjW5tvQtDWx7lxVpj0VXbwVm7X52P0ovS8cxu9n/7KtGcCFf042GR9yYedAvkIDo9eoB/7ab7d3Zlf6cGu6yHmZVFuuiVWRQrqZJ2G1kTJC66rYJ6oYYeuRw2kEWg5IKgMquaHFufVBjK74bzVAtlagblXQ7GObcnZAFzNrXO7P0MAl6HcHd5gJ3N0zaaDwm5+/E6HWZWgB2y51+uSn1ac2HbxtRXhS7fGIo86Lc/UvPZ1vwQQLhk1rWQh0WEoby0nSIrmOxm9jvfagWB+Cu/0R7JMoopNlhJkcKWwWUchVPOMKEhZFRJWXkLEFYgXxT4U+bk++n4G/AMvK0Xs/31oaZDunyPF4L4Y8G+RpukGSpvDrGeDt7lZJrtOs4hoaJsLBc5KtFTxwmZWfkK/9K7Yl70frvZoyglG1CXmjQrbEHK1aymqzmX78aBQ8KIBIQj1+qwyt3SROX/MpQw9aMRya7BK8q6swSi3PxKy4I/QG+AupKVkGjfdJ5ss3C95O578Xy+0l9Hn4/8b0relggyU/gaDvE7Q3vyZa2S3gsrPNSLZYlFyRUpA9Sj05AbZxGwYlcGFYSyJJH7pvmbmqS47ZKeCSgoyFfOSyC0OAwlw3zt9QCrozO/b7r5oFP1oBkQo3mysAl04+AA3j3lFcApqP47ZatZ/pkVk+xc1Ljs/odthVUJ2wE+355obftQLGTAPWAhNOsgoXAvW3FX3pEtWziYlIkCDnuHWkmrKZawsd9PjNJtpP0w1n5MkloGpPSWJQrVgJBa0+NVLd05K9CfqdHJMMBDsy1I1H3ofqFZrR15Rbl/ARouFbHrS4wocuwtadm64uQxfYUYaOicVrLBFnEv9/6iJZmUTgcwiMg3afFhjkKWdiILpdBax9jim740gmzNhbxT9andskug8LGV7v2vPX2yaEwafhFhYOnOZngCHojvyRmJQxM74rfsPNEiSPzwKNn6QVlE5dguOTTid2Jl5y8t9WH5TdJ1jQNAElw5+NtJ5fjGsbPr96m/mbQk8iVb1Q16BHPF7D79tANq2L6jwgkq8Hj0Y+R/9omdRkHBpL+1T7c9nV8wnVUiSwfXrrJJG55o1/csektQUVZMTOzoejYSJaL/HfQ3d2ZPcRlv/i4Hkr2vN6dyp/AOLlxZ/5MvJ40tplIRS8k+Nci4PVStLqLMf3yfRjwUE6AfOh5OTWcs+Bpn9fFUoa2lFt/1FFCUW5wt5dFA3iMUHmQrDi6DevWQ3DqoXH4eb/amlUWMdauhhtF2QoBvRfZWrbZpL8SHIRXrovyeZtjVC1ULM5NkTfdU8xe4U553iglultGGSX+W6+LpgRS7YaY1j18pIncd4Z5lZV6u0hWKMf0D9pTfxr22VMrf5zPup1Ezx92U96zxiZrbobNqyG1e5YuAp2LMjAM8FhfBDyaNp0m/DkDwy6xD7RZP6Y8ZAILjJC/5Jx+NHmvvMNi5eEAov5zG9aW6wg+xuLeA7wXE9Qjofa03zTargd46+1JkNDuKjb6xxXomlczqLyTwTD5rror318fK+N+ldpzc0H3lSqEHpWXAPvAfB7OAHC0yWOmxrNN4T6JklqdzK/GtRlDtz8WO8+tI7H5D8CXZG0UL3vzEIKcBkJu7vmMbt/fQehtP6EUIJyHqTfQTlLMBvUd98NWSjwIpzg3wQZl/vrFufJACJrUlTeJrRzPxbYTlO99+HIGk95mFL5Q79fEyU+ICD9Rx/wLHkzfLTKh3/UAePoTs7dv1YZEIPaHgLap43ZzXQnK+AKOBaLlVa3XbDKwxi1rtj2ULW8Iwe9l4h61+El33QRFc9unB7R1xBr0+gfVyQ7wOAxg7AT4BAcgu5w3NwvwpMD8WFa9yGXmy1TgHbTSL2O9nE8A1NJ8XiRlD5a+1WGA7DNLcD1qJwwhT8s8CAVo/uJReyETYV8SEUX7JRxCQwz+Nu6yW5NivkDMOgozCKODNe5IAoX84DGUZX7fgWtW2gEk0UBs7E/sn+riDh6DRY4O+AdmjzPSRGhwjLJxoqIBjyDGAhU56nahoJeUzvF7HoPtxnv9eKKMoHXoqGlOS+eJe21Zw8U/3Zaxr6wZvgNciF+dOSyZc1x9+MCsnsdMXG5AGYoPaNu+x01fPQKtO2siG/G4xDqIqNAObSa1rmhd/JFKcmUCwd0Dwg6pU2iqwYLHsRChH4gkwddHmu4VAiirgVopt/59+ELazGxBHhz9SclV/gJ/xqZSzODoOmoE1C+ZzIKkvC4L0bLtOLobYaYltzn6opD0jnr5apISQg+mCoRykl2+EhlZl6cr+lfbYUtqWu456wjoP/bY//h7mSQ9kP6McuMrUD4Q/RFMU3B1Fcvhx23TsOd0VUPD1FXT2bgmX8LYDc91WJxb7bEK7qzv0TakoBoDUN/spzRRSNXaMYJSVy8sodrPXD2WqpZhmcmxkW26PEow2x1XKDtd5uEeHzHppZ300zxxbg2GV/zuzRT9Pq5hnl/Kboy5h7yIiiROtmdDPe5UqLNwBM6+iU9dcs9ifVWLhsoJeW4Mn8XqvssvVbBTww9YguLdV4sibR4vOBZDKT3iaF+HBY7z0hLeoY19ck+JDevpLa9dm4aCettFi7wW24Opr+QSWORpPY9x0p9T9E2EDMzF4xrRzce/vYnktsYY/Jcgmcl+obDbkUxJL/qocWraKE1ReXSrIhW/RlZYHTgi6AJeNWCHOH2sHatPWlcGkjCkoGiM8Q4V19kpYqoBnllCoGDOA/OtoOdoRFv4VKXiaJPUQPZKdTYY9xmRJTL41Djk1cSfg+MwTyQdHpcffVn8TzOBXHMNSIudZK9RpH/S4h79XLvqWlJ/zmuCMnG0oTtaLo+RSm5ggBK32O/a6a7TQPisHP77bED374ENAyKt44PZvN7fqG7ytYnSFPGdVoUqtAdguySjk0czntHyUMFMT+VzK/P1i8rAcn8WKKP2k2zhGsL0iUvYORvK3ep0Nl5YyFM+/0SD/7qimvtfdhG4N9R0Wb6FqjjLrLLpGquAeYxXvveQFfVgYtkNnVO09zxrZgJHwnQSanHQfVm3Eq/ccVN908pukaNus45URw/Ma2zjHQgj/AFRZ5eqlYXVod/3uN3eetZx1s0NyK8QAbvHqs1YunLpxci2+Liuf220fmDISHz95qnzCkt988h7SA8Oo1IpKUA2wVgdOTDcmg6Ur4vU5Rqn3ZR25iXX4hmEQYHj1ZuvTqoZkhtv2OSCfEQHUecnJMWSOm1l1hz8aiScapLdla2JDxWzRtSTHqHh5NtQJfYf92SEF/liAq3AKt3x0fRjxUKzdVQVWT7JHoXOUYIR/1shDQP1IXC4w513zrDMTitQA/DuH9FRzWTCSytSMSXqYDMlxneGWG+vuf4J4EoK8cz4mgIprIrGdM1+0o51Vph/teLhoZo8FrcRsfztC7hPaEusN0r8YkNM38PTYn5+MBDaOUyhmo3/NQ5xLMbrsmQJr2UK2irCGnDulApyxChBudBJBA0eDpeWUbvwvfiryOGhld6+8sDKC/EfeXpyJd9gwkaqaYj46nAaG/sSFlUjNRW5lmEsethlm3bAPAvgwpUgKYaTY7/I+aweBjryamkAAgzTgHeWbt1NO7n6nXvoonch8eey+Qf2Smx5Ba+sh0SpALq1LFuxAg/WkWBm9tnHvaw29Yz+K4YHnXf2Z1qKJPxUZICvLdGaTu4MIfRi/led/r1j1BR8EVk7yvoEfBuknly1Cn2avgsBIXXzr44U48kbJMyiZ0NbrX4RXbwlT/chm+CNBzITZuah9EMVZygDdleM2dbejPkgxj28KhNUS2kRDVv82uWnL0dG8F6JDl+Q2R/fPHPTehSZC4Qvlv7e+t4KhwJk5O9FiyE0cohAMtVlt1DhnJXtR8Ybn19dmc89lZ4gUWmMs+KV0UtE/27oVGz8+Quh5vr0yvUX+nXqFBksQwP5mfz+FG4FimEsQ4dRAcj1YnCff5JQ53V4JMsxBHNXjUAALOSOZslr55kOQT78m7vo58wiSi71cwvXX2WUYEYIrMNtzj8X8B1rqe3BEsFS5eEHfI6KwAHALpYrcjIMpSwj/KnaBGotcvB/czDj9w2OBWuQM8w8kdpMoqf8MWkPcpjhZ2l5b1bSc/jSwow7SzCywXQNf2uypO/fdOUKh0i2sScTKb3XalR23X6jfJA42jiP6RDKpuFiKpv9xlvafKVrMxTAVuksJs4koZ3uzY139JsfJooHgFUYt3C72dnKLaEnavCeinwyCQGhpD3qhj8NNS4L+YLDQ/1MaOeZ4GH46Iq+xuHoGEP7pGnTifQuideg3oZsil4zmzR5wA46jSOJlWbk/UQtVQ8w7vzGS+NMU0mEIYncVNOOaFEr5B+EM2OyWYIs1l0p3qj8hkbtdLafe8fVIIv21fzGHDbz93QlXbNe3MiMnyehnzcVuJxbGhNuETKl3n86mNQkKkIare40A7+xWQ5M4VeMRIc9YRvOH8mC83By39kfh+115O9xYvkJR3KYhKMcxBU8gfVzNsHqacgkLbW2Lb50UWXT8HQk0s40X87XpC2+OjiRmPDs5F+L9f/qzuaMAkz8diNgC2W0Yn/n42u+B5CJpVmAlEEY0qpkxLPLZLvqv8JskB5uOM/jzrAj02EEjWbSDFQaz1FrEdFoxbxiZFDhgit+Pe4dGgYWCIt89ke/iHl6wzsEnRYbo3j9DW4MRQ4ekFNnpmgPJp6vW1BiOnLtWoLUSxUDh5qgvTIWwUsrPLPNh6D2z4D5p23sP/SmpxuBxejWVCkQlWiWUohqIKxQaiHZj4rYdFH2GuZKoR9ScNjgUJXQXZg+4J111NDBMAqmp3z/UGJJN8s7uJ8nllBcB1HaIbWne/3E+rOoQ4XUGd7j/4/oY9pLkvYkNz39nzMgxyN1TkIUgD/jJKKQE3MPyp0g1pBzW436n72/Jx/c/tuZ2b1Z3FX5pauzV4WTbYK6dVsaLUA8tY5rM7olgp+zx5AMyocya99hL6vPGoK39C/AyKenrqQYLsnn4cA0QvuOdAtaXuICLhIHDuhCenOWdM/2Ct//mBfphkw+ndwq599vTkMmQiSQgsOCrl68p3857SZhlFqozobyYg+PZUG09R5PA0+C6DWsAoj8lw68TvostK+cEneOvbo8mQvG9zMkaGKb3y2Red3xpeADXmlXI3Y6AYPC+v5e0iiI0OVG9TcSHRiDYRYffUdPNc7Rb6qw3jsMZmphlCPzlpT05x6sE5U35I0Az9en9H1XLe4LwZxUxsIiU4ExIsz7fAdzjuoA9YM96FXB4UCAfDayciMO9XF5Z2TXpEM+8+gaDKOUL+63gyx1mCmLiYSGimIUQuPJUTs9bYx5YLSJOMCMdbn/Q4qEoKXsIbHiStPQlPnxsT2+wG9+MH6T23zEcpTjunmq0HKz91sIQIaVmpvTOxHcUDb83du3GduHIMkt3QnPCPbFZME5wu2hRYRUBlC5D/W1VkxHM1vTdLUgeGG5wMbR1dgNf8YCUihnlRdmCpx5EyvPNAVsV/Co3lIMwwlA5mm5niFE3jpcww95YRoe3L6Ub1t85+jeuR81hqVTirnaP2SQY9izupUHlWDqcZI0Twww73qUMsTTua0AHbBww3xg6rWCU2efPUmM+bI0da+/iVvVv/COWjwisvvxFmRkPSGjq/NoLKATPmrgFWyrlDMunvAjWScvMWuqfkcDp6b3N4ZsXcW4ji6WqHYvAfATdR50oLqDCpJP1JKXUlajNMpe1DsQ1JMb2mK0i2MyvXX+RkWDbPOjHaql/bCezNUvfv80+kb7z9IMZFLYgjZ+IRTioG8X1A+kar+9GBOxOZ2ih7i+QfPFgtX9q0M6rAZ5PxvXGkIrbak3iQ8ARdEsNR2wMhG2fMz+mc1ZSuGBis+RNzPsKFnWeFdybWZ6xBMeFK3eCcEQuXgEtxYwHdEW6+R+Rshf9W0vmf1W30ePZzNKMPj9D56io1gLW37ANHWT32KFDSJFlVmLiBJ+wqioiWUu0vRzaGLuDCexnruKRQkWERhHGKpKhYbEEQ2QsBC754hxxjBDQIG0WD9gpLaR8+8v7e6NnzYBfyMuCZA5DUcQTseofNyIx+FDqx4VDvwtLw2u5SjtogJVpQkYvfIA0YMtg+EmjOo/x0SZ0vPjKWkJ13hJGBEzzHMcw880JYoN/JrqVCzz8d8wBnHYDwfRfI2uWQO8WxxfY+72iXrsRlVtnbeHfL0LowDiuRHPC7I/CcZ+wa5340+PTSGAJ3+7jP+oD9/NvELtyvubiPm5L4+Hjsx9Y+su/12LA1Pp0NQ4FHEoJgAUHXn4gjbeKsvZ0Lc2QpyFUPhK+ZL796sCh0pOLtRujICbDCZQ0W+6NamjVYN0GYX+8biLbyX6LO1FMi/0m4Qsq4XidVvZgp57EH/EDo/fIf4dhT7362htrq0W/BGLkNKCbBn2BuDenc5kmTVW3/0c8JQZ/u/sZlf6JpbeU6Hn0zwzdxduHZqGxRoJzYXpirOeJv8LPY8GFMwXu9hH5ZCz00bq4JfZUX+yPdgwiAG5COXBUJM4rHkNOHjAuZ4w9aQlEsGhOR+3pj7njpoCpXE0F2BXyMhZNWlOW9nXTrXB/pw0m3iWSP7zNj82k98LaqRYY9FSrllX9l+eg0gTvuOQw9TH6K58/2erRZkHWpuPBLQxYLECo+4QWB9u433MMfq6tTq3Oezjn7+eY/UA7E9lElLR+FcrmlHTTOUCAQQCNL5kfD9GAuLzO6aupLUpLLL1ErOd+j19Q5UEKGFgv+fmagIwNd+4YDBaeVx3iU6iacUxgCzwTclBFukxKvxSG+92RKdQz1anyGC12hKDD4Y2qEkBOjIOCeCGRHyQ7OB4VdcuIKmcZh2/Oi1emkGCqUXL8g4o2hDruCvnFngCySTmk50KJY2pbt5SooXgPkjznJGwu711diFBM2nSSAEgenl+1Anc0Mv0qyKLpErPBlueGiwt1Exix5xtrN8oCp1O1UZ8O11msxEMeC5ZxgLxoyi6pAb2YENk2M51fRbxbIZMyHJp8IcRr/LH3yvsCg1wGXRNf8afTSeNEKp5aCOiba1ChCxgGIS2haQYNi2+8UEklHcy2Y6tMnhoCsWsFgWBsDhNzB+o6KpmtuxbR1hzNKPiJ5pTGnwu56xAEi88BmyprF1C5k/5TLcAZqvj2S9V1aAVf7B+iZlo3UFfMIHSQfLn6wTcXuth4wV8PrdJl6mHzwdxKCy8DqtdPxRixRMkF0+nRr4hn7O49WtQki5U6LW8LLlilc6zkQu5Hg3xUuIf2VnRCmNw03WogIMyF31pJP94rfGHb/5D8bMu+9MnXelRf7g8WBryFllbqLUzSLc8YzqqhooKHULnPBcp11HI2MXxL6LslPS670lLtk6rcUr1DOuEs8XKVinWF/BYxhy3BBOAnUwl73nFKf/hS95etAZw7ovZ5Q1TPVQ/EI9g1OWsEFqqoSHCwhDQ/0WNhy4Ttih4ZiRh+8tJn1HeGD0jDJ1DvX3hmTTp94PfLRM81IxkSNLYNqvhedKNr7jG7nZ84rBGvDPO00DhdDe/DLck8mDh7jnlWWJkAUqH9PjEZ5ZIXgfG4brxMrURykVdp8bDjYb0Hjx3L329sXeg6nT/KYwL20tLS2Hrvh+gFvyFXQcTDAS91ZgSxPpk74Sfexh5UFRgIE+9m5runTe0JYVd0X9+vFt8mY21Z+U1Zd/RjxEPhYnxAc2z9sHfI1ZXDiUhV4OUMgg1fQBPymsaI0Km/AOoOl104GOmXQMNXx90DQ9NTin1i8CFJnvKc+1N5SMaxNklSQSfLAOeUfPeLYnm5I9fxVmhn6CyWWsVGTCDQnFa1+pMINoob+t0RkZtNp9jyh9h3g7Fq05Q2pgfTxSFu9j4nP08vyqN7m6ySzx7yidFUhiV343uKV0cekxYi6v7wgOogM1C6js0BY7aFvp0fhk9lM6iKRg7r9BtxlNoxXJWKuY5rlWz3A88obGVze37oJpDT9zsFAqSPDeydj02g/iR2OqbatulSAZ2nZWedXyVMJQj/uF7KvnQbUfezz+Ze/UqTbxWj96y5WXV/JG1gOpqCRGCyXXeh2JuZzgiZ2zkOKLde8rJQflzKVDufgQwlAUVhaRWOvAHMjgneQr+ljMQ8l9MtX82cca0P//HMBov+X6F8nud6dXtWOjbybN69q+lA8bCzGh/LrOyPpmzHGcu0RX9/F4f440XKHwmQSEyuYTKpKM42FG8UvxSUwQv5v5iUtA33HdSN8Q+iSzbhu1w80MQrBR/5ML4JMGSlqZuj2VKUnb0JdgXrbTaDWe8khnvV3N2eJHnfamJcyQlQtlWYsslUAvz1pH0Nz/R1t3aydLfhDJYugx+Lip3BQnLfWMnSMqg7YlOMoTHxHY4sDfyd3+Hx6rR+1TMVeWd1b+cqZDgwxtui+nMsg5DbNS6zJhhJUeEc+d9HONpF9Zm6l+TnOBcUyRXrMOj4nqsxreWG5y6bwHA/mchg27zxf8ZFHfhVpcXP88Sl5S3ym5kkGhmDQ/xpIV6RA8t/Tx4cGvezUbNrJSooyWWTMfkCYfzBQrp29ZKn2SY4+xm7/Idcyp7EgbsyhrpN+jEZoi8TuR73ilFqcu6OzZTK6F1t0uFIgQVeKuG6FosWX14qktl/wzHNjJ9FJ5k9og+2vzv46tnNi3JaLO/qhlU/7zddblrOlj9g06qz+5xdpsh7SLGl1E+p4oI/AuQHiznvy9J4KH88b2724OYSW9JmdwquDOx49NQ990HxgbDgDNAzUEIJFAHbpQbkkCtHgsA+akNslSVeXB1pve8ng++qVtimNeHwmhh5E1hsX6XAuwOdm+vPypXJEPRYC0HjSijznqXvGx5zJaaacSIpxgqbe8IAVQ5SZDLXOljsPq1xZWQLqzAymevKnHq70UgjXJ5qEsp8BG5OXug69CqCm+9hKzr5F+I+DEw8E6M3ARg6Yjsv3rCBjSyw53uM5QuxNlsLGNeWDitOVnPY9r1Y303X3RKcJD5OQjFNvnYGZucjkTXI2dFeIJARNJ+D42KRzusXyFTEWZXg+SW42LDfS04FUxpgPWcAnF/6CNNlGIVnY5qJoN5VuyRg5tOz6GX0zTFnWocE06i5MrqnSHxxCWSl5GNC0W/6W8T582Cw0MXFAhfx0h0YeKqpnt3tNoDyiaHHmjMQxoHBjdDzqT7XCTTUUGgn5GKq4bJDRCuLZuOwk56le5UkhkGwiwv9yyZ7crM++jW8vAYJcDBzx3FiGe++SjwhIL1OMDrcB2y3GxoYYK1xSU8YI5U8/2rf0aaLQ70oCBvA5wZ4n0KV33hC6OGWUbIWDHs/19eY7Uy+JlNiGLImWjv9i+gf1sU0d3RYiJveC2uACwkQUypNmlS9Oc2f24EaIOLd8tNYCEfF2YqKzhsSQlR4i0jbbciZT8ZYxv5wIhlZr/ipKOd8hsZuEtOc3pUHVSHxoItqXGG++CIJzOqHX2BSVeLvFwVYthNCnMlwpRwdXX5JClIp8KLzuwi7WtPu1RycWNnz81UM1QM15SEv2QIdoy5DFMIaRTdJ6LMBKlFhtm06bDpxYVWq3FQBAhsr3N5I80vCus2OvLsmEKSBRca0/1VkKeJYjQd6W7d9ZmhuhQmT41tgtWnCZqHxpaQyV2glu7Hy0C9ywiMtLn4037lwCtEAuzFnvMxz71GTkdvgbsWPBXXqJEkyQx4Jc5Z7KUnuF1ZeiqRy5sMCJGvL4L243IPTLp177AOxpNjUhRWJe2Tp83y0zPFFfyYnecBPlDNH7mD/L6ZS611C797xZHkTOyhPNCKZlhr26hYuxtO6JXpiXDqYzkaXePwsc5FvRe+y7exf7nq72nFcCH4D+QjdUShDuST1D4HXin/50I5z/tk4vJVVF2u7kZzxfcjKrX+mtONKgzTm9n9TI9jcH751fhTLyFpwsNY3s/C3t65czouJZFK+TvkLXaVA0bToxV+FztxLXtcB0zzdPzGscBTBHra5GSjN9jHuUj6b7EHPsiDb/O8NKUHAfCV55TDhGkmKVTTz8qwANkCSsnuK/g5aBnASC4pzFS7d1j49oiFXxshOemrg3T5nAAW542yKWrYimpuEDXV/ONZxNuXs8lb/V0co6yoQwG0uKFVi03hQjxIkDKrdz0lIu9XDwf4BvJZyh0Zs34gvuYqRGDtL+uH6LqzYHLB08gtMr/Lz30xb9kox+5rsO70iY5IjgkRBqY2F+HfFj9h6miXvfhc4jpHM6DTOfv+tw8CcEdC67YkVAZ6ge1/6OXErgkbuIxRVYnF9Bruk08Rh0DY3zNWBfJ6OfEP7ESQW4z/wOy9q31UPa4V963aqJRjn+mx5tCq9BbPOCjDvOpr35IwZmqZcD3a0vuSDQwIArjRuDrVGMKqUfCYFdIn8IFUKDjOY6ivJhhRKQlItrkK//ZxjGwRsHcAZf6+SdNqnOWjI6rFiLsOyI+940RcP+LdXD6poEMVff0fpPLG7kBejtjHJ35cBL0f59V/18hnXaWG1STUxfWMkYOUqHetOt0jbEg6OZWkVjTCz9HmvCpZ3GK9XyLcAUcmsPIzF+U4mnsf0CfdM29OEcHpsouMEKbMGSrnDYRyVrm4zG3wh518ZW+dVb7KknpXxpkSeTuY0Jz4mv6RgM2uflGCSkBRUTRNhTmCGhx7ClVN6aoKGWpEwGIw3BS8nhS4lNI7IJiLbOK+dvoO0vNkCZBS8RoINMqokZ1qlcJXv3+8yQE8SDz48BBgsU97uLkHKoadgPup8/mbYUx56o2J+3CyUUsWfOZT6sPgFH99LorXfE80WeYNOqqXtbDsJfxy+XY19C9x/j8YNL40rN2FT3LuOolDiz9vuB1WbA75wd2G8gss8P8Wzfj7uGroF4QfvvkIhKcMGg+Hmcv4ksS2racDaNWfXc8Z7QDztbXmlr8KL9LtWc8TWFhzmPdfm+f15j3kuI+9Qi9nZePzZHIIQu/xk8IElWv+FCsKCuoGkV+j2IjmqIO/f46KUOujI0nIO9Fe1De6WoAqM/MFpZSxEzuS598NGMdA3JSamJaLt+geDiq5hJV9vEothbhvunQLRW8JadZimLaOPi6H2DEquapcf0Y8fSyMNQasf1BM8PSJpzJlxxnh/rs95g7DSFBUj0EIJNttxThZRG8FJ+fh+YUGz0mudX3Wy9ePluLDODCCOBJgOKBRNEuehNKAWWABVWfNj/5nHJKw/MItIah2FzZvQY8wT7R3bgahaOeHesEF0hldZmJJol/QvUJNfm9NGF01gC4vHq0FAvup+GA7Ufq5UxdKy1cWEncfZPNdgBLGwHTevSXlh7rPFG5HoAqewf4EbtIup6bG0Ep/cUaxiGLkg9NY1zHVp+bI4LGQa0jlOmnbKqRM10qocQw8Xp1WVW7gPrW9vSCaxjXpM3eUsHnoUYaZQdmssKhWFb4BuIl46sbF827WXTIzYWm051xtkivssmMplKeywUhqZsMgEWz+cPDlzTqZB7HsvgJ5a6IqUWcgfJfP5OdMG2tF7hbaiEcbuOuQzPSaf9MwPw8NqUNJOqULz+70eDdN4eNhGVjXy4bNZPdp0LyNqP0DYn9ITyArjO+2e23zmSus/2ADIMwn2UTMsumZlcB0vPcyI52/GOP4ABKHhwTYELkKuficFdsdxD7VhAh0+tcdXPIbDk9r0/He6XPL3/bGNFm3FIJh5zYkeV7j1FANLs65SQqZJyc1iz77yQvxBpVKGa3uJTa/jOrUAHdrlcFUaImfNDPLdYfszARm1E+ZHoL8mtzc9HhUfjUrAj17Q4DvEZalnq2hgfhjG9bqcYOMGdo+48LomHmddvTjwR/EuL2FHmSlK6CNqNRcKnN9JWy7usnn+OTQtajJ1X7FcYijhm2HT+nKLhTnQWHGXNBfb4HLSNF0yRtWHBjU2YZbWQWN/PMIQ0bUlzpgK8oxDg9o',
        '_ifr_': 'false',
        '_isfl_': 'false'
    });
    var gsodar = document.createElement('script');
    gsodar.type = 'text/javascript';
    gsodar.async = true;
    gsodar.src = '//ep2.adtrafficquality.google/sodar/VFc2VJAc.js';
    var s = document.getElementsByTagName('script')[0];
    s.parentNode.insertBefore(gsodar, s);
})();
! function() {
    try {
        var t = "u" > typeof window ? window : "u" > typeof global ? global : "u" > typeof globalThis ? globalThis : "u" > typeof self ? self : {};
        t._sentryModuleMetadata = t._sentryModuleMetadata || {}, t._sentryModuleMetadata[(new t.Error).stack] = function(t) {
            for (var e = 1; e < arguments.length; e++) {
                var n = arguments[e];
                if (null != n)
                    for (var i in n) n.hasOwnProperty(i) && (t[i] = n[i])
            }
            return t
        }({}, t._sentryModuleMetadata[(new t.Error).stack], {
            "_sentryBundlerPluginAppKey:crazygames-portal": !0
        });
        var e = (new t.Error).stack;
        e && (t._sentryDebugIds = t._sentryDebugIds || {}, t._sentryDebugIds[e] = "62bdabd3-2100-4034-a0eb-3ac9f521ae55", t._sentryDebugIdIdentifier = "sentry-dbid-62bdabd3-2100-4034-a0eb-3ac9f521ae55")
    } catch (t) {}
}(), (self.webpackChunk_N_E = self.webpackChunk_N_E || []).push([
    [6847], {
        6847: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => g
            });
            var i = n(6029),
                a = n(75155),
                r = n(55729),
                o = n(98417),
                u = n(50212),
                s = n(89922),
                l = n(52461),
                c = n(69395),
                d = n(27642),
                _ = n(44162),
                m = n(74914),
                h = n(29256),
                y = n.n(h);
            let b = r.memo(t => {
                    let e, n, r, u, s, c, _, m = (0, a.c)(30),
                        {
                            game: h,
                            clickOrigin: y,
                            width: b,
                            loading: g,
                            enableInstantJoin: B,
                            thumbClickFn: z,
                            thumbIcon: I,
                            thumbIconClickFn: f,
                            thumbLongPressFn: T,
                            thumbStatusOverlayFn: p,
                            thumbDimmedFn: G,
                            removeThumbLabels: v
                        } = t,
                        w = g || h.loading;
                    return m[0] !== h || m[1] !== z ? (e = (0, o.O)(z) ? t => z(h, t) : void 0, m[0] = h, m[1] = z, m[2] = e) : e = m[2], m[3] !== h || m[4] !== p ? (n = p ? .(h), m[3] = h, m[4] = p, m[5] = n) : n = m[5], m[6] !== h || m[7] !== G ? (r = G ? .(h), m[6] = h, m[7] = G, m[8] = r) : r = m[8], m[9] !== h || m[10] !== T ? (u = (0, o.O)(T) ? () => T(h) : void 0, m[9] = h, m[10] = T, m[11] = u) : u = m[11], m[12] !== h || m[13] !== f ? (s = (0, o.O)(f) ? () => f(h) : void 0, m[12] = h, m[13] = f, m[14] = s) : s = m[14], m[15] !== B || m[16] !== h || m[17] !== v || m[18] !== w || m[19] !== e || m[20] !== n || m[21] !== r || m[22] !== u || m[23] !== s || m[24] !== I || m[25] !== b ? (c = (0, i.jsx)(d.A, {
                        removeThumbLabels: v,
                        game: h,
                        width: b,
                        loading: w,
                        enableInstantJoin: B,
                        customOnClick: e,
                        icon: I,
                        statusOverlay: n,
                        dimmed: r,
                        longPressFn: u,
                        iconFn: s
                    }), m[15] = B, m[16] = h, m[17] = v, m[18] = w, m[19] = e, m[20] = n, m[21] = r, m[22] = u, m[23] = s, m[24] = I, m[25] = b, m[26] = c) : c = m[26], m[27] !== y || m[28] !== c ? (_ = (0, i.jsx)(l.x, {
                        newClickOrigin: y,
                        children: c
                    }), m[27] = y, m[28] = c, m[29] = _) : _ = m[29], _
                }),
                g = t => {
                    let e, n, o, l, d, h = (0, a.c)(28),
                        {
                            games: g,
                            loading: z,
                            expectedSize: I,
                            enableInstantJoin: f,
                            customOrigin: T,
                            className: p,
                            overlapInOrientationChange: G,
                            thumbClickFn: v,
                            thumbIcon: w,
                            thumbIconClickFn: S,
                            thumbLongPressFn: k,
                            thumbStatusOverlayFn: M,
                            thumbDimmedFn: x,
                            containerWidth: C,
                            removeThumbLabels: A
                        } = t,
                        {
                            innerWidth: O
                        } = r.useContext(m.w),
                        E = (0, c.A)();
                    h[0] !== C || h[1] !== O || h[2] !== E ? (e = C ? Math.ceil(C / 3) : O ? E ? Math.ceil(O / 6) : Math.ceil(O / 3) : void 0, h[0] = C, h[1] = O, h[2] = E, h[3] = e) : e = h[3];
                    let L = e,
                        N = G && y().overlapInOrientationChange,
                        P = !!C && y().containerWidth;
                    return h[4] !== p || h[5] !== N || h[6] !== P ? (n = (0, u.A)(y().instantGridContainer, y().smallGrid, "underGameInstantGames", N, P, p), h[4] = p, h[5] = N, h[6] = P, h[7] = n) : n = h[7], h[8] !== I || h[9] !== g.length ? (o = 0 === g.length && (0, s.K)(I).map(B), h[8] = I, h[9] = g.length, h[10] = o) : o = h[10], h[11] !== T || h[12] !== f || h[13] !== g || h[14] !== z || h[15] !== A || h[16] !== v || h[17] !== x || h[18] !== w || h[19] !== S || h[20] !== k || h[21] !== M || h[22] !== L ? (l = 0 !== g.length && g.map((t, e) => t.loading ? (0, i.jsx)(_.A, {}, e) : (0, i.jsx)(b, {
                        game: t,
                        clickOrigin: T || "instantSmall",
                        width: L,
                        loading: z,
                        enableInstantJoin: f,
                        thumbClickFn: v,
                        thumbIcon: w,
                        thumbIconClickFn: S,
                        thumbLongPressFn: k,
                        thumbStatusOverlayFn: M,
                        thumbDimmedFn: x,
                        removeThumbLabels: A
                    }, t.slug)), h[11] = T, h[12] = f, h[13] = g, h[14] = z, h[15] = A, h[16] = v, h[17] = x, h[18] = w, h[19] = S, h[20] = k, h[21] = M, h[22] = L, h[23] = l) : l = h[23], h[24] !== n || h[25] !== o || h[26] !== l ? (d = (0, i.jsxs)("div", {
                        className: n,
                        children: [o, l]
                    }), h[24] = n, h[25] = o, h[26] = l, h[27] = d) : d = h[27], d
                };

            function B(t) {
                return (0, i.jsx)(_.A, {}, t)
            }
        },
        20583: (t, e, n) => {
            "use strict";
            n.d(e, {
                P: () => a
            });
            var i = n(55729);

            function a(t) {
                let {
                    isScrolling: e,
                    content: n,
                    onScrollStart: a
                } = t, r = i.useRef(null), o = i.useRef(null), u = i.useRef(null), s = i.useEffectEvent(t => a ? .(t));
                return i.useEffect(() => {
                    let t = r.current,
                        n = o.current;
                    if (!e || !t || !n) return void u.current ? .pause();
                    u.current ? .cancel(), u.current = null;
                    let i = n.offsetWidth - t.clientWidth,
                        a = window.matchMedia ? .("(prefers-reduced-motion: reduce)") ? .matches ? ? !1;
                    if (i <= 0 || a || "function" != typeof n.animate) return;
                    let l = i / 40 * 1e3,
                        c = 400 + l + 1e3 + l / 3,
                        d = "translateX(0)",
                        _ = `translateX(-${i}px)`;
                    u.current = n.animate([{
                        transform: d,
                        offset: 0
                    }, {
                        transform: d,
                        offset: 400 / c,
                        easing: "linear"
                    }, {
                        transform: _,
                        offset: (400 + l) / c
                    }, {
                        transform: _,
                        offset: (400 + l + 1e3) / c,
                        easing: "linear"
                    }, {
                        transform: d,
                        offset: 1
                    }], {
                        duration: c,
                        iterations: 1 / 0
                    }), s(400 + l + 1e3)
                }, [e, n]), i.useEffect(() => () => u.current ? .cancel(), []), {
                    containerRef: r,
                    textRef: o
                }
            }
        },
        20636: t => {
            t.exports = {
                czyButton: "InstantThumb_czyButton__ubL8Z",
                "czyButton--contained--purple": "InstantThumb_czyButton--contained--purple__vfjRW",
                "czyButton--contained--white": "InstantThumb_czyButton--contained--white__yOp6P",
                "czyButton--contained--grey": "InstantThumb_czyButton--contained--grey__AhrTO",
                "czyButton--contained--warning": "InstantThumb_czyButton--contained--warning__XQhrE",
                "czyButton--contained--alert": "InstantThumb_czyButton--contained--alert__8rzJ1",
                "czyButton--contained--success": "InstantThumb_czyButton--contained--success__vM2GU",
                "czyButton--contained--black": "InstantThumb_czyButton--contained--black__LdICL",
                "czyButton--contained--green-gradient": "InstantThumb_czyButton--contained--green-gradient__dGb1E",
                "czyButton--contained--animated-green-gradient": "InstantThumb_czyButton--contained--animated-green-gradient___ENAj",
                "scroll-gradient": "InstantThumb_scroll-gradient__4siXL",
                "czyButton--outlined--purple": "InstantThumb_czyButton--outlined--purple__gDiCm",
                "czyButton--link--purple": "InstantThumb_czyButton--link--purple__mjkXq",
                "czyButton--outlined--white": "InstantThumb_czyButton--outlined--white__svrrU",
                "czyButton--link--white": "InstantThumb_czyButton--link--white__wPxQg",
                "czyButton--outlined--grey": "InstantThumb_czyButton--outlined--grey__IN9yy",
                "czyButton--link--grey": "InstantThumb_czyButton--link--grey__Qzl0d",
                "czyButton--outlined--warning": "InstantThumb_czyButton--outlined--warning__66N23",
                "czyButton--link--warning": "InstantThumb_czyButton--link--warning__VV3Ts",
                "czyButton--outlined--alert": "InstantThumb_czyButton--outlined--alert__dyotE",
                "czyButton--link--alert": "InstantThumb_czyButton--link--alert__78Ty_",
                "czyButton--outlined--success": "InstantThumb_czyButton--outlined--success__1wjQy",
                "czyButton--link--success": "InstantThumb_czyButton--link--success__pK3Wl",
                "czyButton--outlined": "InstantThumb_czyButton--outlined__oJEBj",
                "czyButton--disabled": "InstantThumb_czyButton--disabled__b_kWZ",
                "czyButton--height50": "InstantThumb_czyButton--height50__26Vf2",
                "czyButton--height34": "InstantThumb_czyButton--height34__r_mba",
                "czyButton--height28": "InstantThumb_czyButton--height28__GoCCI",
                "czyButton--fullWidth": "InstantThumb_czyButton--fullWidth__tPdVe",
                "czyButton--headerIcon": "InstantThumb_czyButton--headerIcon___MaMM",
                "czyButton--headerIcon--desktop": "InstantThumb_czyButton--headerIcon--desktop__3_eab",
                "czyButton--headerIcon--mobile": "InstantThumb_czyButton--headerIcon--mobile__qOfsk",
                "czyButton--headerIcon--withLabel": "InstantThumb_czyButton--headerIcon--withLabel__SRlZ3",
                instantThumb: "InstantThumb_instantThumb__t4FWM",
                gameThumbArea: "InstantThumb_gameThumbArea__ktlqZ",
                smallThumbPlaceholder: "InstantThumb_smallThumbPlaceholder__rr8zB",
                smallThumbImage: "InstantThumb_smallThumbImage__L53rK",
                largeThumbPlaceholder: "InstantThumb_largeThumbPlaceholder__ZcWW5",
                gameNameContainer: "InstantThumb_gameNameContainer__Rn3SW",
                revealsOnHover: "InstantThumb_revealsOnHover__mycdJ",
                isLarge: "InstantThumb_isLarge__Giqu8",
                mainImage: "InstantThumb_mainImage__gx4FE",
                fadeOut: "InstantThumb_fadeOut__AKIfn",
                greyedOut: "InstantThumb_greyedOut__SqmPB",
                dimmed: "InstantThumb_dimmed__YagnZ",
                isSmall: "InstantThumb_isSmall__4EpNa",
                addHoverEffect: "InstantThumb_addHoverEffect__CNvK9",
                bottomContainer: "InstantThumb_bottomContainer__5Rp6S",
                thumbOverlay: "InstantThumb_thumbOverlay__3BZnK",
                thumbBlur: "InstantThumb_thumbBlur__PjSAe",
                gameBack: "InstantThumb_gameBack__LQPIU",
                statusOverlay: "InstantThumb_statusOverlay__mfo83",
                isVisible: "InstantThumb_isVisible__Gd__e",
                iconContainer: "InstantThumb_iconContainer__jNnJ4"
            }
        },
        27236: t => {
            t.exports = {
                scrollingGameName: "ScrollingGameName_scrollingGameName__Lfica",
                text: "ScrollingGameName_text__R5uvA"
            }
        },
        27642: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => A
            });
            var i = n(6029),
                a = n(55729),
                r = n(50212),
                o = n(15490),
                u = n(71024),
                s = n.n(u),
                l = n(4230),
                c = n(50293),
                d = n(48431),
                _ = n(34302),
                m = n(47883),
                h = n(90930),
                y = n(82638),
                b = n(37916),
                g = n(40369),
                B = n(81930),
                z = n(71684),
                I = n(47352),
                f = n(52711),
                T = n(99521),
                p = n(82207),
                G = n(75155),
                v = n(20583),
                w = n(27236),
                S = n.n(w);
            let k = t => {
                let e, n, a, o, u = (0, G.c)(12),
                    {
                        name: s,
                        isScrolling: l,
                        className: c
                    } = t;
                u[0] !== l || u[1] !== s ? (e = {
                    isScrolling: l,
                    content: s
                }, u[0] = l, u[1] = s, u[2] = e) : e = u[2];
                let {
                    containerRef: d,
                    textRef: _
                } = (0, v.P)(e);
                return u[3] !== c ? (n = (0, r.A)(S().scrollingGameName, c), u[3] = c, u[4] = n) : n = u[4], u[5] !== s || u[6] !== _ ? (a = (0, i.jsx)("span", {
                    ref: _,
                    className: S().text,
                    children: s
                }), u[5] = s, u[6] = _, u[7] = a) : a = u[7], u[8] !== d || u[9] !== n || u[10] !== a ? (o = (0, i.jsx)("div", {
                    ref: d,
                    className: n,
                    children: a
                }), u[8] = d, u[9] = n, u[10] = a, u[11] = o) : o = u[11], o
            };
            var M = n(20636),
                x = n.n(M);
            let C = s()(() => Promise.all([n.e(5869), n.e(82396), n.e(83582)]).then(n.bind(n, 83582)), {
                    loadableGenerated: {
                        webpack: () => [83582]
                    },
                    ssr: !1
                }),
                A = a.memo(t => {
                    let {
                        game: e,
                        width: n,
                        loading: u,
                        enableInstantJoin: s,
                        customOnClick: G,
                        icon: v,
                        iconFn: w,
                        longPressFn: S,
                        statusOverlay: M,
                        extraLabel: A,
                        dimmed: O,
                        addHoverEffect: E,
                        revealNameOnHover: L,
                        removeThumbLabels: N
                    } = t, {
                        game: P,
                        artworkId: V,
                        artworkExperimentId: j
                    } = (0, m.F)(e), R = (0, m.m)(), W = P.covers && P.covers["1x1"] ? P.covers["1x1"] : P.cover, {
                        gameService: F,
                        crazyAnalyticsService: D
                    } = a.useContext(z.A).services, H = a.useContext(l.A), [q, J] = a.useState(!1), [K, U] = a.useState(!1), Z = a.useRef(null), Q = a.useRef(null), X = a.useRef(!1), Y = a.useRef(null), $ = a.useRef(null), tt = a.useContext(y.g).addViewedGames, te = (0, g.Ay)(a.useContext(h.o)), [tn, ti] = a.useState(v), [ta, tr] = a.useState(!!v), [to, tu] = a.useState(!!v), [ts, tl] = a.useState(M), tc = a.useRef(null), [td, t_] = a.useState(!1), tm = a.useCallback(() => {
                        F.prefetchGameData(P, H)
                    }, [P, F, H]);
                    a.useEffect(() => {
                        let t;
                        return Z && Z.current && (t = Z.current, f.A.get().observe(Z.current, () => {
                            f.A.get().unobserve(t), tt(P.id, te), J(!0)
                        })), () => {
                            t && f.A.get().unobserve(t), Q.current && window.clearTimeout(Q.current), $.current && window.clearTimeout($.current), tc.current && window.clearTimeout(tc.current)
                        }
                    }, [P.id, tt, te]), (0, _.A)({
                        gameId: P.id,
                        artworkId: V,
                        artworkExperimentId: j,
                        enabled: q
                    });
                    let [th, ty] = a.useState(M);
                    M !== th && (ty(M), M && tl(M)), a.useEffect(() => {
                        if (tc.current && clearTimeout(tc.current), !M) return tc.current = setTimeout(() => tl(void 0), 350), () => {
                            tc.current && clearTimeout(tc.current)
                        }
                    }, [M]);
                    let [tb, tg] = a.useState(v);
                    if (v !== tb) {
                        tg(v);
                        let t = !!v;
                        ta === t ? (ti(v), tu(t)) : tu(!1)
                    }
                    a.useEffect(() => {
                        let t = !!v;
                        if ($.current && clearTimeout($.current), ta !== t) return $.current = setTimeout(() => {
                            ti(v), tr(t), requestAnimationFrame(() => {
                                requestAnimationFrame(() => tu(t))
                            })
                        }, 150), () => {
                            $.current && clearTimeout($.current)
                        }
                    }, [v, ta]), a.useEffect(() => {
                        let t = new IntersectionObserver(t => {
                            let [e] = t;
                            !K && e.isIntersecting && (U(!0), (0, c.xl)(H) || (0, o.requestIdleCallback)(tm))
                        });
                        return Z && Z.current && t.observe(Z.current), () => {
                            t.disconnect()
                        }
                    }, [Z, K, tm, H]);
                    let tB = (0, p.V)(P) || (0, d.JK)() && !!P.isDisabledInApp,
                        tz = () => {
                            Y.current = null, null !== Q.current && (clearTimeout(Q.current), Q.current = null)
                        },
                        tI = N ? P.gameThumbLabels ? .filter(t => !N.includes(t)) ? ? [] : P.gameThumbLabels,
                        tf = t => {
                            L && t_(!0), (0, c.xl)(H) && tm()
                        },
                        tT = t => {
                            L && t_(!1)
                        };
                    return (0, i.jsx)(I.A, {
                        className: "game-thumb-test-class",
                        slug: P.slug,
                        isInstantJoin: s && !!P ? .multiplayerOptions ? .supportsInstantJoin,
                        onClick: t => {
                            if (tz(), X.current) {
                                t.preventDefault(), t.stopPropagation(), X.current = !1;
                                return
                            }
                            G ? G(t) : D.sendClickOnGame(P.id)
                        },
                        onPointerDown: t => {
                            S && (X.current = !1, Y.current = {
                                x: t.clientX,
                                y: t.clientY
                            }, Q.current = setTimeout(() => {
                                X.current = !0, S()
                            }, 600))
                        },
                        onPointerMove: t => {
                            let e = Y.current;
                            !e || (Math.abs(t.clientX - e.x) > 10 || Math.abs(t.clientY - e.y) > 10) && tz()
                        },
                        onPointerUp: tz,
                        onPointerLeave: tz,
                        onPointerCancel: tz,
                        onMouseEnter: tf,
                        onMouseLeave: tT,
                        onFocus: tf,
                        onBlur: tT,
                        "data-testid": b.mx,
                        children: (0, i.jsxs)("div", {
                            ref: Z,
                            className: (0, r.A)(x().instantThumb, x().isSmall, tB && x().greyedOut, O && x().dimmed, E && x().addHoverEffect),
                            children: [tn && (0, i.jsx)("div", {
                                className: (0, r.A)(x().iconContainer, to && x().isVisible),
                                onClick: t => {
                                    if (t.preventDefault(), t.stopPropagation(), tz(), X.current) {
                                        X.current = !1;
                                        return
                                    }
                                    w && w(P.slug)
                                },
                                children: tn
                            }), (0, i.jsxs)("div", {
                                className: x().gameThumbArea,
                                children: [(0, i.jsx)("div", {
                                    className: x().smallThumbPlaceholder
                                }), (0, i.jsx)(C, {
                                    gameThumbLabels: tI,
                                    extraLabel: A
                                }), (0, i.jsx)(T.A, {
                                    game: P
                                }), n && !u && R && (0, i.jsx)("img", {
                                    src: (0, B.Ay)(W, {
                                        width: n
                                    }),
                                    width: n,
                                    height: n,
                                    srcSet: R ? (0, B.Wn)(W, {
                                        width: n
                                    }) : void 0,
                                    alt: P.name,
                                    className: x().smallThumbImage,
                                    onLoad: t => {
                                        let e = t.currentTarget;
                                        e.style.opacity = "1";
                                        let n = e.parentElement ? .querySelector(`.${x().smallThumbPlaceholder}`);
                                        n && (n.style.opacity = "0")
                                    }
                                }), ts && (0, i.jsx)("div", {
                                    className: (0, r.A)(x().statusOverlay, M && x().isVisible),
                                    children: ts
                                }), L ? (0, i.jsx)(k, {
                                    name: P.name,
                                    isScrolling: td,
                                    className: (0, r.A)(x().gameNameContainer, x().revealsOnHover)
                                }) : (0, i.jsx)("div", {
                                    className: x().gameNameContainer,
                                    children: P.name
                                })]
                            })]
                        })
                    })
                })
        },
        29256: t => {
            t.exports = {
                czyButton: "MobileInstantGrid_czyButton__BPqAJ",
                "czyButton--contained--purple": "MobileInstantGrid_czyButton--contained--purple__w0etW",
                "czyButton--contained--white": "MobileInstantGrid_czyButton--contained--white__r20_D",
                "czyButton--contained--grey": "MobileInstantGrid_czyButton--contained--grey__QS_MD",
                "czyButton--contained--warning": "MobileInstantGrid_czyButton--contained--warning__hgr_W",
                "czyButton--contained--alert": "MobileInstantGrid_czyButton--contained--alert__trqde",
                "czyButton--contained--success": "MobileInstantGrid_czyButton--contained--success__L3po5",
                "czyButton--contained--black": "MobileInstantGrid_czyButton--contained--black__ASquz",
                "czyButton--contained--green-gradient": "MobileInstantGrid_czyButton--contained--green-gradient__UxP1U",
                "czyButton--contained--animated-green-gradient": "MobileInstantGrid_czyButton--contained--animated-green-gradient__cP4bA",
                "scroll-gradient": "MobileInstantGrid_scroll-gradient__nC9gW",
                "czyButton--outlined--purple": "MobileInstantGrid_czyButton--outlined--purple__pzrDm",
                "czyButton--link--purple": "MobileInstantGrid_czyButton--link--purple__gKS6S",
                "czyButton--outlined--white": "MobileInstantGrid_czyButton--outlined--white__NYfCk",
                "czyButton--link--white": "MobileInstantGrid_czyButton--link--white__QPj96",
                "czyButton--outlined--grey": "MobileInstantGrid_czyButton--outlined--grey__TJOfO",
                "czyButton--link--grey": "MobileInstantGrid_czyButton--link--grey__iFIZg",
                "czyButton--outlined--warning": "MobileInstantGrid_czyButton--outlined--warning__OGK1_",
                "czyButton--link--warning": "MobileInstantGrid_czyButton--link--warning__8KYAr",
                "czyButton--outlined--alert": "MobileInstantGrid_czyButton--outlined--alert__p0ZiZ",
                "czyButton--link--alert": "MobileInstantGrid_czyButton--link--alert__iLVBr",
                "czyButton--outlined--success": "MobileInstantGrid_czyButton--outlined--success__V4Nhf",
                "czyButton--link--success": "MobileInstantGrid_czyButton--link--success__dgNxT",
                "czyButton--outlined": "MobileInstantGrid_czyButton--outlined__SqE9R",
                "czyButton--disabled": "MobileInstantGrid_czyButton--disabled__pArBJ",
                "czyButton--height50": "MobileInstantGrid_czyButton--height50__RFFB8",
                "czyButton--height34": "MobileInstantGrid_czyButton--height34__EsIZ6",
                "czyButton--height28": "MobileInstantGrid_czyButton--height28__OzmCb",
                "czyButton--fullWidth": "MobileInstantGrid_czyButton--fullWidth__GQsvG",
                "czyButton--headerIcon": "MobileInstantGrid_czyButton--headerIcon__qzI7L",
                "czyButton--headerIcon--desktop": "MobileInstantGrid_czyButton--headerIcon--desktop__KGRMI",
                "czyButton--headerIcon--mobile": "MobileInstantGrid_czyButton--headerIcon--mobile__w1AeD",
                "czyButton--headerIcon--withLabel": "MobileInstantGrid_czyButton--headerIcon--withLabel___QFy3",
                instantGridContainer: "MobileInstantGrid_instantGridContainer__xWykg",
                largeGrid: "MobileInstantGrid_largeGrid__w6Gzy",
                emptyGames: "MobileInstantGrid_emptyGames__T4A_e",
                overlapInOrientationChange: "MobileInstantGrid_overlapInOrientationChange__6XxLX",
                mediumGrid: "MobileInstantGrid_mediumGrid__U63dS",
                smallGrid: "MobileInstantGrid_smallGrid__U48s2",
                containerWidth: "MobileInstantGrid_containerWidth__IeaiO"
            }
        },
        34302: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => u
            });
            var i = n(75155),
                a = n(55729),
                r = n(71684),
                o = n(82638);

            function u(t) {
                let e, n, u, s, l = (0, i.c)(10),
                    {
                        gameId: c,
                        artworkId: d,
                        artworkExperimentId: _,
                        enabled: m
                    } = t,
                    h = void 0 === m || m,
                    {
                        services: y
                    } = (0, a.useContext)(r.A),
                    {
                        pageType: b
                    } = (0, a.useContext)(o.g),
                    g = (0, a.useRef)(b);
                l[0] !== b ? (e = () => {
                    g.current = b
                }, n = [b], l[0] = b, l[1] = e, l[2] = n) : (e = l[1], n = l[2]), (0, a.useEffect)(e, n), l[3] !== _ || l[4] !== d || l[5] !== h || l[6] !== c || l[7] !== y ? (u = () => {
                    h && y.crazyAnalyticsService.sendArtworkVersion(c, d, _, g.current)
                }, s = [y, c, d, _, h], l[3] = _, l[4] = d, l[5] = h, l[6] = c, l[7] = y, l[8] = u, l[9] = s) : (u = l[8], s = l[9]), (0, a.useEffect)(u, s)
            }
        },
        37916: (t, e, n) => {
            "use strict";
            n.d(e, {
                GE: () => c,
                Is: () => _,
                RV: () => d,
                Th: () => u,
                VI: () => m,
                ZZ: () => r,
                hv: () => s,
                mx: () => a,
                oL: () => o,
                rv: () => l,
                y7: () => i
            });
            let i = "instant-large-thumb",
                a = "instant-small-thumb",
                r = "mobile-recommended-module",
                o = "category-carousel-",
                u = "carousel-featured",
                s = "carousel-new-games",
                l = "carousel-originals",
                c = "carousel-recommended",
                d = "promotional-offline-content-card",
                _ = "carousel-offline-downloads",
                m = "debug-pill"
        },
        44162: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => a
            });
            var i = n(6029);
            let a = n(55729).memo(() => (0, i.jsx)("div", {
                style: {
                    width: "100%",
                    borderRadius: 16,
                    position: "relative",
                    overflow: "hidden",
                    aspectRatio: "186 / 237",
                    background: "var(--black-60)"
                }
            }))
        },
        47352: (t, e, n) => {
            "use strict";
            n.d(e, {
                G: () => l,
                A: () => d
            });
            var i = n(6029),
                a = n(55729),
                r = n(93389),
                o = n(13246),
                u = n(43711),
                s = n(51196);
            let l = "instantJoin";

            function c(t, e, n) {
                if (URL.canParse(t.href)) {
                    let i = new URL(t.href);
                    return i.searchParams.set(e, n), {
                        href: i.toString()
                    }
                }
                let i = new URL(t.href, "https://temporary-fallback.internal");
                return i.searchParams.set(e, n), {
                    href: i.pathname + i.search + i.hash
                }
            }
            let d = a.forwardRef((t, e) => {
                let {
                    routeHelper: n
                } = a.useContext(r.A), {
                    pageUrlHelper: d
                } = a.useContext(s.e), {
                    slug: _,
                    isKids: m,
                    className: h,
                    isInstantJoin: y,
                    launchSource: b,
                    children: g,
                    ...B
                } = t;
                if (m) {
                    let t = {
                        href: `${o.A.Instance.data.kids}/game/${_}`,
                        rel: "external nofollow",
                        target: "_blank"
                    };
                    return (0, i.jsx)("a", { ...t,
                        className: h,
                        ...B,
                        ref: e,
                        children: g
                    })
                }
                let z = n.gamePageLink(_);
                y && (z = c(z, l, "true")), b && (z = c(z, "launchSource", b));
                let I = d.isGamePage() && d.getGameParams().game;
                return (0, i.jsx)(u.A, { ...z,
                    className: h,
                    ...B,
                    shallow: I === _,
                    ref: e,
                    prefetch: !0,
                    children: g
                })
            })
        },
        47883: (t, e, n) => {
            "use strict";
            n.d(e, {
                F: () => u,
                m: () => s
            });
            var i = n(75155),
                a = n(55729),
                r = n(20579),
                o = n(76226);

            function u(t) {
                let e, n = (0, i.c)(3),
                    u = (0, a.useContext)(r.A);
                return n[0] !== u || n[1] !== t ? (e = (0, o.u)(t, u), n[0] = u, n[1] = t, n[2] = e) : e = n[2], e
            }

            function s() {
                let {
                    isBucketIdReady: t,
                    isCrawler: e
                } = (0, a.useContext)(r.A);
                return e || t
            }
        },
        52711: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => r
            });
            let i = {
                    errorMargin: .05,
                    percentCompensation: .2,
                    minTimeVisible: 250,
                    config: {
                        root: null,
                        rootMargin: "0px",
                        threshold: .75
                    }
                },
                a = null;
            class r {
                static get() {
                    return a && a instanceof r ? a : a = new r(i)
                }
                constructor(t) {
                    this.reportVisibilityStates = () => {
                        this.elements.forEach((t, e) => {
                            let {
                                visible: n
                            } = t;
                            n && this.onVisibilityChange(e, n)
                        })
                    }, this.watchElements = t => {
                        let e = window.innerHeight || document.documentElement.clientHeight;
                        t.filter(t => t.isIntersecting).forEach(t => {
                            let n = t.target,
                                i = this.elements.get(n);
                            if (!i) return;
                            let a = (t.boundingClientRect || n.getBoundingClientRect()).height,
                                r = this.isElementHeightSimilarToContainer(a, e) ? this.options.errorMargin : .025,
                                o = e / a > 1 ? 1 - r : e / a - r,
                                u = t.intersectionRatio >= o;
                            if (!u || !i.timeoutSet)
                                if (u) i.timeoutSet = !0, this.timeouts.set(n, setTimeout(() => {
                                    this.onVisibilityChange(n, !0)
                                }, this.options.minTimeVisible));
                                else {
                                    let t = this.timeouts.get(n);
                                    this.onVisibilityChange(n, !1), clearTimeout(t), this.timeouts.delete(n), i.timeoutSet = !1
                                }
                        })
                    }, this.observe = (t, e) => {
                        if (t && e) {
                            this.elements.set(t, {
                                callback: e,
                                visible: !1,
                                entry: t,
                                timeoutSet: !1
                            });
                            try {
                                t && this.observer.observe(t)
                            } catch (t) {
                                console.log(t)
                            }
                        }
                    }, this.unobserve = t => {
                        !t || this.elements.get(t) && (this.observer && this.observer.unobserve(t), this.elements.delete(t), 0 === this.elements.size && this.destroy())
                    }, this.options = Object.assign({}, i, t), (isNaN(this.options.minTimeVisible) || this.options.minTimeVisible < 0) && (this.options.minTimeVisible = i.minTimeVisible), this.elements = new Map, this.timeouts = new Map, this.observer = new IntersectionObserver(this.watchElements, this.options.config), window.addEventListener("focus", this.reportVisibilityStates), window.addEventListener("orientationchange", this.reportVisibilityStates)
                }
                removeEventListeners() {
                    window.removeEventListener("focus", this.reportVisibilityStates), window.removeEventListener("orientationchange", this.reportVisibilityStates)
                }
                destroy() {
                    return this.elements.clear(), this.timeouts.clear(), this.observer && "function" == typeof this.observer.disconnect && this.observer.disconnect(), this.removeEventListeners(), a = null
                }
                isElementHeightSimilarToContainer(t, e) {
                    return t >= e - e * this.options.percentCompensation && t <= e + e * this.options.percentCompensation
                }
                onVisibilityChange(t, e) {
                    if (!t) return;
                    let n = this.elements.get(t);
                    if (!n) return;
                    n.visible = e;
                    let {
                        callback: i
                    } = n;
                    "function" == typeof i && i(e)
                }
            }
        },
        56732: t => {
            t.exports = {
                czyButton: "GameThumbShared_czyButton__K2r3h",
                "czyButton--contained--purple": "GameThumbShared_czyButton--contained--purple__gOHDR",
                "czyButton--contained--white": "GameThumbShared_czyButton--contained--white___f21U",
                "czyButton--contained--grey": "GameThumbShared_czyButton--contained--grey__7NVUu",
                "czyButton--contained--warning": "GameThumbShared_czyButton--contained--warning__ZV7n9",
                "czyButton--contained--alert": "GameThumbShared_czyButton--contained--alert__DIEu3",
                "czyButton--contained--success": "GameThumbShared_czyButton--contained--success__OjOwg",
                "czyButton--contained--black": "GameThumbShared_czyButton--contained--black__madd0",
                "czyButton--contained--green-gradient": "GameThumbShared_czyButton--contained--green-gradient__cjuIN",
                "czyButton--contained--animated-green-gradient": "GameThumbShared_czyButton--contained--animated-green-gradient__w1LMs",
                "scroll-gradient": "GameThumbShared_scroll-gradient__V_ok0",
                "czyButton--outlined--purple": "GameThumbShared_czyButton--outlined--purple__ikmMq",
                "czyButton--link--purple": "GameThumbShared_czyButton--link--purple__DGk4d",
                "czyButton--outlined--white": "GameThumbShared_czyButton--outlined--white__uVQl4",
                "czyButton--link--white": "GameThumbShared_czyButton--link--white__qSIfD",
                "czyButton--outlined--grey": "GameThumbShared_czyButton--outlined--grey__snDVh",
                "czyButton--link--grey": "GameThumbShared_czyButton--link--grey__govPt",
                "czyButton--outlined--warning": "GameThumbShared_czyButton--outlined--warning__1e2rl",
                "czyButton--link--warning": "GameThumbShared_czyButton--link--warning__Hpkvr",
                "czyButton--outlined--alert": "GameThumbShared_czyButton--outlined--alert__HAVus",
                "czyButton--link--alert": "GameThumbShared_czyButton--link--alert__PzAL0",
                "czyButton--outlined--success": "GameThumbShared_czyButton--outlined--success__8Wjbd",
                "czyButton--link--success": "GameThumbShared_czyButton--link--success__aPHVh",
                "czyButton--outlined": "GameThumbShared_czyButton--outlined__Ko3Xz",
                "czyButton--disabled": "GameThumbShared_czyButton--disabled__GQxUO",
                "czyButton--height50": "GameThumbShared_czyButton--height50__YtENe",
                "czyButton--height34": "GameThumbShared_czyButton--height34__xQzVa",
                "czyButton--height28": "GameThumbShared_czyButton--height28__UuO7r",
                "czyButton--fullWidth": "GameThumbShared_czyButton--fullWidth__LRxDR",
                "czyButton--headerIcon": "GameThumbShared_czyButton--headerIcon__erVgQ",
                "czyButton--headerIcon--desktop": "GameThumbShared_czyButton--headerIcon--desktop__BNWS_",
                "czyButton--headerIcon--mobile": "GameThumbShared_czyButton--headerIcon--mobile__bIjoS",
                "czyButton--headerIcon--withLabel": "GameThumbShared_czyButton--headerIcon--withLabel__5cfYt",
                gameThumbImage: "GameThumbShared_gameThumbImage__7EHHi",
                greyedOut: "GameThumbShared_greyedOut__xjzF_",
                gameThumbImagePositioned: "GameThumbShared_gameThumbImagePositioned__LJJut",
                imageSkeleton: "GameThumbShared_imageSkeleton__zpuJx",
                bottomLabelContainer: "GameThumbShared_bottomLabelContainer__4Ci6k",
                videoPlaying: "GameThumbShared_videoPlaying__lZYid",
                closeBtnContainer: "GameThumbShared_closeBtnContainer___ON_O",
                greyedOutOverlay: "GameThumbShared_greyedOutOverlay__bZlW3",
                labelContainer: "GameThumbShared_labelContainer__6tS_1",
                skeleton: "GameThumbShared_skeleton__csN4D",
                skeletonCarouselMargin: "GameThumbShared_skeletonCarouselMargin__KoXs_"
            }
        },
        82207: (t, e, n) => {
            "use strict";
            n.d(e, {
                Q: () => o,
                V: () => r
            });
            var i = n(50293);
            let a = ["UNAVAILABLE", "ARCHIVED"],
                r = t => void 0 !== t.status && a.includes(t.status),
                o = (t, e) => {
                    let n = t.androidFriendly && !t.iosFriendly,
                        a = t.iosFriendly && !t.androidFriendly;
                    return (0, i.m0)(e) && a || (0, i.aR)(e) && n
                }
        },
        89922: (t, e, n) => {
            "use strict";

            function i(t) {
                let e = Array(t);
                for (let t = 0; t < e.length; t++) e[t] = t + 1;
                return e
            }

            function a(t, e) {
                let n = new Map;
                for (let i of t) {
                    let t = e(i);
                    n.has(t) ? n.get(t).push(i) : n.set(t, [i])
                }
                return n
            }
            n.d(e, {
                $: () => a,
                K: () => i
            })
        },
        99521: (t, e, n) => {
            "use strict";
            n.d(e, {
                A: () => h
            });
            var i = n(6029),
                a = n(75155),
                r = n(55729),
                o = n(79942),
                u = n(50212),
                s = n(50293),
                l = n(4230),
                c = n(82207),
                d = n(56732),
                _ = n.n(d);
            let m = t => {
                    let e, n, r = (0, a.c)(3),
                        {
                            trlId: s
                        } = t;
                    return r[0] === Symbol.for("react.memo_cache_sentinel") ? (e = (0, u.A)(_().greyedOutOverlay, "greyedOutOverlay"), r[0] = e) : e = r[0], r[1] !== s ? (n = (0, i.jsx)("div", {
                        className: e,
                        children: (0, i.jsx)("div", {
                            className: _().labelContainer,
                            children: (0, i.jsx)(o.x6, {
                                id: s
                            })
                        })
                    }), r[1] = s, r[2] = n) : n = r[2], n
                },
                h = t => {
                    let e = (0, a.c)(3),
                        {
                            game: n
                        } = t,
                        o = r.useContext(l.A);
                    if ((0, c.V)(n)) {
                        let t;
                        return e[0] === Symbol.for("react.memo_cache_sentinel") ? (t = (0, i.jsx)(m, {
                            trlId: "common.notAvailable"
                        }), e[0] = t) : t = e[0], t
                    }
                    if (!(0, s.xl)(o) && !(n.androidFriendly || n.iosFriendly)) {
                        let t;
                        return e[1] === Symbol.for("react.memo_cache_sentinel") ? (t = (0, i.jsx)(m, {
                            trlId: "common.computerOnly"
                        }), e[1] = t) : t = e[1], t
                    }
                    if ((0, c.Q)(n, o)) {
                        let t;
                        return e[2] === Symbol.for("react.memo_cache_sentinel") ? (t = (0, i.jsx)(m, {
                            trlId: "common.deviceNotSupported"
                        }), e[2] = t) : t = e[2], t
                    }
                    return null
                }
        }
    }
]);
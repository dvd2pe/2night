(function(stc) {
    var m, aa = typeof Object.create == "function" ? Object.create : function(a) {
            var b = function() {};
            b.prototype = a;
            return new b
        },
        ba = typeof Object.defineProperties == "function" ? Object.defineProperty : function(a, b, c) {
            if (a == Array.prototype || a == Object.prototype) return a;
            a[b] = c.value;
            return a
        },
        da = function(a) {
            a = ["object" == typeof globalThis && globalThis, a, "object" == typeof window && window, "object" == typeof self && self, "object" == typeof global && global];
            for (var b = 0; b < a.length; ++b) {
                var c = a[b];
                if (c && c.Math == Math) return c
            }
            throw Error("Cannot find global object");
        },
        fa = da(this),
        n = function(a, b) {
            if (b) a: {
                var c = fa;a = a.split(".");
                for (var d = 0; d < a.length - 1; d++) {
                    var e = a[d];
                    if (!(e in c)) break a;
                    c = c[e]
                }
                a = a[a.length - 1];d = c[a];b = b(d);b != d && b != null && ba(c, a, {
                    configurable: !0,
                    writable: !0,
                    value: b
                })
            }
        },
        ha;
    if (typeof Object.setPrototypeOf == "function") ha = Object.setPrototypeOf;
    else {
        var ia;
        a: {
            var ja = {
                    a: !0
                },
                ka = {};
            try {
                ka.__proto__ = ja;
                ia = ka.a;
                break a
            } catch (a) {}
            ia = !1
        }
        ha = ia ? function(a, b) {
            a.__proto__ = b;
            if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
            return a
        } : null
    }
    var la = ha,
        r = function(a, b) {
            a.prototype = aa(b.prototype);
            a.prototype.constructor = a;
            if (la) la(a, b);
            else
                for (var c in b)
                    if (c != "prototype")
                        if (Object.defineProperties) {
                            var d = Object.getOwnPropertyDescriptor(b, c);
                            d && Object.defineProperty(a, c, d)
                        } else a[c] = b[c];
            a.fd = b.prototype
        },
        ma = function(a) {
            var b = 0;
            return function() {
                return b < a.length ? {
                    done: !1,
                    value: a[b++]
                } : {
                    done: !0
                }
            }
        },
        u = function(a) {
            var b = typeof Symbol != "undefined" && Symbol.iterator && a[Symbol.iterator];
            if (b) return b.call(a);
            if (typeof a.length == "number") return {
                next: ma(a)
            };
            throw Error(String(a) + " is not an iterable or ArrayLike");
        },
        na = function(a) {
            if (!(a instanceof Array)) {
                a = u(a);
                for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
                a = c
            }
            return a
        },
        pa = function(a) {
            return oa(a, a)
        },
        oa = function(a, b) {
            a.raw = b;
            Object.freeze && (Object.freeze(a), Object.freeze(b));
            return a
        },
        v = function(a, b) {
            var c;
            b && !b.done && (c = a["return"]) && c.call(a)
        },
        qa = function() {
            for (var a = Number(this), b = [], c = a; c < arguments.length; c++) b[c - a] = arguments[c];
            return b
        };
    n("globalThis", function(a) {
        return a || fa
    });
    n("Symbol", function(a) {
        if (a) return a;
        var b = function(f, g) {
            this.yc = f;
            ba(this, "description", {
                configurable: !0,
                writable: !0,
                value: g
            })
        };
        b.prototype.toString = function() {
            return this.yc
        };
        var c = "jscomp_symbol_" + (Math.random() * 1E9 >>> 0) + "_",
            d = 0,
            e = function(f) {
                if (this instanceof e) throw new TypeError("Symbol is not a constructor");
                return new b(c + (f || "") + "_" + d++, f)
            };
        return e
    });
    n("Symbol.iterator", function(a) {
        if (a) return a;
        a = Symbol("Symbol.iterator");
        ba(Array.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return ra(ma(this))
            }
        });
        return a
    });
    n("Symbol.toStringTag", function(a) {
        return a ? a : Symbol("Symbol.toStringTag")
    });
    var ra = function(a) {
            var b = (typeof Iterator != "undefined" && Iterator.prototype && !Iterator.prototype.next ? Iterator.prototype : null) || Object.prototype,
                c = aa(b);
            c.next = a;
            b[Symbol.iterator] || (c[Symbol.iterator] = function() {
                return this
            });
            return c
        },
        sa = function(a, b) {
            return Object.prototype.hasOwnProperty.call(a, b)
        },
        ta = typeof Object.assign == "function" ? Object.assign : function(a, b) {
            if (a == null) throw new TypeError("No nullish arg");
            a = Object(a);
            for (var c = 1; c < arguments.length; c++) {
                var d = arguments[c];
                if (d)
                    for (var e in d) sa(d,
                        e) && (a[e] = d[e])
            }
            return a
        };
    n("Object.assign", function(a) {
        return a || ta
    });
    n("Iterator", function(a) {
        var b = Object.getPrototypeOf,
            c = typeof Symbol != "undefined" && Symbol.iterator && [][Symbol.iterator] ? [][Symbol.iterator]() : null;
        b = (c = c && b ? b(c) : null) && b ? b(c) : null;
        b === Object.prototype && (b = null);
        if (a && b && a.prototype === b) return a;
        var d = function() {
            if (!(this instanceof d) || this.constructor === d) throw new TypeError("Abstract Iterator not directly constructable");
        };
        b && (d.prototype = b);
        ba(d.prototype, "constructor", {
            configurable: !0,
            writable: !0,
            value: d
        });
        d.prototype[Symbol.iterator] || (d.prototype[Symbol.iterator] =
            function() {
                return this
            });
        return d
    });
    var ua = function(a) {
            if (Object(a) !== a) throw new TypeError("Expected an object");
            return a
        },
        va = function(a) {
            try {
                var b = a["return"];
                typeof b == "function" && b.call(a)
            } catch (c) {}
        },
        wa = function(a, b) {
            b == null && (b = !0);
            return {
                value: a,
                done: b
            }
        },
        ya = null,
        za = function(a, b) {
            var c = ya;
            if (!c) {
                var d = function(e, f) {
                    if (!e || e.cd !== e) throw new TypeError("Method called on incompatible object");
                    var g = e.xa;
                    if (g === 3) throw new TypeError("Generator is already running");
                    if (g != 4) {
                        e.xa = f && g == 1 ? 4 : 3;
                        try {
                            if (f) {
                                var h = e.Yb,
                                    k = h["return"];
                                if (k !=
                                    null) {
                                    if (typeof k != "function") throw new TypeError("Iterator return is not a function");
                                    ua(k.call(h))
                                }
                            } else {
                                var l = e.wc();
                                if (l) return e.xa = 2, l
                            }
                        } finally {
                            e.xa != 2 && (e.xa = 4, e.wc = e.Yb = null)
                        }
                    }
                    return wa()
                };
                c = ya = aa(Iterator.prototype);
                c.next = function() {
                    return d(this, !1)
                };
                c.return = function() {
                    return d(this, !0)
                };
                c[Symbol.toStringTag] = "Iterator Helper"
            }
            c = aa(c);
            c.cd = c;
            c.xa = 1;
            c.Yb = a;
            c.wc = b;
            return c
        },
        Da = function(a, b) {
            ua(a);
            if (typeof b != "function") throw va(a), new TypeError("callback must be a function");
        },
        Ea = function(a,
            b, c) {
            Da(a, b);
            var d = a.next,
                e = 0;
            return za(a, function() {
                for (;;) {
                    var f = ua(d.call(a));
                    if (f.done) break;
                    f = f.value;
                    try {
                        var g = b(f, e++)
                    } catch (h) {
                        throw va(a), h;
                    }
                    if (!c || g) return wa(c ? f : g, !1)
                }
            })
        };
    n("Iterator.prototype.map", function(a) {
        return a || function(b) {
            return Ea(this, b, !1)
        }
    });
    var Fa = function(a, b, c) {
        Da(a, b);
        b = a.next;
        for (var d = 0, e; !(e = ua(b.call(a))).done;) {
            try {
                var f = c(e.value, d++)
            } catch (g) {
                try {
                    v(a, e)
                } catch (h) {}
                throw g;
            }
            if (f) {
                c = a["return"];
                c != null && ua(c.call(a));
                break
            }
        }
    };
    n("Iterator.prototype.forEach", function(a) {
        return a || function(b) {
            Fa(this, b, function(c, d) {
                b(c, d)
            })
        }
    });
    n("Array.prototype.find", function(a) {
        return a ? a : function(b, c) {
            a: {
                var d = this;d instanceof String && (d = String(d));
                for (var e = d.length, f = 0; f < e; f++) {
                    var g = d[f];
                    if (b.call(c, g, f, d)) {
                        b = g;
                        break a
                    }
                }
                b = void 0
            }
            return b
        }
    });
    n("Iterator.prototype.find", function(a) {
        return a || function(b) {
            var c;
            Fa(this, b, function(d, e) {
                if (b(d, e)) return c = d, !0
            });
            return c
        }
    });
    n("WeakMap", function(a) {
        function b() {}

        function c(k) {
            var l = typeof k;
            return l === "object" && k !== null || l === "function"
        }

        function d(k) {
            if (!sa(k, f)) {
                var l = new b;
                ba(k, f, {
                    value: l
                })
            }
        }

        function e(k) {
            var l = Object[k];
            l && (Object[k] = function(p) {
                if (p instanceof b) return p;
                Object.isExtensible(p) && d(p);
                return l(p)
            })
        }
        if (function() {
                if (!a || !Object.seal) return !1;
                try {
                    var k = Object.seal({}),
                        l = Object.seal({}),
                        p = new a([
                            [k, 2],
                            [l, 3]
                        ]);
                    if (p.get(k) != 2 || p.get(l) != 3) return !1;
                    p.delete(k);
                    p.set(l, 4);
                    return !p.has(k) && p.get(l) == 4
                } catch (q) {
                    return !1
                }
            }()) return a;
        var f = "$jscomp_hidden_" + Math.random();
        e("freeze");
        e("preventExtensions");
        e("seal");
        var g = 0,
            h = function(k) {
                this.sa = (g += Math.random() + 1).toString();
                if (k) {
                    k = u(k);
                    for (var l; !(l = k.next()).done;) l = l.value, this.set(l[0], l[1])
                }
            };
        h.prototype.set = function(k, l) {
            if (!c(k)) throw Error("Invalid WeakMap key");
            d(k);
            if (!sa(k, f)) throw Error("WeakMap key fail: " + k);
            k[f][this.sa] = l;
            return this
        };
        h.prototype.get = function(k) {
            return c(k) && sa(k, f) ? k[f][this.sa] : void 0
        };
        h.prototype.has = function(k) {
            return c(k) && sa(k, f) && sa(k[f],
                this.sa)
        };
        h.prototype.delete = function(k) {
            return c(k) && sa(k, f) && sa(k[f], this.sa) ? delete k[f][this.sa] : !1
        };
        return h
    });
    n("Map", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var h = Object.seal({
                            x: 4
                        }),
                        k = new a(u([
                            [h, "s"]
                        ]));
                    if (k.get(h) != "s" || k.size != 1 || k.get({
                            x: 4
                        }) || k.set({
                            x: 4
                        }, "t") != k || k.size != 2) return !1;
                    var l = k.entries(),
                        p = l.next();
                    if (p.done || p.value[0] != h || p.value[1] != "s") return !1;
                    p = l.next();
                    return !(p.done || p.value[0].x != 4 || p.value[1] != "t" || !l.next().done)
                } catch (q) {
                    return !1
                }
            }()) return a;
        var b = new WeakMap,
            c = function(h) {
                this[0] = {};
                this[1] = f();
                this.size = 0;
                if (h) {
                    h = u(h);
                    for (var k; !(k = h.next()).done;) k = k.value, this.set(k[0], k[1])
                }
            };
        c.prototype.set = function(h, k) {
            h = h === 0 ? 0 : h;
            var l = d(this, h);
            l.list || (l.list = this[0][l.id] = []);
            l.entry ? l.entry.value = k : (l.entry = {
                next: this[1],
                K: this[1].K,
                head: this[1],
                key: h,
                value: k
            }, l.list.push(l.entry), this[1].K.next = l.entry, this[1].K = l.entry, this.size++);
            return this
        };
        c.prototype.delete = function(h) {
            h = d(this, h);
            return h.entry && h.list ? (h.list.splice(h.index, 1), h.list.length || delete this[0][h.id], h.entry.K.next = h.entry.next,
                h.entry.next.K = h.entry.K, h.entry.head = null, this.size--, !0) : !1
        };
        c.prototype.clear = function() {
            this[0] = {};
            this[1] = this[1].K = f();
            this.size = 0
        };
        c.prototype.has = function(h) {
            return !!d(this, h).entry
        };
        c.prototype.get = function(h) {
            return (h = d(this, h).entry) && h.value
        };
        c.prototype.entries = function() {
            return e(this, function(h) {
                return [h.key, h.value]
            })
        };
        c.prototype.keys = function() {
            return e(this, function(h) {
                return h.key
            })
        };
        c.prototype.values = function() {
            return e(this, function(h) {
                return h.value
            })
        };
        c.prototype.forEach =
            function(h, k) {
                for (var l = this.entries(), p; !(p = l.next()).done;) p = p.value, h.call(k, p[1], p[0], this)
            };
        c.prototype[Symbol.iterator] = c.prototype.entries;
        var d = function(h, k) {
                var l = k && typeof k;
                l == "object" || l == "function" ? b.has(k) ? l = b.get(k) : (l = "" + ++g, b.set(k, l)) : l = "p_" + k;
                var p = h[0][l];
                if (p && sa(h[0], l))
                    for (h = 0; h < p.length; h++) {
                        var q = p[h];
                        if (k !== k && q.key !== q.key || k === q.key) return {
                            id: l,
                            list: p,
                            index: h,
                            entry: q
                        }
                    }
                return {
                    id: l,
                    list: p,
                    index: -1,
                    entry: void 0
                }
            },
            e = function(h, k) {
                var l = h[1];
                return ra(function() {
                    if (l) {
                        for (; l.head !=
                            h[1];) l = l.K;
                        for (; l.next != l.head;) return l = l.next, {
                            done: !1,
                            value: k(l)
                        };
                        l = null
                    }
                    return {
                        done: !0,
                        value: void 0
                    }
                })
            },
            f = function() {
                var h = {};
                return h.K = h.next = h.head = h
            },
            g = 0;
        return c
    });
    n("Set", function(a) {
        if (function() {
                if (!a || typeof a != "function" || !a.prototype.entries || typeof Object.seal != "function") return !1;
                try {
                    var c = Object.seal({
                            x: 4
                        }),
                        d = new a(u([c]));
                    if (!d.has(c) || d.size != 1 || d.add(c) != d || d.size != 1 || d.add({
                            x: 4
                        }) != d || d.size != 2) return !1;
                    var e = d.entries(),
                        f = e.next();
                    if (f.done || f.value[0] != c || f.value[1] != c) return !1;
                    f = e.next();
                    return f.done || f.value[0] == c || f.value[0].x != 4 || f.value[1] != f.value[0] ? !1 : e.next().done
                } catch (g) {
                    return !1
                }
            }()) return a;
        var b = function(c) {
            this.I = new Map;
            if (c) {
                c =
                    u(c);
                for (var d; !(d = c.next()).done;) this.add(d.value)
            }
            this.size = this.I.size
        };
        b.prototype.add = function(c) {
            c = c === 0 ? 0 : c;
            this.I.set(c, c);
            this.size = this.I.size;
            return this
        };
        b.prototype.delete = function(c) {
            c = this.I.delete(c);
            this.size = this.I.size;
            return c
        };
        b.prototype.clear = function() {
            this.I.clear();
            this.size = 0
        };
        b.prototype.has = function(c) {
            return this.I.has(c)
        };
        b.prototype.entries = function() {
            return this.I.entries()
        };
        b.prototype.values = function() {
            return this.I.values()
        };
        b.prototype.keys = b.prototype.values;
        b.prototype[Symbol.iterator] = b.prototype.values;
        b.prototype.forEach = function(c, d) {
            var e = this;
            this.I.forEach(function(f) {
                return c.call(d, f, f, e)
            })
        };
        return b
    });
    n("Math.log2", function(a) {
        return a ? a : function(b) {
            return Math.log(b) / Math.LN2
        }
    });
    n("Object.values", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) sa(b, d) && c.push(b[d]);
            return c
        }
    });
    n("Object.is", function(a) {
        return a ? a : function(b, c) {
            return b === c ? b !== 0 || 1 / b === 1 / c : b !== b && c !== c
        }
    });
    n("Array.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            var d = this;
            d instanceof String && (d = String(d));
            var e = d.length;
            c = c || 0;
            for (c < 0 && (c = Math.max(c + e, 0)); c < e; c++) {
                var f = d[c];
                if (f === b || Object.is(f, b)) return !0
            }
            return !1
        }
    });
    var Ga = function(a, b, c) {
        if (a == null) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
        if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
        return a + ""
    };
    n("String.prototype.includes", function(a) {
        return a ? a : function(b, c) {
            return Ga(this, b, "includes").indexOf(b, c || 0) !== -1
        }
    });
    n("Array.from", function(a) {
        return a ? a : function(b, c, d) {
            c = c != null ? c : function(h) {
                return h
            };
            var e = [],
                f = typeof Symbol != "undefined" && Symbol.iterator && b[Symbol.iterator];
            if (typeof f == "function") {
                b = f.call(b);
                for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
            } else
                for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
            return e
        }
    });
    n("Object.entries", function(a) {
        return a ? a : function(b) {
            var c = [],
                d;
            for (d in b) sa(b, d) && c.push([d, b[d]]);
            return c
        }
    });
    n("Number.isFinite", function(a) {
        return a ? a : function(b) {
            return typeof b !== "number" ? !1 : !isNaN(b) && b !== Infinity && b !== -Infinity
        }
    });
    n("Iterator.prototype.filter", function(a) {
        return a || function(b) {
            return Ea(this, b, !0)
        }
    });
    n("Number.MAX_SAFE_INTEGER", function() {
        return 9007199254740991
    });
    n("Number.MIN_SAFE_INTEGER", function() {
        return -9007199254740991
    });
    n("Number.isInteger", function(a) {
        return a ? a : function(b) {
            return Number.isFinite(b) ? b === Math.floor(b) : !1
        }
    });
    n("Number.isSafeInteger", function(a) {
        return a ? a : function(b) {
            return Number.isInteger(b) && Math.abs(b) <= Number.MAX_SAFE_INTEGER
        }
    });
    n("String.prototype.startsWith", function(a) {
        return a ? a : function(b, c) {
            var d = Ga(this, b, "startsWith");
            b += "";
            var e = d.length,
                f = b.length;
            c = Math.max(0, Math.min(c | 0, d.length));
            for (var g = 0; g < f && c < e;)
                if (d[c++] != b[g++]) return !1;
            return g >= f
        }
    });
    var Ha = function(a, b) {
        a instanceof String && (a += "");
        var c = 0,
            d = !1;
        return ra(function() {
            if (!d && c < a.length) {
                var e = c++;
                return {
                    value: b(e, a[e]),
                    done: !1
                }
            }
            d = !0;
            return {
                done: !0,
                value: void 0
            }
        })
    };
    n("Array.prototype.entries", function(a) {
        return a ? a : function() {
            return Ha(this, function(b, c) {
                return [b, c]
            })
        }
    });
    n("Iterator.prototype.some", function(a) {
        return a || function(b) {
            var c = !1;
            Fa(this, b, function(d, e) {
                return c = !!b(d, e)
            });
            return c
        }
    });
    n("Math.trunc", function(a) {
        return a ? a : function(b) {
            b = Number(b);
            if (isNaN(b) || b === Infinity || b === -Infinity || b === 0) return b;
            var c = Math.floor(Math.abs(b));
            return b < 0 ? -c : c
        }
    });
    n("Number.isNaN", function(a) {
        return a ? a : function(b) {
            return typeof b === "number" && isNaN(b)
        }
    });
    n("Array.prototype.keys", function(a) {
        return a ? a : function() {
            return Ha(this, function(b) {
                return b
            })
        }
    });
    n("Array.prototype.values", function(a) {
        return a ? a : function() {
            return Ha(this, function(b, c) {
                return c
            })
        }
    });
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var w = this || self,
        Ja = function(a) {
            a = a.split(".");
            for (var b = w, c = 0; c < a.length; c++)
                if (b = b[a[c]], b == null) return null;
            return b
        },
        Ka = function(a) {
            var b = typeof a;
            return b != "object" ? b : a ? Array.isArray(a) ? "array" : b : "null"
        },
        La = function(a) {
            var b = Ka(a);
            return b == "array" || b == "object" && typeof a.length == "number"
        },
        Ma = function(a) {
            var b = typeof a;
            return b == "object" && a != null || b == "function"
        },
        Na = function(a, b) {
            function c() {}
            c.prototype = b.prototype;
            a.fd = b.prototype;
            a.prototype = new c;
            a.prototype.constructor = a;
            a.zd = function(d,
                e, f) {
                for (var g = Array(arguments.length - 2), h = 2; h < arguments.length; h++) g[h - 2] = arguments[h];
                return b.prototype[e].apply(d, g)
            }
        };

    function Oa(a, b) {
        if (Error.captureStackTrace) Error.captureStackTrace(this, Oa);
        else {
            var c = Error().stack;
            c && (this.stack = c)
        }
        a && (this.message = String(a));
        b !== void 0 && (this.cause = b)
    }
    Na(Oa, Error);
    Oa.prototype.name = "CustomError";
    var Pa;

    function Qa(a, b) {
        a = a.split("%s");
        for (var c = "", d = a.length - 1, e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
        Oa.call(this, c + a[d])
    }
    Na(Qa, Oa);
    Qa.prototype.name = "AssertionError";

    function Ra(a, b, c, d) {
        var e = "Assertion failed";
        if (c) {
            e += ": " + c;
            var f = d
        } else a && (e += ": " + a, f = b);
        throw new Qa("" + e, f || []);
    }
    var x = function(a, b, c) {
            a || Ra("", null, b, Array.prototype.slice.call(arguments, 2))
        },
        z = function(a, b, c) {
            a == null && Ra("Expected to exist: %s.", [a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Sa = function(a, b, c) {
            typeof a !== "number" && Ra("Expected number but got %s: %s.", [Ka(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Ta = function(a, b, c) {
            typeof a !== "string" && Ra("Expected string but got %s: %s.", [Ka(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        Ua = function(a, b, c) {
            typeof a !== "function" &&
                Ra("Expected function but got %s: %s.", [Ka(a), a], b, Array.prototype.slice.call(arguments, 2))
        },
        D = function(a, b, c) {
            Array.isArray(a) || Ra("Expected array but got %s: %s.", [Ka(a), a], b, Array.prototype.slice.call(arguments, 2));
            return a
        },
        Wa = function(a, b, c, d) {
            a instanceof b || Ra("Expected instanceof %s but got %s.", [Va(b), Va(a)], c, Array.prototype.slice.call(arguments, 3));
            return a
        };

    function Va(a) {
        return a instanceof Function ? a.displayName || a.name || "unknown type name" : a instanceof Object ? a.constructor.displayName || a.constructor.name || Object.prototype.toString.call(a) : a === null ? "null" : typeof a
    };
    var Ya, Za = Ja("CLOSURE_FLAGS"),
        $a = Za && Za[748402147];
    Ya = $a != null ? $a : !0;
    var ab = String.prototype.trim ? function(a) {
        return a.trim()
    } : function(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    };

    function bb(a, b) {
        var c = 0;
        a = ab(String(a)).split(".");
        b = ab(String(b)).split(".");
        for (var d = Math.max(a.length, b.length), e = 0; c == 0 && e < d; e++) {
            var f = a[e] || "",
                g = b[e] || "";
            do {
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                if (f[0].length == 0 && g[0].length == 0) break;
                c = cb(f[1].length == 0 ? 0 : parseInt(f[1], 10), g[1].length == 0 ? 0 : parseInt(g[1], 10)) || cb(f[2].length == 0, g[2].length == 0) || cb(f[2], g[2]);
                f = f[3];
                g = g[3]
            } while (c == 0)
        }
        return c
    }

    function cb(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };

    function db() {
        var a = w.navigator;
        return a && (a = a.userAgent) ? a : ""
    }

    function E(a) {
        return db().indexOf(a) != -1
    };

    function eb() {
        return E("Firefox") || E("FxiOS")
    }

    function fb() {
        return (E("Chrome") || E("CriOS")) && !E("Edge") || E("Silk")
    };

    function gb() {
        return E("iPhone") && !E("iPod") && !E("iPad")
    }

    function hb() {
        gb() || E("iPad") || E("iPod")
    };
    var ib = Array.prototype.indexOf ? function(a, b) {
            x(a.length != null);
            return Array.prototype.indexOf.call(a, b, void 0)
        } : function(a, b) {
            if (typeof a === "string") return typeof b !== "string" || b.length != 1 ? -1 : a.indexOf(b, 0);
            for (var c = 0; c < a.length; c++)
                if (c in a && a[c] === b) return c;
            return -1
        },
        jb = Array.prototype.forEach ? function(a, b) {
            x(a.length != null);
            Array.prototype.forEach.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = typeof a === "string" ? a.split("") : a, e = 0; e < c; e++) e in d && b.call(void 0, d[e], e, a)
        },
        kb = Array.prototype.map ?
        function(a, b) {
            x(a.length != null);
            return Array.prototype.map.call(a, b, void 0)
        } : function(a, b) {
            for (var c = a.length, d = Array(c), e = typeof a === "string" ? a.split("") : a, f = 0; f < c; f++) f in e && (d[f] = b.call(void 0, e[f], f, a));
            return d
        };

    function lb(a, b) {
        a: {
            for (var c = typeof a === "string" ? a.split("") : a, d = a.length - 1; d >= 0; d--)
                if (d in c && b.call(void 0, c[d], d, a)) {
                    b = d;
                    break a
                }
            b = -1
        }
        return b < 0 ? null : typeof a === "string" ? a.charAt(b) : a[b]
    }

    function mb(a) {
        var b = a.length;
        if (b > 0) {
            for (var c = Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    };
    var nb = function(a) {
        nb[" "](a);
        return a
    };
    nb[" "] = function() {};
    E("Opera");
    E("Trident") || E("MSIE");
    E("Edge");
    var ob = E("Gecko") && !(db().toLowerCase().indexOf("webkit") != -1 && !E("Edge")) && !(E("Trident") || E("MSIE")) && !E("Edge"),
        pb = db().toLowerCase().indexOf("webkit") != -1 && !E("Edge");
    pb && E("Mobile");
    E("Macintosh");
    E("Windows");
    E("Linux") || E("CrOS");
    E("Android");
    gb();
    E("iPad");
    E("iPod");
    hb();
    db().toLowerCase().indexOf("kaios");
    eb();
    gb() || E("iPod");
    E("iPad");
    !E("Android") || fb() || eb() || E("Opera") || E("Silk");
    fb();
    !E("Safari") || fb() || E("Coast") || E("Opera") || E("Edge") || E("Edg/") || E("OPR") || eb() || E("Silk") || E("Android") || hb();
    var qb = {},
        rb = null,
        sb = ob || pb || typeof w.btoa == "function";

    function tb(a) {
        var b;
        x(La(a), "encodeByteArray takes an array as a parameter");
        b === void 0 && (b = 0);
        if (!rb) {
            rb = {};
            for (var c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), d = ["+/=", "+/", "-_=", "-_.", "-_"], e = 0; e < 5; e++) {
                var f = c.concat(d[e].split(""));
                qb[e] = f;
                for (var g = 0; g < f.length; g++) {
                    var h = f[g],
                        k = rb[h];
                    k === void 0 ? rb[h] = g : x(k === g)
                }
            }
        }
        b = qb[b];
        c = Array(Math.floor(a.length / 3));
        d = b[64] || "";
        for (e = f = 0; f < a.length - 2; f += 3) {
            k = a[f];
            var l = a[f + 1];
            h = a[f + 2];
            g = b[k >> 2];
            k = b[(k & 3) << 4 | l >> 4];
            l = b[(l &
                15) << 2 | h >> 6];
            h = b[h & 63];
            c[e++] = "" + g + k + l + h
        }
        g = 0;
        h = d;
        switch (a.length - f) {
            case 2:
                g = a[f + 1], h = b[(g & 15) << 2] || d;
            case 1:
                a = a[f], c[e] = "" + b[a >> 2] + b[(a & 3) << 4 | g >> 4] + h + d
        }
        return c.join("")
    }

    function ub(a) {
        if (sb) a = w.btoa(a);
        else {
            for (var b = [], c = 0, d = 0; d < a.length; d++) {
                var e = a.charCodeAt(d);
                if (e > 255) throw Error("go/unicode-to-byte-error");
                b[c++] = e
            }
            a = tb(b)
        }
        return a
    };

    function vb(a) {
        a = Error(a);
        a.__closure__error__context__984382 || (a.__closure__error__context__984382 = {});
        a.__closure__error__context__984382.severity = "warning";
        return a
    };

    function wb() {
        return typeof BigInt === "function"
    }

    function xb() {
        var a, b;
        return typeof window === "undefined" || ((a = globalThis) == null ? void 0 : (b = a.hd) == null ? void 0 : b["jspb.DISABLE_RANDOMIZE_SERIALIZATION"])
    };
    var yb = typeof Symbol === "function" && typeof Symbol() === "symbol";

    function zb(a, b, c) {
        return typeof Symbol === "function" && typeof Symbol() === "symbol" ? (c === void 0 ? 0 : c) && Symbol.for && a ? Symbol.for(a) : a != null ? Symbol(a) : Symbol() : b
    }
    var Ab = zb("jas", void 0, !0),
        Bb = zb("defaultInstance", "0di"),
        Cb = zb("oneofCases", "1oa"),
        Db = zb("m_m", "Dd", !0),
        Eb = zb("validPivotSelector", "vps"),
        Fb = zb("knownMessageType", "knownMessageType"),
        Ib = zb("destroyedStructure", "destroyedStructure");
    x(Math.round(Math.log2(Math.max.apply(Math, na(Object.values({
        qd: 1,
        pd: 2,
        od: 4,
        ud: 8,
        wd: 16,
        sd: 32,
        jd: 64,
        md: 128,
        kd: 256,
        vd: 512,
        ld: 1024,
        nd: 2048,
        td: 4096,
        rd: 8192
    }))))) === 13);
    var Jb = {
            Mc: {
                value: 0,
                configurable: !0,
                writable: !0,
                enumerable: !1
            }
        },
        Kb = Object.defineProperties,
        F = yb ? z(Ab) : "Mc",
        Lb, Mb = [];
    Nb(Mb, 7);
    Lb = Object.freeze(Mb);

    function Ob(a) {
        return D(a, "state is only maintained on arrays.")[F] | 0
    }

    function Pb(a, b) {
        x((b & 16777215) === b);
        D(a, "state is only maintained on arrays.");
        yb || F in a || Kb(a, Jb);
        a[F] |= b
    }

    function Nb(a, b) {
        x((b & 16777215) === b);
        D(a, "state is only maintained on arrays.");
        yb || F in a || Kb(a, Jb);
        a[F] = b
    }

    function G(a, b, c) {
        (c === void 0 || !c || b & 2048) && x(b & 64, "state for messages must be constructed");
        x((b & 5) === 0, "state for messages should not contain repeated field state");
        x((b & 8192) === 0, "state for messages should not contain map field state");
        if (b & 64) {
            x(b & 64);
            c = b >> 14 & 1023 || 536870912;
            var d = a.length;
            x(b & 64);
            x(c + (b & 128 ? 0 : -1) >= d - 1, "pivot %s is pointing at an index earlier than the last index of the array, length: %s", c, d);
            b & 128 && x(typeof a[0] === "string", "arrays with a message_id bit must have a string in the first position, got: %s",
                a[0])
        }
    }

    function Qb(a) {
        var b = D(a, "state is only maintained on arrays.")[F] | 0;
        G(a, b);
        return b
    }

    function Rb(a) {
        return !!((D(a, "state is only maintained on arrays.")[F] | 0) & 2)
    }

    function Sb(a, b) {
        Sa(b);
        x(b > 0 && b <= 1023 || 536870912 === b, "pivot must be in the range [1, 1024) or NO_PIVOT got %s", b);
        return a & -16760833 | (b & 1023) << 14
    }

    function Tb(a) {
        x(a & 64);
        return a & 128 ? 0 : -1
    }

    function Ub(a, b) {
        2 & b && (a |= 2);
        return a | 1
    }
    var Vb = Object.getOwnPropertyDescriptor(Array.prototype, "Oc");
    Object.defineProperties(Array.prototype, {
        Oc: {
            get: function() {
                var a = Wb(this);
                return Vb ? Vb.get.call(this) + "|" + a : a
            },
            configurable: !0,
            enumerable: !1
        }
    });

    function Wb(a) {
        function b(e, f) {
            e & c && d.push(f)
        }
        var c = D(a, "state is only maintained on arrays.")[F] | 0,
            d = [];
        b(1, "IS_REPEATED_FIELD");
        b(2, "IS_IMMUTABLE_ARRAY");
        b(4, "IS_API_FORMATTED");
        b(512, "STRING_FORMATTED");
        b(1024, "GBIGINT_FORMATTED");
        b(1024, "BINARY");
        b(8, "ONLY_MUTABLE_VALUES");
        b(16, "UNFROZEN_SHARED");
        b(32, "MUTABLE_REFERENCES_ARE_OWNED");
        b(64, "CONSTRUCTED");
        b(128, "HAS_MESSAGE_ID");
        b(256, "FROZEN_ARRAY");
        b(2048, "HAS_WRAPPER");
        b(4096, "MUTABLE_SUBSTRUCTURES");
        b(8192, "KNOWN_MAP_ARRAY");
        c & 64 && (x(c & 64), a =
            c >> 14 & 1023 || 536870912, a !== 536870912 && d.push("pivot: " + a));
        return d.join(",")
    };
    var J = yb && Math.random() < .5,
        K = J ? Symbol() : void 0;

    function Xb(a) {
        x(M(a));
        return J ? a[z(K)] : a.h
    }
    var Yb, Zb = typeof Db === "symbol",
        $b = {};

    function M(a) {
        var b = a[Db],
            c = b === $b;
        x(!Yb || c === a instanceof Yb);
        if (Zb && b && !c) throw Error("multiple jspb runtimes detected");
        return c
    }

    function ac(a) {
        return a != null && M(a)
    }

    function bc(a, b) {
        Sa(a);
        x(a > 0);
        x(b === 0 || b === -1);
        return a + b
    }

    function cc(a, b) {
        x(b === dc || b === void 0);
        return a + (b ? 0 : -1)
    }

    function ec(a, b) {
        Sa(a);
        x(a >= 0);
        x(b === 0 || b === -1);
        return a - b
    }

    function fc(a, b) {
        if (b === void 0) {
            if (b = !hc(a)) x(M(a)), a = J ? a[z(K)] : a.h, b = D(a, "state is only maintained on arrays.")[F] | 0, G(a, b), b = !!(2 & b);
            return b
        }
        x(M(a));
        var c = J ? a[z(K)] : a.h;
        var d = D(c, "state is only maintained on arrays.")[F] | 0;
        G(c, d);
        x(b === d);
        return !!(2 & b) && !hc(a)
    }
    var ic = {};

    function hc(a) {
        var b = a.Cc,
            c;
        (c = !b) || (x(M(a)), a = J ? a[z(K)] : a.h, c = D(a, "state is only maintained on arrays.")[F] | 0, G(a, c), c = !!(2 & c));
        x(c);
        x(b === void 0 || b === ic);
        return b === ic
    }

    function jc(a, b) {
        x(M(a));
        var c = J ? a[z(K)] : a.h;
        var d = D(c, "state is only maintained on arrays.")[F] | 0;
        G(c, d);
        x(b === !!(2 & d));
        a.Cc = b ? ic : void 0
    }
    var kc = Symbol("exempted jspb subclass"),
        lc = typeof Symbol != "undefined" && typeof Symbol.hasInstance != "undefined";

    function mc() {}

    function nc(a, b) {
        var c = Ob(D(a));
        b || x(!(c & 2 && c & 4 || c & 256) || Object.isFrozen(a));
        oc(a)
    }

    function oc(a) {
        a = D(a, "state is only maintained on arrays.")[F] | 0;
        var b = a & 4,
            c = (512 & a ? 1 : 0) + (1024 & a ? 1 : 0);
        x(b && c <= 1 || !b && c === 0, "Expected at most 1 type-specific formatting bit, but got " + c + " with state: " + a)
    }
    var pc = Object.freeze({});
    Object.freeze({});
    var dc = {};

    function qc(a, b) {
        a = D(a, "state is only maintained on arrays.")[F] | 0;
        x(a & 64);
        a & 128 ? x(b === dc) : x(b === void 0)
    };

    function rc(a, b) {
        b = b === void 0 ? new Set : b;
        if (b.has(a)) return "(Recursive reference)";
        switch (typeof a) {
            case "object":
                if (a) {
                    var c = Object.getPrototypeOf(a);
                    switch (c) {
                        case Map.prototype:
                        case Set.prototype:
                        case Array.prototype:
                            b.add(a);
                            var d = "[" + Array.from(a, function(e) {
                                return rc(e, b)
                            }).join(", ") + "]";
                            b.delete(a);
                            c !== Array.prototype && (d = sc(c.constructor) + "(" + d + ")");
                            return d;
                        case Object.prototype:
                            return b.add(a), c = "{" + Object.entries(a).map(function(e) {
                                var f = u(e);
                                e = f.next().value;
                                f = f.next().value;
                                return e +
                                    ": " + rc(f, b)
                            }).join(", ") + "}", b.delete(a), c;
                        default:
                            return d = "Object", c && c.constructor && (d = sc(c.constructor)), typeof a.toString === "function" && a.toString !== Object.prototype.toString ? d + "(" + String(a) + ")" : "(object " + d + ")"
                    }
                }
                break;
            case "function":
                return "function " + sc(a);
            case "number":
                if (!Number.isFinite(a)) return String(a);
                break;
            case "bigint":
                return a.toString(10) + "n";
            case "symbol":
                return a.toString()
        }
        return JSON.stringify(a)
    }

    function sc(a) {
        var b = a.displayName;
        return b && typeof b === "string" || (b = a.name) && typeof b === "string" ? b : (a = /function\s+([^\(]+)/m.exec(String(a))) ? a[1] : "(Anonymous)"
    };

    function tc(a, b) {
        var c = uc,
            d = [];
        vc(b, a, d) || wc.apply(null, [void 0, c, "Guard " + b.jb().trim() + " failed:"].concat(na(d.reverse())))
    }

    function Ac(a, b) {
        tc(a, b);
        return a
    }

    function Bc(a, b) {
        var c = uc;
        a || wc("Guard truthy failed:", b || c || "Expected truthy, got " + rc(a))
    }

    function Cc(a, b) {
        a.Cd = !0;
        a.jb = typeof b === "function" ? b : function() {
            return b
        };
        return a
    }

    function vc(a, b, c) {
        var d = a(b, c);
        d || Dc(c, function() {
            var e = "";
            e.length > 0 && (e += ": ");
            return e + "Expected " + a.jb().trim() + ", got " + rc(b)
        });
        return d
    }

    function Dc(a, b) {
        a == null || a.push((typeof b === "function" ? b() : b).trim())
    }
    var uc = void 0;

    function Ec(a) {
        return typeof a === "function" ? a() : a
    }

    function wc() {
        throw Error(qa.apply(0, arguments).map(Ec).filter(Boolean).join("\n").trim().replace(/:$/, ""));
    }
    var Fc = Cc(function(a) {
        return a !== null && a !== void 0
    }, "exists");
    var Gc = Cc(function(a) {
            return typeof a === "number"
        }, "number"),
        Hc = Cc(function(a) {
            return typeof a === "string"
        }, "string"),
        Ic = Cc(function(a) {
            return typeof a === "boolean"
        }, "boolean"),
        Jc = Cc(function(a) {
            return typeof a === "bigint"
        }, "bigint"),
        Kc = Cc(function(a) {
            return typeof a === "function"
        }, "Function");

    function Lc() {
        var a = qa.apply(0, arguments);
        return Cc(function(b) {
            return a.some(function(c) {
                return c(b)
            })
        }, function() {
            return "" + a.map(function(b) {
                return b.jb().trim()
            }).join(" | ")
        })
    };
    var Mc = typeof w.BigInt === "function" && typeof w.BigInt(0) === "bigint";

    function Nc(a) {
        var b = a;
        if (Hc(b)) {
            if (!/^\s*(?:-?[1-9]\d*|0)?\s*$/.test(b)) throw Error("Invalid string for toGbigint: " + b);
        } else if (Gc(b) && !Number.isSafeInteger(b)) throw Error("Invalid number for toGbigint: " + b);
        return Mc ? (Jc(a) || (tc(a, Lc(Hc, Ic, Gc)), a = BigInt(a)), a % BigInt(2) === BigInt(Oc()) ? a.toString() : a) : a = Ic(a) ? a ? "1" : "0" : Hc(a) ? a.trim() || "0" : String(a)
    }
    var Qc = Cc(function(a) {
            return Mc ? Pc(a) : Hc(a) && /^(?:-?[1-9]\d*|0)$/.test(a)
        }, "gbigint"),
        Wc = Cc(function(a) {
            if (Mc) return tc(Rc, Jc), tc(Sc, Jc), a = BigInt(a), a >= Rc && a <= Sc;
            a = Ac(a, Hc);
            return a[0] === "-" ? Tc(a, Uc) : Tc(a, Vc)
        }, "isSafeInt52"),
        Uc = Number.MIN_SAFE_INTEGER.toString(),
        Rc = Mc ? BigInt(Number.MIN_SAFE_INTEGER) : void 0,
        Vc = Number.MAX_SAFE_INTEGER.toString(),
        Sc = Mc ? BigInt(Number.MAX_SAFE_INTEGER) : void 0;

    function Tc(a, b) {
        if (a.length > b.length) return !1;
        if (a.length < b.length || a === b) return !0;
        for (var c = 0; c < a.length; c++) {
            var d = a[c],
                e = b[c];
            if (d > e) return !1;
            if (d < e) return !0
        }
        c = uc;
        wc("Assertion fail:", "isInRange weird case. Value was: " + a + ". Boundary was: " + b + "." || c)
    }

    function Pc(a) {
        if (typeof a === "bigint") return a % BigInt(2) === BigInt(Oc()) ? (console.error("isGbigint: got a `bigint` when we were expecting a `string`. Make sure to call `toGbigint()` when creating `gbigint` instances!"), !1) : !0;
        if (Hc(a)) {
            if (!/^(?:-?[1-9]\d*|0)$/.test(a)) return !1;
            if (Number(a[a.length - 1]) % 2 === Oc()) return !0;
            console.error("isGbigint: got a `string` when we were expecting a `bigint`. Make sure to call `toGbigint()` when creating `gbigint` instances!")
        }
        return !1
    }

    function Oc() {
        Bc(!0);
        var a = typeof Window === "function" && globalThis.top instanceof Window ? globalThis.top : globalThis;
        a.gbigintUseStrInDebugToggleVal == null && Object.defineProperties(a, {
            gbigintUseStrInDebugToggleVal: {
                value: Math.round(Math.random())
            }
        });
        return a.gbigintUseStrInDebugToggleVal
    };
    var Xc = 0,
        Yc = 0;

    function Zc(a) {
        var b = a >>> 0;
        Xc = b;
        Yc = (a - b) / 4294967296 >>> 0
    }

    function $c(a) {
        if (a < 0) {
            Zc(0 - a);
            var b = u(ad(Xc, Yc));
            a = b.next().value;
            b = b.next().value;
            Xc = a >>> 0;
            Yc = b >>> 0
        } else Zc(a)
    }

    function bd(a, b) {
        var c = b * 4294967296 + (a >>> 0);
        return Number.isSafeInteger(c) ? c : cd(a, b)
    }

    function cd(a, b) {
        b >>>= 0;
        a >>>= 0;
        if (b <= 2097151) var c = "" + (4294967296 * b + a);
        else wb() ? c = "" + (BigInt(b) << BigInt(32) | BigInt(a)) : (c = (a >>> 24 | b << 8) & 16777215, b = b >> 16 & 65535, a = (a & 16777215) + c * 6777216 + b * 6710656, c += b * 8147497, b *= 2, a >= 1E7 && (c += a / 1E7 >>> 0, a %= 1E7), c >= 1E7 && (b += c / 1E7 >>> 0, c %= 1E7), x(b), c = b + dd(c) + dd(a));
        return c
    }

    function dd(a) {
        a = String(a);
        return "0000000".slice(a.length) + a
    }

    function ed() {
        var a = Xc,
            b = Yc;
        b & 2147483648 ? wb() ? a = "" + (BigInt(b | 0) << BigInt(32) | BigInt(a >>> 0)) : (b = u(ad(a, b)), a = b.next().value, b = b.next().value, a = "-" + cd(a, b)) : a = cd(a, b);
        return a
    }

    function fd(a) {
        x(a.length > 0);
        if (a.length < 16) $c(Number(a));
        else if (wb()) a = BigInt(a), Xc = Number(a & BigInt(4294967295)) >>> 0, Yc = Number(a >> BigInt(32) & BigInt(4294967295));
        else {
            x(a.length > 0);
            var b = +(a[0] === "-");
            Yc = Xc = 0;
            for (var c = a.length, d = 0 + b, e = (c - b) % 6 + b; e <= c; d = e, e += 6) d = Number(a.slice(d, e)), Yc *= 1E6, Xc = Xc * 1E6 + d, Xc >= 4294967296 && (Yc += Math.trunc(Xc / 4294967296), Yc >>>= 0, Xc >>>= 0);
            b && (b = u(ad(Xc, Yc)), a = b.next().value, b = b.next().value, Xc = a, Yc = b)
        }
    }

    function ad(a, b) {
        b = ~b;
        a ? a = ~a + 1 : b += 1;
        return [a, b]
    };

    function gd(a) {
        return Array.prototype.slice.call(a)
    };
    var hd = typeof BigInt === "function" ? BigInt.asIntN : void 0,
        id = typeof BigInt === "function" ? BigInt.asUintN : void 0,
        jd = Number.isSafeInteger,
        kd = Number.isFinite,
        ld = Math.trunc,
        md = Number.MAX_SAFE_INTEGER;

    function nd(a) {
        if (a == null || typeof a === "number") return a;
        if (a === "NaN" || a === "Infinity" || a === "-Infinity") return Number(a)
    }

    function od(a) {
        return a.displayName || a.name || "unknown type name"
    }

    function pd(a) {
        if (typeof a !== "boolean") throw Error("Expected boolean but got " + Ka(a) + ": " + a);
        return a
    }
    var qd = /^-?([1-9][0-9]*|0)(\.[0-9]+)?$/;

    function rd(a) {
        switch (typeof a) {
            case "bigint":
                return !0;
            case "number":
                return kd(a);
            case "string":
                return qd.test(a);
            default:
                return !1
        }
    }

    function sd(a) {
        if (!kd(a)) throw a = "Expected enum as finite number but got " + Ka(a) + ": " + a, vb(a);
        return a | 0
    }

    function td(a) {
        return a == null ? a : kd(a) ? a | 0 : void 0
    }

    function ud(a) {
        return "Expected int32 as finite number but got " + Ka(a) + ": " + a
    }

    function vd(a) {
        if (typeof a !== "number") throw vb(ud(a));
        if (!kd(a)) throw vb(ud(a));
        return a | 0
    }

    function wd(a) {
        return a == null ? a : vd(a)
    }

    function xd(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return kd(a) ? a | 0 : void 0
    }

    function yd(a) {
        if (a == null) return a;
        if (typeof a === "string" && a) a = +a;
        else if (typeof a !== "number") return;
        return kd(a) ? a >>> 0 : void 0
    }

    function zd(a) {
        var b = void 0;
        b != null || (b = xb() ? 0 : 1024);
        if (!rd(a)) throw a = "Expected an int64 value encoded as a number or a string but got " + Ka(a) + ": " + a, vb(a);
        var c = typeof a;
        switch (b) {
            case 512:
                switch (c) {
                    case "string":
                        return Ad(a, !0);
                    case "bigint":
                        return String(hd(64, a));
                    default:
                        return Bd(a)
                }
            case 1024:
                switch (c) {
                    case "string":
                        return Cd(a);
                    case "bigint":
                        return Dd(a);
                    default:
                        return Nc(jd(a) ? a : Bd(a))
                }
            case 0:
                switch (c) {
                    case "string":
                        return Ad(a, !1);
                    case "bigint":
                        return Dd(a);
                    default:
                        x(rd(a));
                        x(!0);
                        a = ld(a);
                        if (!jd(a)) {
                            x(!jd(a));
                            x(Number.isInteger(a));
                            $c(a);
                            b = Xc;
                            c = Yc;
                            if (a = c & 2147483648) b = ~b + 1 >>> 0, c = ~c >>> 0, b == 0 && (c = c + 1 >>> 0);
                            b = bd(b, c);
                            a = typeof b === "number" ? a ? -b : b : a ? "-" + b : b
                        }
                        return a
                }
            default:
                throw Error("Unknown format requested type for int64");
        }
    }

    function Ed(a) {
        x(a.indexOf(".") === -1);
        var b = a.length;
        if (a[0] === "-" ? b < 20 || b === 20 && a <= "-9223372036854775808" : b < 19 || b === 19 && a <= "9223372036854775807") return a;
        fd(a);
        return ed()
    }

    function Fd(a) {
        x(a.indexOf(".") === -1);
        if (a[0] === "-") var b = !1;
        else b = a.length, b = b < 20 ? !0 : b === 20 && a <= "18446744073709551615";
        if (b) return a;
        fd(a);
        return cd(Xc, Yc)
    }

    function Bd(a) {
        x(rd(a));
        x(!0);
        a = ld(a);
        jd(a) ? a = String(a) : (x(!jd(a)), x(Number.isInteger(a)), $c(a), a = ed());
        return a
    }

    function Gd(a, b) {
        x(rd(a));
        x(b || !0);
        a = ld(a);
        a >= 0 && jd(a) ? a = String(a) : (x(a < 0 || a > md), x(Number.isInteger(a)), $c(a), a = cd(Xc, Yc));
        return a
    }

    function Ad(a, b) {
        x(rd(a));
        x(b || !0);
        b = ld(Number(a));
        if (jd(b)) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return Ed(a)
    }

    function Cd(a) {
        var b = ld(Number(a));
        if (jd(b)) return Nc(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return wb() ? Dd(BigInt(a)) : Nc(Ed(a))
    }

    function Hd(a, b) {
        x(rd(a));
        x(b || !0);
        b = ld(Number(a));
        if (jd(b) && b >= 0) return String(b);
        b = a.indexOf(".");
        b !== -1 && (a = a.substring(0, b));
        return Fd(a)
    }

    function Dd(a) {
        x(typeof a === "bigint");
        return Nc(hd(64, a))
    }

    function Id(a) {
        x(typeof a === "bigint");
        return Nc(id(64, a))
    }

    function Jd(a) {
        var b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return Dd(a);
        if (rd(a)) return b === "string" ? Cd(a) : Nc(jd(a) ? a : Bd(a))
    }

    function Kd(a) {
        if (a == null) return a;
        if (typeof a === "bigint") return a >= 0 && Wc(a) ? a = Number(a) : (a = id(64, a), a = Wc(a) ? Number(a) : String(a)), a;
        if (rd(a)) {
            if (typeof a === "number") x(rd(a)), x(!0), a = ld(a), a >= 0 && jd(a) || (x(a < 0 || a > md), x(Number.isInteger(a)), $c(a), a = bd(Xc, Yc));
            else {
                x(rd(a));
                x(!0);
                x(!0);
                var b = ld(Number(a));
                0 <= b && b <= md ? a = b : (a = Hd(a, !1), b = Number(a), a = jd(b) ? b : a)
            }
            return a
        }
    }

    function Ld(a, b) {
        var c = typeof a;
        if (a == null) return a;
        if (c === "bigint") return String(id(64, a));
        b = !!b;
        if (rd(a)) return c === "string" ? Hd(a, b) : Gd(a, b)
    }

    function Md(a) {
        var b = typeof a;
        if (a == null) return a;
        if (b === "bigint") return Id(a);
        if (rd(a)) return b === "string" ? (b = ld(Number(a)), jd(b) && b >= 0 ? a = Nc(b) : (b = a.indexOf("."), b !== -1 && (a = a.substring(0, b)), a = wb() ? Id(BigInt(a)) : Nc(Fd(a)))) : a = Nc(a >= 0 && jd(a) ? a : Gd(a, !0)), a
    }

    function Nd(a) {
        if (typeof a !== "string") throw Error("Expected a string but got " + a + " a " + Ka(a));
        return a
    }

    function Od(a) {
        if (a != null && typeof a !== "string") throw Error("Expected a string or null or undefined but got " + a + " a " + Ka(a));
        return a
    }

    function Pd(a) {
        return a == null || typeof a === "string" ? a : void 0
    }

    function Qd(a, b) {
        if (!(a instanceof b)) throw Error("Expected instanceof " + od(b) + " but got " + (a && od(a.constructor)));
    }

    function Rd(a, b, c, d) {
        if (ac(a)) return a;
        if (!Array.isArray(a)) return c ? d & 2 ? b[Bb] || (b[Bb] = Sd(b)) : new b : void 0;
        c = Ob(a);
        d = c | d & 32 | d & 2;
        d !== c && Nb(a, d);
        return new b(a)
    }

    function Td(a) {
        if (!Array.isArray(a)) throw a = "Expected array but got " + Ka(a) + ": " + a, vb(a);
    }

    function Sd(a) {
        a = new a;
        x(M(a));
        var b = J ? a[z(K)] : a.h;
        Pb(b, 34);
        return a
    };

    function Ud(a) {
        return a
    }
    Ud[Eb] = {};

    function Vd(a) {
        return a
    };
    var Wd = function() {
        throw Error("please construct maps as mutable then call toImmutable");
    };
    if (lc) {
        var Xd = function() {
                throw Error("Cannot perform instanceof checks on ImmutableMap: please use isImmutableMap or isMutableMap to assert on the mutability of a map. See go/jspb-api-gotchas#immutable-classes for more information");
            },
            Yd = {};
        Object.defineProperties(Wd, (Yd[Symbol.hasInstance] = {
            value: Xd,
            configurable: !1,
            writable: !1,
            enumerable: !1
        }, Yd));
        x(Wd[Symbol.hasInstance] === Xd, "defineProperties did not work: was it monkey-patched?")
    };

    function Zd(a) {
        x(M(a));
        x(M(a));
        a = J ? a[z(K)] : a.h;
        D(a)
    };

    function $d(a, b, c, d, e) {
        var f = d !== void 0;
        d = !!d;
        var g = [],
            h = a.length,
            k = 4294967295,
            l = !1,
            p = !!(b & 64);
        if (p) {
            x(b & 64);
            var q = b & 128 ? 0 : -1
        } else q = void 0;
        if (!(b & 1)) {
            var y = h && a[h - 1];
            y == null || typeof y !== "object" || y[Ib] || y.constructor !== Object ? y = void 0 : (h--, k = h);
            if (p && !(b & 128) && !f) {
                l = !0;
                var t;
                b = (t = ae) != null ? t : Ud;
                k = bc(b(ec(k, z(q)), z(q), a, y, e), z(q))
            }
        }
        e = void 0;
        for (t = 0; t < h; t++)
            if (b = a[t], b != null && (b = c(b, d)) != null)
                if (p && t >= k) {
                    be();
                    f = ec(t, z(q));
                    var H = void 0;
                    ((H = e) != null ? H : e = {})[f] = b
                } else g[t] = b;
        if (y)
            for (var B in y) a = y[B],
                a != null && (a = c(a, d)) != null && (h = +B, t = void 0, p && !Number.isNaN(h) && (t = bc(h, z(q))) < k ? (be(), g[z(t)] = a) : (h = void 0, ((h = e) != null ? h : e = {})[B] = a));
        e && (l ? g.push(e) : (x(k < 4294967295), g[k] = e));
        return g
    }

    function ce(a) {
        z(a);
        switch (typeof a) {
            case "number":
                return Number.isFinite(a) ? a : "" + a;
            case "bigint":
                return Wc(a) ? Number(a) : "" + a;
            case "boolean":
                return a ? 1 : 0;
            case "object":
                if (Array.isArray(a)) {
                    nc(a);
                    var b = D(a, "state is only maintained on arrays.")[F] | 0;
                    return a.length === 0 && b & 1 ? void 0 : $d(a, b, ce)
                }
                if (ac(a)) return de(a);
                x(!(a instanceof Uint8Array));
                return
        }
        return a
    }
    var ae;

    function ee(a) {
        x(!ae);
        return de(a)
    }

    function de(a) {
        x(M(a));
        var b = J ? a[z(K)] : a.h;
        var c = D(b, "state is only maintained on arrays.")[F] | 0;
        G(b, c);
        return $d(b, c, ce, void 0, a.constructor)
    }

    function be() {
        var a, b = (a = ae) != null ? a : Ud;
        x(b !== Vd)
    };
    if (typeof Proxy !== "undefined") {
        var ge = fe;
        new Proxy({}, {
            getPrototypeOf: ge,
            setPrototypeOf: ge,
            isExtensible: ge,
            preventExtensions: ge,
            getOwnPropertyDescriptor: ge,
            defineProperty: ge,
            has: ge,
            get: ge,
            set: ge,
            deleteProperty: ge,
            apply: ge,
            construct: ge
        })
    }

    function fe(a, b) {
        if (b === Ib) return !0;
        throw Error("this array or object is owned by JSPB and should not be reused, did you mean to copy it with copyJspbArray? See go/jspb-api-gotchas#construct_from_array");
    };

    function he(a, b, c, d) {
        d = d === void 0 ? 0 : d;
        if (a != null)
            for (var e = 0; e < a.length; e++) {
                var f = a[e];
                Array.isArray(f) && nc(f)
            }
        if (a == null) e = 32, c ? (a = [c], e |= 128) : a = [], b && (e = Sb(e, b));
        else {
            if (!Array.isArray(a)) throw Error("data passed to JSPB constructors must be an Array, got '" + JSON.stringify(a) + "' a " + Ka(a));
            e = D(a, "state is only maintained on arrays.")[F] | 0;
            if (Ya && 1 & e) throw Error("Array passed to JSPB constructor is a repeated field array that belongs to another proto instance.");
            2048 & e && !(2 & e) && ie();
            if (Object.isFrozen(a) ||
                !Object.isExtensible(a) || Object.isSealed(a)) throw Error("data passed to JSPB constructors must be mutable");
            if (e & 256) throw Error("farr");
            if (e & 64) return (e | d) !== e && Nb(a, e |= d), G(a, e), a;
            if (c && (e |= 128, c !== a[0])) throw Error('Expected message to have a message id: "' + c + '" in the array, got: ' + JSON.stringify(a[0]) + " a " + Ka(a[0]) + ", are you parsing with the wrong proto?");
            a: {
                c = a;e |= 64;
                var g = c.length;
                if (g) {
                    var h = g - 1;
                    f = c[h];
                    if (f != null && typeof f === "object" && !f[Ib] && f.constructor === Object) {
                        b = Tb(e);
                        g = ec(h, b);
                        if (g >=
                            1024) throw Error("Found a message with a sparse object at fieldNumber " + g + " is >= the limit 1024");
                        for (var k in f) h = +k, h < g && (h = bc(h, b), x(c[h] == null), c[h] = f[k], delete f[k]);
                        e = Sb(e, g);
                        break a
                    }
                }
                if (b) {
                    k = Math.max(b, ec(g, Tb(e)));
                    if (k > 1024) throw Error("a message was constructed with an array of length " + g + " which is longer than 1024, are you using a supported serializer?");
                    e = Sb(e, k)
                }
            }
        }
        Nb(a, e | 64 | d);
        return a
    }

    function ie() {
        if (Ya) throw Error("Array passed to JSPB constructor already belongs to another JSPB proto instance");
    };

    function je(a) {
        x(!(2 & a));
        x(!(2048 & a));
        return !(4096 & a) && !(16 & a)
    }

    function ke(a, b) {
        z(a);
        if (typeof a !== "object") return a;
        if (Array.isArray(a)) {
            nc(a);
            var c = D(a, "state is only maintained on arrays.")[F] | 0;
            a.length === 0 && c & 1 ? a = void 0 : c & 2 || (b && je(c) ? (Pb(a, 34), c & 4 && Object.freeze(a)) : a = le(a, c, !1, b && !(c & 16)));
            return a
        }
        if (ac(a)) return x(ac(a)), b = Xb(a), c = Qb(b), fc(a, c) ? a : me(a, b, c) ? ne(a, b) : le(b, c);
        x(!(a instanceof Uint8Array))
    }

    function ne(a, b, c) {
        a = new a.constructor(b);
        c && jc(a, !0);
        a.Uc = ic;
        return a
    }

    function le(a, b, c, d) {
        x(b === (D(a, "state is only maintained on arrays.")[F] | 0));
        d != null || (d = !!(34 & b));
        a = $d(a, b, ke, d);
        d = 32;
        c && (d |= 2);
        b = b & 16769217 | d;
        Nb(a, b);
        return a
    }

    function oe(a) {
        x(M(a));
        var b = J ? a[z(K)] : a.h;
        var c = D(b, "state is only maintained on arrays.")[F] | 0;
        G(b, c);
        return fc(a, c) ? me(a, b, c) ? ne(a, b, !0) : new a.constructor(le(b, c, !1)) : a
    }

    function pe(a) {
        if (!hc(a)) return !1;
        var b;
        x(M(a));
        var c = b = J ? a[z(K)] : a.h,
            d = D(c, "state is only maintained on arrays.")[F] | 0;
        G(c, d);
        x(d & 2);
        b = le(b, d);
        Pb(b, 2048);
        x(M(a));
        D(b);
        J ? a[z(K)] = b : a.h = b;
        jc(a, !1);
        a.Uc = void 0;
        return !0
    }

    function qe(a) {
        var b;
        if (b = !pe(a)) {
            x(M(a));
            b = J ? a[z(K)] : a.h;
            var c = D(b, "state is only maintained on arrays.")[F] | 0;
            G(b, c);
            b = fc(a, c)
        }
        if (b) throw Error("Cannot mutate an immutable Message");
    }

    function re(a, b) {
        if (b === void 0) b = D(a, "state is only maintained on arrays.")[F] | 0, G(a, b, !0);
        else {
            var c = D(a, "state is only maintained on arrays.")[F] | 0;
            G(a, c, !0);
            x(b === c)
        }
        x(!(b & 2));
        b & 32 && !(b & 4096) && Nb(a, b | 4096)
    }

    function me(a, b, c) {
        return kc && a[kc] ? !1 : c & 2 ? !0 : c & 32 && !(c & 4096) ? (Nb(b, c | 2), jc(a, !0), !0) : !1
    };
    var se = Nc(0),
        ue = function(a, b, c, d) {
            x(Object.isExtensible(a));
            x(M(a));
            a = J ? a[z(K)] : a.h;
            b = te(a, b, c, d);
            (c = b !== null) || (c = void 0);
            if (c) return b
        },
        ve = function(a, b, c) {
            return te(a, b, void 0, c)
        };

    function te(a, b, c, d) {
        qc(a, c);
        if (b === -1) return null;
        var e = cc(b, c);
        x(e === bc(b, Tb(D(a, "state is only maintained on arrays.")[F] | 0)));
        x(e >= 0);
        var f = a.length - 1;
        if (!(f < cc(1, c))) {
            if (e >= f) {
                var g = a[f];
                if (g == null || typeof g !== "object" || g[Ib] || g.constructor !== Object)
                    if (e === f) c = g;
                    else return;
                else {
                    c = g[b];
                    var h = !0
                }
            } else c = a[e];
            if (d && c != null) {
                d = d(c);
                if (d == null) return d;
                if (!Object.is(d, c)) return h ? g[b] = d : a[e] = d, d
            }
            return c
        }
    }
    var N = function(a, b, c) {
        qe(a);
        x(M(a));
        var d = J ? a[z(K)] : a.h;
        var e = D(d, "state is only maintained on arrays.")[F] | 0;
        G(d, e);
        we(d, e, b, c);
        return a
    };

    function we(a, b, c, d, e) {
        qc(a, e);
        var f = cc(c, e);
        x(f === bc(c, Tb(D(a, "state is only maintained on arrays.")[F] | 0)));
        x(f >= 0);
        var g = a.length - 1;
        if (g >= cc(1, e) && f >= g) {
            var h = a[g];
            if (h != null && typeof h === "object" && !h[Ib] && h.constructor === Object) return h[c] = d, b
        }
        if (f <= g) return a[f] = d, b;
        d !== void 0 && ((g = b) == null && (b = D(a, "state is only maintained on arrays.")[F] | 0, G(a, b), g = b), x(g & 64), g = g >> 14 & 1023 || 536870912, c >= g ? (x(g !== 536870912), d != null && (f = {}, a[cc(g, e)] = (f[c] = d, f))) : a[f] = d);
        return b
    }

    function xe(a, b) {
        if (!a) return a;
        x(Rb(b) ? fc(a) : !0);
        return a
    }

    function ye(a, b, c) {
        c = c === void 0 ? !1 : c;
        nc(a, c);
        var d = D(a, "state is only maintained on arrays.")[F] | 0;
        x(d & 1);
        c || (x(Object.isFrozen(a) || d & 16), x(Rb(b) ? Object.isFrozen(a) : !0))
    }
    var ze = function(a) {
        return a && a === pc ? 2 : 4
    };

    function Ae(a, b) {
        return a ? fc(a, b) : !!(2 & b)
    }

    function Be(a, b, c) {
        return c && c !== 4 ? c !== 1 && Ae(a, b) ? 1 : c : 4
    }

    function Ce(a, b, c, d, e) {
        x(M(a));
        var f = J ? a[z(K)] : a.h;
        var g = D(f, "state is only maintained on arrays.")[F] | 0;
        G(f, g);
        d = Be(a, g, d);
        e = !!e || d === 3;
        d === 2 && pe(a) && (x(M(a)), f = J ? a[z(K)] : a.h, g = D(f, "state is only maintained on arrays.")[F] | 0, G(f, g));
        a = De(f, b);
        var h = a === Lb ? 7 : D(a, "state is only maintained on arrays.")[F] | 0,
            k = Ub(h, g);
        oc(a);
        var l = !(4 & k);
        if (l) {
            for (var p = 0, q = 0; p < a.length; p++) {
                var y = c(a[p]);
                y != null && (a[q++] = y)
            }
            q < p && (a.length = q);
            c = (k | 4) & -513;
            k = c &= -1025;
            k &= -4097
        }
        k !== h && (Nb(a, k), 2 & k && Object.freeze(a));
        a = Ee(a,
            k, f, g, b, d, l, e);
        oc(a);
        e || ye(a, f);
        return a
    }

    function Ee(a, b, c, d, e, f, g, h) {
        var k = b,
            l = Fe(b);
        l && f === 2 && (a = gd(a), k = 0, b = Ge(b, d), d = z(we(c, d, e, a)), l = !1);
        l || (f === 1 || (f !== 4 ? 0 : 2 & b || !(16 & b) && 32 & d) ? (e = !a.length || g && !(4096 & b) || !!(32 & d) && je(b), b |= e ? 2 : 256, b !== k && Nb(a, b), Object.freeze(a)) : (h || (b |= 16), b !== k && Nb(a, b)));
        2 & b || je(b) || re(c, d);
        return a
    }

    function De(a, b) {
        a = te(a, b);
        return Array.isArray(a) ? a : Lb
    }

    function Fe(a) {
        return !!(2 & a) && !!(4 & a) || !!(256 & a)
    }

    function He(a, b, c, d) {
        qe(a);
        x(M(a));
        var e = J ? a[z(K)] : a.h;
        var f = D(e, "state is only maintained on arrays.")[F] | 0;
        G(e, f);
        we(e, f, b, (d === "0" ? Number(c) === 0 : c === d) ? void 0 : c);
        return a
    }
    var Ke = function(a, b, c, d) {
            qe(a);
            x(M(a));
            var e = J ? a[z(K)] : a.h;
            var f = D(e, "state is only maintained on arrays.")[F] | 0;
            G(e, f);
            if (d == null) {
                var g = Ie(e);
                if (Je(g, e, f, c) === b) g.set(c, 0);
                else return a
            } else {
                x(b === 0 || c.includes(b));
                g = Ie(e);
                var h = Je(g, e, f, c);
                h !== b && (h && (f = we(e, f, h)), g.set(c, b))
            }
            we(e, f, b, d);
            return a
        },
        Me = function(a, b, c) {
            return Le(a, b) === c ? c : -1
        },
        Le = function(a, b) {
            x(M(a));
            a = J ? a[z(K)] : a.h;
            return Je(Ie(a), a, void 0, b)
        };

    function Ie(a) {
        if (yb) {
            var b;
            return (b = a[Cb]) != null ? b : a[Cb] = new Map
        }
        if (Cb in a) return Wa(a[Cb], Map);
        b = new Map;
        Object.defineProperty(a, Cb, {
            value: b
        });
        return b
    }

    function Je(a, b, c, d) {
        qc(b);
        var e = a.get(d);
        if (e != null) return e;
        for (var f = e = 0; f < d.length; f++) {
            var g = d[f];
            te(b, g) != null && (e !== 0 && (c = we(b, c, e)), e = g)
        }
        a.set(d, e);
        return e
    }

    function Ne(a, b, c, d) {
        var e = !1;
        d = ve(a, d, function(f) {
            var g = Rd(f, c, !1, b);
            e = g !== f && g != null;
            return g
        });
        if (d != null) return e && !fc(d) && re(a, b), xe(d, a)
    }
    var Pe = function(a) {
            var b = Oe;
            x(M(a));
            a = J ? a[z(K)] : a.h;
            var c = D(a, "state is only maintained on arrays.")[F] | 0;
            G(a, c);
            return Ne(a, c, b, 4) || b[Bb] || (b[Bb] = Sd(b))
        },
        Qe = function(a, b, c) {
            x(M(a));
            var d = J ? a[z(K)] : a.h;
            var e = D(d, "state is only maintained on arrays.")[F] | 0;
            G(d, e);
            b = Ne(d, e, b, c);
            if (b == null) return b;
            e = D(d, "state is only maintained on arrays.")[F] | 0;
            G(d, e);
            var f = e;
            fc(a, f) || (e = oe(b), e !== b && (pe(a) && (x(M(a)), d = J ? a[z(K)] : a.h, a = D(d, "state is only maintained on arrays.")[F] | 0, G(d, a), f = a), b = e, f = we(d, f, c, b), re(d,
                f)));
            return xe(b, d)
        },
        Re = function(a, b, c, d) {
            x(M(a));
            var e = J ? a[z(K)] : a.h;
            var f = D(e, "state is only maintained on arrays.")[F] | 0;
            G(e, f);
            var g = f;
            d = Be(a, g, d);
            f = d === 3;
            var h = !Ae(a, g);
            (d === 2 || h) && a && pe(a) && (x(M(a)), a = e = J ? a[z(K)] : a.h, g = D(a, "state is only maintained on arrays.")[F] | 0, G(a, g));
            a = De(e, c);
            var k = a === Lb ? 7 : D(a, "state is only maintained on arrays.")[F] | 0,
                l = Ub(k, g),
                p = !(4 & l);
            if (p) {
                var q = a,
                    y = g,
                    t = !!(2 & l);
                t && (y |= 2);
                for (var H = !t, B = !0, A = 0, O = 0; A < q.length; A++) {
                    var ca = Rd(q[A], b, !1, y);
                    if (ca instanceof b) {
                        if (!t) {
                            var U =
                                fc(ca);
                            H && (H = !U);
                            B && (B = U)
                        }
                        q[O++] = ca
                    }
                }
                O < A && (q.length = O);
                l |= 4;
                l = B ? l & -4097 : l | 4096;
                l = H ? l | 8 : l & -9
            }
            l !== k && (Nb(a, l), 2 & l && Object.freeze(a));
            if (h && !(8 & l || !a.length && (d === 1 || (d !== 4 ? 0 : 2 & l || !(16 & l) && 32 & g)))) {
                Fe(l) && (a = gd(a), l = Ge(l, g), g = z(we(e, g, c, a)));
                b = a;
                h = l;
                for (k = 0; k < b.length; k++) q = b[k], l = oe(q), q !== l && (b[k] = l);
                h |= 8;
                l = h = b.length ? h | 4096 : h & -4097;
                Nb(a, l)
            }
            a = Ee(a, l, e, g, c, d, p, f);
            if (!f) {
                c = a;
                d = d === 2;
                d = d === void 0 ? !1 : d;
                f = Rb(e);
                g = Rb(c);
                b = Object.isFrozen(c) && g;
                ye(c, e, d);
                if (f || g) d ? x(g) : x(b);
                x(!!((D(c, "state is only maintained on arrays.")[F] |
                    0) & 4));
                if (g && c.length)
                    for (d = 0; d < 1; d++) xe(c[d], e)
            }
            return a
        };

    function Se(a, b) {
        a != null ? Qd(a, z(b)) : a = void 0;
        return a
    }
    var Te = function(a, b, c, d) {
            d = Se(d, b);
            N(a, c, d);
            d && !fc(d) && (x(M(a)), b = J ? a[z(K)] : a.h, re(b));
            return a
        },
        Ue = function(a, b, c, d, e) {
            e = Se(e, b);
            Ke(a, c, d, e);
            e && !fc(e) && (x(M(a)), b = J ? a[z(K)] : a.h, re(b));
            return a
        },
        Ve = function(a, b, c, d) {
            qe(a);
            x(M(a));
            var e = J ? a[z(K)] : a.h;
            var f = D(e, "state is only maintained on arrays.")[F] | 0;
            G(e, f);
            x(!(f & 2));
            if (d == null) we(e, f, c);
            else {
                Td(d);
                for (var g = d === Lb ? 7 : D(d, "state is only maintained on arrays.")[F] | 0, h = g, k = Fe(g), l = k || Object.isFrozen(d), p = !0, q = !0, y = 0; y < d.length; y++) {
                    var t = d[y];
                    Qd(t,
                        z(b));
                    k || (t = fc(t), p && (p = !t), q && (q = t))
                }
                k || (g = p ? 13 : 5, g = q ? g & -4097 : g | 4096);
                l && g === h || (d = gd(d), h = 0, g = Ge(g, f));
                g !== h && Nb(d, g);
                nc(d);
                f = z(we(e, f, c, d));
                2 & g || je(g) || re(e, f)
            }
            return a
        };

    function Ge(a, b) {
        return a = (2 & b ? a | 2 : a & -3) & -273
    }

    function We(a, b) {
        qe(a);
        a = Ce(a, 4, Pd, 2, !0);
        a === Lb || D(a, "state is only maintained on arrays.");
        if (Array.isArray(b))
            for (var c = b.length, d = 0; d < c; d++) a.push(Nd(b[d]));
        else {
            b = u(b);
            c = b.next();
            try {
                for (; !c.done; c = b.next()) a.push(Nd(c.value))
            } finally {
                v(b, c)
            }
        }
        oc(a)
    }
    var Xe = function(a) {
            return xb() ? Kd(ue(a, 3)) : Kd(ue(a, 3, void 0, Md))
        },
        Ye = function(a, b) {
            a = ue(a, b);
            a = a == null || typeof a === "boolean" ? a : typeof a === "number" ? !!a : void 0;
            return a != null ? a : !1
        },
        Ze = function(a, b) {
            var c = c === void 0 ? 0 : c;
            a = xd(ue(a, b));
            return a != null ? a : c
        },
        $e = function(a, b) {
            var c = c === void 0 ? 0 : c;
            a = yd(ue(a, b));
            return a != null ? a : c
        },
        af = function(a, b) {
            var c = c === void 0 ? se : c;
            a = xb() ? Jd(ue(a, b)) : ue(a, b, void 0, Jd);
            return a != null ? a : c
        },
        bf = function(a, b) {
            a = ue(a, b, void 0, nd);
            return a != null ? a : 0
        },
        cf = function(a, b) {
            a = Pd(ue(a,
                b));
            return a != null ? a : ""
        },
        Q = function(a, b) {
            var c = c === void 0 ? 0 : c;
            var d;
            return (d = td(ue(a, b))) != null ? d : c
        },
        df = function(a) {
            var b = b === void 0 ? "0" : b;
            a = xb() ? Ld(ue(a, 3), !0) : Ld(ue(a, 3, void 0, Md));
            return a != null ? a : b
        },
        R = function(a, b, c) {
            return Q(a, Me(a, c, b))
        },
        ef = function(a, b, c) {
            b = Me(a, c, b);
            return td(ue(a, b))
        },
        ff = function(a, b, c) {
            return He(a, b, c == null ? c : zd(c), "0")
        },
        gf = function(a, b, c) {
            return He(a, b, c == null ? c : sd(c), 0)
        },
        T = function(a, b, c, d) {
            return Ke(a, b, c, d == null ? d : sd(d))
        },
        hf = function(a, b, c) {
            qe(a);
            x(M(a));
            var d = J ? a[z(K)] :
                a.h;
            var e = D(d, "state is only maintained on arrays.")[F] | 0;
            G(d, e);
            if (c == null) we(d, e, b);
            else {
                Td(c);
                var f = c === Lb ? 7 : D(c, "state is only maintained on arrays.")[F] | 0,
                    g = f,
                    h = Fe(f),
                    k = h || Object.isFrozen(c);
                h || (f = 0);
                k || (c = gd(c), g = 0, f = Ge(f, e), k = !1);
                f |= 5;
                h = 4 & f ? 512 & f ? 512 : 1024 & f ? 1024 : 0 : void 0;
                f |= h != null ? h : xb() ? 0 : 1024;
                for (h = 0; h < c.length; h++) {
                    var l = c[h],
                        p = vd(l);
                    Object.is(l, p) || (k && (c = gd(c), g = 0, f = Ge(f, e), k = !1), c[h] = p)
                }
                f !== g && (k && (c = gd(c), f = Ge(f, e)), Nb(c, f));
                nc(c);
                we(d, e, b, c)
            }
            return a
        };
    x(!0);
    var jf = function(a, b, c) {
        this.preventPassingToStructuredClone = mc;
        Wa(this, jf, "The message constructor should only be used by subclasses");
        x(this.constructor !== jf, "Message is an abstract class and cannot be directly constructed");
        var d = this.constructor,
            e;
        if (a && ((e = a[Fb]) != null ? e : a[Fb] = d) !== d) throw Error("data must only be constructed with one message type");
        a = he(a, b, c, 2048);
        x(M(this));
        D(a);
        J ? this[z(K)] = a : this.h = a;
        x(M(this));
        a = J ? this[z(K)] : this.h;
        b = D(a, "state is only maintained on arrays.")[F] | 0;
        G(a, b);
        x(b & 64);
        x(b & 2048)
    };
    jf.prototype.toJSON = function() {
        return ee(this)
    };
    var kf = function(a) {
        return JSON.stringify(ee(a))
    };
    jf.prototype.getExtension = function(a) {
        Wa(this, a.Lc);
        var b = Wa(this, jf);
        Zd(b);
        return a.la ? a.mb ? a.pa(b, a.la, a.ba, ze(), a.ca) : a.pa(b, a.la, a.ba, a.ca) : a.mb ? a.pa(b, a.ba, ze(), a.ca) : a.pa(b, a.ba, a.defaultValue, a.ca)
    };
    jf.prototype.hasExtension = function(a) {
        x(!a.mb, "repeated extensions don't support hasExtension");
        var b = Wa(this, jf);
        Zd(b);
        a.la ? (x(M(b)), b = J ? b[z(K)] : b.h, a = te(b, a.ba, a.ca), a = ac(a) || Array.isArray(a)) : (x(!a.mb, "repeated extensions don't support getExtensionOrUndefined"), Wa(b, a.Lc), b = Wa(b, jf), Zd(b), a = a.la ? a.pa(b, a.la, a.ba, a.ca) : a.pa(b, a.ba, null, a.ca), a = (a === null ? void 0 : a) !== void 0);
        return a
    };
    jf.prototype.clone = function() {
        var a = Wa(this, jf);
        x(ac(a));
        var b = Xb(a),
            c = Qb(b);
        return me(a, b, c) ? ne(a, b, !0) : new a.constructor(le(b, c, !1))
    };
    Yb = jf;
    jf.prototype[Db] = $b;
    jf.prototype.toString = function() {
        x(M(this));
        return (J ? this[z(K)] : this.h).toString()
    };

    function lf(a) {
        if (a instanceof jf) return a.constructor.i
    };
    (function() {
        var a = w.jspbGetTypeName;
        w.jspbGetTypeName = a ? function(b) {
            return a(b) || lf(b)
        } : lf
    })();
    var V = jf;

    function mf(a) {
        return function(b) {
            Ua(a);
            if (b == null || b == "") b = Wa(new a, jf);
            else {
                Ta(b);
                b = JSON.parse(b);
                if (!Array.isArray(b)) throw Error("Expected to deserialize an Array but got " + Ka(b) + ": " + b);
                Pb(b, 32);
                b = new a(b)
            }
            return b
        }
    };
    var nf = function(a) {
        V.call(this, a)
    };
    r(nf, V);
    var of = mf(nf);
    nf.i = "contentads.bow.rendering.client.Dv3MetaData";
    var pf = new function(a, b) {
        b = b === void 0 ? 0 : b;
        this.key = a;
        this.defaultValue = b;
        this.valueType = "number"
    }("100004", 16E3);

    function qf(a, b) {
        if (a)
            for (var c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function rf(a) {
        try {
            var b;
            if (b = !!a && a.location.href != null) a: {
                try {
                    nb(a.foo);
                    b = !0;
                    break a
                } catch (c) {}
                b = !1
            }
            return b
        } catch (c) {
            return !1
        }
    }

    function sf(a, b, c) {
        b = b === void 0 ? !1 : b;
        var d = d === void 0 ? w : d;
        c = (c === void 0 ? 0 : c) ? tf(d) : d;
        for (d = 0; c && d++ < 40 && (!b && !rf(c) || !a(c));) c = tf(c)
    }

    function tf(a) {
        try {
            var b = a.parent;
            if (b && b !== a) return b
        } catch (c) {}
        return null
    };

    function uf(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };

    function vf() {
        return E("iPad") || E("Android") && !E("Mobile") || E("Silk")
    };
    /* 
     
     Copyright Google LLC 
     SPDX-License-Identifier: Apache-2.0 
    */
    var wf = {};

    function xf() {
        if (wf !== wf) throw Error("Bad secret");
    };
    var yf = globalThis.trustedTypes,
        zf;

    function Af() {
        var a = null;
        if (!yf) return a;
        try {
            var b = function(c) {
                return c
            };
            a = yf.createPolicy("goog#html", {
                createHTML: b,
                createScript: b,
                createScriptURL: b
            })
        } catch (c) {
            throw c;
        }
        return a
    }

    function Bf() {
        zf === void 0 && (zf = Af());
        return zf
    };
    var Cf = function(a) {
        xf();
        this.hc = a
    };
    Cf.prototype.toString = function() {
        return this.hc + ""
    };

    function Df(a) {
        var b = Bf();
        a = b ? b.createScriptURL(a) : a;
        return new Cf(a)
    }

    function Ef(a) {
        if (a instanceof Cf) return a.hc;
        throw Error("Unexpected type when unwrapping TrustedResourceUrl");
    };
    var Ff = pa([""]),
        Gf = oa(["\x00"], ["\\0"]),
        Hf = oa(["\n"], ["\\n"]),
        If = oa(["\x00"], ["\\u0000"]),
        Jf = pa([""]),
        Kf = oa(["\x00"], ["\\0"]),
        Lf = oa(["\n"], ["\\n"]),
        Mf = oa(["\x00"], ["\\u0000"]);

    function Nf(a) {
        return Object.isFrozen(a) && Object.isFrozen(a.raw)
    }

    function Of(a) {
        return a.toString().indexOf("`") === -1
    }
    var Pf = Of(function(a) {
            return a(Ff)
        }) || Of(function(a) {
            return a(Gf)
        }) || Of(function(a) {
            return a(Hf)
        }) || Of(function(a) {
            return a(If)
        }),
        Qf = Nf(Jf) && Nf(Kf) && Nf(Lf) && Nf(Mf);
    var Rf = function(a) {
        xf();
        this.Yc = a
    };
    Rf.prototype.toString = function() {
        return this.Yc
    };
    new Rf("about:blank");
    new Rf("about:invalid#zClosurez");
    var Sf = /^\s*(?!javascript:)(?:[\w+.-]+:|[^:/?#]*(?:[/?#]|$))/i,
        Tf = [],
        Uf = function() {};
    Vf(function(a) {
        console.warn("A URL with content '" + a + "' was sanitized away.")
    });

    function Vf(a) {
        Tf.indexOf(a) === -1 && Tf.push(a);
        Uf = function(b) {
            Tf.forEach(function(c) {
                c(b)
            })
        }
    };
    var Wf = function(a) {
        xf();
        this.fc = a
    };
    Wf.prototype.toString = function() {
        return this.fc + ""
    };

    function Xf(a) {
        var b = Bf();
        a = b ? b.createHTML(a) : a;
        return new Wf(a)
    }

    function Yf(a) {
        if (a instanceof Wf) return a.fc;
        throw Error("Unexpected type when unwrapping SafeHtml");
    };

    function Zf(a) {
        a = a === void 0 ? document : a;
        var b, c;
        a = (c = (b = a).querySelector) == null ? void 0 : c.call(b, "script[nonce]");
        return a == null ? "" : a.nonce || a.getAttribute("nonce") || ""
    };

    function $f(a, b) {
        a.src = Ef(b);
        (b = Zf(a.ownerDocument)) && a.setAttribute("nonce", b)
    };
    var ag = uf(function() {
        return !vf() && (E("iPod") || E("iPhone") || E("Android") || E("IEMobile")) ? 2 : vf() ? 1 : 0
    });

    function bg() {
        if (!globalThis.crypto) return Math.random();
        try {
            var a = new Uint32Array(1);
            globalThis.crypto.getRandomValues(a);
            return a[0] / 65536 / 65536
        } catch (b) {
            return Math.random()
        }
    };
    var cg, dg = 64;

    function eg() {
        try {
            return cg != null || (cg = new Uint32Array(64)), dg >= 64 && (crypto.getRandomValues(cg), dg = 0), cg[dg++]
        } catch (a) {
            return Math.floor(Math.random() * 4294967296)
        }
    };

    function fg() {
        var a = window;
        if (!Gc(a.goog_pvsid)) try {
            var b = eg() + (eg() & 2097151) * 4294967296;
            Object.defineProperty(a, "goog_pvsid", {
                value: b,
                configurable: !0
            })
        } catch (c) {}
        return Number(a.goog_pvsid) || -1
    };

    function gg(a) {
        if (a instanceof Wf) return a;
        a = hg(String(a));
        return Xf(a)
    }

    function hg(a) {
        return a.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;")
    }

    function ig(a) {
        return jg(a)
    }

    function jg(a) {
        var b = gg("");
        return Xf(a.map(function(c) {
            return Yf(gg(c))
        }).join(Yf(b).toString()))
    }
    var kg = /^[a-z][a-z\d-]*$/i,
        lg = "APPLET BASE EMBED IFRAME LINK MATH META OBJECT SCRIPT STYLE SVG TEMPLATE".split(" "),
        mg = "AREA BR COL COMMAND HR IMG INPUT KEYGEN PARAM SOURCE TRACK WBR".split(" "),
        ng = ["action", "formaction", "href"];

    function og(a) {
        if (!kg.test(a)) throw Error("Invalid tag name <" + a + ">.");
        if (lg.indexOf(a.toUpperCase()) !== -1) throw Error("Tag name <" + a + "> is not allowed for createHtml.");
    }

    function pg(a, b) {
        var c = {};
        og(a);
        var d = "<" + a;
        c && (d += qg(c));
        Array.isArray(b) || (b = b === void 0 ? [] : [b]);
        if (mg.indexOf(a.toUpperCase()) !== -1) {
            if (b.length > 0) throw Error("Void tag <" + a + "> does not allow content.");
            d += ">"
        } else b = ig(b.map(function(e) {
            return e instanceof Wf ? e : gg(String(e))
        })), d += ">" + b.toString() + "</" + a + ">";
        return Xf(d)
    }

    function qg(a) {
        for (var b = "", c = Object.keys(a), d = 0; d < c.length; d++) {
            var e = c[d],
                f = a[e];
            if (!kg.test(e)) throw Error('Invalid attribute name "' + e + '".');
            if (f !== void 0 && f !== null) {
                if (/^on./i.test(e)) throw Error('Attribute "' + e + " is forbidden. Inline event handlers can lead to XSS. Please use the 'addEventListener' API instead.");
                if (ng.indexOf(e.toLowerCase()) !== -1)
                    if (f instanceof Rf) f = f.toString();
                    else {
                        var g = f = String(f),
                            h = !Sf.test(g);
                        h && Uf(g);
                        f = h ? void 0 : f;
                        f = f || "about:invalid#zClosurez"
                    }
                if (!(f instanceof Rf ||
                        f instanceof Wf) && typeof f !== "string" && typeof f !== "number") throw Error("String or number value expected, got " + typeof f + " with value '" + f + "' given.");
                e = e + '="' + gg(String(f)) + '"';
                b += " " + e
            }
        }
        return b
    };
    "ARTICLE SECTION NAV ASIDE H1 H2 H3 H4 H5 H6 HEADER FOOTER ADDRESS P HR PRE BLOCKQUOTE OL UL LH LI DL DT DD FIGURE FIGCAPTION MAIN DIV EM STRONG SMALL S CITE Q DFN ABBR RUBY RB RT RTC RP DATA TIME CODE VAR SAMP KBD SUB SUP I B U MARK BDI BDO SPAN BR WBR NOBR INS DEL PICTURE PARAM TRACK MAP TABLE CAPTION COLGROUP COL TBODY THEAD TFOOT TR TD TH SELECT DATALIST OPTGROUP OPTION OUTPUT PROGRESS METER FIELDSET LEGEND DETAILS SUMMARY MENU DIALOG SLOT CANVAS FONT CENTER ACRONYM BASEFONT BIG DIR HGROUP STRIKE TT".split(" ").concat(["BUTTON",
        "INPUT"
    ]);

    function rg(a) {
        var b = a.indexOf("//") + 2,
            c = a.indexOf("/", b);
        if (c <= b) return "Can't interpolate data in a url's origin, Please make sure to fully specify the origin, terminated with '/'.";
        a = a.substring(b, c);
        if (!/^[0-9a-z.:-]+$/i.test(a)) return "The origin contains unsupported characters.";
        if (!/^[^:]*(:[0-9]+)?$/i.test(a)) return "Invalid port number.";
        if (!/(^|\.)[a-z][^.]*$/i.test(a)) return "The top-level domain must start with a letter."
    }

    function sg(a) {
        a = a.toLowerCase();
        if (/^data:/.test(a)) return "Data URLs cannot have expressions in the template literal input.";
        if (/^https:\/\//.test(a) || /^\/\//.test(a)) return rg(a);
        if (/^\//.test(a)) return a = a === "/" || a.length > 1 && a[1] !== "/" && a[1] !== "\\" ? void 0 : "The path start in the url is invalid.", a;
        if (/^about:blank/.test(a)) return a = a === "about:blank" || /^about:blank#/.test(a) ? void 0 : "The about url is invalid.", a;
        if (!RegExp("^[^:\\s\\\\/]+/").test(a)) return "Trying to interpolate expressions in an unsupported url format. The template literal must start with a compile-time static origin (e.g. 'https://example.com/'), absolute path ('/path/'), or relative path ('path/'). See go/ts-dom-sink#trustedresourceurl."
    };

    function tg(a) {
        var b = qa.apply(1, arguments),
            c = b.length;
        if (!Array.isArray(a) || !Array.isArray(a.raw) || a.length !== a.raw.length || !Pf && a === a.raw || !(Pf && !Qf || Nf(a)) || c + 1 !== a.length) throw new TypeError("\n    ############################## ERROR ##############################\n\n    It looks like you are trying to call a template tag function (fn`...`)\n    using the normal function syntax (fn(...)), which is not supported.\n\n    The functions in the safevalues library are not designed to be called\n    like normal functions, and doing so invalidates the security guarantees\n    that safevalues provides.\n\n    If you are stuck and not sure how to proceed, please reach out to us\n    instead through:\n     - go/ise-hardening-yaqs (preferred) // LINE-INTERNAL\n     - g/ise-hardening // LINE-INTERNAL\n     - https://github.com/google/safevalues/issues\n\n    ############################## ERROR ##############################");
        if (b.length === 0) return Df(a[0]);
        c = sg(a[0]);
        if (c !== void 0) throw Error(c);
        c = a[0];
        for (var d = 0; d < b.length; d++) c += encodeURIComponent(b[d]) + a[d + 1];
        return Df(c)
    }

    function ug(a, b) {
        a = Ef(a).toString();
        var c = a.split(/[?#]/),
            d = /[?]/.test(a) ? "?" + c[1] : "";
        return vg(c[0], d, /[#]/.test(a) ? "#" + (d ? c[2] : c[1]) : "", b)
    }

    function vg(a, b, c, d) {
        function e(g, h) {
            g != null && (Array.isArray(g) ? g.forEach(function(k) {
                return e(k, h)
            }) : (b += f + encodeURIComponent(h) + "=" + encodeURIComponent(g), f = "&"))
        }
        var f = b.length ? "&" : "?";
        d.constructor === Object && (d = Object.entries(d));
        Array.isArray(d) ? d.forEach(function(g) {
            return e(g[1], g[0])
        }) : d.forEach(e);
        return Df(a + b + c)
    };
    var wg = function(a, b) {
        b = b === void 0 ? document : b;
        return b.createElement(String(a).toLowerCase())
    };
    var xg = [];

    function yg() {
        var a = xg;
        xg = [];
        a = u(a);
        var b = a.next();
        try {
            for (; !b.done; b = a.next()) {
                var c = b.value;
                try {
                    c()
                } catch (d) {}
            }
        } finally {
            v(a, b)
        }
    };
    var zg = function(a, b, c) {
            function d(h) {
                h && b.appendChild(typeof h === "string" ? a.createTextNode(h) : h)
            }
            for (var e = 1; e < c.length; e++) {
                var f = c[e];
                if (!La(f) || Ma(f) && f.nodeType > 0) d(f);
                else {
                    a: {
                        if (f && typeof f.length == "number") {
                            if (Ma(f)) {
                                var g = typeof f.item == "function" || typeof f.item == "string";
                                break a
                            }
                            if (typeof f === "function") {
                                g = typeof f.item == "function";
                                break a
                            }
                        }
                        g = !1
                    }
                    jb(g ? mb(f) : f, d)
                }
            }
        },
        Ag = function(a, b) {
            b = String(b);
            a.contentType === "application/xhtml+xml" && (b = b.toLowerCase());
            return a.createElement(b)
        },
        Bg = function(a) {
            x(a,
                "Node cannot be null or undefined.");
            return a.nodeType == 9 ? a : a.ownerDocument || a.document
        },
        Cg = function(a) {
            this.Ya = a || w.document || document
        };
    m = Cg.prototype;
    m.getElementsByTagName = function(a, b) {
        return (b || this.Ya).getElementsByTagName(String(a))
    };
    m.createElement = function(a) {
        return Ag(this.Ya, a)
    };
    m.createTextNode = function(a) {
        return this.Ya.createTextNode(String(a))
    };
    m.appendChild = function(a, b) {
        x(a != null && b != null, "goog.dom.appendChild expects non-null arguments");
        a.appendChild(b)
    };
    m.append = function(a, b) {
        zg(Bg(a), a, arguments)
    };
    m.canHaveChildren = function(a) {
        if (a.nodeType != 1) return !1;
        switch (a.tagName) {
            case "APPLET":
            case "AREA":
            case "BASE":
            case "BR":
            case "COL":
            case "COMMAND":
            case "EMBED":
            case "FRAME":
            case "HR":
            case "IMG":
            case "INPUT":
            case "IFRAME":
            case "ISINDEX":
            case "KEYGEN":
            case "LINK":
            case "NOFRAMES":
            case "NOSCRIPT":
            case "META":
            case "OBJECT":
            case "PARAM":
            case "SCRIPT":
            case "SOURCE":
            case "STYLE":
            case "TRACK":
            case "WBR":
                return !1
        }
        return !0
    };
    m.removeNode = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    };
    m.isElement = function(a) {
        return Ma(a) && a.nodeType == 1
    };
    m.contains = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && b.nodeType == 1) return a == b || a.contains(b);
        if (typeof a.compareDocumentPosition != "undefined") return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    };

    function Dg(a) {
        w.document.readyState === "complete" ? (xg.push(a), xg.length === 1 && (window.Promise ? Promise.resolve().then(yg) : (a = window.setImmediate, Kc(a) ? a(yg) : setTimeout(yg, 0)))) : w.addEventListener("load", a)
    };

    function Eg(a, b, c, d, e) {
        Fg(a, b, c === void 0 ? null : c, d === void 0 ? !1 : d, e === void 0 ? !1 : e)
    }

    function Fg(a, b, c, d, e) {
        e = e === void 0 ? !1 : e;
        a.google_image_requests || (a.google_image_requests = []);
        var f = wg("IMG", a.document);
        if (c || d) {
            var g = function(h) {
                c && c(h);
                if (d) {
                    h = a.google_image_requests;
                    var k = ib(h, f);
                    k >= 0 && (x(h.length != null), Array.prototype.splice.call(h, k, 1))
                }
                typeof f.removeEventListener === "function" && f.removeEventListener("load", g, !1);
                typeof f.removeEventListener === "function" && f.removeEventListener("error", g, !1)
            };
            typeof f.addEventListener === "function" && f.addEventListener("load", g, !1);
            typeof f.addEventListener ===
                "function" && f.addEventListener("error", g, !1)
        }
        e && (f.attributionSrc = "");
        f.src = b;
        a.google_image_requests.push(f)
    }

    function Gg(a) {
        var b = b === void 0 ? !1 : b;
        var c;
        if (c = w.navigator) c = w.navigator.userAgent, c = !(!/Chrome/.test(c) || /Edge/.test(c));
        c && typeof w.navigator.sendBeacon === "function" ? w.navigator.sendBeacon(a) : Eg(w, a, void 0, b)
    }

    function Hg(a) {
        var b = b === void 0 ? !1 : b;
        var c = "https://pagead2.googlesyndication.com/pagead/gen_204?id=rcs_internal";
        qf(a, function(d, e) {
            if (d || d === 0) c += "&" + e + "=" + encodeURIComponent(String(d))
        });
        Ig(window, c, b)
    }

    function Ig(a, b, c) {
        c = c === void 0 ? !1 : c;
        var d = d === void 0 ? !1 : d;
        a.fetch ? (c = {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors"
        }, d && (c.mode = "cors", "setAttributionReporting" in XMLHttpRequest.prototype ? c.attributionReporting = {
            eventSourceEligible: "true",
            triggerEligible: "false"
        } : c.headers = {
            "Attribution-Reporting-Eligible": "event-source"
        }), a.fetch(b, c)) : Eg(a, b, void 0, c, d)
    };
    var Jg = function() {
            this.eb = {}
        },
        Mg = function() {
            Kg || (Kg = new Lg);
            var a = Kg.eb[pf.key];
            if (pf.valueType === "proto") {
                try {
                    var b = JSON.parse(a);
                    if (Array.isArray(b)) return b
                } catch (c) {}
                return pf.defaultValue
            }
            return typeof a === typeof pf.defaultValue ? a : pf.defaultValue
        };
    var Lg = function() {
            this.eb = {};
            var a = document.currentScript;
            a = (a = (a = a === void 0 ? null : a) && a.getAttribute("data-jc") === "0" ? a : document.querySelector('[data-jc="0"]')) && a.getAttribute("data-jc-flags") || "";
            try {
                var b = JSON.parse(a)[0];
                a = "";
                for (var c = 0; c < b.length; c++) a += String.fromCharCode(b.charCodeAt(c) ^ "\u0003\u0007\u0003\u0007\b\u0004\u0004\u0006\u0005\u0003".charCodeAt(c % 10));
                this.eb = JSON.parse(a)
            } catch (d) {}
        },
        Kg;
    r(Lg, Jg);
    var Ng = function(a) {
        V.call(this, a)
    };
    r(Ng, V);
    Ng.prototype.W = function(a) {
        var b = Ce(this, 3, xd, 3, !0);
        if (typeof a !== "number" || a < 0 || a >= b.length) throw Error("Index " + a + " out of range for field of length " + b.length + ".");
        return b[a]
    };
    Ng.i = "contentads.shared.capture.remote.ClientPingMetadata";
    var Og = function(a, b) {
        var c = c === void 0 ? {} : c;
        this.error = a;
        this.meta = c;
        this.context = b.context;
        this.msg = b.message || "";
        this.id = b.id || "jserror"
    };

    function Pg(a) {
        var b = a.toString();
        a.name && b.indexOf(a.name) == -1 && (b += ": " + a.name);
        a.message && b.indexOf(a.message) == -1 && (b += ": " + a.message);
        if (a.stack) a: {
            a = a.stack;
            var c = b;
            try {
                a.indexOf(c) == -1 && (a = c + "\n" + a);
                for (var d; a != d;) d = a, a = a.replace(RegExp("((https?:/..*/)[^/:]*:\\d+(?:.|\n)*)\\2"), "$1");
                b = a.replace(RegExp("\n *", "g"), "\n");
                break a
            } catch (e) {
                b = c;
                break a
            }
            b = void 0
        }
        return b
    };

    function Qg(a, b) {
        try {
            var c = function(d) {
                var e = {};
                return [(e[d.gd] = d.Rc, e)]
            };
            return JSON.stringify([a.filter(function(d) {
                return d.ac
            }).map(c), ee(b), a.filter(function(d) {
                return !d.ac
            }).map(c)])
        } catch (d) {
            return Rg(d, b), ""
        }
    }

    function Rg(a, b) {
        try {
            Hg({
                m: Pg(a instanceof Error ? a : Error(String(a))),
                b: Q(b, 1) || null,
                v: cf(b, 2) || null
            })
        } catch (c) {}
    }
    var Sg = function(a, b, c) {
            this.Kb = c;
            c = new Ng;
            a = gf(c, 1, a);
            this.Wa = He(a, 2, Od(b), "")
        },
        Tg = function(a) {
            if (a.Kb) {
                var b = a.Wa,
                    c = [],
                    d = c.concat,
                    e = Set,
                    f = [],
                    g = f.concat;
                var h = Ce(a.Wa, 3, xd);
                c = d.call(c, na(new e(g.call(f, na(h), na(a.Kb())))));
                hf(b, 3, c)
            }
            a = a.Wa;
            x(M(a));
            b = J ? a[z(K)] : a.h;
            c = D(b, "state is only maintained on arrays.")[F] | 0;
            G(b, c);
            return fc(a, c) ? a : me(a, b, c) ? ne(a, b) : new a.constructor(le(b, c, !0))
        };

    function Ug(a) {
        var b = new CompressionStream("gzip"),
            c = (new Response(b.readable)).arrayBuffer(),
            d = b.writable.getWriter(),
            e = typeof a === "string" ? (new TextEncoder).encode(a) : a;
        return d.ready.then(function() {
            return d.write(e)
        }).then(function() {
            return d.close()
        }).then(function() {
            return c
        }).then(function(f) {
            return new Uint8Array(f)
        })
    };
    var Vg = function(a) {
        V.call(this, a)
    };
    r(Vg, V);
    Vg.prototype.Ea = function() {
        return Q(this, 3)
    };
    Vg.prototype.sb = function(a) {
        return N(this, 3, a == null ? a : sd(a))
    };
    Vg.i = "tagging.common.experiments.GenotypeDisjointConditionCollisionEvent";
    var Wg = function(a) {
        V.call(this, a)
    };
    r(Wg, V);
    Wg.prototype.M = function() {
        return Q(this, 1)
    };
    Wg.prototype.fa = function(a) {
        return gf(this, 1, a)
    };
    var Xg = function(a, b) {
        return gf(a, 2, b)
    };
    Wg.i = "tagging.common.experiments.GenotypeDiversionEvent.DiversionPointInBinary";
    var Yg = function(a) {
        V.call(this, a)
    };
    r(Yg, V);
    Yg.prototype.gb = function() {
        return R(this, 2, Zg)
    };
    Yg.prototype.ub = function(a) {
        T(this, 2, Zg, a)
    };
    Yg.i = "tagging.common.experiments.GenotypeDiversionEvent.ModAssignment";
    var Zg = [1, 2];
    var $g = function(a) {
        V.call(this, a)
    };
    r($g, V);
    var ah = function(a, b) {
            return Te(a, Wg, 1, b)
        },
        bh = function(a, b) {
            return Ve(a, Wg, 2, b)
        },
        ch = function(a, b) {
            return hf(a, 4, b)
        },
        dh = function(a, b) {
            return Ve(a, Yg, 5, b)
        },
        eh = function(a, b) {
            return gf(a, 6, b)
        };
    $g.i = "tagging.common.experiments.GenotypeDiversionEvent";
    var fh = function(a) {
        V.call(this, a)
    };
    r(fh, V);
    m = fh.prototype;
    m.Fa = function() {
        return Le(this, gh)
    };
    m.oa = function() {
        return R(this, 1, gh)
    };
    m.jc = function(a) {
        T(this, 1, gh, a)
    };
    m.Ja = function() {
        return R(this, 2, gh)
    };
    m.nc = function(a) {
        T(this, 2, gh, a)
    };
    m.Ka = function() {
        return R(this, 3, gh)
    };
    m.rc = function(a) {
        T(this, 3, gh, a)
    };
    m.ra = function() {
        return R(this, 4, gh)
    };
    m.sc = function(a) {
        T(this, 4, gh, a)
    };
    m.Ia = function() {
        return R(this, 6, gh)
    };
    m.mc = function(a) {
        T(this, 6, gh, a)
    };
    m.Ub = function() {
        return ef(this, 6, gh) != null
    };
    m.Ha = function() {
        return R(this, 7, gh)
    };
    m.lc = function(a) {
        T(this, 7, gh, a)
    };
    fh.i = "tagging.common.experiments.GenotypeFlagsOverriddenAfterAccessEvent.FlagOverriddenAfterAccess";
    var gh = [1, 2, 3, 4, 6, 7];
    var hh = function(a) {
        V.call(this, a)
    };
    r(hh, V);
    hh.prototype.tb = function(a) {
        return He(this, 1, wd(a), 0)
    };
    hh.i = "tagging.common.experiments.GenotypeFlagsOverriddenAfterAccessEvent";
    var ih = function(a) {
        V.call(this, a)
    };
    r(ih, V);
    ih.prototype.Rb = function() {
        return Le(this, jh)
    };
    var kh = function(a, b) {
        return N(a, 1, b == null ? b : sd(b))
    };
    m = ih.prototype;
    m.Mb = function() {
        return R(this, 2, jh)
    };
    m.kc = function(a) {
        return T(this, 2, jh, a)
    };
    m.Qb = function() {
        return R(this, 3, jh)
    };
    m.oc = function(a) {
        return T(this, 3, jh, a)
    };
    m.Tb = function() {
        return R(this, 4, jh)
    };
    m.tc = function(a) {
        return T(this, 4, jh, a)
    };
    ih.i = "tagging.common.experiments.GenotypePropertyErrorEvent.PropertyError";
    var jh = [2, 3, 4];
    var lh = function(a) {
        V.call(this, a)
    };
    r(lh, V);
    m = lh.prototype;
    m.Rb = function() {
        return Le(this, mh)
    };
    m.Mb = function() {
        return R(this, 3, mh)
    };
    m.kc = function(a) {
        return T(this, 3, mh, a)
    };
    m.Qb = function() {
        return R(this, 4, mh)
    };
    m.oc = function(a) {
        return T(this, 4, mh, a)
    };
    m.Tb = function() {
        return R(this, 5, mh)
    };
    m.tc = function(a) {
        return T(this, 5, mh, a)
    };
    lh.i = "tagging.common.experiments.Condition";
    var mh = [3, 4, 5],
        nh = [6, 7];
    var oh = function(a) {
        V.call(this, a)
    };
    r(oh, V);
    m = oh.prototype;
    m.L = function() {
        return Qe(this, lh, 1)
    };
    m.Sa = function(a) {
        return Te(this, lh, 1, a)
    };
    m.M = function() {
        return Q(this, 2)
    };
    m.fa = function(a) {
        return N(this, 2, a == null ? a : sd(a))
    };
    m.tb = function(a) {
        return N(this, 3, wd(a))
    };
    oh.i = "tagging.common.experiments.GenotypePropertyErrorEvent";
    var ph = [4, 5];
    var qh = function(a) {
        V.call(this, a)
    };
    r(qh, V);
    qh.prototype.Sb = function() {
        return af(this, 6)
    };
    qh.prototype.qc = function(a) {
        return ff(this, 6, a)
    };
    var sh = function(a) {
        var b = new qh;
        return Ue(b, $g, 4, rh, a)
    };
    qh.i = "tagging.common.experiments.GenotypeEvent";
    var rh = [4, 5, 7, 8, 9];
    var th = function() {
        Sg.apply(this, arguments)
    };
    r(th, Sg);
    var uh = function() {
        th.apply(this, arguments)
    };
    r(uh, th);
    uh.prototype.Qa = function() {
        this.dd.apply(this, na(qa.apply(0, arguments).map(function(a) {
            return {
                ac: !0,
                gd: 4,
                Rc: ee(a)
            }
        })))
    };

    function vh(a, b) {
        if (globalThis.fetch) globalThis.fetch(a, {
            method: "POST",
            body: b,
            keepalive: b.length < 65536,
            credentials: "omit",
            mode: "no-cors",
            redirect: "follow"
        }).catch(function() {});
        else {
            var c = new XMLHttpRequest;
            c.open("POST", a, !0);
            c.send(b)
        }
    }

    function wh(a, b, c, d) {
        c = c === void 0 ? 1 : c;
        if (d === void 0 ? 0 : d) {
            d = typeof CompressionStream === "function";
            var e = b.length > 1024;
            typeof document !== "undefined" && document.visibilityState !== "hidden" && d && e ? Ug(b).then(function(f) {
                var g = c === 1 ? 5 : 6;
                f = tb(f);
                vh(a + "?e=" + g, f)
            }).catch(function() {
                vh(a + "?e=" + c, b)
            }) : vh(a + "?e=" + c, b)
        } else vh(a + "?e=" + c, b)
    };
    var xh = function(a, b, c, d, e, f, g, h, k) {
        uh.call(this, a, b, k);
        this.Xc = c;
        this.Wc = d;
        this.Zc = e;
        this.Pc = f;
        this.Vc = g;
        this.Bb = h;
        this.Gc = !1;
        this.P = [];
        this.va = null;
        this.Xb = !1
    };
    r(xh, uh);
    var yh = function(a) {
        a.va !== null && (clearTimeout(a.va), a.va = null);
        if (a.P.length) {
            var b = Qg(a.P, Tg(a));
            a.Wc(a.Xc, b, 1, a.Gc);
            a.P = []
        }
    };
    xh.prototype.dd = function() {
        var a = qa.apply(0, arguments),
            b = this;
        try {
            this.Vc && Qg(this.P.concat(a), Tg(this)).length >= 65536 && yh(this), this.Bb && !this.Xb && (this.Xb = !0, this.Bb.xd(function() {
                yh(b)
            })), this.P.push.apply(this.P, na(a)), this.P.length >= this.Pc && yh(this), this.P.length && this.va === null && (this.va = setTimeout(function() {
                yh(b)
            }, this.Zc))
        } catch (c) {
            Rg(c, Tg(this))
        }
    };
    var zh = function(a, b, c, d, e, f, g) {
        xh.call(this, a, b, "https://pagead2.googlesyndication.com/pagead/ping", wh, c === void 0 ? 1E3 : c, d === void 0 ? 100 : d, (e === void 0 ? !1 : e) && !!globalThis.fetch, f, g)
    };
    r(zh, xh);
    var Ah = new function(a, b) {
            b = b === void 0 ? [] : b;
            this.bb = a;
            this.defaultValue = b
        }(6001, ["A3vKT9yxRPjmXN3DpIiz58f5JykcWHjUo/W7hvmtjgh9jPpQgem9VbADiNovG8NkO6mRmk70Kex8/KUqAYWVWAEAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ=="]),
        Bh = new function(a, b) {
            b = b === void 0 ? !1 : b;
            this.bb = a;
            this.defaultValue = b
        }(6E3, !0);

    function Ch(a) {
        var b = a == null || Qc(a);
        Bc(b);
        if (a != null) return x(Qc(a), "Expected a gbigint, got " + a + " of type " + typeof a), b = Wc(a), Bc(b, "Expected a safe int52, got " + a), Wc(a) ? Number(a) : String(a)
    };
    var Dh = ["FRAME", "IMG", "IFRAME"],
        Eh = /^[01](px)?$/,
        Fh = function() {
            this.Hc = this.Za = this.Ib = this.Jb = this.Zb = this.ha = this.pb = this.Xa = !1
        },
        Gh = function() {
            var a = new Fh;
            a.Xa = !1;
            a.pb = !0;
            a.ha = !0;
            a.Zb = !0;
            return a
        };

    function Hh(a) {
        return Hc(a) ? document.getElementById(a) : a
    }

    function Ih(a, b) {
        b = b === void 0 ? !1 : b;
        if (a.tagName === "IMG") {
            if (a.complete && (!a.naturalWidth || !a.naturalHeight)) return !0;
            var c;
            if (b && ((c = a.style) == null ? void 0 : c.display) === "none") return !0
        }
        var d, e;
        return Eh.test((d = a.getAttribute("width")) != null ? d : "") && Eh.test((e = a.getAttribute("height")) != null ? e : "")
    }

    function Jh(a, b) {
        if (a.tagName === "IMG") return !(!a.naturalWidth || !a.naturalHeight);
        try {
            if (a.readyState) var c = a.readyState;
            else {
                var d, e;
                c = (d = a.contentWindow) == null ? void 0 : (e = d.document) == null ? void 0 : e.readyState
            }
            return c === "complete"
        } catch (f) {
            return b === void 0 ? !1 : b
        }
    }

    function Kh(a) {
        a || (a = function(b, c, d) {
            b.addEventListener(c, d)
        });
        return a
    }

    function Lh(a, b, c) {
        c = c === void 0 ? new Fh : c;
        if (a = Hh(a)) {
            var d = Kh(d);
            for (var e = !1, f = function(A) {
                    e || (e = !0, b(A))
                }, g, h = 2, k = 0; k < Dh.length; ++k)
                if (Dh[k] === a.tagName) {
                    h = 3;
                    g = [a];
                    break
                }
            g || (g = a.querySelectorAll(Dh.join(",")));
            var l = 0,
                p = 0,
                q = !c.ha,
                y = a = !1;
            k = {};
            for (var t = 0; t < g.length; k = {
                    Ma: void 0
                }, t++) {
                var H = g[t];
                if (!Ih(H, c.ha))
                    if (k.Ma = H.tagName === "IMG", Jh(H, c.Xa)) a = !0, k.Ma && (q = !0);
                    else {
                        l++;
                        var B = function(A) {
                            return function(O) {
                                l--;
                                !l && q && f(h);
                                A.Ma && (O = O && O.type === "error", p--, O || (q = !0), !p && y && q && f(h))
                            }
                        }(k);
                        d(H, "load",
                            B);
                        k.Ma && (p++, d(H, "error", B))
                    }
            }
            p === 0 && (q = !0);
            g = null;
            g = w.document.readyState === "complete";
            if (c.Zb && g) {
                if (p > 0) {
                    y = !0;
                    return
                }
                h = 5
            } else if (l === 0 && !a && g) h = 5;
            else if (l || !a) {
                d(w, "load", function() {
                    !c.pb || !p && q ? f(4) : y = !0
                });
                return
            }
            f(h)
        }
    }

    function Mh(a, b, c) {
        function d(I) {
            var L = u(I.La),
                C = L.next();
            try {
                for (; !C.done; C = L.next()) {
                    var S = C.value;
                    I.element.removeEventListener(S.type, S.handler)
                }
            } finally {
                v(L, C)
            }
            I.La = []
        }

        function e() {
            var I = w.document.readyState === "complete",
                L = !c.ha,
                C = !1,
                S = !1,
                P = !1,
                ea = !0,
                Z = u(p),
                Aa = Z.next();
            try {
                for (; !Aa.done; Aa = Z.next()) {
                    var Ia = Aa.value;
                    Ia.completed ? (C = !0, Ia.Vb && (S = !0, Ia.isError || (L = !0))) : (ea = !1, Ia.Vb && (P = !0))
                }
            } finally {
                v(Z, Aa)
            }
            L = !S || L;
            if (ea && C && L) return ca(xa), !0;
            I && (U = !0, xa = 5);
            I = !c.pb || !P && L;
            return U && I ? (ca(xa), !0) : !1
        }

        function f(I) {
            I = u(I);
            var L = I.next();
            try {
                for (var C = {}; !L.done; C = {
                        N: void 0,
                        S: void 0,
                        Na: void 0
                    }, L = I.next())
                    if (C.N = L.value, !p.some(function(P) {
                            return function(ea) {
                                return ea.element === P.N
                            }
                        }(C)) && !Ih(C.N, c.ha)) {
                        C.Na = C.N.tagName === "IMG";
                        C.S = {
                            element: C.N,
                            Vb: C.Na,
                            isError: !1,
                            La: [],
                            completed: !1
                        };
                        if (Jh(C.N, c.Xa)) C.S.completed = !0;
                        else {
                            var S = function(P) {
                                return function(ea) {
                                    P.S.completed = !0;
                                    P.Na && ea && ea.type === "error" && (P.S.isError = !0);
                                    d(P.S);
                                    e()
                                }
                            }(C);
                            k(C.N, "load", S);
                            C.S.La.push({
                                type: "load",
                                handler: S
                            });
                            C.Na && (k(C.N, "error", S), C.S.La.push({
                                type: "error",
                                handler: S
                            }))
                        }
                        p.push(C.S)
                    }
            } finally {
                v(I, L)
            }
        }

        function g(I) {
            if (Dh.some(function(C) {
                    return String(C) === I.tagName
                })) return xa = 3, [I];
            var L = I.querySelectorAll(Dh.join(","));
            return Array.from(L)
        }

        function h(I) {
            l = new w.MutationObserver(function(P) {
                p = p.filter(function(xc) {
                    if (c.Ib) {
                        var Ba = xc.element;
                        if (typeof Ba.isConnected === "boolean") var Xa = Ba.isConnected;
                        else {
                            var yc, Gb, Hb;
                            Xa = (Hb = (yc = Ba.ownerDocument) == null ? void 0 : (Gb = yc.documentElement) == null ? void 0 : Gb.contains(Ba)) !=
                                null ? Hb : !1
                        }
                        Xa = !Xa
                    } else Xa = !xc.element.isConnected;
                    return Xa ? (d(xc), !1) : !0
                });
                var ea = [];
                P = u(P);
                var Z = P.next();
                try {
                    for (; !Z.done; Z = P.next())
                        for (var Aa = Z.value, Ia = 0; Ia < Aa.addedNodes.length; Ia++) {
                            var zc = Aa.addedNodes[Ia];
                            zc.nodeType === 1 && ea.push.apply(ea, na(g(zc)))
                        }
                } finally {
                    v(P, Z)
                }
                f(ea);
                e()
            });
            var L;
            if (L = I.tagName === "BODY" && I.ownerDocument) {
                try {
                    var C = w.top === w
                } catch (P) {
                    C = !1
                }
                L = !C
            }
            I = L ? I.ownerDocument : I;
            var S;
            (S = l) == null || S.observe(I, {
                childList: !0,
                subtree: !0
            })
        }
        c = c === void 0 ? new Fh : c;
        if (a = Hh(a)) {
            var k = Kh(k);
            var l = null,
                p = [],
                q = !1,
                y = function() {
                    e()
                },
                t = !1,
                H = function() {
                    t = !0
                },
                B = c.Za && c.Hc,
                A = B ? rf(w.top) ? w.top : null : null;
            B && (A ? A.addEventListener("pagehide", H) : t = !0);
            var O = function() {
                    if (!q) {
                        var I = B && t;
                        p.length !== 0 || I || ca(5)
                    }
                },
                ca = function(I) {
                    if (!q) {
                        q = !0;
                        l && l.disconnect();
                        var L = u(p),
                            C = L.next();
                        try {
                            for (; !C.done; C = L.next()) d(C.value)
                        } finally {
                            v(L, C)
                        }
                        p = [];
                        c.Jb && w.document.removeEventListener && w.document.removeEventListener("readystatechange", y);
                        c.Za && (w.removeEventListener && w.removeEventListener("pagehide", O), B && (A ==
                            null || A.removeEventListener("pagehide", H)));
                        b(I)
                    }
                },
                U = !1,
                xa = 2;
            f(g(a));
            c.Ib ? typeof w.MutationObserver === "function" && h(a) : h(a);
            if (!e()) {
                var Ca = function() {
                    U = !0;
                    xa = 4;
                    e();
                    w.removeEventListener("load", Ca)
                };
                k(w, "load", Ca);
                c.Jb && k(w.document, "readystatechange", y);
                c.Za && k(w, "pagehide", O)
            }
        }
    };
    var Nh = RegExp("^https?://(\\w|-)+\\.cdn\\.ampproject\\.(net|org)(\\?|/|$)"),
        Qh = function() {
            if (!b) {
                var a = w;
                var b = [];
                var c = null;
                do {
                    var d = a;
                    if (rf(d)) {
                        var e = d.location.href;
                        c = d.document && d.document.referrer || null
                    } else e = c, c = null;
                    b.push(new Oh(e || ""));
                    try {
                        a = d.parent
                    } catch (g) {
                        a = null
                    }
                } while (a && d !== a);
                d = 0;
                for (a = b.length - 1; d <= a; ++d) b[d].depth = a - d;
                d = w;
                if (d.location && d.location.ancestorOrigins && d.location.ancestorOrigins.length === b.length - 1)
                    for (a = 1; a < b.length; ++a) e = b[a], e.url || (e.url = d.location.ancestorOrigins[a -
                        1] || "", e.Wb = !0)
            }
            d = new Oh(w.location.href, !1);
            e = null;
            for (c = a = b.length - 1; c >= 0; --c) {
                var f = b[c];
                !e && Nh.test(f.url) && (e = f);
                if (f.url && !f.Wb) {
                    d = f;
                    break
                }
            }
            e = null;
            c = b.length && b[a].url;
            d.depth !== 0 && c && (e = b[a]);
            return new Ph(d, e)
        },
        Ph = function(a, b) {
            this.ya = a;
            this.Va = b
        },
        Oh = function(a, b) {
            this.url = a;
            this.Wb = !!b;
            this.depth = null
        };
    var Rh = null,
        Sh = function() {
            var a = a === void 0 ? window : a;
            if (Rh === null) {
                Rh = "";
                try {
                    var b = "";
                    try {
                        b = a.top.location.hash
                    } catch (d) {
                        b = a.location.hash
                    }
                    if (b) {
                        var c = b.match(/\bdeid=([\d,]+)/);
                        Rh = c ? c[1] : ""
                    }
                } catch (d) {}
            }
            return Rh
        };
    var Th = w.performance,
        Uh = !!(Th && Th.mark && Th.measure && Th.clearMarks),
        Vh = uf(function() {
            var a;
            if (a = Uh) a = Sh(), a = !!a.indexOf && a.indexOf("1337") >= 0;
            return a
        });
    var Wh = function(a) {
            var b = b === void 0 ? "&" : b;
            this.Qc = a === void 0 ? 4E3 : a;
            this.ob = b;
            this.aa = {};
            this.Tc = 0;
            this.ia = []
        },
        Xh = function(a, b) {
            var c = {};
            c[a] = b;
            return [c]
        },
        Zh = function(a, b, c, d, e) {
            var f = [];
            qf(a, function(g, h) {
                (g = Yh(g, b, c, d, e)) && f.push(encodeURIComponent(h) + "=" + g)
            });
            return f.join(b)
        },
        Yh = function(a, b, c, d, e) {
            if (a == null) return "";
            b = b || "&";
            c = c || ",$";
            Hc(c) && (c = c.split(""));
            if (a instanceof Array) {
                if (d || (d = 0), d < c.length) {
                    for (var f = [], g = 0; g < a.length; g++) f.push(Yh(a[g], b, c, d + 1, e));
                    return f.join(c[d])
                }
            } else if (typeof a ===
                "object") return e || (e = 0), e < 2 ? encodeURIComponent(Zh(a, b, c, d, e + 1)) : "...";
            return encodeURIComponent(String(a))
        },
        $h = function(a, b, c) {
            Bc(!a.aa[b]);
            a.ia.push(b);
            a.aa[b] = c
        },
        ai = function(a, b, c, d) {
            Bc(!a.aa[b]);
            a.ia.push(b);
            a.aa[b] = Xh(c, d)
        },
        bi = function(a, b, c) {
            var d = a.Tc++;
            $h(a, d, Xh(b, c))
        },
        ei = function(a, b, c, d) {
            return ci(a) - d.length < 0 ? "" : b + "//" + c + d + di(a, d)
        },
        di = function(a, b) {
            var c = ci(a) - b.length;
            if (c < 0) return "";
            b = "";
            a.ia.sort(function(p, q) {
                return p - q
            });
            for (var d = null, e = "", f = 0; f < a.ia.length; f++)
                for (var g = a.ia[f],
                        h = a.aa[g], k = 0; k < h.length; k++) {
                    if (!c) {
                        d = d == null ? g : d;
                        break
                    }
                    var l = Zh(h[k], a.ob, ",$");
                    if (l) {
                        l = e + l;
                        if (c >= l.length) {
                            c -= l.length;
                            b += l;
                            e = a.ob;
                            break
                        }
                        d = d == null ? g : d
                    }
                }
            a = "";
            d != null && (a = "" + e + "trn=" + d);
            return b + a
        },
        ci = function(a) {
            var b = 1,
                c;
            for (c in a.aa) c.length > b && (b = c.length);
            return a.Qc - 3 - b - a.ob.length - 1
        };
    var fi = RegExp("^(?:([^:/?#.]+):)?(?://(?:([^\\\\/?#]*)@)?([^\\\\/?#]*?)(?::([0-9]+))?(?=[\\\\/?#]|$))?([^?#]+)?(?:\\?([^#]*))?(?:#([\\s\\S]*))?$");

    function gi(a, b) {
        if (a) {
            a = a.split("&");
            for (var c = 0; c < a.length; c++) {
                var d = a[c].indexOf("="),
                    e = null;
                if (d >= 0) {
                    var f = a[c].substring(0, d);
                    e = a[c].substring(d + 1)
                } else f = a[c];
                b(f, e ? decodeURIComponent(e.replace(/\+/g, " ")) : "")
            }
        }
    }

    function hi(a, b, c) {
        Ta(a);
        if (Array.isArray(b)) {
            D(b);
            for (var d = 0; d < b.length; d++) hi(a, String(b[d]), c)
        } else b != null && c.push(a + (b === "" ? "" : "=" + encodeURIComponent(String(b))))
    }

    function ii(a, b) {
        x(Math.max(a.length - (b || 0), 0) % 2 == 0, "goog.uri.utils: Key/value lists must be even in length.");
        var c = [];
        for (b = b || 0; b < a.length; b += 2) hi(a[b], a[b + 1], c);
        return c.join("&")
    }

    function ji(a, b) {
        var c = arguments.length == 2 ? ii(arguments[1], 0) : ii(arguments, 1);
        if (c) {
            var d = a;
            var e = d.indexOf("#");
            e < 0 && (e = d.length);
            var f = d.indexOf("?");
            if (f < 0 || f > e) {
                f = e;
                var g = ""
            } else g = d.substring(f + 1, e);
            d = [d.slice(0, f), g, d.slice(e)];
            e = d[1];
            d[1] = c ? e ? e + "&" + c : c : e;
            c = d[0] + (d[1] ? "?" + d[1] : "") + d[2]
        } else c = a;
        return c
    };
    var li = function() {
            var a = ki;
            var b = b === void 0 ? null : b;
            this.O = a;
            this.Jc = "dv3-err";
            this.uc = !0;
            this.Ua = b;
            this.Ab = null;
            this.xc = !1;
            this.Ic = this.bc
        },
        mi = function(a, b, c) {
            try {
                if (a.Ua && a.Ua.Ad) {
                    var d = a.Ua.start((66).toString(), 3);
                    var e = b();
                    a.Ua.end(d)
                } else e = b()
            } catch (h) {
                b = a.uc;
                try {
                    d && Th && Vh() && (Th.clearMarks("goog_" + d.label + "_" + d.uniqueId + "_start"), Th.clearMarks("goog_" + d.label + "_" + d.uniqueId + "_end")), b = a.Ic(66, new Og(h, {
                        message: Pg(h)
                    }), void 0, c)
                } catch (k) {
                    a.bc(217, k)
                }
                if (b) {
                    var f, g;
                    (f = window.console) == null || (g =
                        f.error) == null || g.call(f, h)
                } else throw h;
            }
            return e
        },
        pi = function(a) {
            var b = ni,
                c = oi;
            return function() {
                var d = qa.apply(0, arguments);
                return mi(c, function() {
                    return a.apply(void 0, d)
                }, b)
            }
        };
    li.prototype.bc = function(a, b, c, d, e) {
        e = e || this.Jc;
        var f = void 0;
        try {
            var g = new Wh;
            ai(g, 1, "context", a);
            b.error && b.meta && b.id || (b = new Og(b, {
                message: Pg(b)
            }));
            b.msg && ai(g, 2, "msg", b.msg.substring(0, 512));
            var h = b.meta || {};
            if (this.Ab) try {
                this.Ab(h)
            } catch (A) {}
            if (d) try {
                d(h)
            } catch (A) {}
            $h(g, 3, [h]);
            f = Qh();
            f.Va && ai(g, 4, "top", f.Va.url || "");
            var k = {
                url: f.ya.url || ""
            };
            if (f.ya.url) {
                var l = f.ya.url.match(fi),
                    p = l[1],
                    q = l[3],
                    y = l[4];
                d = "";
                p && (d += p + ":");
                q && (d += "//", d += q, y && (d += ":" + y));
                var t = d
            } else t = "";
            $h(g, 5, [k, {
                url: t
            }]);
            qi(this.O,
                e, g, this.xc, c)
        } catch (A) {
            try {
                var H, B;
                qi(this.O, e, {
                    context: "ecmserr",
                    rctx: a,
                    msg: Pg(A),
                    url: (B = (H = f) == null ? void 0 : H.ya.url) != null ? B : ""
                }, this.xc, c)
            } catch (O) {}
        }
        return this.uc
    };

    function ri(a, b) {
        var c = Re(a, lh, 2);
        if (!c.length) return si(a, b);
        a = Q(a, 1);
        if (a === 1) {
            var d = ri(c[0], b);
            return d.success ? {
                success: !0,
                value: !d.value
            } : d
        }
        c = kb(c, function(h) {
            return ri(h, b)
        });
        switch (a) {
            case 2:
                var e;
                return (e = (d = c.find(function(h) {
                    return h.success && !h.value
                })) != null ? d : c.find(function(h) {
                    return !h.success
                })) != null ? e : {
                    success: !0,
                    value: !0
                };
            case 3:
                var f, g;
                return (g = (f = c.find(function(h) {
                    return h.success && h.value
                })) != null ? f : c.find(function(h) {
                    return !h.success
                })) != null ? g : {
                    success: !0,
                    value: !1
                };
            default:
                return {
                    success: !1,
                    G: 3
                }
        }
    }

    function si(a, b) {
        var c = a.Rb();
        a: {
            switch (c) {
                case 3:
                    var d = a.Mb();
                    break a;
                case 4:
                    d = a.Qb();
                    break a;
                case 5:
                    d = a.Tb();
                    break a
            }
            d = void 0
        }
        if (!d) return {
            success: !1,
            G: 2
        };
        b = (b = b[c]) && b[d];
        if (!b) return {
            success: !1,
            property: d,
            ua: c,
            G: 1
        };
        try {
            var e = b.apply;
            var f = Ce(a, 8, Pd);
            var g = e.call(b, null, na(f))
        } catch (h) {
            return {
                success: !1,
                property: d,
                ua: c,
                G: 2
            }
        }
        e = Q(a, 1);
        if (e === 4) return {
            success: !0,
            value: !!g
        };
        if (e === 5) return {
            success: !0,
            value: g != null
        };
        if (e === 12) a = cf(a, Me(a, nh, 7));
        else a: {
            switch (c) {
                case 4:
                    a = bf(a, Me(a, nh, 6));
                    break a;
                case 5:
                    a =
                        cf(a, Me(a, nh, 7));
                    break a
            }
            a = void 0
        }
        if (a == null) return {
            success: !1,
            property: d,
            ua: c,
            G: 3
        };
        if (e === 6) return {
            success: !0,
            value: g === a
        };
        if (e === 9) return {
            success: !0,
            value: g != null && bb(String(g), a) === 0
        };
        if (g == null) return {
            success: !1,
            property: d,
            ua: c,
            G: 4
        };
        switch (e) {
            case 7:
                c = g < a;
                break;
            case 8:
                c = g > a;
                break;
            case 12:
                c = Hc(a) && Hc(g) && (new RegExp(a)).test(g);
                break;
            case 10:
                c = g != null && bb(String(g), a) === -1;
                break;
            case 11:
                c = g != null && bb(String(g), a) === 1;
                break;
            default:
                return {
                    success: !1,
                    G: 3
                }
        }
        return {
            success: !0,
            value: c
        }
    }

    function ti(a, b) {
        return a ? b ? ri(a, b) : {
            success: !1,
            G: 1
        } : {
            success: !0,
            value: !0
        }
    };
    var Oe = function(a) {
        V.call(this, a)
    };
    r(Oe, V);
    Oe.prototype.getStringValue = function() {
        return cf(this, 3)
    };
    Oe.prototype.setStringValue = function(a) {
        return He(this, 3, Od(a), "")
    };
    var ui = function(a) {
        return Ce(a, 4, Pd)
    };
    Oe.i = "tagging.common.experiments.FlagValue";
    var vi = function(a) {
        V.call(this, a)
    };
    r(vi, V);
    vi.prototype.L = function() {
        return Qe(this, lh, 1)
    };
    vi.prototype.Sa = function(a) {
        return Te(this, lh, 1, a)
    };
    vi.prototype.getValue = function() {
        return Qe(this, Oe, 2)
    };
    vi.prototype.clearValue = function() {
        return N(this, 2)
    };
    vi.i = "tagging.common.experiments.ConditionalValue";
    var wi = function(a) {
        V.call(this, a)
    };
    r(wi, V);
    m = wi.prototype;
    m.Fa = function() {
        return Le(this, xi)
    };
    m.oa = function() {
        return R(this, 1, xi)
    };
    m.jc = function(a) {
        T(this, 1, xi, a)
    };
    m.Ja = function() {
        return R(this, 2, xi)
    };
    m.nc = function(a) {
        T(this, 2, xi, a)
    };
    m.Ka = function() {
        return R(this, 3, xi)
    };
    m.rc = function(a) {
        T(this, 3, xi, a)
    };
    m.ra = function() {
        return R(this, 6, xi)
    };
    m.sc = function(a) {
        T(this, 6, xi, a)
    };
    m.Ha = function() {
        return R(this, 7, xi)
    };
    m.lc = function(a) {
        T(this, 7, xi, a)
    };
    m.Ia = function() {
        return R(this, 8, xi)
    };
    m.mc = function(a) {
        T(this, 8, xi, a)
    };
    m.Ub = function() {
        return ef(this, 8, xi) != null
    };
    var yi = function(a) {
            var b = Oe;
            qe(a);
            x(M(a));
            a = J ? a[z(K)] : a.h;
            var c = D(a, "state is only maintained on arrays.")[F] | 0;
            G(a, c);
            var d = te(a, 4);
            b = Rd(d, b, !0, c);
            b = oe(b);
            d !== b && (c = we(a, c, 4, b), re(a, c));
            return b
        },
        zi = mf(wi);
    wi.i = "tagging.common.experiments.FlagDefinition";
    var xi = [1, 2, 3, 6, 7, 8];
    var Ai = function(a, b, c, d) {
            d = d === void 0 ? new zh(6, "unknown", b) : d;
            this.bd = a;
            this.ad = c;
            this.O = d;
            this.ta = [];
            this.Ra = a > 0 && bg() < 1 / a
        },
        Ci = function(a, b, c, d, e, f) {
            if (a.Ra) {
                var g = Xg((new Wg).fa(b), c);
                b = eh(bh(ah(dh(ch(new $g, d), e), g), a.ta.slice()), f);
                b = sh(b);
                a.O.Qa(Bi(a, b));
                if (f === 1 || f === 3 || f === 4 && !a.ta.some(function(h) {
                        return h.M() === g.M() && Q(h, 2) === c
                    })) a.ta.push(g), a.ta.length > 100 && a.ta.shift()
            }
        },
        Di = function(a, b, c, d) {
            if (a.Ra) {
                var e = new Vg;
                b = N(e, 1, wd(b));
                c = N(b, 2, wd(c)).sb(d);
                d = new qh;
                c = Ue(d, Vg, 8, rh, c);
                a.O.Qa(Bi(a,
                    c))
            }
        },
        Ei = function(a, b, c, d, e) {
            if (a.Ra) {
                b = (new oh).Sa(b).fa(c).tb(d);
                if (e.ua === void 0) T(b, 4, ph, e.G);
                else switch (e.ua) {
                    case 3:
                        e = kh((new ih).kc(e.property), e.G);
                        Ue(b, ih, 5, ph, e);
                        break;
                    case 4:
                        e = kh((new ih).oc(e.property), e.G);
                        Ue(b, ih, 5, ph, e);
                        break;
                    case 5:
                        e = kh((new ih).tc(e.property), e.G), Ue(b, ih, 5, ph, e)
                }
                e = new qh;
                b = Ue(e, oh, 9, rh, b);
                a.O.Qa(Bi(a, b))
            }
        },
        Bi = function(a, b) {
            var c = Date.now();
            c = Number.isFinite(c) ? Math.round(c) : 0;
            b = ff(b, 1, c);
            c = fg();
            return ff(b, 2, c).qc(a.bd)
        };
    var Fi = [],
        W = function(a) {
            x(!Object.isSealed(a), "Cannot use getInstance() with a sealed constructor.");
            var b = "lb";
            if (a.lb && a.hasOwnProperty(b)) return a.lb;
            Fi.push(a);
            var c = new a;
            a.lb = c;
            x(a.hasOwnProperty(b), "Could not instantiate singleton.");
            return c
        };
    var Gi = function() {
        var a = {};
        this.D = (a[3] = {}, a[4] = {}, a[5] = {}, a)
    };
    m = Gi.prototype;
    m.yb = function(a) {
        this.D = a
    };
    m.za = function(a) {
        var b = u([3, 4, 5]),
            c = b.next();
        try {
            for (; !c.done; c = b.next()) {
                var d = c.value;
                Object.assign(Ac(this.D[d], Fc), a[d])
            }
        } finally {
            v(b, c)
        }
    };
    m.rb = function(a, b) {
        this.D[3][a] == null && (this.D[3][a] = b)
    };
    m.xb = function(a, b) {
        this.D[4][a] == null && (this.D[4][a] = b)
    };
    m.zb = function(a, b) {
        this.D[5][a] == null && (this.D[5][a] = b)
    };
    var Hi = /^true$/.test("false");

    function Ii(a, b) {
        switch (b) {
            case 1:
                return a.oa();
            case 7:
                return a.Ha();
            case 2:
                return a.Ja();
            case 3:
                return a.Ka();
            case 6:
                return a.ra();
            case 8:
                return a.Ia();
            default:
                return null
        }
    }

    function Ji(a, b) {
        if (!a) return null;
        switch (b) {
            case 1:
                return Ye(a, 1);
            case 7:
                return a.getStringValue();
            case 2:
                return bf(a, 2);
            case 3:
                return a.getStringValue();
            case 6:
                return ui(a);
            case 8:
                return ui(a);
            default:
                return null
        }
    }
    var Ki = uf(function() {
        if (!Hi) return {};
        try {
            var a = a === void 0 ? window : a;
            try {
                var b = a.sessionStorage.getItem("GGDFSSK")
            } catch (c) {
                b = null
            }
            if (b) return JSON.parse(b)
        } catch (c) {}
        return {}
    });

    function Li(a, b, c, d) {
        var e = d = d === void 0 ? 0 : d,
            f, g;
        W(Mi).fb[e] = (g = (f = W(Mi).fb[e]) == null ? void 0 : f.add(b)) != null ? g : (new Set).add(b);
        e = Ki();
        if (e[b] != null) return e[b];
        b = Ni(d)[b];
        if (!b) return c;
        b = zi(JSON.stringify(b));
        b = Oi(b);
        a = Ji(b, a);
        return a != null ? a : c
    }

    function Oi(a) {
        var b = W(Gi).D;
        if (b && a.Fa() !== 8) {
            var c = lb(Re(a, vi, 5), function(f) {
                f = ti(f.L(), b);
                return f.success && f.value
            });
            if (c) {
                var d;
                return (d = c.getValue()) != null ? d : null
            }
        }
        var e;
        return (e = Qe(a, Oe, 4)) != null ? e : null
    }
    var Mi = function() {
        this.cb = {};
        this.Ac = [];
        this.fb = {};
        this.U = new Map
    };

    function Pi(a, b, c) {
        return !!Li(1, a, b === void 0 ? !1 : b, c)
    }

    function Qi(a, b, c) {
        b = b === void 0 ? "" : b;
        a = Li(7, a, b, c);
        if (Hc(a)) try {
            return JSON.parse(a)
        } catch (d) {}
        try {
            return JSON.parse(b)
        } catch (d) {
            return null
        }
    }

    function Ri(a, b, c) {
        b = b === void 0 ? 0 : b;
        a = Number(Li(2, a, b, c));
        return isNaN(a) ? b : a
    }

    function Si(a, b, c) {
        b = b === void 0 ? "" : b;
        a = Li(3, a, b, c);
        return Hc(a) ? a : b
    }

    function Ti(a, b, c) {
        b = b === void 0 ? [] : b;
        a = Li(6, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function Ui(a, b, c) {
        b = b === void 0 ? [] : b;
        a = Li(8, a, b, c);
        return Array.isArray(a) ? a : b
    }

    function Ni(a) {
        return W(Mi).cb[a] || (W(Mi).cb[a] = {})
    }

    function Vi(a, b) {
        var c = Ni(b);
        qf(a, function(d, e) {
            if (c[e]) {
                d = zi(JSON.stringify(d));
                if (d.Ub()) {
                    var f = zi(JSON.stringify(c[e])),
                        g = yi(d);
                    f = ui(Pe(f));
                    We(g, f)
                }
                c[e] = ee(d)
            } else c[e] = d
        })
    }

    function Wi(a, b, c, d, e) {
        e = e === void 0 ? !1 : e;
        var f = [],
            g = [];
        b = u(b);
        var h = b.next();
        try {
            for (; !h.done; h = b.next()) {
                var k = h.value,
                    l = Ni(k),
                    p = u(a),
                    q = p.next();
                try {
                    for (; !q.done; q = p.next()) {
                        var y = q.value,
                            t = y.Fa(),
                            H = Ii(y, t);
                        if (H) {
                            var B = void 0,
                                A = void 0,
                                O = void 0;
                            var ca = (B = (O = W(Mi).U.get(k)) == null ? void 0 : (A = O.get(H)) == null ? void 0 : A.slice(0)) != null ? B : [];
                            a: {
                                B = H;A = t;O = ca;
                                var U = new fh;
                                switch (A) {
                                    case 1:
                                        U.jc(B);
                                        break;
                                    case 2:
                                        U.nc(B);
                                        break;
                                    case 3:
                                        U.rc(B);
                                        break;
                                    case 6:
                                        U.sc(B);
                                        break;
                                    case 7:
                                        U.lc(B);
                                        break;
                                    case 8:
                                        U.mc(B);
                                        break;
                                    default:
                                        var xa = void 0;
                                        break a
                                }
                                hf(U, 5, O);xa = U
                            }
                            B = xa;
                            var Ca;
                            if (Ca = B) A = void 0, Ca = !((A = W(Mi).fb[k]) == null || !A.has(H));
                            Ca && f.push(B);
                            if (t === 8 && l[H]) {
                                var I = zi(JSON.stringify(l[H])),
                                    L = yi(y),
                                    C = ui(Pe(I));
                                We(L, C)
                            } else {
                                var S;
                                if (S = B) A = void 0, S = !((A = W(Mi).U.get(k)) == null || !A.has(H));
                                S && g.push(B)
                            }
                            if (!e) {
                                B = H;
                                A = k;
                                O = d;
                                var P = W(Mi);
                                P.U.has(A) || P.U.set(A, new Map);
                                P.U.get(A).has(B) || P.U.get(A).set(B, []);
                                O && P.U.get(A).get(B).push(O)
                            }
                            l[H] = ee(y)
                        }
                    }
                } finally {
                    v(p, q)
                }
            }
        } finally {
            v(b, h)
        }
        if (f.length || g.length) a = d != null ? d : void 0, c.Ra &&
            c.ad && (d = new hh, f = Ve(d, fh, 2, f), g = Ve(f, fh, 3, g), a && g.tb(a), f = new qh, g = Ue(f, hh, 7, rh, g), c.O.Qa(Bi(c, g)))
    }

    function Xi(a, b) {
        b = Ni(b);
        a = u(a);
        var c = a.next();
        try {
            for (; !c.done; c = a.next()) {
                var d = c.value,
                    e = zi(JSON.stringify(d)),
                    f = e.Fa(),
                    g = Ii(e, f);
                g && (b[g] || (b[g] = d))
            }
        } finally {
            v(a, c)
        }
    }

    function Yi() {
        return Object.keys(W(Mi).cb).map(function(a) {
            return Number(a)
        })
    }

    function Zi(a) {
        W(Mi).Ac.includes(a) || Vi(Ni(4), a)
    };

    function $i(a, b, c) {
        c.hasOwnProperty(a) || Object.defineProperty(c, String(a), {
            value: b
        })
    }

    function X(a, b, c) {
        return b[a] || c
    }

    function aj(a) {
        $i(5, Pi, a);
        $i(18, Qi, a);
        $i(6, Ri, a);
        $i(7, Si, a);
        $i(8, Ti, a);
        $i(17, Ui, a);
        $i(13, Xi, a);
        $i(15, Zi, a)
    }

    function bj(a) {
        $i(4, function(b) {
            return void W(Gi).yb(b)
        }, a);
        $i(9, function(b, c) {
            return void W(Gi).rb(b, c)
        }, a);
        $i(10, function(b, c) {
            return void W(Gi).xb(b, c)
        }, a);
        $i(11, function(b, c) {
            return void W(Gi).zb(b, c)
        }, a);
        $i(14, function(b) {
            return void W(Gi).za(b)
        }, a)
    }

    function cj(a) {
        a.hasOwnProperty("init-done") || Object.defineProperty(a, "init-done", {
            value: !0
        })
    };
    var dj = function() {};
    m = dj.prototype;
    m.ja = function() {};
    m.ga = function() {};
    m.Da = function() {
        return []
    };
    m.W = function() {
        return []
    };
    m.kb = function(a, b) {
        this.ja = X(1, a, function() {});
        this.Da = function(c, d) {
            return X(2, a, function() {
                return []
            })(c, b, d)
        };
        this.W = function(c) {
            return X(3, a, function() {
                return []
            })(c != null ? c : b)
        };
        this.ga = function(c) {
            X(16, a, function() {})(c, b)
        }
    };

    function ej(a) {
        W(dj).ga(a)
    }

    function fj(a) {
        W(dj).Da(22, a)
    };

    function gj(a, b) {
        b = b === void 0 ? document : b;
        var c;
        return !((c = b.featurePolicy) == null || !c.allowedFeatures().includes(a))
    };

    function hj(a, b) {
        try {
            var c = a.split(".");
            a = w;
            for (var d = 0, e; a != null && d < c.length; d++) e = a, a = a[c[d]], typeof a === "function" && (a = e[c[d]]());
            var f = a;
            if (typeof f === b) return f
        } catch (g) {}
    }
    var ij = {},
        jj = {},
        kj = {},
        lj = {},
        mj = (lj[3] = (ij[8] = function(a) {
                try {
                    return Ja(a) != null
                } catch (b) {}
            }, ij[9] = function(a) {
                try {
                    var b = Ja(a)
                } catch (c) {
                    return
                }
                if (a = typeof b === "function") b = b && b.toString && b.toString(), a = Hc(b) && b.indexOf("[native code]") != -1;
                return a
            }, ij[10] = function() {
                return window === window.top
            }, ij[6] = function(a, b) {
                b = b ? Number(b) : void 0;
                b = W(dj).W(b);
                return ib(b, Number(a)) >= 0
            }, ij[27] = function(a) {
                a = hj(a, "boolean");
                return a !== void 0 ? a : void 0
            }, ij[60] = function(a) {
                try {
                    return !!w.document.querySelector(a)
                } catch (b) {}
            },
            ij[80] = function(a) {
                try {
                    return !!w.matchMedia(a).matches
                } catch (b) {}
            }, ij[69] = function(a) {
                var b = w.document;
                b = b === void 0 ? document : b;
                var c;
                return !((c = b.featurePolicy) == null || !c.features().includes(a))
            }, ij[70] = function(a) {
                return gj(a, w.document)
            }, ij), lj[4] = (jj[3] = function() {
            return ag()
        }, jj[6] = function(a) {
            a = hj(a, "number");
            return a !== void 0 ? a : void 0
        }, jj), lj[5] = (kj[2] = function() {
            return window.location.href
        }, kj[3] = function() {
            try {
                return window.top.location.hash
            } catch (a) {
                return ""
            }
        }, kj[4] = function(a) {
            a = hj(a, "string");
            return a !== void 0 ? a : void 0
        }, kj[12] = function(a) {
            try {
                var b = hj(a, "string");
                if (b !== void 0) return atob(b)
            } catch (c) {}
        }, kj), lj);

    function nj() {
        var a = a === void 0 ? w : a;
        return a.ggeac || (a.ggeac = {})
    };
    var oj = function(a) {
        V.call(this, a)
    };
    r(oj, V);
    m = oj.prototype;
    m.Ga = function(a) {
        return Re(this, wi, 2, a && ze(a))
    };
    m.L = function() {
        return Qe(this, lh, 3)
    };
    m.Sa = function(a) {
        return Te(this, lh, 3, a)
    };
    m.ib = function() {
        return Ze(this, 4)
    };
    m.qa = function() {
        return Q(this, 6)
    };
    m.M = function() {
        return Q(this, 7)
    };
    m.fa = function(a) {
        return gf(this, 7, a)
    };
    m.gb = function() {
        return Q(this, 13)
    };
    m.ub = function(a) {
        gf(this, 13, a)
    };
    m.Pb = function() {
        return Q(this, 14)
    };
    m.Ob = function() {
        return $e(this, 11)
    };
    m.Ea = function() {
        return Q(this, 17)
    };
    m.sb = function(a) {
        return gf(this, 17, a)
    };
    m.Nb = function() {
        return Q(this, 18)
    };
    oj.i = "tagging.common.experiments.Experiment";
    var pj = function(a) {
        V.call(this, a)
    };
    r(pj, V);
    m = pj.prototype;
    m.ib = function() {
        return $e(this, 1)
    };
    m.L = function() {
        return Qe(this, lh, 3)
    };
    m.Sa = function(a) {
        return Te(this, lh, 3, a)
    };
    m.qa = function() {
        return Q(this, 4)
    };
    m.M = function() {
        return Q(this, 5)
    };
    m.fa = function(a) {
        return gf(this, 5, a)
    };
    m.gb = function() {
        return Q(this, 10)
    };
    m.ub = function(a) {
        gf(this, 10, a)
    };
    m.Pb = function() {
        return Q(this, 11)
    };
    m.Ob = function() {
        return $e(this, 8)
    };
    m.Ea = function() {
        return Q(this, 13)
    };
    m.sb = function(a) {
        return gf(this, 13, a)
    };
    m.Nb = function() {
        return Q(this, 14)
    };
    pj.i = "tagging.common.experiments.Study";
    var qj = function(a) {
        V.call(this, a)
    };
    r(qj, V);
    qj.prototype.M = function() {
        return Q(this, 1)
    };
    qj.prototype.fa = function(a) {
        return gf(this, 1, a)
    };
    qj.i = "tagging.common.experiments.ExperimentState.DiversionPointToStudy";
    var rj = function(a) {
        V.call(this, a)
    };
    r(rj, V);
    rj.prototype.Sb = function() {
        return af(this, 2)
    };
    rj.prototype.qc = function(a) {
        return ff(this, 2, a)
    };
    rj.i = "tagging.common.experiments.ExperimentState.ObservabilityConfig";
    var sj = function(a) {
        V.call(this, a)
    };
    r(sj, V);
    sj.prototype.Ga = function(a) {
        return Re(this, wi, 1, a && ze(a))
    };
    sj.i = "tagging.common.experiments.ExperimentState";

    function tj(a) {
        var b = {};
        return uj((b[0] = new Map, b[1] = new Map, b[2] = new Map, b), a)
    }

    function uj(a, b) {
        var c = new Map,
            d = u(a[1].entries()),
            e = d.next();
        try {
            for (; !e.done; e = d.next()) {
                var f = u(e.value),
                    g = f.next().value,
                    h = f.next().value,
                    k = h[h.length - 1];
                c.set(g, k.vc + k.cc * k.dc)
            }
        } finally {
            v(d, e)
        }
        b = u(b);
        d = b.next();
        try {
            for (; !d.done; d = b.next()) {
                var l = d.value;
                var p = Re(l, pj, 2);
                var q = u(p),
                    y = q.next();
                try {
                    for (; !y.done; y = q.next()) {
                        var t = y.value;
                        if (Re(t, oj, 2).length !== 0) {
                            var H = t.Ob();
                            if (t.qa() && !t.Ea() && !t.Nb()) {
                                e = void 0;
                                H = (e = c.get(t.qa())) != null ? e : 0;
                                var B = t.ib() * Re(t, oj, 2).length;
                                c.set(t.qa(), H + B)
                            }
                            e = [];
                            for (f = 0; f < Re(t, oj, 2).length; f++) {
                                var A = {
                                    vc: H,
                                    cc: t.ib(),
                                    dc: Re(t, oj, 2).length,
                                    Sc: f,
                                    Ca: l.M(),
                                    Ta: t,
                                    experiment: Re(t, oj, 2)[f]
                                };
                                e.push(A)
                            }
                            if (!vj(a[2], t.gb(), e) && !vj(a[1], t.qa(), e)) {
                                var O = a[0],
                                    ca = Re(t, oj, 2)[0];
                                var U = Ze(ca, 1);
                                vj(O, U, e)
                            }
                        }
                    }
                } finally {
                    v(q, y)
                }
            }
        } finally {
            v(b, d)
        }
        return a
    }

    function vj(a, b, c) {
        if (!b) return !1;
        a.has(b) || a.set(b, []);
        a = a.get(b);
        a = Ac(a, Fc);
        a.push.apply(a, na(c));
        return !0
    };

    function wj(a) {
        var b = a.length;
        if (b === 0) return 0;
        for (var c = 305419896, d = 0; d < b; d++) c ^= (c << 5) + (c >> 2) + a.charCodeAt(d) & 4294967295;
        return c > 0 ? c : 4294967296 + c
    };

    function xj() {
        var a = a === void 0 ? bg() : a;
        return function(b) {
            return wj(b + " + " + a) % 1E3
        }
    };
    var yj = [12, 13, 20, 32],
        zj = function(a, b, c, d) {
            d = d === void 0 ? {} : d;
            var e = d.Lb;
            e = e === void 0 ? !1 : e;
            d = d.Ed;
            d = d === void 0 ? [] : d;
            this.Oa = a;
            this.Y = c;
            this.Fb = {};
            this.Lb = e;
            a = {};
            this.wa = (a[b] = [], a[4] = [], a);
            this.Db = {};
            this.qb = {};
            if (b = Sh()) {
                b = u(b.split(",") || []);
                a = b.next();
                try {
                    for (; !a.done; a = b.next()) {
                        var f = Number(a.value);
                        f && this.ja(f)
                    }
                } finally {
                    v(b, a)
                }
            }
            f = u(d);
            b = f.next();
            try {
                for (; !b.done; b = f.next()) this.ja(b.value)
            } finally {
                v(f, b)
            }
        };
    zj.prototype.W = function(a) {
        return (this.wa[a] || []).concat(this.wa[4])
    };
    zj.prototype.ja = function(a) {
        this.Db[a] = !0
    };
    zj.prototype.Da = function(a, b, c) {
        var d = this,
            e = [],
            f;
        if (f = a !== 9) this.Fb[a] ? f = !0 : (this.Fb[a] = !0, f = !1);
        if (f) return Ci(this.Y, a, b, e, [], 4), e;
        f = yj.includes(a);
        var g = [],
            h = [],
            k = u([0, 1, 2]),
            l = k.next();
        try {
            for (; !l.done; l = k.next()) {
                var p = l.value,
                    q = u(this.Oa[p].entries()),
                    y = q.next();
                try {
                    for (; !y.done; y = q.next()) {
                        var t = u(y.value),
                            H = t.next().value,
                            B = t.next().value,
                            A = H,
                            O = B,
                            ca = new Yg,
                            U = O.filter(function(Hb) {
                                return Hb.Ca === a && d.Db[Ze(Hb.experiment, 1)] && Aj(d, Hb)
                            });
                        if (U.length) {
                            var xa = u(U),
                                Ca = xa.next();
                            try {
                                for (; !Ca.done; Ca =
                                    xa.next()) h.push(Ca.value.experiment)
                            } finally {
                                v(xa, Ca)
                            }
                        } else if (!this.Lb) {
                            var I = void 0;
                            p === 2 ? (I = c[1], ca.ub(A)) : I = c[0];
                            var L = void 0,
                                C = void 0,
                                S = (C = (L = I) == null ? void 0 : L(String(A))) != null ? C : p === 2 && O[0].Ta.Pb() === 1 ? void 0 : c[0](String(A));
                            if (S !== void 0) {
                                var P = u(O),
                                    ea = P.next();
                                try {
                                    for (; !ea.done; ea = P.next()) {
                                        var Z = ea.value;
                                        if (Z.Ca === a) {
                                            var Aa = S - Z.vc;
                                            A = Z;
                                            var Ia = A.cc,
                                                zc = A.dc,
                                                xc = A.Sc;
                                            if (!(Aa < 0 || Aa >= Ia * zc || Aa % zc !== xc) && Aj(this, Z)) {
                                                var Ba = Z.Ta.Ea();
                                                if (Ba !== 0 && Ba !== void 0) {
                                                    var Xa = this.qb[String(Ba)];
                                                    Xa !== void 0 &&
                                                        Xa !== Ze(Z.experiment, 1) ? Di(this.Y, this.qb[String(Ba)], Ze(Z.experiment, 1), Ba) : this.qb[String(Ba)] = Ze(Z.experiment, 1)
                                                }
                                                h.push(Z.experiment)
                                            }
                                        }
                                    }
                                } finally {
                                    v(P, ea)
                                }
                                Le(ca, Zg) !== 0 && (He(ca, 3, wd(S), 0), g.push(ca))
                            }
                        }
                    }
                } finally {
                    v(q, y)
                }
            }
        } finally {
            v(k, l)
        }
        c = u(h);
        p = c.next();
        try {
            for (; !p.done; p = c.next()) {
                var yc = p.value,
                    Gb = Ze(yc, 1);
                e.push(Gb);
                this.ga(Gb, f ? 4 : b);
                Wi(yc.Ga(), f ? Yi() : [b], this.Y, Gb)
            }
        } finally {
            v(c, p)
        }
        Ci(this.Y, a, b, e, g, 1);
        return e
    };
    zj.prototype.ga = function(a, b) {
        this.wa[b] || (this.wa[b] = []);
        b = this.wa[b];
        b.includes(a) || b.push(a)
    };
    var Aj = function(a, b) {
            var c = W(Gi).D,
                d = ti(b.Ta.L(), c);
            if (!d.success) return Ei(a.Y, b.Ta.L(), b.Ca, Ze(b.experiment, 1), d), !1;
            if (!d.value) return !1;
            c = ti(b.experiment.L(), c);
            return c.success ? !!c.value : (Ei(a.Y, b.experiment.L(), b.Ca, Ze(b.experiment, 1), c), !1)
        },
        Bj = function(a, b) {
            b = b.map(function(c) {
                return new qj(c)
            }).filter(function(c) {
                return !yj.includes(c.M())
            });
            a.Oa = uj(a.Oa, b)
        },
        Cj = function(a, b) {
            $i(1, function(c) {
                return void a.ja(c)
            }, b);
            $i(2, function(c, d, e) {
                return a.Da(c, d, e)
            }, b);
            $i(3, function(c) {
                    return a.W(c)
                },
                b);
            $i(12, function(c) {
                return void Bj(a, c)
            }, b);
            $i(16, function(c, d) {
                return void a.ga(c, d)
            }, b)
        };
    var Dj = function() {
        var a = {};
        this.oa = function(b, c) {
            return a[b] != null ? Ac(a[b], Ic) : c
        };
        this.Ha = function() {
            try {
                return JSON.parse(void 0)
            } catch (b) {
                return null
            }
        };
        this.Ja = function() {
            return a[void 0] != null ? Ac(a[void 0], Gc) : void 0
        };
        this.Ka = function() {
            return a[void 0] != null ? Ac(a[void 0], Hc) : void 0
        };
        this.ra = function(b, c) {
            return a[b] != null ? D(a[b]) : c
        };
        this.Ia = function() {
            return a[void 0] != null ? (void 0).concat(D(a[void 0])) : void 0
        };
        this.Eb = function() {}
    };
    var Ej = function() {
        this.rb = function() {};
        this.xb = function() {};
        this.zb = function() {};
        this.yb = function() {};
        this.za = function() {}
    };
    Ej.prototype.kb = function(a) {
        this.rb = X(9, a, function() {});
        this.xb = X(10, a, function() {});
        this.zb = X(11, a, function() {});
        this.yb = X(4, a, function() {});
        this.za = X(14, a, function() {})
    };

    function Fj(a) {
        W(Ej).za(a)
    };
    var Gj, Hj, Ij, Jj, Kj, Lj;

    function Mj(a) {
        var b = a.Kc;
        var c = a.D;
        var d = a.config;
        var e = a.yd;
        e = e === void 0 ? nj() : e;
        var f = a.Bc;
        f = f === void 0 ? 0 : f;
        var g = a.O;
        var h = a.Y;
        g = h === void 0 ? new Ai((Jj = Ch((Gj = Qe(b, rj, 5)) == null ? void 0 : Gj.Sb())) != null ? Jj : 0, (Kj = Ch((Hj = Qe(b, rj, 5)) == null ? void 0 : af(Hj, 4))) != null ? Kj : 0, (Lj = (Ij = Qe(b, rj, 5)) == null ? void 0 : Ye(Ij, 3)) != null ? Lj : !1, g) : h;
        a = a.Oa;
        a = a === void 0 ? tj(Re(b, qj, 2, pc && ze(pc))) : a;
        e.hasOwnProperty("init-done") ? (X(12, e, function() {})(Re(b, qj, 2).map(function(k) {
                return ee(k)
            })), X(13, e, function() {})(b.Ga().map(function(k) {
                return ee(k)
            }), f),
            c && X(14, e, function() {})(c), Nj(f, e)) : (Cj(new zj(a, f, g, d), e), aj(e), bj(e), cj(e), Nj(f, e), Wi(b.Ga(pc), [f], g, void 0, !0), Hi = Hi || !(!d || !d.Bd), Fj(mj), c && Fj(c))
    }

    function Nj(a, b) {
        var c = b = b === void 0 ? nj() : b;
        W(dj).kb(c, a);
        Oj(b, a);
        a = b;
        W(Ej).kb(a);
        W(Dj).Eb()
    }

    function Oj(a, b) {
        var c = W(Dj);
        c.oa = function(d, e) {
            return X(5, a, function() {
                return !1
            })(d, e, b)
        };
        c.Ha = function() {
            return X(18, a, function() {
                return null
            })(void 0, void 0, b)
        };
        c.Ja = function() {
            return X(6, a, function() {
                return 0
            })(void 0, void 0, b)
        };
        c.Ka = function() {
            return X(7, a, function() {
                return ""
            })(void 0, void 0, b)
        };
        c.ra = function(d, e) {
            return X(8, a, function() {
                return []
            })(d, e, b)
        };
        c.Ia = function() {
            return X(17, a, function() {
                return []
            })(void 0, void 0, b)
        };
        c.Eb = function() {
            X(15, a, function() {})(b)
        }
    };
    var qi = function(a, b, c, d, e) {
        if (((d === void 0 ? 0 : d) ? a.ed : Math.random()) < (e || a.Fc)) try {
            if (c instanceof Wh) var f = c;
            else f = new Wh, qf(c, function(h, k) {
                bi(f, k, h)
            });
            var g = ei(f, a.protocol, a.domain, a.path + b + "&");
            g && (a.zc ? Gg(g) : Eg(w, g))
        } catch (h) {}
    };
    var Pj = function(a) {
        V.call(this, a)
    };
    r(Pj, V);
    Pj.i = "wireless.mdl.UserAgentClientHints.BrandAndVersion";
    var Qj = function(a) {
        V.call(this, a)
    };
    r(Qj, V);
    var Rj = function(a, b) {
            return N(a, 2, Od(b))
        },
        Sj = function(a, b) {
            return N(a, 3, Od(b))
        },
        Tj = function(a, b) {
            return N(a, 4, Od(b))
        },
        Uj = function(a, b) {
            return N(a, 5, Od(b))
        },
        Vj = function(a, b) {
            return N(a, 9, Od(b))
        },
        Wj = function(a, b) {
            return Ve(a, Pj, 10, b)
        },
        Xj = function(a, b) {
            return N(a, 11, b == null ? b : pd(b))
        },
        Yj = function(a, b) {
            return N(a, 1, Od(b))
        },
        Zj = function(a, b) {
            return N(a, 7, b == null ? b : pd(b))
        };
    Qj.i = "wireless.mdl.UserAgentClientHints";
    var ak = "platform platformVersion architecture model uaFullVersion bitness fullVersionList wow64".split(" ");

    function bk() {
        var a;
        return (a = w.google_tag_data) != null ? a : w.google_tag_data = {}
    }

    function ck() {
        var a, b;
        return typeof((a = w.navigator) == null ? void 0 : (b = a.userAgentData) == null ? void 0 : b.getHighEntropyValues) === "function"
    }

    function dk() {
        if (!ck()) return null;
        var a = bk();
        if (a.uach_promise) return a.uach_promise;
        var b = w.navigator.userAgentData.getHighEntropyValues(ak).then(function(c) {
            a.uach != null || (a.uach = c);
            return c
        });
        return a.uach_promise = b
    }

    function ek(a) {
        var b;
        return Xj(Wj(Uj(Rj(Yj(Tj(Zj(Vj(Sj(new Qj, a.architecture || ""), a.bitness || ""), a.mobile || !1), a.model || ""), a.platform || ""), a.platformVersion || ""), a.uaFullVersion || ""), ((b = a.fullVersionList) == null ? void 0 : b.map(function(c) {
            var d = new Pj;
            d = N(d, 1, Od(c.brand));
            return N(d, 2, Od(c.version))
        })) || []), a.wow64 || !1)
    };
    var fk = function(a) {
            this.ea = a
        },
        gk = function(a, b) {
            b && (a.ea.aacm = b);
            return a.ea.aacm
        },
        hk = function(a, b) {
            b && (a.ea.corr = b);
            return a.ea.corr
        };
    fk.prototype.timestamp = function(a) {
        a && (this.ea.ts = a);
        return this.ea.ts
    };
    var jk = function(a) {
        return (a = ik(a)) ? new fk(a) : null
    };

    function kk(a, b) {
        qf(a, function(c, d) {
            b[d] = c
        })
    }

    function lk(a, b) {
        hk(b, hk(a));
        b.timestamp(a.timestamp());
        gk(b, {});
        gk(a) && kk(gk(a), gk(b))
    }

    function ik(a) {
        return Ma(a) ? typeof a.corr === "string" && typeof a.ts === "number" && Ma(a.aacm) ? a : null : null
    };

    function mk(a, b, c, d, e) {
        try {
            for (var f = [], g, h = 0;
                (g = c(a)) && a !== b && ++h < 100;) {
                for (var k = null, l = d(g), p = 0, q = 0; q < l.length; ++q) {
                    if (l[q] === a) {
                        k = q - p;
                        break
                    }
                    e(l[q]) && ++p
                }
                if (k === null) return null;
                f.unshift(k);
                a = g
            }
            return f
        } catch (y) {
            return null
        }
    }

    function nk() {
        return mk(w, w.top || w, function(a) {
            try {
                return a.parent
            } catch (b) {
                return null
            }
        }, function(a) {
            return a.frames
        }, function() {
            return !1
        })
    }

    function ok(a) {
        return mk(a, document.documentElement, function(b) {
            return b.parentElement
        }, function(b) {
            return b.children
        }, function(b) {
            return b.nodeType === 8
        })
    };
    var pk = function(a) {
            if (a.X && typeof a.X == "function") return a.X();
            if (typeof Map !== "undefined" && a instanceof Map || typeof Set !== "undefined" && a instanceof Set) return Array.from(a.values());
            if (typeof a === "string") return a.split("");
            if (La(a)) {
                for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
                return b
            }
            b = [];
            c = 0;
            for (d in a) b[c++] = a[d];
            return b
        },
        qk = function(a) {
            if (a.hb && typeof a.hb == "function") return a.hb();
            if (!a.X || typeof a.X != "function") {
                if (typeof Map !== "undefined" && a instanceof Map) return Array.from(a.keys());
                if (!(typeof Set !== "undefined" && a instanceof Set)) {
                    if (La(a) || typeof a === "string") {
                        var b = [];
                        a = a.length;
                        for (var c = 0; c < a; c++) b.push(c);
                        return b
                    }
                    b = [];
                    c = 0;
                    for (var d in a) b[c++] = d;
                    return b
                }
            }
        },
        rk = function(a, b, c) {
            if (a.forEach && typeof a.forEach == "function") a.forEach(b, c);
            else if (La(a) || typeof a === "string") Array.prototype.forEach.call(a, b, c);
            else
                for (var d = qk(a), e = pk(a), f = e.length, g = 0; g < f; g++) b.call(c, e[g], d && d[g], a)
        };

    function sk(a) {
        this.F = this.Z = this.R = "";
        this.da = null;
        this.V = this.J = "";
        this.C = this.Nc = !1;
        if (a instanceof sk) {
            this.C = a.C;
            tk(this, a.R);
            var b = a.Z;
            uk(this);
            this.Z = b;
            b = a.F;
            uk(this);
            this.F = b;
            vk(this, a.da);
            b = a.J;
            uk(this);
            this.J = b;
            wk(this, a.A.clone());
            a = a.V;
            uk(this);
            this.V = a
        } else a && (b = String(a).match(fi)) ? (this.C = !1, tk(this, b[1] || "", !0), a = b[2] || "", uk(this), this.Z = xk(a), a = b[3] || "", uk(this), this.F = xk(a, !0), vk(this, b[4]), a = b[5] || "", uk(this), this.J = xk(a, !0), wk(this, b[6] || "", !0), a = b[7] || "", uk(this), this.V = xk(a)) :
            (this.C = !1, this.A = new yk(null, this.C))
    }
    sk.prototype.toString = function() {
        var a = [],
            b = this.R;
        b && a.push(zk(b, Ak, !0), ":");
        var c = this.F;
        if (c || b == "file") a.push("//"), (b = this.Z) && a.push(zk(b, Ak, !0), "@"), a.push(encodeURIComponent(String(c)).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.da, c != null && a.push(":", String(c));
        if (c = this.J) this.F && c.charAt(0) != "/" && a.push("/"), a.push(zk(c, c.charAt(0) == "/" ? Bk : Ck, !0));
        (c = this.A.toString()) && a.push("?", c);
        (c = this.V) && a.push("#", zk(c, Dk));
        return a.join("")
    };
    sk.prototype.resolve = function(a) {
        var b = this.clone(),
            c = !!a.R;
        c ? tk(b, a.R) : c = !!a.Z;
        if (c) {
            var d = a.Z;
            uk(b);
            b.Z = d
        } else c = !!a.F;
        c ? (d = a.F, uk(b), b.F = d) : c = a.da != null;
        d = a.J;
        if (c) vk(b, a.da);
        else if (c = !!a.J) {
            if (d.charAt(0) != "/")
                if (this.F && !this.J) d = "/" + d;
                else {
                    var e = b.J.lastIndexOf("/");
                    e != -1 && (d = b.J.slice(0, e + 1) + d)
                }
            e = d;
            if (e == ".." || e == ".") d = "";
            else if (e.indexOf("./") != -1 || e.indexOf("/.") != -1) {
                d = e.lastIndexOf("/", 0) == 0;
                e = e.split("/");
                for (var f = [], g = 0; g < e.length;) {
                    var h = e[g++];
                    h == "." ? d && g == e.length && f.push("") : h ==
                        ".." ? ((f.length > 1 || f.length == 1 && f[0] != "") && f.pop(), d && g == e.length && f.push("")) : (f.push(h), d = !0)
                }
                d = f.join("/")
            } else d = e
        }
        c ? (uk(b), b.J = d) : c = a.A.toString() !== "";
        c ? wk(b, a.A.clone()) : c = !!a.V;
        c && (a = a.V, uk(b), b.V = a);
        return b
    };
    sk.prototype.clone = function() {
        return new sk(this)
    };
    var tk = function(a, b, c) {
            uk(a);
            a.R = c ? xk(b, !0) : b;
            a.R && (a.R = a.R.replace(/:$/, ""))
        },
        vk = function(a, b) {
            uk(a);
            if (b) {
                b = Number(b);
                if (isNaN(b) || b < 0) throw Error("Bad port number " + b);
                a.da = b
            } else a.da = null
        },
        wk = function(a, b, c) {
            uk(a);
            b instanceof yk ? (a.A = b, a.A.wb(a.C)) : (c || (b = zk(b, Ek)), a.A = new yk(b, a.C))
        };
    sk.prototype.getQuery = function() {
        return this.A.toString()
    };
    sk.prototype.removeParameter = function(a) {
        uk(this);
        this.A.remove(a);
        return this
    };
    var uk = function(a) {
        if (a.Nc) throw Error("Tried to modify a read-only Uri");
    };
    sk.prototype.wb = function(a) {
        this.C = a;
        this.A && this.A.wb(a)
    };
    var xk = function(a, b) {
            return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) : ""
        },
        zk = function(a, b, c) {
            return typeof a === "string" ? (a = encodeURI(a).replace(b, Fk), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null
        },
        Fk = function(a) {
            a = a.charCodeAt(0);
            return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
        },
        Ak = /[#\/\?@]/g,
        Ck = /[#\?:]/g,
        Bk = /[#\?]/g,
        Ek = /[#\?@]/g,
        Dk = /#/g,
        yk = function(a, b) {
            this.o = this.j = null;
            this.u = a || null;
            this.C = !!b
        },
        Gk = function(a) {
            a.j || (a.j = new Map, a.o = 0, a.u && gi(a.u, function(b, c) {
                a.add(decodeURIComponent(b.replace(/\+/g,
                    " ")), c)
            }))
        };
    yk.prototype.add = function(a, b) {
        Gk(this);
        this.u = null;
        a = Hk(this, a);
        var c = this.j.get(a);
        c || this.j.set(a, c = []);
        c.push(b);
        this.o = Sa(this.o) + 1;
        return this
    };
    yk.prototype.remove = function(a) {
        Gk(this);
        a = Hk(this, a);
        return this.j.has(a) ? (this.u = null, this.o = Sa(this.o) - this.j.get(a).length, this.j.delete(a)) : !1
    };
    yk.prototype.clear = function() {
        this.j = this.u = null;
        this.o = 0
    };
    yk.prototype.isEmpty = function() {
        Gk(this);
        return this.o == 0
    };
    var Ik = function(a, b) {
        Gk(a);
        b = Hk(a, b);
        return a.j.has(b)
    };
    m = yk.prototype;
    m.forEach = function(a, b) {
        Gk(this);
        this.j.forEach(function(c, d) {
            c.forEach(function(e) {
                a.call(b, e, d, this)
            }, this)
        }, this)
    };
    m.hb = function() {
        Gk(this);
        for (var a = Array.from(this.j.values()), b = Array.from(this.j.keys()), c = [], d = 0; d < b.length; d++)
            for (var e = a[d], f = 0; f < e.length; f++) c.push(b[d]);
        return c
    };
    m.X = function(a) {
        Gk(this);
        var b = [];
        if (typeof a === "string") Ik(this, a) && (b = b.concat(this.j.get(Hk(this, a))));
        else {
            a = Array.from(this.j.values());
            for (var c = 0; c < a.length; c++) b = b.concat(a[c])
        }
        return b
    };
    m.set = function(a, b) {
        Gk(this);
        this.u = null;
        a = Hk(this, a);
        Ik(this, a) && (this.o = Sa(this.o) - this.j.get(a).length);
        this.j.set(a, [b]);
        this.o = Sa(this.o) + 1;
        return this
    };
    m.get = function(a, b) {
        if (!a) return b;
        a = this.X(a);
        return a.length > 0 ? String(a[0]) : b
    };
    m.toString = function() {
        if (this.u) return this.u;
        if (!this.j) return "";
        for (var a = [], b = Array.from(this.j.keys()), c = 0; c < b.length; c++) {
            var d = b[c],
                e = encodeURIComponent(String(d));
            d = this.X(d);
            for (var f = 0; f < d.length; f++) {
                var g = e;
                d[f] !== "" && (g += "=" + encodeURIComponent(String(d[f])));
                a.push(g)
            }
        }
        return this.u = a.join("&")
    };
    m.clone = function() {
        var a = new yk;
        a.u = this.u;
        this.j && (a.j = new Map(this.j), a.o = this.o);
        return a
    };
    var Hk = function(a, b) {
        b = String(b);
        a.C && (b = b.toLowerCase());
        return b
    };
    yk.prototype.wb = function(a) {
        a && !this.C && (Gk(this), this.u = null, this.j.forEach(function(b, c) {
            var d = c.toLowerCase();
            c != d && (this.remove(c), this.remove(d), b.length > 0 && (this.u = null, this.j.set(Hk(this, d), mb(b)), this.o = Sa(this.o) + b.length))
        }, this));
        this.C = a
    };
    yk.prototype.extend = function(a) {
        for (var b = 0; b < arguments.length; b++) rk(arguments[b], function(c, d) {
            this.add(d, c)
        }, this)
    };
    var Jk = pa(["https://pagead2.googlesyndication.com/", "/", ""]),
        Kk = pa(["https://pagead2.googlesyndication-cn.com/", "/", ""]),
        Lk = pa(["https://ad.doubleclick.net/", "/", ""]),
        Mk = pa(["https://googleads.g.doubleclick.net/", "/", ""]),
        Nk = function(a) {
            this.ec = !1;
            this.ma = "dbm";
            this.na = "ad";
            this.ka = new sk(a)
        },
        Y = function(a, b, c, d) {
            d = d === void 0 ? !1 : d;
            (b.length + encodeURIComponent(c).length + 1 + a.ka.toString().length < (Number(Mg()) || 16384) || d) && a.ka.A.set(b, c)
        },
        Pk = function(a) {
            var b = Ok(),
                c, d;
            b && (b.responseEnd && b.startTime &&
                (c = b.responseEnd - b.startTime), b.transferSize !== void 0 && (d = b.transferSize === 0));
            var e;
            if (b = (e = window.performance) == null ? 0 : e.getEntriesByName) {
                var f;
                (f = window.performance) != null && f.measure ? (window.performance.measure("dm", "db"), b = !0) : b = !1
            }
            if (b && (e = window.performance.getEntriesByName("dm"), e.length > 0 && e[0].entryType === "measure")) var g = e[0].duration;
            c && Y(a, "idt", Math.round(c).toString());
            d !== void 0 && Y(a, "cac", d ? "1" : "0");
            g && Y(a, "dtd", Math.round(g).toString())
        },
        Qk = function(a) {
            var b = new Map;
            a.ka.A.forEach(function(c,
                d) {
                return b.set(d, c)
            });
            return a.ka.F === "pagead2.googlesyndication.com" ? ug(tg(Jk, a.ma, a.na), b) : a.ka.F === "pagead2.googlesyndication-cn.com" ? ug(tg(Kk, a.ma, a.na), b) : a.ec ? ug(tg(Lk, a.ma, a.na), b) : ug(tg(Mk, a.ma, a.na), b)
        };
    var Rk = RegExp("((.*\\.doubleclick\\.net/(dbm/ad|pagead/adfetch))|(pagead2\\.googlesyndication(-cn)?\\.com/(dbm/(ad|clk|vast)|pagead/adfetch))).*dv3_ver=.*");

    function Ok() {
        var a;
        if ((a = window.performance) != null && a.getEntriesByType && (a = window.performance.getEntriesByType("resource").filter(function(b) {
                return b.name.indexOf("pagead/js/dv3.js") >= 0
            }), a.length !== 0)) return a[0]
    }

    function Sk() {
        var a;
        (a = window.performance) == null || a.mark("db")
    }

    function Tk() {
        var a;
        (a = window.performance) == null || a.clearMarks()
    }

    function Uk() {
        var a;
        return (a = window.performance) != null && a.getEntriesByType ? window.performance.getEntriesByType("resource").filter(function(b) {
            return Rk.test(b.name)
        }).length > 0 : !0
    };
    var Vk = pa(["https://pagead2.googlesyndication.com/pagead/managed/js/activeview/current/ufs_web_display.js?cache=r20110914"]),
        Wk = !1,
        Xk = function(a) {
            this.T = a;
            this.H = null;
            this.Aa = !1;
            this.Ba = 0;
            this.Cb = !1;
            this.nb = a.getAttribute("data-dv3-creative-fetch");
            this.l = new Nk(this.nb);
            this.Pa = a.getAttribute("data-dv3-render-mode").toLowerCase();
            this.Hb = a.getAttribute("data-dv3-width");
            this.Gb = a.getAttribute("data-dv3-height");
            var b = a.getAttribute("data-dv3-meta-data");
            this.B = of (b);
            b = nk() || ["?"];
            a = ok(a) || ["?"];
            this.slotId = wj(b.join(",") + ":" + a.join(","));
            Wk = !1
        },
        dl = function(a) {
            if (a.H && a.Pa === "script") {
                var b = a.T.parentElement;
                if (b != null && b.classList.contains("GoogleActiveViewClass")) {
                    var c = b.ownerDocument,
                        d;
                    b = (d = c.head) != null ? d : c.documentElement;
                    b != null && (d = (c ? new Cg(Bg(c)) : Pa || (Pa = new Cg)).createElement("LINK"), d.as = "script", d.setAttribute("fetchpriority", "high"), (c = Zf(c)) && d.setAttribute("nonce", c), d.href = Ef(Yk).toString(), d.rel = "preload", b.appendChild(d))
                }
            }(b = a.H) || (b = Q(a.B, 6), b = !!cf(a.B, 7) && (b === 2 || b ===
                3));
            b && Zk(a);
            if (a.H) w.setTimeout($k(a, "f"), 1E3);
            else if (b = Qk(a.l), a.Pa === "script")
                if (a.Aa) delete w.dv3Utw, al(a, b);
                else try {
                    c = document;
                    var e = bl(a, b);
                    c.write(Yf(e))
                } catch (f) {
                    cl(a), Wk = !0
                } else e = Ag(document, "IFRAME"), $f(e, b), e.allow = "attribution-reporting", e.width = a.Hb, e.height = a.Gb, e.title = "Advertisement", e.style = "border: 0", e.scrolling = "no", document.body.appendChild(e)
        },
        bl = function(a, b) {
            a = {
                attributionSrc: a.ab
            };
            b = Ef(b).toString();
            b = '<script src="' + hg(b) + '"';
            if (a == null ? 0 : a.async) b += " async";
            (a == null ?
                void 0 : a.attributionSrc) !== void 0 && (b += ' attributionsrc="' + hg(a.attributionSrc) + '"');
            if (a == null ? 0 : a.Ec) b += ' custom-element="' + hg(a.Ec) + '"';
            if (a == null ? 0 : a.defer) b += " defer";
            if (a == null ? 0 : a.id) b += ' id="' + hg(a.id) + '"';
            if (a == null ? 0 : a.nonce) b += ' nonce="' + hg(a.nonce) + '"';
            if (a == null ? 0 : a.type) b += ' type="' + hg(a.type) + '"';
            if (a == null ? 0 : a.Dc) b += ' crossorigin="' + hg(a.Dc) + '"';
            a = Xf(b + ">\x3c/script>").toString().replace(/&amp;/g, "&");
            return Xf(a)
        },
        al = function(a, b) {
            var c = Ag(document, "SCRIPT");
            c.async = !0;
            c.setAttribute("fetchpriority",
                "high");
            $f(c, b);
            a.ab !== void 0 && c.setAttribute("attributionsrc", a.ab);
            (a.T.parentElement || document.body).appendChild(c)
        },
        $k = function(a, b) {
            return function(c) {
                if (!a.Cb)
                    if (a.Cb = !0, a.H) {
                        var d = a.l;
                        Pk(d);
                        Y(d, "cbvp", "2", !0);
                        Y(d, "dett", c || 0);
                        Y(d, "clm", b);
                        c = Qk(d);
                        el(a.T.parentElement);
                        al(a, c);
                        Tk()
                    } else Ig(w, ji(cf(a.B, 7), "vt", 11, "dett", c || 0, "clm", b))
            }
        },
        Zk = function(a) {
            var b = a.T.parentElement || document.body,
                c = Gh();
            a.H && delete w.dv3Utw;
            if ((a.H ? a.Ba : Q(a.B, 6)) === 3) Mh(b, $k(a, "dyn"), c);
            else {
                Lh(b, $k(a, "i"), c);
                document.addEventListener("DOMContentLoaded",
                    function() {
                        Lh(b, $k(a, "d"), c)
                    });
                var d = new MutationObserver(function() {
                    Lh(b, $k(a, "m"), c);
                    d.disconnect()
                });
                d.observe(b, {
                    childList: !0
                })
            }
        },
        fl = function() {
            var a = W(Dj).ra(Ah.bb, Ah.defaultValue);
            sf(function(b) {
                b = b.document;
                if (a.length && b.head) {
                    var c = u(a),
                        d = c.next();
                    try {
                        for (; !d.done; d = c.next()) {
                            var e = d.value;
                            if (e && b.head) {
                                var f = wg("META");
                                b.head.appendChild(f);
                                f.httpEquiv = "origin-trial";
                                f.content = e
                            }
                        }
                    } finally {
                        v(c, d)
                    }
                }
                return !1
            }, !1, !1)
        },
        cl = function(a) {
            if (!Wk) {
                Wk = !0;
                Y(a.l, "fbi", "1");
                var b = Qk(a.l),
                    c = a.Hb,
                    d = a.Gb,
                    e = Ag(document, "IFRAME");
                e.setAttribute("frameborder", "0");
                e.setAttribute("scrolling", "no");
                e.setAttribute("marginheight", "0");
                e.setAttribute("marginwidth", "0");
                e.setAttribute("topmargin", "0");
                e.setAttribute("leftmargin", "0");
                e.setAttribute("allowtransparency", "true");
                e.setAttribute("width", c);
                e.setAttribute("height", d);
                e.title = "Advertisement";
                Ze(a.B, 2) === 77 && (e.style.display = "none");
                a.T.parentNode ? a.T.parentNode.insertBefore(e, a.T.nextSibling) : document.body.appendChild(e);
                a = pg("body", bl(a, b));
                a = ig([Xf("<!DOCTYPE html>"),
                    pg("html", a)
                ]);
                e = e.contentWindow ? e.contentWindow.document : e.contentDocument;
                if (!e) throw Error("Can not create iFrame.");
                e.open("text/html", "replace");
                e.write(Yf(a));
                e.close()
            }
        },
        gl = function(a) {
            var b;
            sf(function(d) {
                d = d.google_tag_data;
                if (d != null && d.uach) {
                    d = d.uach;
                    var e = Object.assign({}, d);
                    d.fullVersionList && (e.fullVersionList = d.fullVersionList.slice(0));
                    d = e
                } else d = null;
                d && (b = d);
                return !!b
            });
            if (b) Y(a.l, "uach", ub(kf(ek(b))));
            else {
                var c = dk();
                c && c.then(function(d) {
                    Y(a.l, "uach", ub(kf(ek(d))))
                })
            }
        };

    function el(a) {
        a != null && (a.onCreativeLoad = function(b) {
            if (b != null) {
                var c = {
                    type: "creativeLoad"
                };
                try {
                    b(1, c)
                } catch (d) {}
            }
        })
    }
    var Yk = tg(Vk);
    var ki = new function() {
            var a = !0;
            a = a === void 0 ? !1 : a;
            this.domain = "pagead2.googlesyndication.com";
            this.path = "/pagead/gen_204?id=";
            this.Fc = .1;
            this.zc = a;
            this.protocol = "https:";
            this.ed = Math.random()
        },
        oi = new li;
    var hl = function(a) {
        V.call(this, a)
    };
    r(hl, V);
    var il = mf(hl);
    hl.i = "tagging.dv3.proto.Dv3ServeTimeConfig";
    var jl = typeof stc === "undefined" ? void 0 : stc;

    function kl() {
        var a = 11;
        a = a === void 0 ? 0 : a;
        tc(jl, Hc);
        var b = il(jl);
        var c = Qe(b, sj, 1);
        if (c) {
            var d = {},
                e = {};
            Mj({
                Kc: c,
                D: (e[3] = {}, e[4] = {}, e[5] = (d[9] = function() {
                    return cf(b, 2)
                }, d), e),
                Bc: a
            });
            (a = cf(b, 2)) && ej(Number(a));
            a = {};
            fj((a[0] = xj(), a))
        }
    };
    var ll = String(Math.floor(Math.random() * 1E13));

    function ml(a, b, c) {
        var d = d === void 0 ? 1 : d;
        var e = new Wh(15E3);
        bi(e, "msg", a);
        c && bi(e, "fet", c);
        bi(e, "ord", ll);
        bi(e, "version", "m202611090101");
        b && (a = b.B, bi(e, "ct", Ze(a, 2)), bi(e, "x", Ze(a, 1)), Xe(a) != null && bi(e, "cor", df(a)));
        qi(ki, "dv3-render", e, !0, d)
    }

    function nl(a) {
        a.Pa === "script" && (ml("tler", a), a.H || a.Aa || Uk() || (ml("tlmf", a, Qk(a.l).toString()), cl(a)))
    }

    function ol() {
        a: {
            var a = u(document.getElementsByTagName("SCRIPT")),
                b = a.next();
            try {
                for (; !b.done; b = a.next()) {
                    var c = b.value;
                    if (c) {
                        var d = c;
                        if (d.getAttribute("data-dv3-creative-fetch") && d.getAttribute("data-dv3-render-mode") && d.getAttribute("data-dv3-width") && d.getAttribute("data-dv3-height") && d.getAttribute("data-dv3-done") !== "true") {
                            var e = d;
                            break a
                        }
                    }
                }
            } finally {
                v(a, b)
            }
            e = null
        }
        if (!e) {
            var f = Error;
            e = document.currentScript || document.scripts[document.scripts.length - 1];
            x(e !== null, "goog.dom.getOuterHtml expects a non-null value for element");
            "outerHTML" in e ? e = e.outerHTML : (a = Bg(e), a = Ag(a, "DIV"), a.appendChild(e.cloneNode(!0)), e = a.innerHTML);
            throw f("NoDv3Node:" + e);
        }
        a = new Xk(e);ml("tlbr", a);gl(a);
        if (td(ue(a.B, 5)) != null && Ze(a.B, 2) === 77) switch (a.Ba = Q(a.B, 5), a.Ba) {
            case 2:
            case 3:
                a.H = !0;
                a.Aa = !0;
                break;
            case 4:
                a.Aa = !0
        }
        c = [];
        switch (a.Ba) {
            case 1:
                c.push(95403801);
                break;
            case 2:
                c.push(95403802);
                break;
            case 3:
                c.push(95403803);
                break;
            case 4:
                c.push(95403804)
        }
        b = a.l;d = W(dj).W();c = c === void 0 ? [] : c;
        if (d.length > 0 || c.length > 0) c = [].concat(na(d), na(c)),
        Y(b, "dc_eid",
            c.join(","));Y(a.l, "dv3_ver", "m202611090101");W(Dj).oa(Bh.bb, Bh.defaultValue) && (fl(), gj("attribution-reporting") && Y(a.l, "nel", "1"), a.nb.startsWith("https://ad.doubleclick.net") && a.Pa === "script" && (a.ab = "", a.l.ec = !0));RegExp(".*.doubleclick.net/pagead/adfetch").test(a.nb) && (b = a.l, b.ma = "pagead", b.na = "adfetch");b = a.l;c = Qh();c = c.Va ? c.Va.url : c.ya.url;d = c.indexOf("?");
        (c = d >= 0 ? c.substring(0, d) : c) && Y(b, "rfl", c);typeof document.readyState === "string" && Y(a.l, "ds", document.readyState.charAt(0));b = a.l;c = !rf(w.top);
        Y(b, "xdt", c ? "1" : "0");b = a.l;c = Ze(a.B, 2);Y(b, "ct", c);Y(a.l, "iif", w !== w.parent ? "1" : "0");Xe(a.B) != null && (b = a.l, c = df(a.B), Y(b, "cor", c));Y(a.l, "adk", a.slotId);d = ik(w.googDdmPs);b = null;
        var g = !0;g = g === void 0 ? !1 : g;
        var h = [w.top];c = [];
        for (var k = 0, l; l = h[k++];) {
            g && !rf(l) || c.push(l);
            try {
                if (l.frames)
                    for (var p = 0; p < l.frames.length && h.length < 1024; ++p) h.push(l.frames[p])
            } catch (y) {}
        }
        g = u(c);h = g.next();
        try {
            for (; !h.done; h = g.next()) {
                var q = h.value;
                if (q !== w && (b = ik(q.googDdmPs))) break
            }
        } finally {
            v(g, h)
        }
        if (d) q = d,
        b && (d = new fk(q),
            g = new fk(b), g.timestamp() > d.timestamp() ? lk(g, d) : lk(d, g));
        else if (b) w.googDdmPs = q = {},
        lk(new fk(b), new fk(q));
        else {
            q = "";
            for (d = 0; d < 10; ++d) q += "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ-_.!*'()" [Math.floor(Math.random() * 70)];
            w.googDdmPs = q = {
                corr: q,
                ts: Date.now(),
                aacm: {}
            }
        }
        b || ((b = c[0]) && b !== w ? (b.googDdmPs = b = {}, lk(new fk(q), new fk(b))) : b = q);c = b;b = a.slotId;
        (q = jk(q)) ? (q = gk(q), d = q[b] || 0, q[b] = d + 1, (c = jk(c)) && (gk(c)[b] = q[b]), q = d) : q = 0;q > 0 && Y(a.l, "rc", q);q = a.l;f = f === void 0 ? w : f;f = f.devicePixelRatio;
        f = Gc(f) ? +f.toFixed(3) : null;f !== null && f > 0 && Y(q, "u_sd", f);e.setAttribute("data-dv3-done", "true");
        return a
    }

    function ni(a) {
        a.version = "m202611090101";
        a.sample = "0.1";
        a.experiments = W(dj).W().join(",")
    };
    pi(function() {
        w.dv3_render_state = w.dv3_render_state ? w.dv3_render_state + 1 : 1;
        ml("running");
        Sk();
        kl();
        var a = ol();
        Dg(function() {
            w.setTimeout(function() {
                pi(nl)(a)
            }, 1E3)
        });
        a.H || Pk(a.l);
        dl(a);
        a.H || Tk()
    })();
}).call(this, "[[[[null,null,null,[null,null,null,[\"A3vKT9yxRPjmXN3DpIiz58f5JykcWHjUo\/W7hvmtjgh9jPpQgem9VbADiNovG8NkO6mRmk70Kex8\/KUqAYWVWAEAAACLeyJvcmlnaW4iOiJodHRwczovL2dvb2dsZXN5bmRpY2F0aW9uLmNvbTo0NDMiLCJmZWF0dXJlIjoiUHJpdmFjeVNhbmRib3hBZHNBUElzIiwiZXhwaXJ5IjoxNjk1MTY3OTk5LCJpc1N1YmRvbWFpbiI6dHJ1ZSwiaXNUaGlyZFBhcnR5Ijp0cnVlfQ==\"]],null,6001],[6000,null,null,[1]]],null,null,null,[null,1000,1,1000]]]");
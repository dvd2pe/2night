(function() {
    'use strict';
    /* 
     
     Copyright The Closure Library Authors. 
     SPDX-License-Identifier: Apache-2.0 
    */
    var h = this || self;

    function k(a) {
        k[" "](a);
        return a
    }
    k[" "] = function() {};

    function m(a) {
        for (var b = h, c = 0; b && c++ < 40;) {
            var d = !1;
            try {
                var e;
                if (e = !!b && b.location.href != null) b: {
                    try {
                        k(b.foo);
                        e = !0;
                        break b
                    } catch (f) {}
                    e = !1
                }
                d = e
            } catch {
                d = !1
            }
            if (d && a(b)) break;
            a: {
                try {
                    let f = b.parent;
                    if (f && f !== b) {
                        b = f;
                        break a
                    }
                } catch {}
                b = null
            }
        }
    };

    function p() {
        return new q(a => a(void 0))
    }

    function r(a, b) {
        if (!a.i)
            if (b instanceof q) b.then(c => {
                r(a, c)
            });
            else {
                a.i = !0;
                a.j = b;
                for (b = 0; b < a.h.length; ++b) t(a, a.h[b]);
                a.h = []
            }
    }

    function t(a, b) {
        a.i ? b(a.j) : a.h.push(b)
    }
    class q {
        constructor(a) {
            this.i = !1;
            this.h = [];
            a(b => {
                r(this, b)
            })
        }
        then(a) {
            return new q(b => {
                t(this, c => {
                    b(a(c))
                })
            })
        }
    };

    function u(a, b) {
        if (a)
            for (let c in a) Object.prototype.hasOwnProperty.call(a, c) && b(a[c], c, a)
    };

    function v(a = document) {
        return a.createElement("img")
    };

    function w(a, b, c = null, d = !1) {
        x(a, b, c, d)
    }

    function x(a, b, c, d) {
        a.google_image_requests || (a.google_image_requests = []);
        var e = v(a.document);
        if (c || d) {
            let f = g => {
                c && c(g);
                if (d) {
                    g = a.google_image_requests;
                    let n = Array.prototype.indexOf.call(g, e, void 0);
                    n >= 0 && Array.prototype.splice.call(g, n, 1)
                }
                typeof e.removeEventListener === "function" && e.removeEventListener("load", f, !1);
                typeof e.removeEventListener === "function" && e.removeEventListener("error", f, !1)
            };
            typeof e.addEventListener === "function" && e.addEventListener("load", f, !1);
            typeof e.addEventListener === "function" &&
                e.addEventListener("error", f, !1)
        }
        e.src = b;
        a.google_image_requests.push(e)
    }

    function y({
        u: a = !1
    } = {}) {
        return a ? "connect.pagead2.googlesyndication.com" : "pagead2.googlesyndication.com"
    }

    function z(a) {
        ({
            C: c = !1,
            u: b = !1
        } = {});
        var b, c, d = `https://${y({u:b})}/pagead/gen_204?id=rhmss`;
        u(a, (e, f) => {
            if (e || e === 0) d += `&${f}=${encodeURIComponent(String(e))}`
        });
        A(d, c)
    }

    function A(a, b = !1) {
        var c = window;
        c.fetch ? c.fetch(a, {
            keepalive: !0,
            credentials: "include",
            redirect: "follow",
            method: "get",
            mode: "no-cors"
        }) : w(c, a, void 0, b)
    };
    var B = {
        A: "app",
        B: "web"
    };

    function C(a) {
        if (!a) throw Error("functionToExecute must not be truthy.");
    };

    function D() {
        return /\d+\.\d+\.\d+(-.*)?/.test("1.6.11-google_20261022")
    }

    function E() {
        var a = ["1", "6", "11"],
            b = ["1", "0", "3"];
        for (let c = 0; c < 3; c++) {
            let d = parseInt(a[c], 10),
                e = parseInt(b[c], 10);
            if (d > e) break;
            else if (d < e) return !1
        }
        return !0
    };

    function F(a) {
        return !!a && a.omid_message_guid !== void 0 && a.omid_message_method !== void 0 && a.omid_message_version !== void 0 && typeof a.omid_message_guid === "string" && typeof a.omid_message_method === "string" && typeof a.omid_message_version === "string" && (a.omid_message_args === void 0 || a.omid_message_args !== void 0)
    }

    function G(a) {
        return new H(a.omid_message_guid, a.omid_message_method, a.omid_message_version, a.omid_message_args)
    }

    function I(a) {
        var b = {
            omid_message_guid: a.i,
            omid_message_method: a.method,
            omid_message_version: a.version
        };
        a.h !== void 0 && (b.omid_message_args = a.h);
        return b
    }
    class H {
        constructor(a, b, c, d) {
            this.i = a;
            this.method = b;
            this.version = c;
            this.h = d
        }
    };
    class J {
        constructor(a) {
            this.i = a
        }
    };

    function K(a, b) {
        try {
            return a.frames && !!a.frames[b]
        } catch (c) {
            return !1
        }
    }

    function L(a) {
        return ["omid_v1_present", "omid_v1_present_web", "omid_v1_present_app"].some(b => K(a, b))
    }

    function M(a) {
        for (let b of Object.values(B))
            if (K(a, {
                    app: "omid_v1_present_app",
                    web: "omid_v1_present_web"
                }[b])) return b;
        return null
    };

    function N(a, b) {
        return a && (a[b] || (a[b] = {}))
    };

    function O() {
        return typeof crypto !== "undefined" && typeof crypto.getRandomValues === "function"
    }

    function P() {
        var a = new Uint8Array(16);
        crypto.getRandomValues(a);
        a[6] = a[6] & 15 | 64;
        a[8] = a[8] & 63 | 128;
        var b = [];
        for (let c = 0; c < 16; c++) b.push(a[c].toString(16).padStart(2, "0"));
        return b[0] + b[1] + b[2] + b[3] + "-" + b[4] + b[5] + "-" + b[6] + b[7] + "-" + b[8] + b[9] + "-" + b[10] + b[11] + b[12] + b[13] + b[14] + b[15]
    }

    function Q() {
        return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, a => {
            var b = Math.random() * 16 | 0;
            return a === "y" ? (b & 3 | 8).toString(16) : b.toString(16)
        })
    };

    function aa(...a) {
        ba(() => {
            throw Error("Could not complete the test successfully - ", ...a);
        }, () => console.error(...a))
    }

    function ba(a, b) {
        typeof jasmine !== "undefined" && jasmine ? a() : typeof console !== "undefined" && console && console.error && b()
    };
    var R = function() {
        if (typeof omidGlobal !== "undefined" && omidGlobal) return omidGlobal;
        if (typeof global !== "undefined" && global) return global;
        if (typeof window !== "undefined" && window) return window;
        if (typeof globalThis !== "undefined" && globalThis) return globalThis;
        var a = Function("return this")();
        if (a) return a;
        throw Error("Could not determine global object context.");
    }();
    class S extends J {
        constructor(a) {
            super(a);
            this.handleExportedMessage = S.prototype.j.bind(this)
        }
        sendMessage(a, b = this.i) {
            if (!b) throw Error("Message destination must be defined at construction time or when sending the message.");
            b.handleExportedMessage(I(a), this)
        }
        j(a, b) {
            F(a) && this.h && this.h(G(a), b)
        }
    };

    function T(a) {
        return a != null && typeof a.top !== "undefined" && a.top != null
    }

    function ca(a) {
        if (a === R) return !1;
        try {
            if (typeof a.location.hostname === "undefined") return !0
        } catch (b) {
            return !0
        }
        return !1
    }

    function U() {
        var a;
        typeof a === "undefined" && typeof window !== "undefined" && window && (a = window);
        return T(a) ? a : R
    };
    class da extends J {
        constructor(a, b = R) {
            super(b);
            a.addEventListener("message", c => {
                if (typeof c.data === "object") {
                    var d = c.data;
                    F(d) && c.source && this.h && this.h(G(d), c.source)
                }
            })
        }
        sendMessage(a, b = this.i) {
            if (!b) throw Error("Message destination must be defined at construction time or when sending the message.");
            b.postMessage(I(a), "*")
        }
    };
    var ea = ["omid", "v1_VerificationServiceCommunication"],
        fa = ["omidVerificationProperties", "serviceWindow"];

    function V(a, b) {
        return b.reduce((c, d) => c && c[d], a)
    };

    function W(a, b, c, ...d) {
        if (a.i) {
            var e = O() ? P() : Q();
            c && (a.j[e] = c);
            b = "VerificationService." + b;
            d = D() && E() ? d : JSON.stringify(d);
            a.i.sendMessage(new H(e, b, "1.6.11-google_20261022", d))
        }
    }
    class X {
        constructor(a) {
            if (!a) {
                a = U();
                var b = [],
                    c = V(a, fa);
                c && b.push(c);
                b.push(T(a) ? a.top : R);
                a: {
                    for (let e of b) {
                        b: {
                            b = a;c = L;
                            if (!ca(e)) try {
                                let f = V(e, ea);
                                if (f) {
                                    var d = new S(f);
                                    break b
                                }
                            } catch (f) {}
                            d = c(e) ? new da(b, e) : null
                        }
                        if (b = d) {
                            a = b;
                            break a
                        }
                    }
                    a = null
                }
            }
            if (this.i = a) this.i.h = this.l.bind(this);
            else if (d = (d = R.omid3p) && typeof d.registerSessionObserver === "function" && typeof d.addEventListener === "function" ? d : null) this.omid3p = d;
            this.j = {};
            (this.h = (d = R.omidVerificationProperties) ? d.injectionId : void 0) || (O() ? P() : Q())
        }
        registerSessionObserver(a,
            b) {
            C(a);
            this.omid3p ? this.omid3p.registerSessionObserver(a, b, this.h) : W(this, "addSessionListener", a, b, this.h)
        }
        addEventListener(a, b) {
            if (!a) throw Error("Value for eventType is undefined, null or blank.");
            if (typeof a !== "string" && !(a instanceof String)) throw Error("Value for eventType is not a string.");
            if (a.trim() === "") throw Error("Value for eventType is empty string.");
            C(b);
            this.omid3p ? this.omid3p.addEventListener(a, b, this.h) : W(this, "addEventListener", b, a, this.h)
        }
        l(a) {
            var b = a.method,
                c = a.i;
            a = a.h;
            if (b ===
                "response" && this.j[c]) {
                var d = D() && E() ? a ? a : [] : a && typeof a === "string" ? JSON.parse(a) : [];
                this.j[c].apply(this, d)
            }
            b === "error" && window.console && aa(a)
        }
    }(function(a, b, c = typeof omidExports === "undefined" ? null : omidExports) {
        c && (a = a.split("."), a.slice(0, a.length - 1).reduce(N, c)[a[a.length - 1]] = b)
    })("OmidVerificationClient", X);

    function ha() {
        var a = null;
        m(b => (b = b.mraid) && b.IS_GMA_SDK ? (a = b, !0) : !1);
        return a
    }

    function ia() {
        return new q(a => {
            h.document.readyState && h.document.readyState === "complete" ? a() : h.addEventListener("load", a)
        })
    }

    function ja() {
        return new q(a => {
            var b = ha();
            b && (b.getState() === "loading" ? b.addEventListener("ready", () => {
                a(b)
            }) : a(b))
        })
    }

    function ka(a, b = null) {
        b = new la({
            timeout: b
        });
        b.i || ma(b);
        b.i.then(a)
    }

    function na() {
        return new q(a => {
            ia().then(() => {
                ja().then(b => {
                    var c = (d, e) => {
                        e.width > 0 && e.height > 0 && (a(), b.removeEventListener("exposureChange", c))
                    };
                    b.addEventListener("exposureChange", c)
                })
            })
        })
    }

    function ma(a) {
        a.m ? (a.i = new q(b => {
            var c = new q(e => {
                    var f = !1,
                        g, n = (new Date).getTime();
                    a.l.registerSessionObserver(l => {
                        l.type === "sessionStart" && (g && h.clearTimeout(g), f ? (f = !1, l = (new Date).getTime() - n, a.o || (a.o = !0, z({
                            te: l,
                            to: a.j
                        }))) : (l = l.data, e(l.context.environment == "app"), l.context.omidNativeInfo && (a.h.sdk = l.context.omidNativeInfo.partnerName)))
                    });
                    a.j != null && (g = h.setTimeout(() => {
                        f = !0;
                        e(!1)
                    }, a.j))
                }),
                d = new q(e => {
                    a.l.addEventListener("geometryChange", f => {
                        f = f.data;
                        var g = f.adView.reasons;
                        g && g.indexOf("hidden") !=
                            -1 || (f = f.adView, (f = f.onScreenContainerGeometry || f.onScreenGeometry) && f.width && f.height && e())
                    })
                });
            c.then(e => {
                e ? (d.then(() => {
                    a.h.src = 1;
                    b(a.h)
                }), na().then(() => {
                    a.h.src = 2;
                    b(a.h)
                })) : b()
            })
        }), a.i.then(() => {
            a.m = !1
        })) : a.i = p()
    }
    var la = class {
        constructor(a = {}) {
            var b = this.l = a.client ? ? new X,
                c = U();
            var d = (d = R.omidVerificationProperties) && d.injectionSource ? d.injectionSource : void 0;
            this.v = (d || M(c) || M(T(c) ? c.top : R)) !== "web" || b.h ? !(!b.i && !b.omid3p) : !1;
            this.i = null;
            this.m = this.v;
            this.h = {};
            this.j = a.timeout ? ? null;
            this.o = !1
        }
    };
    var Y = function(a, b = null) {
            return b && b.getAttribute("data-jc") === String(a) ? b : document.querySelector(`[data-jc="${a}"]`)
        }(86, document.currentScript),
        Z;
    if (Y) {
        let a = {},
            b = Y.attributes;
        for (let c = b.length - 1; c >= 0; c--) {
            let d = b[c].name;
            d.indexOf("data-jcp-") === 0 && (a[d.substring(9)] = b[c].value)
        }
        Z = a
    } else Z = {};
    window.omrhp = function(a) {
        var b = +a ? .owwt;
        Number.isNaN(b) && (b = null);
        return c => {
            ka(c, b)
        }
    }(Z);
}).call(this);